# Obsidian Interoperability Strategy

**DOC-CN-13** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Obsidian is an optional reader of an export. It is not the database, and nothing here claims a hosted, browser-based Obsidian.

## 1. Export contract

- One folder per project plus a workspace folder; deterministic filenames: title for the owner's notes, ID for managed notes (IR1.1 D-14 carried as convention).
- Flat YAML properties with the stable `id`, type, project, state, dates and source references.
- Wikilinks by ID-resolved title; backlinks follow from links; block anchors for memory records in digest notes.
- Attachments referenced by content hash; originals are not duplicated into the vault unless asked.
- Arabic and mixed-direction text follow IR1.1's right-to-left rules.
- Identical state produces a byte-identical export.

## 2. Getting the export to a device

Download as an archive, or a private export repository cloned by the device (CD-09). Either way the vault is a copy.

## 3. Re-import

Optional and later (CD-12). An edited file is parsed, validated against the schema, compared with the record's current version, and turned into a proposal. Managed properties edited by hand are ignored and reported. Nothing is overwritten without conflict detection and approval.

## 4. If browser-only visual work is wanted

That is a separate web interface and a separate decision, not Obsidian.
