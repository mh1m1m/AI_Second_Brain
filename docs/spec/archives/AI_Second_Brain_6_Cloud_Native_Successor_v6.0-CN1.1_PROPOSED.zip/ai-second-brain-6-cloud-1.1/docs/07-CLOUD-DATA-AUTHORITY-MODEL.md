# Cloud Data Authority Model

**DOC-CN-07** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

One authority and one writer for each class. Everything else is a copy or a projection and loses any conflict.

| Data class | Authority | Writer | Copies and projections | Conflict rule |
|---|---|---|---|---|
| Source code | GitHub repository | Claude Code and the owner | Release archives | Git |
| Specification and ADRs | Platform repository | Owner-approved changes | This package | Git |
| Original documents | Object storage, by content hash | The service | Backups | Immutable; a different hash is a different object |
| Canonical knowledge and memory records | PostgreSQL | The service, on approval | Markdown and JSON export; search index | Database wins; an edited export is a proposal |
| The owner's notes | PostgreSQL (recommended, CD-06) | The service, on the owner's action | Markdown export | As above |
| Project memory, decisions, approvals | PostgreSQL | The service | Export | Database wins |
| Session records | PostgreSQL | The service, from what the session submits | None | Append-only |
| Audit events | PostgreSQL, hash-chained | The service | Chain head in every backup | Never edited |
| Search index | Derived | The service | — | Rebuilt from canonical data |
| Generated Markdown | Derived | The service | Obsidian vault; export repository if used | Regenerated |
| Backups | Second provider | The scheduler | — | Verified against manifest |
| Secrets | Secret manager | The owner | None | Never copied |

Synchronisation is one-way from the authority outward. The only inward path is a validated re-import that produces proposals (CR-21).
