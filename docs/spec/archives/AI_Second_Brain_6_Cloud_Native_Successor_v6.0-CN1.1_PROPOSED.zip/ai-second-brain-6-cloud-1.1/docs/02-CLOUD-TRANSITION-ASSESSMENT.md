# Cloud Transition Assessment

**DOC-CN-02** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Evidence words: **VERIFIED** = read in documentation or measured today; **UNVERIFIED** = not checked in this pass; **PROPOSED** = a recommendation awaiting the owner.

## 1. What changed

The owner confirmed on 2026-11-10 that the product is cloud-native: usable from authorised Claude Code environments with no personal computer online, through a remote MCP connector, with a cloud Python service, managed PostgreSQL as the leading database candidate, private object storage, GitHub for code and versioned artifacts, optional Obsidian. IR1.1 specified the opposite deployment: one Mac, one file database, a local vault, no MCP. Its governance survives. Its deployment decisions do not.

## 2. Impact by area

| Area | IR1.1 | Cloud-native | Consequence |
|---|---|---|---|
| Database | SQLite file, executed schema | Managed database | Schema and probes redone (ADR-004) |
| Search | FTS5 over normalised text | Database full-text search over the same normalised text | Engine swap; Arabic behaviour UNVERIFIED (CV-03) |
| Data security | Public content on a private disk | Private content at a provider | Encryption, residency, access control become mandatory (CD-01) |
| Authentication | None: one OS account | OAuth for the connector, passkey for the owner | New |
| Authorisation | Claude Code rules, sandbox, CLI gate, triggers | Token scope, service gate, constraints | Client-side layers no longer count |
| GitHub | Local Git only | Code and versioned artifacts; references from the service | No credential in the service (CD-08) |
| Execution | CLI on the Mac | Hosted service and worker | Operations become a standing duty |
| Session capture | Not in scope | Summaries; optional events | Not universal across environments |
| Memory | Records, revisions, evidence | Same, plus sessions and project scope | Extended (ADR-020) |
| Obsidian | Live local vault | Export, optional re-import | No live sync at first |
| Backups | External disk | Provider backups plus independent encrypted export | Redesigned (CD-10) |
| Recovery | Restore-test before ingestion | Same rule | Preserved |
| Cost | None recurring | Recurring | Ceiling and alarm (CD-03) |
| Lock-in | None | Provider-shaped | Export and exit drill (CR-15) |
| ADRs | 20 proposed | 10 amended, 1 deferred, 4 retained, 5 superseded | ADR-TRANSITION-MATRIX |
| Requirements | 100 | 46 preserved, 54 modified, 48 new | CLOUD-REQUIREMENTS-COVERAGE-MATRIX |
| Phases | 0 to 10, Mac verification first | Ten separations, cloud verification first | CLOUD-IMPLEMENTATION-ROADMAP |
| Operations | Owner's machine | A public service to patch, monitor and rotate keys for | Largest new burden |

## 3. Options compared

| Option | What it is | Meets the requirement | Assessment |
|---|---|---|---|
| O1 | IR1.1 as specified, local | No | Excluded by the confirmed requirement |
| O2 | GitHub-native: knowledge as files in a private repository, an index built in each session | Partly | Cheapest and simplest to host, but no transactions across records, approvals not bound to state, weak for originals. Excluded by the owner's rule that GitHub is not the live database |
| O3 | Hosted Python service, managed PostgreSQL, object storage, one remote MCP server | Yes | **Recommended.** The owner's leading candidate; widest provider choice; most to operate |
| O4 | As O3 with a hosted SQLite-compatible database | Yes | Keeps most of IR1.1's executed schema; fewer providers and weaker tooling. The fallback if CV-03 goes badly for PostgreSQL |

## 4. Findings of this assessment

1. **Approval must not be a connector tool.** If the token that proposes can also approve, a manipulated session can approve its own proposal. Approval belongs outside the session (CD-04).
2. **The server should call no model.** Session summaries and proposals are written by Claude in the session and submitted as data. ADR-001 is retained, which keeps cost and attack surface down.
3. **The service does not need GitHub credentials.** Claude Code already works with repositories. The service stores references (CD-08).
4. **'Public information only' no longer describes the content.** Project knowledge, session summaries and code references are private. IR1.1 named a change of classification as the trigger for mandatory encryption and stronger controls (CD-01).
5. **The repository picture is incomplete.** One session listed five repositories, all public, none for this project. A session lists only the repositories its connection was granted, so this says nothing about private repositories or about the account as a whole. No conclusion is drawn; a full read-only inventory is CV-15.
6. **Client-side protections are gone.** IR1.1 relied on a sandbox and permission rules in one workspace. Sessions that use the brain will run in other projects, with web access and other tools. Everything the connector receives is untrusted, and anything it returns can leave through the session's other tools.
7. **A project can shadow the connector.** Claude Code resolves a server name defined in several places in the order local, project, user, plugin, claude.ai connector. A repository that defines a server with the connector's name would be used instead, after an approval prompt in interactive sessions. It could not read the brain, but it could feed false context and receive what the session submits (CR-22, CV-06).
8. **Automatic session capture is not universal.** Hooks exist for the end of a turn and of a session and can call an HTTP endpoint or an MCP tool, but cloud sessions do not read a user's own settings, and the session-end hook has a short time budget. Explicit closing with a summary works wherever tools work (CD-07).
9. **PostgreSQL's Arabic behaviour is unmeasured.** IR1.1's normalisation and stemming are in the application and carry over. How the PostgreSQL tokenizer treats the result has not been run (CV-03).
10. **Recovery has a price.** On the one provider checked, the free plan pauses a project after a week without activity and has no automatic backups, and point-in-time recovery costs US$100 a month per seven days. An independent export is the affordable route to a daily recovery point.
11. **Skills change sides.** IR1.1 treated personal and synced skills as a risk to switch off. A bootstrap skill that must be present in every environment is exactly such a skill (CD-14).
12. **The plan grew.** V5.0, still a mandatory reference, criticised infrastructure built before a need was shown. Cloud hosting is now a stated need; the dashboard, repository synchronisation, knowledge graph and mobile interface are not yet (CD-16).

## 5. What v6.0-CN1 is and is not

It is a transition assessment and an architecture-level successor: dispositions, boundaries, models, decisions, gates. It is not yet an implementation baseline. IR1.1 had an executed schema, a command specification and 143 designed tests; the successor's database schema, tool schemas, rewritten requirements and test cases are written after the owner's answers, because each depends on CD-02, CD-04, CD-05 or CD-06.
