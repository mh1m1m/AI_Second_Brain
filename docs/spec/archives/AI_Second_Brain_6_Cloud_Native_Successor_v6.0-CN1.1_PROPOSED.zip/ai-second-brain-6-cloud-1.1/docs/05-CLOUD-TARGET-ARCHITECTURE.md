# Cloud Target Architecture

**DOC-CN-05** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

## 1. Components

```
Claude Code session (terminal, desktop, cloud, mobile)
   │  HTTPS, OAuth, grant: scopes (read, propose, originals), projects, class ceiling
   ▼
Remote MCP server ── narrow tools only
   │
Knowledge service (Python) ── policy gate, proposals, audit
   │                    │                      │
Managed PostgreSQL   Object storage         Scheduler
registry, search     immutable originals    backup, verify, expiry
   │                    │
   └── Independent encrypted export ──► second provider

Owner ── passkey ──► Approval surface and authorisation server (own origin; no connector token accepted)
GitHub ── code, protocols, releases; referenced by the service, never written by it
Obsidian ── reads a Markdown export
```

## 2. Responsibilities

| Component | Does | Never does |
|---|---|---|
| Claude Code | All reasoning; writes summaries and proposals; does repository work with its own access | Approves; writes to the database |
| Remote MCP server | Authenticates, checks scope, validates input, limits rate and size, returns evidence | Runs SQL or shell from input; exposes approval; writes to GitHub |
| Knowledge service | Is the only writer: registry, memory lifecycle, proposals, audit chain | Calls a model |
| PostgreSQL | Holds governed state and the search index; enforces constraints | Is reachable from the internet |
| Object storage | Holds originals, attachments, exports, backup staging; private | Holds secrets or public objects |
| Approval page | Shows a proposal's exact change and records the owner's decision | Accepts a connector token |
| Scheduler | Backups, verification, expiry, index maintenance | Runs anything not allowlisted |
| GitHub | Versions code, protocols, ADRs, releases, and exports if the owner asks | Acts as the live database |

## 3. Flows

- **Retrieve.** Session calls search with a query and optional project; the service returns ranked passages with locators, project and state, inside a size budget.
- **Propose.** Session submits a candidate with its evidence; the service validates, de-duplicates, binds it to the versions it depends on, and queues it within the limits of GAP-033.
- **Approve.** The owner opens the approval page, sees the exact change, approves or rejects with a passkey; the service applies it in one transaction and writes the audit event.
- **Ingest a document.** Upload to staging; the worker inspects and extracts in isolation; the original becomes an immutable object, then the rows commit.
- **Close a session.** Session submits summary, artifact references, open issues and next actions; durable knowledge inside it becomes proposals, not facts.
- **Export.** Deterministic Markdown and JSON to object storage, and to a repository only if the owner asks.
- **Back up.** Provider backup daily; independent encrypted export daily; restore-test on a schedule.

## 4. Deliberately absent

A custom chat application; a server-side model; repository writes by the service; third-party MCP servers; vector search before gate RET-G2; a graph database; full transcript storage by default.

## 5. First usable slice

Search and retrieve, propose, approval page, session open and close, backups with a passed restore-test. Everything else waits for use to justify it (CD-16).
