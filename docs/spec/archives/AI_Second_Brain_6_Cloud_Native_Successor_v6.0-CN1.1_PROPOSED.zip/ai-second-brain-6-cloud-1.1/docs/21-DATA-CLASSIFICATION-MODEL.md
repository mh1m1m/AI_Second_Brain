# Data Classification Model

**DOC-CN-21** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Replaces CN1's blanket 'everything is private personal data' and IR1.1's 'public information only' (D-03). Proposed; decided through CD-01. Having a document is not permission to store it: the question for every source is who owns it and what they allow.

## 1. Classes

| Class | Meaning | Examples |
|---|---|---|
| K0 Public | Published, no restriction on use that matters here | Published reports, public documentation, open-source code |
| K1 Personal | The owner's own material | Own notes, own decisions, session summaries of personal projects, own unpublished writing |
| K2 Confidential | The owner's own material whose disclosure would cause harm | Unreleased product designs, business plans, private project code references, anything about identifiable other people |
| K3 Employer- or third-party-owned | Material another party owns or controls, whatever its sensitivity | Workplace documents, client material, licensed content, colleagues' work |
| K4 Restricted | Never stored | Credentials and keys, identity and financial account numbers, health records of others, anything a law, contract or policy forbids placing with a cloud provider |

## 2. Rules per class

| Rule | K0 | K1 | K2 | K3 | K4 |
|---|---|---|---|---|---|
| Ingestion | Allowed | Allowed | Allowed, classified at intake | Refused unless a clearance is recorded for that source: who permitted it, when, under what terms. Recommended: not admitted in the first release | Refused; the attempt is logged without content |
| Access by a connection | Any grant | Any grant | Through a grant that names the project, such as a connection configured in that project's own repository, or under a time-boxed elevation approved outside the session | Only a grant limited to that one project | — |
| Cross-project retrieval | Yes | Yes | Only from projects the grant names | Never | — |
| Promotion to workspace level | By approval | By approval | By approval; keeps class K2 | Not allowed | — |
| Encryption | In transit and at rest | Same | Same, and excerpts only unless the originals scope is granted | Same as K2; storage location recorded per clearance terms | — |
| Retention | Until withdrawn | Until withdrawn | Until withdrawn; review date required | Ends with the clearance; purge on expiry | — |
| Export | Any destination | Owner's devices and private stores | Owner's devices only; not to a repository | Not exported except back to its owner | — |
| Backup | Yes | Yes, encrypted | Yes, encrypted | Yes, encrypted; purge propagates as backups expire | — |
| Sent to the model in a session | Yes | Yes | Yes, when elevated: this is disclosure to the model provider | Only if the clearance allows processing by an AI service | — |

## 3. Mechanics

- Classification sits on sources, artifacts, records and projects. A project has a ceiling; nothing above it can be filed there.
- A record takes the highest class of its evidence (CR-29). A summary of K2 material is K2.
- Unclassified material is treated as K2 until classified (CR-25). The session may suggest a class; the suggestion is part of the proposal the owner approves.
- Raising a class is immediate. Lowering one is a tier 2 action.
- Session-submitted material is unreviewed: it takes the ceiling of its project, is screened for secret-like strings, stays inside its project and is not knowledge until approved (CR-42). It cannot be filed in a project whose clearance rules it has not passed.
- Code references: a locator into a private repository is at least K2 if the repository is; the code itself stays in GitHub.

## 4. What this cannot do

It cannot recognise ownership by itself. The class of a source is a statement by the owner at intake, checked by the owner at approval. A wrong statement is the owner's error, which is why K3 is recommended out of the first release and why K4 lists categories to refuse on sight.
