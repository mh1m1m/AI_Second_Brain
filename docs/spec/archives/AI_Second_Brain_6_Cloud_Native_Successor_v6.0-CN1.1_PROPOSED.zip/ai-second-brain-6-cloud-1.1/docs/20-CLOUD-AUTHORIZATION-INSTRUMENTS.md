# Cloud Authorisation Instruments

**DOC-CN-20** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Both are drafts. Neither is authorised by being written. IR1.1's Instruments A and B concerned a Mac and are historical.

## Cloud Verification Instrument (draft, not granted)

Permits read-only and synthetic checks only:

| Item | Check | Kind | Instrument |
|---|---|---|---|
| CV-01 | Which repositories the account holds, their visibility, and whether private ones are reachable from sessions | Read-only | Verification |
| CV-02 | A remote HTTP MCP server with OAuth connects in each environment you use: terminal, desktop, cloud session, mobile | Needs a test server | Implementation |
| CV-03 | Arabic search on PostgreSQL: the twelve synthetic sentences and seventeen queries of the SQLite probe, on the candidate provider's version | Executable probe, synthetic data | Verification |
| CV-04 | Whether each environment prompts before a connector tool call, and whether that can be set per tool | Observation | Verification |
| CV-05 | Whether elicitation works outside interactive terminal sessions | Observation | Verification |
| CV-06 | What happens when a project defines a server with the connector's name | Observation with a harmless stub | Verification |
| CV-07 | Which hooks from a repository's settings run in cloud sessions, and within what time | Observation | Verification |
| CV-08 | A cloud environment can reach the service's domain under its network setting | Observation | Verification |
| CV-09 | Each shortlisted provider: regions, backup and recovery options and prices, export, private networking, object versioning or lock | Reading and price confirmation | Verification |
| CV-10 | Retrieval results stay inside the client's tool-output limit | Observation | Verification |
| CV-11 | Where the bootstrap skill is available: repository, personal, synced | Observation | Verification |
| CV-12 | An exported vault opens in Obsidian with Arabic displayed right-to-left | Manual check | Verification |
| CV-13 | Backup and restore drill with synthetic data | Needs resources | Implementation |
| CV-14 | How each client handles OAuth for the connector: issuer validation, the audience or resource it requests, and where it sends tokens | Observation | Verification |
| CV-15 | Read-only inventory of every repository in the account: name, visibility, last push, purpose, candidate project, classification | Read-only, owner-authorised | Verification |
| CV-16 | Current prices for each line of the two costed configurations | Reading and price confirmation | Verification |
| CV-17 | A per-project connection with its own grant works in each environment, including cloud sessions | Needs a test server | Implementation |

Prohibits: creating or changing any repository; provisioning any cloud resource; any cost; any owner data; application code. Two items need something a session does not already have, and the instrument must grant each by name or leave it out: CV-15 needs read-only listing access to the whole account, given by the owner for that purpose; CV-03 needs a temporary PostgreSQL instance holding twelve synthetic sentences. Results go to a verification record with what was observed and where.

For CV-03, say where: a temporary instance inside the specification sandbox (no provider, no cost), or leave it to the Implementation Instrument.

## Cloud Implementation Instrument (draft template, not granted, not to be issued yet)

To be completed after the successor baseline is approved (CD-17). It must name:

- The approved baseline version and ADRs.
- Stage 1 (no cloud resources): the repository to create, permitted directories, dependency policy, tests required.
- Stage 2 (cloud resources): provider, region, resources, monthly ceiling, who holds which credential.
- Security controls that must exist before any owner data: authentication, scopes, approval page, encrypted independent backup with a passed restore-test.
- What remains forbidden: production data migration, deployment from a commit, public resources.
- Rollback: how every resource is removed and every cost stopped.
- Stop conditions: a failed verification item, a cost alarm, a security finding.

Items that need this instrument because they need a deployed test service: CV-02, CV-13, CV-17.
