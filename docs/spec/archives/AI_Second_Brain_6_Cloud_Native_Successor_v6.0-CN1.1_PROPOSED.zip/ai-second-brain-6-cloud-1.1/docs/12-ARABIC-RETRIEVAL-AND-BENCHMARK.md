# Arabic-First Retrieval and Benchmark Strategy

**DOC-CN-12** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

## 1. What carries over unchanged

The normaliser `ar-en-1` and light stemmer `ar-light-1` (application code, engine-independent); indexing normalised text and stemmed text separately; excerpts taken from originals; six outcome classes; benchmark BENCH-1 with its strata; thresholds of NFR-007 (Recall@10 at least 0.90 overall and 0.85 per language, provisional); gates RET-G1 and RET-G2; no vector search before RET-G2.

## 2. What changes

Only the engine underneath. Three candidate designs on PostgreSQL:

| Design | How | Expectation | Status |
|---|---|---|---|
| A | Full-text search with a plain configuration over the application-normalised and stemmed columns | Closest to IR1.1's measured SQLite behaviour, because the application does the language work | UNVERIFIED |
| B | PostgreSQL's built-in Arabic configuration on raw text | Unknown handling of diacritics, letter variants and clitics | UNVERIFIED |
| C | Trigram matching on normalised text | Tolerant of spelling variants; weaker ranking | UNVERIFIED |

## 3. Evidence that exists and evidence that does not

Measured in IR1.1's sandbox on SQLite: raw indexing failed all nine variant probes; normalised and stemmed indexing answered eight; broken plurals were missed. **Nothing has been run on PostgreSQL.** A probe was proposed in this pass and was not run. Until CV-03 is run, any statement about Arabic retrieval on PostgreSQL is an expectation, not a result, and CD-02 is conditional on it.

## 4. Probe and benchmark

CV-03 repeats IR1.1's probe (twelve synthetic sentences, seventeen queries) for designs A, B and C on the candidate provider's PostgreSQL version and compares each result with the SQLite record. The benchmark gate is unchanged and gains two strata for the cloud product: questions whose evidence lies in another project, and questions that must not return a restricted project's records.
