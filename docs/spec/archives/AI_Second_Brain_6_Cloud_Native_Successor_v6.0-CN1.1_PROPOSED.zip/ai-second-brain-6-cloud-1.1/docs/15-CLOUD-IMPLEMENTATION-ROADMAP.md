# Cloud Implementation Roadmap

**DOC-CN-15** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Nothing below is authorised. Each phase states what authorisation it needs.

| Phase | Content | Needs | Reversible |
|---|---|---|---|
| CP0 Architecture approval | Owner answers CLOUD-OWNER-DECISIONS; independent review; detailed design: database schema, tool schemas, rewritten requirements and tests | Specification-only (current) | Yes |
| CP1 Cloud verification | CV-01, CV-03 to CV-12 that need no deployed service | Cloud Verification Instrument | Yes: read-only and synthetic |
| CP2 Development foundation | Platform repository; domain model; migrations; tests on an isolated database; continuous integration | Cloud Implementation Instrument, stage 1 | Yes: no cloud resources, no data |
| CP3 Infrastructure | Provider accounts, database, storage, secrets, networking | Stage 2, with provider and cost approved | Costs begin |
| CP4 Backend | Registry, ingestion, memory lifecycle, proposals, audit, search; **backup and restore-test pass before any owner data** | Stage 2 | Yes until data is loaded |
| CP5 MCP integration | Connector, authentication, scopes, bootstrap skill, approval page; CV-02, CV-13 | Stage 2 | Yes |
| CP6 GitHub integration | Repository mapping by reference | Stage 2 | Yes |
| CP7 Knowledge intelligence | Deduplication, contradiction handling, cross-project retrieval; retrieval gate on the pilot corpus | Owner's pilot corpus (D-10 carried) | Yes |
| CP8 Session persistence | Session open and close; optional event capture | CD-07 | Yes |
| CP9 Obsidian interoperability | Export; later re-import | CD-12 | Yes |
| CP10 Production acceptance | Security suite, exit drill, restore drill, owner acceptance | Separate acceptance decision | — |

Order of first use: CP0 → CP1 → CP2 → CP3 → CP4 → CP5, then real data. CP6 to CP9 follow use. Reversible preparatory work is CP0, CP1 and CP2; everything from CP3 on spends money or holds data.
