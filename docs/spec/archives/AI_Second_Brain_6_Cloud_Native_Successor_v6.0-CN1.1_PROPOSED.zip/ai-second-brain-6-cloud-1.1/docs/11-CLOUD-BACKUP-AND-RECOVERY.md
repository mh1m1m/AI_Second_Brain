# Cloud Backup and Disaster Recovery

**DOC-CN-11** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Replaces the external-disk design of D-06 and ADR-010. The rule of GAP-034 is unchanged: no owner data before a backup has been restored and checked.

| Aspect | Proposal |
|---|---|
| What | Database (logical dump), originals and attachments, configuration and repository mappings, the latest Markdown and JSON export, a manifest with SHA-256 per item, schema version and audit chain head |
| Where | First line: the provider's own daily backups. Second line: a daily export encrypted before it leaves, stored at a second provider in a separate account |
| Keys | Public-key encryption. The backup job holds only the public key and can encrypt but not decrypt. The private key is generated and held by the owner, with an offline recovery copy, and is never placed with any provider |
| When | Daily; before every migration; on demand |
| Verification | Unattended: after writing, the ciphertext is re-read and its checksum compared with the manifest; the job may read what it wrote but cannot decrypt or delete. Owner-run drill, with the private key: restore into a scratch database and bucket and check integrity, foreign keys, audit chain, sampled originals, index rebuild. Once before any real data, then on the owner's schedule |
| Objectives | Recovery point 24 hours. Recovery time unmeasured; set after the first drill. IR1.1's provisional figures are not silently changed: the point is the same, the time was never measured |
| Retention | 14 daily and 8 weekly, as proposed in IR1.1, enforced by the backup store's own lifecycle rules, not by the job |
| Point-in-time recovery | An optional provider add-on; not assumed, because of its price on the provider checked |
| Exit drill | Once before real data and yearly: load a full export into an empty environment at a different provider (CR-15) |
| Runbooks | Lost database; lost object store; lost provider account; lost key or passkey; suspected compromise; cost alarm |

GitHub history is not a backup of the database or of the originals. Decision: CD-10.
