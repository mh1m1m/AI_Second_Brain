# Cloud Provider Comparison and Cost Estimates

**DOC-CN-14** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Evidence words: **VERIFIED** = read in documentation or measured today; **UNVERIFIED** = not checked in this pass; **PROPOSED** = a recommendation awaiting the owner.

No provider is selected. Only one provider's prices were confirmed in this pass; statements about the others come from general knowledge and are marked UNVERIFIED so that they are checked before any decision (CV-09).

## 1. Criteria

Managed PostgreSQL; a place to run a Python service and an isolated worker; private object storage; secret management; backups and their price; region and data residency; private networking; export; recurring cost at one user's scale; how hard it is to leave.

## 2. Candidates

| Candidate | Would provide | Points to weigh | Evidence |
|---|---|---|---|
| Supabase | PostgreSQL, object storage, authentication | Free plan: project paused after one week of inactivity, limit of two projects, no automatic backups. Pro: from US$25 a month; one project on the default compute comes to about US$25 after the included credit. Point-in-time recovery US$100 a month per seven days of retention. The Python service would run elsewhere. An account connector for it appeared in this session; it was not queried | Prices VERIFIED 2026-11-10 from its pricing page; the rest UNVERIFIED |
| Neon | Serverless PostgreSQL | Scale-to-zero and branching; region list and prices not checked | UNVERIFIED |
| A large cloud (AWS, Google Cloud, Azure) | Everything, including regions in the Middle East | Most control over residency and networking; most configuration and usually the highest floor price | UNVERIFIED |
| Cloudflare | Object storage, edge compute, a SQLite-based database | Relevant to option O4 and as an independent backup target; Python support for its compute not checked | UNVERIFIED |
| A container host (for the Python service) | Runs the service and worker beside a managed database | Needed with any database-only provider | UNVERIFIED |

## 3. Cost

Superseded by section 6 below (CN1.1). The CN1 statement, kept for the record: a persistent, never-paused managed PostgreSQL with daily backups starts at about US$25 a month on the provider checked; hosting for the Python service, storage beyond the included amount and a second provider for backups come on top and are not priced here. No free tier examined is suitable for a system whose point is persistence. A planning ceiling is the owner's to set (CD-03); a figure from me now would be a guess.

## 4. Residency

The owner is in Saudi Arabia. Whether personal knowledge must stay in a particular country or region is a question for the owner, and for whoever owns any non-personal material if CD-01 admits it. I am not a lawyer; this is a factor to decide, not advice.

## 5. Leaving a provider

PostgreSQL dumps, S3-style object copies, Markdown and JSON exports. Provider-specific features (their authentication service, their row-level policy language, their functions) are where lock-in enters; the design keeps authorisation in the service for that reason.

## 6. Complete monthly cost, two configurations (CN1.1)

Scale assumed: one owner, a few gigabytes of data, light daily use. **V** = read on the provider's own pricing page on 2026-11-10. **S** = from secondary sources that cite the provider's page in 2026; confirm before deciding. **E** = my estimate, not a quoted price. US dollars a month.

| Line | Configuration A: Supabase for database, storage and login | Configuration B: Neon for database | Basis |
|---|---|---|---|
| Database | 25: Pro plan with one project on default compute after the included credit | About 3 to 15: usage-based at 0.106 per compute-unit hour and 0.35 per gigabyte, scaling to zero when idle | A: V. B: S for the rates; the total is E |
| Python service | 7: smallest always-on web service at a container host | 7 | S |
| Extraction worker | 7 if always on; less if run on demand | 7 or less | S for the instance price; E for on-demand |
| Object storage for originals | 0: within the plan's included storage at this scale | Under 1 at a separate object store | A: S. B: E |
| Login for the approval surface | 0: included | 0 if built into the service; a managed option is not priced | E |
| Monitoring and alerts | 0 on free tiers | 0 on free tiers | E |
| Independent backup at a second provider | Under 1 | Under 1 | E |
| Data transfer | 0 within included amounts | 0 within included amounts | E |
| **Total** | **About 40** | **About 20 to 30** | Mixed |
| Optional point-in-time recovery | Plus 100 per seven days of retention | A restore window is part of the usage pricing; not costed | A: V. B: S |

Differences that are not prices: configuration A never pauses and bundles three components with one provider; configuration B is cheaper and sleeps when idle, so the first request after a pause is slower, and it spreads components across more providers. One secondary source reports a different Neon rate and a five-dollar minimum from an older documentation page; the pricing page should be read directly before deciding (CV-16).

A large-cloud configuration with a region in the Middle East is **not priced**. Expect a higher floor and more configuration; price it under CV-16 if residency turns out to require it.

Not included in any figure: a domain name, the owner's time, and Claude usage, which is unchanged because the server calls no model.
