# GitHub Repository and Synchronisation Strategy

**DOC-CN-06** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

## 1. What exists (read-only listing, 2026-11-10)

| Repository | Visibility | Last push |
|---|---|---|
| mh1m1m/CDF_Notification_Generator | public | 2026-11-09 |
| mh1m1m/CDF_GC_Review | public | 2026-11-09 |
| mh1m1m/CDF_Case_Management | public | 2026-11-07 |
| mh1m1m/Prodysia | public | 2025-08-31 |
| mh1m1m/novel | public | 2025-08-20 |

Nothing was created, changed or cloned. **Limitation.** This is what one session's GitHub connection was granted, not an inventory of the account. Private repositories, repositories in organisations, and repositories not selected for the connection would not appear. No conclusion about what exists follows from it. Whether the five above are meant to be public is the owner's call.

## 2. Proposed repositories

| Repository | Visibility | Holds | When |
|---|---|---|---|
| Platform (name to be chosen by the owner) | Private | Service and connector source, migrations, tests, infrastructure definitions, the bootstrap skill, this specification and its ADRs, release manifests | Created only under the Cloud Implementation Instrument |
| Project repositories | As the owner decides | Each project's own code and documents | Existing ones are linked, never duplicated |
| Knowledge export | Private | Approved Markdown exports and manifests | Not at first (CD-09); only if the owner asks for exports in Git |

A conversation is not a project, and no repository is created per conversation.

## 3. What the service does with GitHub

It stores references: repository, branch, commit, pull request, release. It holds no GitHub credential (CD-08). Commit, push, merge, release and deploy stay separate actions done by Claude Code or the owner under the repository's own protections. A successful commit says nothing about the database, and the reverse.

## 4. Governance for the platform repository

Private; protected default branch; pull-request review for consequential changes; secret scanning and dependency scanning; tests in continuous integration; tagged releases with checksums; no deployment triggered by a commit.

## 5. Never in a repository

Credentials, tokens, decrypted backups, database dumps, originals, personal knowledge that the owner has not explicitly exported.

## 6. Integration levels (CN1.1)

| Level | What | Credential in the service | Status |
|---|---|---|---|
| G0 References | Repository, commit, path and range locators; pull-request and release references | None | First release |
| G1 Metadata | Repository names, branches, commit messages, pull-request titles | None: submitted by the session, which already has repository access | First release |
| G2 Content ingestion | Selected files or documents as classified sources | None at first (session-submitted). Later, if wanted: read-only access per repository | First release in session-submitted form; service-side reading is a later decision |
| G3 Automation | Anything that writes: commits, pull requests, releases | Would need write access | Outside this baseline; its own ADR and authorisation |

**Repository knowledge without duplication.** Code stays in GitHub and is authoritative there. The brain holds distilled records (decisions, findings, how a component works) with locators into a repository at a commit. A session in another project that retrieves such a record gets the knowledge and the locator; it opens the code only if its own GitHub access allows. Nothing is copied wholesale (CR-34, CR-35).

## 7. Read-only inventory procedure (CV-15; not authorised)

1. The owner authorises a listing that covers the whole account, including private repositories and organisations.
2. For each repository record: name, owner, visibility, last push, a one-line purpose from its description or README title.
3. The owner marks which are projects for the brain, their classification ceiling and sharing policy, and whether any is an earlier Second Brain codebase.
4. Nothing is cloned, changed or created. The record is filed with the verification results.
