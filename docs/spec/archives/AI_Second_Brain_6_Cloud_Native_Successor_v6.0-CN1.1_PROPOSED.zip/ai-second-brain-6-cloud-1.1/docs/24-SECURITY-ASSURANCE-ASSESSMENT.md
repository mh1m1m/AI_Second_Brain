# Security Assurance Assessment

**DOC-CN-24** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Specification level. For each sensitive capability: threat, trust boundary, required control, enforcing layer, failure behaviour, audit evidence, acceptance test, remaining uncertainty. Nothing here has been built or tested, and no instruction to Claude is counted as a control.

| Capability | Threat | Boundary | Required control | Layer | Failure behaviour | Audit evidence | Test | Remaining uncertainty |
|---|---|---|---|---|---|---|---|---|
| Classification at intake | Material stored that the owner may not store | Owner / service | Class required; K3 needs recorded clearance; K4 refused; unclassified held at K2 | Service gate | Refused or held; nothing indexed | Intake event with class and clearance reference | CT-31, CT-32 | The class is the owner's statement; the service cannot verify ownership |
| Retrieval ceiling | A session reads above its ceiling | Connector / service | Grant ceiling checked on every read; no counts or hints above it | Token scope + service gate | Empty result | Read event with grant and ceiling | CT-33 | Inference from what is absent |
| Elevation to K2 | A manipulated session obtains confidential material | Session / owner | Time-boxed elevation for named projects, approved at the approval origin; it applies to the whole connection | Approval surface | No elevation, K1 results only | Elevation event | CT-33, CT-47 | Any session on the connection benefits while it lasts; an elevation the owner was talked into |
| Session-submitted material | Injected or unvetted text stored and served to later sessions | Session / service | Stored as unreviewed; same project only; flagged; screened; expiring; never promoted without approval | Service gate | Refused or held | Submission event | CT-46 | Carried forward inside one project: RR-13 |
| Authorisation server | Tokens or grants obtained without the owner | Internet / authorisation origin | Passkey; PKCE; exact redirects; consent as a tier 2 act | Identity | No token issued | Grant event | CT-48 | Client behaviour unverified (CV-14) |
| Approval authentication | Someone other than the owner approves | Internet / approval origin | Passkey; fresh assertion per approval | Identity | Refused | Decision event with authenticator | CT-36, CT-37 | Compromised owner device |
| Approval binding | An approval is used for a different change | Proposal / approval | Challenge derived from the proposal hash; single-use; consumed in the applying transaction | Service + database | Refused | Approval and apply events share the hash | CT-37 | None at design level; untested |
| Approval surface integrity | Forged request, framing, deceptive rendering | Browser / approval origin | Strict cookies, anti-forgery token, Origin check, no framing, escaped text, visible control characters | Web controls | Request rejected | Rejected-request event | CT-38, CT-39 | Browser flaws; a malicious browser extension |
| Project boundaries | A session in one project reads another | Grant / project | Sharing policy and grant checked on every read | Service gate | Empty result | Read event with project | CT-41 | Misconfigured policy |
| Promotion | Sensitive knowledge spreads by copying | Project / workspace | Promotion by approval, linked not copied, class kept | Approval + service | Not promoted | Promotion event | CT-42 | Owner promoting too much |
| Content after release | Released content leaves through the session | Service / session | None after release; limits on what is released | — | — | Read events show what was released | CT-43, CT-44 | Not preventable: RR-01 |
| Service authenticity | The session talks to a false service | Session / internet | Endpoint set in trusted configuration; TLS certificate validation; OAuth issuer and audience validation | Transport + identity | Connection or token refused | Failed-auth events on the real service | CT-40, CV-14 | Client behaviour unverified |
| Connector shadowing | A project defines a server with the connector's name | Repository / session | Distinctive name; approval prompt for project servers; no token for the real service is valid elsewhere; bootstrap check as a supplement | Client + identity | A shadow gets no brain data | None on the service (it is not contacted) | CV-06, CT-53 | A shadow can still mislead the session and receive what the session sends it: RR-02 |
| Repository content | Code or documents ingested without class, or a broad credential held | GitHub / service | No credential at first; content only as classified sources; later per-repository read-only | Service gate | Refused | Intake event | CT-45 | Session-submitted content is as trustworthy as the session |
| Provider access | The provider or a breach reads live data | Service / provider | Encryption at rest; minimal data; K3 and K4 rules | — | — | Provider logs | — | Live data is readable by the provider: RR-05 |
| Backup keys | Lost key or stolen backup | Owner / backup provider | Client-side encryption; owner-held key; offline recovery copy; write-only backup identity | Procedure + identity | Backup unreadable without key | Drill record | CT-14, CT-15 | A procedure; RR-07 |

## Service authenticity in detail

The identity string returned by `brain_health` proves nothing: a false server can return the same string. For a correctly configured client, authenticity rests on four things, in this order:

1. **Trusted endpoint configuration.** The connector's address is set by the owner in the account connector or user configuration, not taken from a repository, a skill or a document.
2. **TLS.** The client validates the certificate for that address.
3. **OAuth issuer.** The client obtains tokens only from the authorisation server the real service advertises; the service accepts tokens only from its own issuer.
4. **Audience and scope.** Tokens name the service as their audience; the service refuses any token whose audience, scope or expiry is wrong, and a token for the service is useless anywhere else.

**Limit of these controls.** They protect the real service and a client that is pointed at it. They do not protect a session from a server that a repository substitutes under the connector's name: that depends on the client's configuration precedence and its approval prompt, which this system does not control and which may not appear in a non-interactive session. The design guarantees less than that: a substituted server receives no brain data and no token the real service would honour. It cannot guarantee that a session is not misled by such a server or does not send it material (RR-02).

The bootstrap's check catches misconfiguration, such as a connection pointing at a test instance. How each Claude Code environment performs steps 2 to 4 is documented in general terms and unverified in detail (CV-14).
