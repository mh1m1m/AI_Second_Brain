# Residual-Risk Register

**DOC-CN-25** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Risks that remain after the proposed controls. Acceptance is the owner's and is recorded here; the column is empty.

| ID | Risk | Level | Controls | Why it remains | Owner acceptance |
|---|---|---|---|---|---|
| RR-01 | Content released to an authorised session can leave through that session's other tools, and is processed by the model provider | High for K2, moderate for K1 | Ceiling K1 by default; elevation; excerpts; budgets; alerts | Not preventable after release |  |
| RR-02 | A repository-defined server with the connector's name misleads a session or receives what the session sends it. No server-side control prevents this | High | Distinctive name; approval prompt; owner habit of refusing such prompts; identity and audience validation | Depends on client behaviour (CV-06, CV-14) |  |
| RR-03 | The owner approves a proposal or an elevation without reading it | High | Bounded queue; exact before-and-after view; batch limits | Human factor |  |
| RR-04 | A source is given a lower class than it deserves, or K3 material is stored without real permission | High | Fail-closed default; clearance record; K3 out of the first release | The service cannot verify ownership |  |
| RR-05 | The provider's systems or staff, or an attacker who breaches the provider, read live data | Moderate | Encryption at rest; provider choice; nothing K4; K3 excluded | Inherent in hosted services |  |
| RR-06 | The owner's device is compromised while the authenticator is unlocked | High | Fresh assertion per approval; tier 2 confirmation; audit; delayed recovery | Endpoint security is outside this system |  |
| RR-07 | Loss of the backup key or of every authenticator | High | Offline recovery copies; drill includes key use | Procedural |  |
| RR-08 | The internet-facing service has an exploitable flaw | High | Small surface; no public database; isolated worker; patching duty | One maintainer |  |
| RR-09 | Retrieval quality in Arabic on PostgreSQL is worse than on SQLite | Moderate | CV-03 before selection; fallback option O4 | Unmeasured |  |
| RR-10 | Automatic capture is assumed where only explicit closing works | Low | Summaries as the baseline; capture stated as optional and per repository | Environment-dependent |  |
| RR-11 | Costs exceed the ceiling, or a provider changes terms | Moderate | Alarm; ceiling; export and exit drill | Market |  |
| RR-12 | This specification has not been reviewed by a person other than its author | High | External review input recorded; separate-agent assessment with twelve findings, dispositions not re-assessed; CD-19 | Open until a reviewer is named |  |
| RR-13 | Unreviewed session material can carry injected or wrong text from one session to later sessions of the same project | Moderate | Flagged as unreviewed; same project only; expiring; never promoted without approval | Continuity inside a project needs it readable before review |  |
| RR-14 | An elevation, or a standing grant above K1, serves every session on that connection, including one that is web-enabled or manipulated | High | Short time boxes; named projects; per-project connections; alerts | The service cannot tell sessions on one connection apart |  |
