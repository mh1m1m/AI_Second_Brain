# Consolidated Cloud Owner-Decision Register

**DOC-CN-17** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

> **Nothing here is approved.** Recommendations are PROPOSED. An empty answer means not decided. IMPLEMENTATION NOT AUTHORIZED.

## 1. Recorded from the owner on 2026-11-10

- Cloud-native operation is a confirmed product requirement.
- The transition directive governs; the master implementation directive is design input only.
- IR1.1 is an immutable historical baseline and is not to be implemented unchanged.
- Managed PostgreSQL is the leading candidate for the database, not a final selection.
- GitHub is not the live database. Obsidian is optional.
- Still in force from before: Arabic first, bilingual (D-02); V5.0 as mandatory reference (D-05).

## 2. No longer asked

D-06 as an external disk, D-07 Mac folders, D-08 terminal and prompt channels, D-11 as a workspace setting, D-12 as a deferral of other environments, D-16 Git in a local vault, D-19 Mac instruments, D-20 as written. Each is replaced below.

## 3. Decisions

| ID | Question | Recommendation | Main alternative | Consequence |
|---|---|---|---|---|
| CD-01 | What may be stored? (replaces D-03) | Adopt the five-class model of DATA-CLASSIFICATION-MODEL. First release admits K0 public, K1 personal and K2 confidential. K3 employer- or third-party-owned stays out until you have a clearance you can record for each source. K4 restricted is never stored | Admit K3 from the start under per-source clearance; or K0 and K1 only | Possessing a document is not permission to upload it. The class decides encryption, retention, export and who can retrieve |
| CD-02 | Database | Managed PostgreSQL, conditional on the Arabic probe CV-03 | A hosted SQLite-compatible service | PostgreSQL widens provider choice and tooling; the executed SQLite schema evidence must be redone |
| CD-03 | Provider, region and monthly cost ceiling | No selection. Two configurations are costed in CLOUD-PROVIDER-EVALUATION at roughly US$20 to 40 a month before optional point-in-time recovery, part verified and part estimated. Confirm prices under CV-16, then set a ceiling | Choose now | A recurring commitment; where your data sits |
| CD-04 | Where and how do you approve? | On a separate approval surface with its own origin and login, as specified in APPROVAL-AUTHORITY-ARCHITECTURE: passkey assertion bound to the proposal hash, single-use, expiring, with cross-site and framing protections | An approving tool behind the client's permission prompt; pull requests as approvals | No session can approve its own proposal; a small web surface must exist from the first usable phase |
| CD-05 | How do you and the connector authenticate? | Owner: passkey, with a recovery method kept offline. Connector: OAuth issued by an owner-facing authorisation server (passkey, PKCE, exact redirects, rotating refresh tokens); consent is a tier 2 act listing scopes, projects, ceiling and expiry | A static bearer token; passwords with one-time codes | A stolen connector token reads up to its ceiling and proposes; it cannot approve, elevate or administer |
| CD-06 | Where are your own notes authoritative? | In the service, with deterministic Markdown export | Markdown files in a private knowledge repository | Notes are searchable and transactional; Obsidian becomes a reader unless re-import is used |
| CD-07 | What is kept from a session? | A summary, artifact references, open issues and next actions, submitted when you close the session and stored as unreviewed: usable by later sessions of the same project and marked as such, never across projects, expiring unless you approve it. No transcripts | Hold every summary until you approve it; event capture by hooks; a transcript archive | Continuity inside a project without letting unreviewed text become knowledge. Injected text can still be carried forward within one project (RR-13) |
| CD-08 | What does the service do with GitHub? | First release: references and session-submitted metadata and content only; the service holds no GitHub credential. Later, if you want it: per-repository read-only access for ingestion. Write automation is out of this baseline and would need its own decision | A GitHub App with read access from the start | Code stays in GitHub; the brain holds locators and distilled knowledge, so nothing is duplicated |
| CD-09 | Repositories | One new private platform repository. No knowledge-export repository at first. Link existing project repositories after a full read-only inventory (CV-15) | Platform plus knowledge repository from the start | The five repositories listed so far are only what one session could see |
| CD-10 | Backup and recovery (replaces D-06) | Provider daily backups plus a daily export encrypted to your public key and stored at a second provider; the job cannot decrypt or delete. Unattended checks verify the ciphertext; restoring is a drill you run with your private key, once before any real data and then on a schedule you set. Recovery point 24 hours; recovery time measured at the first drill | Keep a decryption key in the cloud so that restore-tests run unattended; provider backups only | A fully unattended restore-test would require the decryption key to live in the cloud; this design does not allow that |
| CD-11 | Search across projects | Access comes only from the grant. The account-wide connection reads shared projects (K0, K1). A project's confidential material is read through a connection configured in that project's own repository, with a grant limited to that project. Reusable knowledge is promoted to workspace level by your approval. What a session says its project is affects ranking only | Everything searchable by default (CN1); a single connection with a higher ceiling | Cross-project knowledge stays a core capability; a session cannot widen its access by claiming a repository. Feasibility of per-project connections is CV-17 |
| CD-12 | Obsidian | Export only at first; validated re-import later if you want it | Two-way synchronisation from the start | No sync conflicts to design before the core works |
| CD-13 | Sessions that use the brain may also browse the web | Accept web-enabled sessions for K0 and K1. K2 of another project only under a time-boxed elevation you approve outside the session. An elevation applies to the whole connection for its duration, because the service cannot tell sessions on one connection apart. Output budgets, originals behind a separate scope, volume alerts. Accept in writing RR-01 and RR-14 | Restrict the connector to environments without web access | The server controls what is released, not what an authorised session then does with it |
| CD-14 | How the bootstrap skill reaches a session | From the private platform repository; a personal copy only on machines you control. The skill holds no endpoint, secret or authority: the endpoint comes from the connector's own configuration | Also as a synced skill everywhere | A copied or altered skill can mislead a session but cannot authenticate, authorise or redirect the connector |
| CD-15 | Carry forward compatible IR1.1 decisions | D-02 languages, D-05 V5.0 as reference, D-09 formats in stages, D-10 pilot corpus and benchmark, D-13 context budget, D-14 naming as the export convention, D-17 dates | Re-open any of them | No rework where nothing changed |
| CD-16 | First release scope | Retrieval, proposals, approval page, session summaries, backups. Deferred: repository synchronisation, dashboard, knowledge graph, Obsidian sync, mobile interface | Everything in the directive at once | A usable system sooner and a smaller service to secure |
| CD-17 | Successor baseline approval (replaces D-18) | After the detailed design that follows your answers: database schema, tool schemas, rewritten requirements and tests | Approve the architecture now as the baseline | Implementation is held to a complete baseline, not to an outline |
| CD-18 | Authorisations (replaces D-19) | Cloud Verification Instrument first. Cloud Implementation Instrument later and separately | Authorise implementation now | Read-only checks before any cost or code |
| CD-19 | Independent review | Name a reviewer for CN1.1. The separate-agent adversarial assessment in ADVERSARIAL-ASSESSMENT is not a substitute for a reviewer who is not this model | Rely on the separate-agent assessment | Gate CG-12 stays NOT_VERIFIED until a person or third party reviews |
| CD-20 | Existing codebase and repositories | Authorise the read-only inventory CV-15 so that the question is answered from the whole account, not from one session's view | State from memory whether any exists | Avoids both a false 'none exists' and duplicate repositories |

## 4. Answer record

APPROVE, APPROVE_WITH_AMENDMENT, REJECT or DEFER.

| Item | Answer | Note | Date |
|---|---|---|---|
| CD-01 What may be stored |  |  |  |
| CD-02 Database |  |  |  |
| CD-03 Provider, region and monthly cost ceiling |  |  |  |
| CD-04 Where and how do you approve |  |  |  |
| CD-05 How do you and the connector authenticate |  |  |  |
| CD-06 Where are your own notes authoritative |  |  |  |
| CD-07 What is kept from a session |  |  |  |
| CD-08 What does the service do with GitHub |  |  |  |
| CD-09 Repositories |  |  |  |
| CD-10 Backup and recovery |  |  |  |
| CD-11 Search across projects |  |  |  |
| CD-12 Obsidian |  |  |  |
| CD-13 Sessions that use the brain may also browse the web |  |  |  |
| CD-14 How the bootstrap skill reaches a session |  |  |  |
| CD-15 Carry forward compatible IR1.1 decisions |  |  |  |
| CD-16 First release scope |  |  |  |
| CD-17 Successor baseline approval |  |  |  |
| CD-18 Authorisations |  |  |  |
| CD-19 Independent review |  |  |  |
| CD-20 Existing codebase and repositories |  |  |  |
| Cloud Verification Instrument |  |  |  |
| Cloud Implementation Instrument |  |  |  |

## 5. Status of this register (CN1.1)

On 2026-11-10 the owner accepted CN1's overall direction for further specification work. That is not approval of the architecture, of any ADR or of implementation. Decisions CD-01, CD-03, CD-04, CD-05, CD-08, CD-09, CD-11, CD-13, CD-14, CD-19 and CD-20 were revised in CN1.1 after external review; the others are unchanged from CN1. Residual risks for acceptance are in RESIDUAL-RISK-REGISTER.
