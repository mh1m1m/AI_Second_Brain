# Approval Authority Architecture

**DOC-CN-22** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Completes CD-04 and CD-05. Principle kept from CN1: a connector token can read and propose; it can never approve.

## 1. Separation

| Aspect | Design |
|---|---|
| Origin | Its own hostname, separate from the connector endpoint. No connector route is served there and no approval route is served on the connector |
| Authentication | The owner signs in with a passkey (phishing-resistant, bound to the approval origin). No password-only path. The connector's OAuth tokens are not accepted here, and the approval session's cookie is not a connector credential |
| Authorisation server | Owner-facing and on this origin, never on the connector's. Authorisation-code flow with PKCE and exact redirect matching; rotating refresh tokens. Consent is a tier 2 act: the owner signs in with the passkey, sees the scopes, projects, ceiling and expiry requested, and confirms with a fresh assertion (CR-43) |
| Session | Short-lived, cookie-based, marked HttpOnly, Secure and SameSite=Strict; idle and absolute timeouts; no cross-origin resource sharing; signing out ends it server-side |
| Step-up | Every approval, and every tier 2 action, needs a fresh passkey assertion. A signed-in session alone approves nothing |
| Payload binding | The server stores the proposal in canonical form with its SHA-256 and the versions of everything it depends on. The assertion's challenge is derived from that hash and a one-time nonce, so the owner's gesture is cryptographically tied to that exact change |
| What the owner sees | The stored proposal rendered by the server as plain text with a before-and-after view, its evidence, its class, its project, and who proposed it (which grant, which session) |
| Expiry | Proposals expire after 14 days (IR1.1 value carried). A challenge is valid for minutes. An approval that is not applied within its window is void |
| Replay prevention | Nonce single-use; approval row unique per proposal hash; the approval is consumed in the same database transaction that applies the change (CR-33) |
| Cross-site request forgery | SameSite=Strict cookie, an anti-forgery token on every state-changing request, Origin header check; and since nothing is approved without a fresh assertion, a forged request has nothing to ride on |
| Framing and injection | No framing allowed; strict content security policy; no third-party scripts; proposal text escaped and never interpreted as markup |
| Deceptive text | Direction-override and other invisible characters in proposal text are made visible; Arabic and English are shown in their own direction without letting one reorder the other |
| Audit evidence | One event per decision: proposal hash, decision, owner identity, authenticator identifier, time, origin of the request, outcome; hash-chained |
| Tiers | Tier 1: approve or reject a proposal. Tier 2 (purge, restore, lowering a class, creating or widening a grant, elevation to K2, configuration): fresh assertion plus a typed confirmation |
| Fatigue | The queue is bounded (GAP-033); batch approval is limited to proposals of one project and one class, each still listed; the assertion's challenge is then derived from a digest of the ordered list of their hashes |
| Recovery | A second passkey or offline recovery method registered in advance; recovery is itself audited and time-delayed |

## 2. What it does not protect against

An owner who approves without reading (RR-03). A compromised owner device with the authenticator unlocked (RR-06). These are stated, not solved.

## 3. Identity model in one view

| Actor | Credential | Can | Cannot |
|---|---|---|---|
| A Claude Code session | OAuth token under a grant | Read up to its ceiling in its projects; propose; open and close sessions | Approve, elevate, administer, exceed its ceiling |
| The owner | Passkey at the approval origin | Approve, reject, elevate for a time, manage grants and classes | Act without a fresh assertion |
| The scheduler | Service identity | Run allowlisted deterministic jobs | Read content through the connector; approve |
| The backup job | The owner's public key; write and read-back access to its own ciphertext | Encrypt, write and checksum ciphertext | Decrypt, delete, or read plaintext |
