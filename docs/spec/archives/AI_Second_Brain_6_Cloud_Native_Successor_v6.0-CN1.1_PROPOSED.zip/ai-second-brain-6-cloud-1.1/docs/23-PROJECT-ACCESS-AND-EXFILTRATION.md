# Project Access, Cross-Project Sharing and Exfiltration Limits

**DOC-CN-23** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Revises CD-11 and expands CD-13. Cross-project knowledge stays a core capability; it stops being an unconditional default.

## 1. Grants

A grant ties one connection to: scopes (read, propose, originals), a list of projects or 'all shared projects', a classification ceiling, and an expiry (CR-36). The owner chooses these on the consent screen when authorising a connection and can change or revoke them on the approval surface.

One connection configured in the owner's account is used by every surface that uses account connectors, and the service cannot tell the sessions on one connection apart: not a web-enabled cloud session from a terminal, and not one session from another. Three consequences follow.

1. The account-wide connection has ceiling K1 and reads shared projects only.
2. A project's confidential material is read through a **per-project connection**: a connector entry in that project's own repository, authorised with a grant limited to that project. Sessions in that repository already hold its code, so this releases nothing more sensitive than they have. Whether this works in every environment is CV-17.
3. Reading another project's K2 needs an **elevation**: the owner approves, outside the session, K2 for named projects for a limited time. It applies to every session on that connection until it ends; it cannot be tied to one session (CR-39, RR-14).

## 2. Project sharing policy

| Policy | Meaning | Default for |
|---|---|---|
| Shared | Readable by any grant up to the grant's ceiling | Projects whose ceiling is K0 or K1 |
| By grant | Readable only by grants that name the project | Projects whose ceiling is K2 |
| Closed | Readable only by a grant limited to this project; never in cross-project results | Projects holding K3 |

Access derives only from the grant and the policies (CR-46). The project a session says it is in is used to rank results, never to authorise them; every result names its project. For a project the caller may not read, nothing is returned: no content, no count, no hint (CR-27).

## 3. How knowledge crosses projects

1. **Shared projects**: directly, within the ceiling.
2. **Promotion**: a record proposed for workspace level and approved by the owner becomes visible everywhere up to its class, linked to its origin (CR-38).
3. **Named grant**: the owner adds a project to a grant.
4. **Elevation**: time-boxed, for K2.

## 4. What the server controls and what it does not

Server-side authorisation decides what is released to a session. It does not decide what an authorised session then does. Once content is in a session, it is in the model's context, it has been processed by the model provider, and any other tool in that session can carry it elsewhere: a web request, a file, a commit, another connector. It cannot be recalled.

## 5. Limits that reduce the exposure

| Limit | Effect |
|---|---|
| Ceiling K1 by default | Confidential material is not released without the owner's act |
| Excerpts by default | Results are passages with locators; a whole original needs the originals scope |
| Per-call and per-session budgets | A session cannot drain a project in one go (CR-40) |
| Closed and by-grant projects | Sensitive projects are absent from general sessions |
| Volume alert and suspension | Unusual retrieval is noticed and can be stopped (CR-41) |
| Audit of every call | What was released, to which grant and session, is known afterwards |

None of these prevents leakage of what is released. That remainder is residual risk RR-01, for the owner to accept or to answer by lowering ceilings.
