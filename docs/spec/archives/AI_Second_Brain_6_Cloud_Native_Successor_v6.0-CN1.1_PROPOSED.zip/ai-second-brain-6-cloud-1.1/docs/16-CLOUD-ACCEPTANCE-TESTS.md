# Updated Acceptance Tests

**DOC-CN-16** · v6.0-CN1.1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessors: v6.0-IR1.1 and v6.0-CN1 (both unchanged)

Designed, not executed; no service exists. IR1.1's 143 designed tests, classed by the most affected requirement each covers: keep 64, adapt 63, replace 16. The list below is what the cloud adds. Detailed cases (data, steps, expected result) are written with the detailed design.

| ID | Test | Covers | Area |
|---|---|---|---|
| CT-01 | An unauthenticated or expired token is refused by every tool | CR-02, CR-18 | Authentication |
| CT-02 | A read-scope token cannot propose; no connector token can approve | CR-03 | Authorisation, tool permissions |
| CT-03 | Approval requires a fresh passkey assertion bound to the proposal's hash, single-use and expiring | CR-04 | Approval workflow |
| CT-04 | A restricted project's records are not returned to a cross-project search | CR-09 | Project isolation |
| CT-05 | Cross-project search returns the project and source of every result | CR-09 | Cross-project retrieval, provenance |
| CT-06 | Arabic, English and mixed-language benchmark at the retrieval gate | FR-RET-008, NFR-007 | Arabic, English, mixed retrieval |
| CT-07 | A duplicate proposal returns the existing one; queue limits hold | FR-AGT-003 | Deduplication |
| CT-08 | A contradicting record is kept as a conflict, not overwritten | FR-MEM-005 | Contradiction handling |
| CT-09 | A session opens, registers artifacts and closes with a summary tied to its project | CR-08 | Session association |
| CT-10 | A new version of an artifact keeps the earlier one and its checksum | CR-10 | Artifact versioning |
| CT-11 | The service holds no repository write credential; a commit reference resolves | CR-07 | GitHub synchronisation, branch protection |
| CT-12 | No secret appears in logs, exports, tool results or the repository | CR-12 | Secret protection |
| CT-13 | Instruction-bearing text in a document or tool input changes no permission and writes nothing without approval | CR-19 | Prompt-injection resistance |
| CT-14 | A backup verifies against its manifest; a corrupted one fails closed | CR-14 | Backup integrity |
| CT-15 | A backup restores into a scratch environment with integrity, audit chain and sampled originals checked | CR-14 | Restore verification |
| CT-16 | Migrations apply forward on a copy with a backup taken first | FR-OPS-006 | Database migrations |
| CT-17 | Malformed, oversized and out-of-schema tool inputs are rejected with stable errors | CR-16, CR-19 | API validation |
| CT-18 | An interrupted ingest leaves no row without its object and reconciles orphan objects | CR-11 | Failure recovery |
| CT-19 | Requests beyond the limit are refused and recorded | CR-16 | Rate limiting |
| CT-20 | Every connector call has one audit event; the chain verifies | CR-17 | Audit logging |
| CT-21 | Concurrent sessions allocate distinct sequential IDs | CR-06 | Identifiers |
| CT-22 | An original read back matches its checksum; an altered object is detected | CR-10 | Immutable evidence |
| CT-23 | Export is byte-identical for identical state; re-import of an edited file is validated and needs approval | CR-21 | Markdown export |
| CT-24 | A full export loads into an empty environment at another provider | CR-15 | Portability |
| CT-25 | A revoked token stops working at once; active grants are listed | CR-18 | Token lifecycle |
| CT-26 | The bootstrap reports a mismatch when the connection points at a server whose reported identity differs. This is a configuration check; it does not detect a deliberate impostor | CR-22 | Connector identity |
| CT-27 | A hostile file cannot exceed the worker's limits or reach the network | CR-23 | Extraction isolation |
| CT-28 | No scheduled job calls a model; only allowlisted jobs exist | CR-24 | Scheduling |
| CT-29 | Usage above the alarm threshold notifies the owner | CR-20 | Cost |
| CT-30 | Data stores report the configured region | CR-13 | Residency |
| CT-31 | An unclassified source is held at K2; a K4 item is refused | CR-25, CR-26 | Data classification |
| CT-32 | K3 material is refused without a recorded clearance | CR-26 | Data classification |
| CT-33 | A K1 grant receives no K2 content, count or hint, in results or errors | CR-27, CR-39 | Data classification |
| CT-34 | A record takes the highest class of its evidence; lowering needs tier 2 approval | CR-29 | Data classification |
| CT-35 | Exports exclude classes not permitted for the destination; the manifest lists classes | CR-28 | Data classification |
| CT-36 | The approval surface refuses a connector token and any cross-origin request | CR-30, CR-32 | Approval authority |
| CT-37 | An assertion made for one proposal hash, or for one batch digest, cannot approve another and cannot be replayed | CR-31, CR-33 | Approval authority |
| CT-38 | A forged cross-site request and a framed page cannot approve | CR-32 | Approval authority |
| CT-39 | Direction-override characters in proposal text are shown, not obeyed | CR-32 | Approval authority |
| CT-40 | A token with a wrong issuer, audience, scope or expiry is refused | CR-22 | Service identity |
| CT-41 | A session whose grant does not name project B cannot read it, whatever repository or project the session claims | CR-36, CR-37 | Cross-project access |
| CT-42 | A promoted record is visible across projects up to its class and stays linked to its origin | CR-38 | Cross-project access |
| CT-43 | Output budgets hold per call and per session; originals need their own scope | CR-40 | Exfiltration limits |
| CT-44 | Unusual retrieval volume alerts and can suspend the grant | CR-41 | Exfiltration limits |
| CT-45 | A repository locator resolves at its recorded commit; repository content enters only as a classified source | CR-34, CR-35 | GitHub |
| CT-46 | Session-submitted material is marked unreviewed, stays in its project, is absent from cross-project results and promotion, and secret-like strings are refused | CR-42 | Session persistence |
| CT-47 | An elevation ends at its time limit, covers only its named projects and is recorded as applying to the whole connection | CR-39 | Exfiltration limits |
| CT-48 | No token is issued on a wrong redirect, a missing PKCE proof or a consent without a fresh assertion; the consent lists scopes, projects, ceiling and expiry | CR-43 | Approval authority |
| CT-49 | A tier 2 act is refused without its bound assertion and typed confirmation; recovery is delayed and audited | CR-44 | Approval authority |
| CT-50 | K3 material is purged when its clearance ends; a K2 record without a review date is flagged | CR-45 | Data classification |
| CT-51 | Identifiers visible to a K1 grant show no count or gap attributable to records above its ceiling | CR-47 | Cross-project access |
| CT-52 | The backup job can neither decrypt nor delete; a restore drill needs the owner's key | CR-48 | Backup |
| CT-53 | A token whose audience is another service is refused; a record of how each client reacts to a server it was not configured for is kept as a verification item, not as a pass | CR-22 | Service identity |

## End-to-end demonstration, synthetic data only

Initialise a test workspace → create two projects → ingest sample documents in Arabic and English → open and close test sessions → retrieve across projects → propose an update → show an unauthorised change refused → approve a permitted change on the approval page → verify provenance → export Markdown → restore from the independent backup into a scratch environment.
