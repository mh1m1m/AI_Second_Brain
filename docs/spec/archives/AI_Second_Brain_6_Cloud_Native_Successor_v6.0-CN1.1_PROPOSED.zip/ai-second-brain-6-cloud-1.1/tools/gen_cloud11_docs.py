# Second half of gen_cloud.py (executed in its namespace).
CD = [
 ("CD-01", "What may be stored? (replaces D-03)", "Treat everything as private personal data: project knowledge, session summaries and code references are not public documents. Keep material that belongs to an employer or a third party out unless you clear it separately", "Public sources only, as in IR1.1", "Decides encryption, residency and access rules; IR1.1 made public-only content the reason for several lighter controls"),
 ("CD-02", "Database", "Managed PostgreSQL, conditional on the Arabic probe CV-03", "A hosted SQLite-compatible service", "PostgreSQL widens provider choice and tooling; the executed SQLite schema evidence must be redone"),
 ("CD-03", "Provider, region and monthly cost ceiling", "No selection yet. Shortlist in CLOUD-PROVIDER-EVALUATION, verified under the Cloud Verification Instrument", "Choose now on current information", "A paid, recurring commitment; where your data sits"),
 ("CD-04", "Where do you approve?", "Outside the session, on a small page only you can sign in to. Connector tokens can read and propose, never approve", "An approving tool behind the client's permission prompt; pull requests as approvals", "Claude cannot approve its own proposal even if a session is manipulated; a minimal web page is needed from the first usable phase"),
 ("CD-05", "How do you and the connector authenticate?", "OAuth for the connector with one owner identity; a passkey for approval and administration", "A static bearer token", "A stolen connector token can read and propose, not approve or delete"),
 ("CD-06", "Where are your own notes authoritative?", "In the service, with deterministic Markdown export", "Markdown files in a private knowledge repository", "Notes are searchable and transactional; Obsidian becomes a reader unless re-import is used"),
 ("CD-07", "What is kept from a session?", "A summary you can see, artifact references, open issues and next actions, submitted when you close the session. No transcripts by default", "Event capture by hooks in repositories that opt in; a transcript archive with retention", "Continuity without storing every message; capture that does not depend on one environment"),
 ("CD-08", "What does the service do with GitHub?", "Hold references only (repository, commit, pull request). No GitHub credential in the service. Claude Code keeps doing repository work with its own GitHub access", "A GitHub App with write access held by the service", "One fewer class of credential to protect; no automatic pushes are possible by design"),
 ("CD-09", "Repositories", "One new private platform repository. No knowledge-export repository at first. Link existing project repositories. Review the visibility of the repositories that are public today", "Platform plus knowledge repository from the start", "Nothing personal is committed to a repository until you ask for an export there"),
 ("CD-10", "Backup and recovery (replaces D-06)", "Provider daily backups plus a daily encrypted export to a second provider, key held by you; recovery point 24 hours; recovery time measured at the first drill; restore-tested before any real data", "Provider backups only; add point-in-time recovery", "A second storage account; point-in-time recovery was priced at US$100 a month per seven days on the one provider checked"),
 ("CD-11", "Search across projects", "All your projects searchable by default, each result labelled with its project; a project can be marked restricted", "Per-project isolation unless you ask for cross-project", "One owner, so isolation protects against mistakes rather than other users"),
 ("CD-12", "Obsidian", "Export only at first; validated re-import later if you want it", "Two-way synchronisation from the start", "No sync conflicts to design before the core works"),
 ("CD-13", "Sessions that use the brain may also browse the web", "Accept it; every write is a proposal and every proposal needs you. Retrieved content can still leave through a session's other tools", "Restrict the connector to environments without web access", "Injection moves from prevention on the client to containment on the server"),
 ("CD-14", "How the bootstrap skill reaches a session", "In the platform repository, and as a personal skill for other projects. This reverses IR1.1's proposal to switch synced skills off", "Repository only", "The skill is a convenience; the service does not trust it"),
 ("CD-15", "Carry forward compatible IR1.1 decisions", "D-02 languages, D-05 V5.0 as reference, D-09 formats in stages, D-10 pilot corpus and benchmark, D-13 context budget, D-14 naming as the export convention, D-17 dates", "Re-open any of them", "No rework where nothing changed"),
 ("CD-16", "First release scope", "Retrieval, proposals, approval page, session summaries, backups. Deferred: repository synchronisation, dashboard, knowledge graph, Obsidian sync, mobile interface", "Everything in the directive at once", "A usable system sooner and a smaller service to secure"),
 ("CD-17", "Successor baseline approval (replaces D-18)", "After the detailed design that follows your answers: database schema, tool schemas, rewritten requirements and tests", "Approve the architecture now as the baseline", "Implementation is held to a complete baseline, not to an outline"),
 ("CD-18", "Authorisations (replaces D-19)", "Cloud Verification Instrument first. Cloud Implementation Instrument later and separately", "Authorise implementation now", "Read-only checks before any cost or code"),
 ("CD-19", "Independent review", "Name a reviewer for v6.0-CN1 and give them this package and the IR1.1 archive", "Have a separate agent, with no view of this work, attempt the review", "Gate CG-12 stays NOT_VERIFIED until someone other than the author reviews"),
 ("CD-20", "Existing codebase", "Say whether any exists; none was supplied", "—", "Carried from IR1.1")]
CV = [("CV-01", "Which repositories the account holds, their visibility, and whether private ones are reachable from sessions", "Read-only"),
 ("CV-02", "A remote HTTP MCP server with OAuth connects in each environment you use: terminal, desktop, cloud session, mobile", "Needs a test server: Implementation Instrument"),
 ("CV-03", "Arabic search on PostgreSQL: the twelve synthetic sentences and seventeen queries of the SQLite probe, on the candidate provider's version", "Executable probe, synthetic data"),
 ("CV-04", "Whether each environment prompts before a connector tool call, and whether that can be set per tool", "Observation"),
 ("CV-05", "Whether elicitation works outside interactive terminal sessions", "Observation"),
 ("CV-06", "What happens when a project defines a server with the connector's name", "Observation with a harmless stub"),
 ("CV-07", "Which hooks from a repository's settings run in cloud sessions, and within what time", "Observation"),
 ("CV-08", "A cloud environment can reach the service's domain under its network setting", "Observation"),
 ("CV-09", "Each shortlisted provider: regions, backup and recovery options and prices, export, private networking, object versioning or lock", "Reading and price confirmation"),
 ("CV-10", "Retrieval results stay inside the client's tool-output limit", "Observation"),
 ("CV-11", "Where the bootstrap skill is available: repository, personal, synced", "Observation"),
 ("CV-12", "An exported vault opens in Obsidian with Arabic displayed right-to-left", "Manual check"),
 ("CV-13", "Backup and restore drill with synthetic data", "Needs resources: Implementation Instrument")]
CT = [("CT-01", "An unauthenticated or expired token is refused by every tool", "CR-02, CR-18", "Authentication"), ("CT-02", "A read-scope token cannot propose; no connector token can approve", "CR-03", "Authorisation, tool permissions"),
 ("CT-03", "Approval requires the owner's passkey and is bound to the proposal's hash, single-use and expiring", "CR-04", "Approval workflow"), ("CT-04", "A restricted project's records are not returned to a cross-project search", "CR-09", "Project isolation"),
 ("CT-05", "Cross-project search returns the project and source of every result", "CR-09", "Cross-project retrieval, provenance"), ("CT-06", "Arabic, English and mixed-language benchmark at the retrieval gate", "FR-RET-008, NFR-007", "Arabic, English, mixed retrieval"),
 ("CT-07", "A duplicate proposal returns the existing one; queue limits hold", "FR-AGT-003", "Deduplication"), ("CT-08", "A contradicting record is kept as a conflict, not overwritten", "FR-MEM-005", "Contradiction handling"),
 ("CT-09", "A session opens, registers artifacts and closes with a summary tied to its project", "CR-08", "Session association"), ("CT-10", "A new version of an artifact keeps the earlier one and its checksum", "CR-10", "Artifact versioning"),
 ("CT-11", "The service holds no repository write credential; a commit reference resolves", "CR-07", "GitHub synchronisation, branch protection"), ("CT-12", "No secret appears in logs, exports, tool results or the repository", "CR-12", "Secret protection"),
 ("CT-13", "Instruction-bearing text in a document or tool input changes no permission and writes nothing without approval", "CR-19", "Prompt-injection resistance"), ("CT-14", "A backup verifies against its manifest; a corrupted one fails closed", "CR-14", "Backup integrity"),
 ("CT-15", "A backup restores into a scratch environment with integrity, audit chain and sampled originals checked", "CR-14", "Restore verification"), ("CT-16", "Migrations apply forward on a copy with a backup taken first", "FR-OPS-006", "Database migrations"),
 ("CT-17", "Malformed, oversized and out-of-schema tool inputs are rejected with stable errors", "CR-16, CR-19", "API validation"), ("CT-18", "An interrupted ingest leaves no row without its object and reconciles orphan objects", "CR-11", "Failure recovery"),
 ("CT-19", "Requests beyond the limit are refused and recorded", "CR-16", "Rate limiting"), ("CT-20", "Every connector call has one audit event; the chain verifies", "CR-17", "Audit logging"),
 ("CT-21", "Concurrent sessions allocate distinct sequential IDs", "CR-06", "Identifiers"), ("CT-22", "An original read back matches its checksum; an altered object is detected", "CR-10", "Immutable evidence"),
 ("CT-23", "Export is byte-identical for identical state; re-import of an edited file is validated and needs approval", "CR-21", "Markdown export"), ("CT-24", "A full export loads into an empty environment at another provider", "CR-15", "Portability"),
 ("CT-25", "A revoked token stops working at once; active grants are listed", "CR-18", "Token lifecycle"), ("CT-26", "A stub server using the connector's name is detected by the bootstrap", "CR-22", "Connector identity"),
 ("CT-27", "A hostile file cannot exceed the worker's limits or reach the network", "CR-23", "Extraction isolation"), ("CT-28", "No scheduled job calls a model; only allowlisted jobs exist", "CR-24", "Scheduling"),
 ("CT-29", "Usage above the alarm threshold notifies the owner", "CR-20", "Cost"), ("CT-30", "Data stores report the configured region", "CR-13", "Residency")]
GATES = [("CG-01", "Baseline preservation", "PASS", "IR1.1 archive hash re-computed and unchanged; nothing written to it"),
 ("CG-02", "ADR reconciliation", "PASS (proposals)", "20 of 20 dispositioned; 11 successor records titled, none written in full"),
 ("CG-03", "Requirements traceability", "PASS (classification)", "100 of 100 classified; 24 new requirements proposed; none rewritten yet"),
 ("CG-04", "GitHub architecture", "PENDING_OWNER", "Strategy proposed; the five repositories visible to this session are all public and none belongs to this project"),
 ("CG-05", "Cloud data authority", "PASS (proposal)", "One authority and one writer per data class"),
 ("CG-06", "MCP integration", "NOT_VERIFIED", "Designed from documentation; nothing has been connected or tested"),
 ("CG-07", "Security and privacy", "PARTIAL", "Boundaries, threats and controls stated; token model, schemas and classification await CD-01, CD-04, CD-05"),
 ("CG-08", "Backup and recovery", "PARTIAL", "Design stated; depends on the provider (CD-03, CD-10); nothing run"),
 ("CG-09", "Session persistence", "PARTIAL", "Summary path designed; capture mechanisms known from documentation only"),
 ("CG-10", "Cost and operational feasibility", "PARTIAL", "One provider's prices checked today; Python hosting and the others not priced"),
 ("CG-11", "Owner approval integrity", "PASS", "No approval recorded; every decision PROPOSED"),
 ("CG-12", "Independent review", "NOT_VERIFIED", "No one other than the author has reviewed this package")]

CD = [CD_OVR.get(c[0], c) for c in CD]; CV += CV_EXTRA; CT += CT_EXTRA; CT[:] = [(c, _TT.get(c, t), r, x) for c, t, r, x in CT]; GATES = [GATES_OVR.get(g[0], g) for g in GATES]
o = H("DOC-CN-01", "Baseline Integrity and Preservation Report") + ["## 1. What was found", ""] + T(["Source", "Identity", "Status"], [
 ("`AI_Second_Brain_6_Implementation_Readiness_Baseline_v6.0-IR1.1.zip`", f"SHA-256 `{ZSHA}`; 171 entries", "Authoritative historical baseline. Re-hashed on 2026-11-10 before this work: unchanged"),
 ("Its own checker, `tools/spec_lint.py`", "23 of 23 checks pass", "Includes: snapshot hashes match, approval record empty, no ADR marked approved"),
 ("v6.0-IR1 archive", "SHA-256 `8c2ab27f1b5b71613f62a1b96b3e5a3affd81c6be5cd37ad7e4461e894ed1eb5`", "Superseded by IR1.1; its decision register is preserved inside IR1.1"),
 ("Earlier V6.0 draft (46 files, 10 ADRs) and the 500-slot audit", "Hashed in `docs/_baseline/SNAPSHOT-MANIFEST.md` inside IR1.1", "Superseded; source of the earlier false 'missing ADR' finding"),
 ("Inputs of this pass", "Five files under `inputs/`, hashed in MANIFEST.md", "Kept as received. The master implementation directive is withdrawn as an authorisation and kept as design input"),
 ("Implementation repository", "None supplied", "Existence not established"),
 ("GitHub account reachable from this session", "Five repositories, all public", "Read-only listing; see GITHUB-REPOSITORY-STRATEGY")])
o += ["## 2. Approval state", "", "Nothing in IR1.1 is approved: its approval record (section G) is empty and all 20 ADRs are PROPOSED. Decided by the owner and still in force: D-02 (Arabic first, bilingual) and D-05 (V5.0 as reference). Replaced by the confirmed cloud-native requirement: D-01 (macOS) and D-04 (local vault). Needing a fresh decision: D-03 (public information only), see CD-01.", "",
      "## 3. Conflicting versions", "", "One: the earlier draft archive against IR1.1. Resolved in IR1.1's own records (corrections C-01 to C-08). The master implementation directive conflicted with the transition directive; the owner resolved it on 2026-11-10 in favour of the transition directive.", "",
      "## 4. Missing evidence", "", "- No implementation exists that has been supplied or verified.", "- IR1.1 is not a Git repository; its identity is its hash.", "- The owner's private repositories, if any, are not visible to this session.", "- IR1.1 gate G8 (independent review) remains NOT_VERIFIED and is not affected by this package.", "",
      "## 5. Preservation", "", "This package lives in a separate folder and refers to IR1.1 by hash. No IR1.1 file was opened for writing. One note for exactness: the working copy's `QUALITY-REPORT.json` is rewritten with a new timestamp whenever the checker runs; the archive, not the working copy, is the baseline."]
wr("docs/01-BASELINE-INTEGRITY-REPORT.md", o)

import collections as _cc
_c0c = _cc.Counter(a[2] for a in ADR)
o = H("DOC-CN-02", "Cloud Transition Assessment") + [NOTE, "", "## 1. What changed", "",
 "The owner confirmed on 2026-11-10 that the product is cloud-native: usable from authorised Claude Code environments with no personal computer online, through a remote MCP connector, with a cloud Python service, managed PostgreSQL as the leading database candidate, private object storage, GitHub for code and versioned artifacts, optional Obsidian. IR1.1 specified the opposite deployment: one Mac, one file database, a local vault, no MCP. Its governance survives. Its deployment decisions do not.", "",
 "## 2. Impact by area", ""] + T(["Area", "IR1.1", "Cloud-native", "Consequence"], [
 ("Database", "SQLite file, executed schema", "Managed database", "Schema and probes redone (ADR-004)"), ("Search", "FTS5 over normalised text", "Database full-text search over the same normalised text", "Engine swap; Arabic behaviour UNVERIFIED (CV-03)"),
 ("Data security", "Public content on a private disk", "Private content at a provider", "Encryption, residency, access control become mandatory (CD-01)"), ("Authentication", "None: one OS account", "OAuth for the connector, passkey for the owner", "New"),
 ("Authorisation", "Claude Code rules, sandbox, CLI gate, triggers", "Token scope, service gate, constraints", "Client-side layers no longer count"), ("GitHub", "Local Git only", "Code and versioned artifacts; references from the service", "No credential in the service (CD-08)"),
 ("Execution", "CLI on the Mac", "Hosted service and worker", "Operations become a standing duty"), ("Session capture", "Not in scope", "Summaries; optional events", "Not universal across environments"),
 ("Memory", "Records, revisions, evidence", "Same, plus sessions and project scope", "Extended (ADR-020)"), ("Obsidian", "Live local vault", "Export, optional re-import", "No live sync at first"),
 ("Backups", "External disk", "Provider backups plus independent encrypted export", "Redesigned (CD-10)"), ("Recovery", "Restore-test before ingestion", "Same rule", "Preserved"),
 ("Cost", "None recurring", "Recurring", "Ceiling and alarm (CD-03)"), ("Lock-in", "None", "Provider-shaped", "Export and exit drill (CR-15)"),
 ("ADRs", "20 proposed", ", ".join(f"{v} {k.lower()}" for k, v in sorted(_c0c.items())), "ADR-TRANSITION-MATRIX"), ("Requirements", "100", f"{cnt['RETAINED']+cnt['DEFERRED']} preserved, {cnt['AMENDED']+cnt['SUPERSEDED']} modified, {len(CR)} new", "CLOUD-REQUIREMENTS-COVERAGE-MATRIX"),
 ("Phases", "0 to 10, Mac verification first", "Ten separations, cloud verification first", "CLOUD-IMPLEMENTATION-ROADMAP"), ("Operations", "Owner's machine", "A public service to patch, monitor and rotate keys for", "Largest new burden")])
o += ["## 3. Options compared", ""] + T(["Option", "What it is", "Meets the requirement", "Assessment"], [
 ("O1", "IR1.1 as specified, local", "No", "Excluded by the confirmed requirement"),
 ("O2", "GitHub-native: knowledge as files in a private repository, an index built in each session", "Partly", "Cheapest and simplest to host, but no transactions across records, approvals not bound to state, weak for originals. Excluded by the owner's rule that GitHub is not the live database"),
 ("O3", "Hosted Python service, managed PostgreSQL, object storage, one remote MCP server", "Yes", "**Recommended.** The owner's leading candidate; widest provider choice; most to operate"),
 ("O4", "As O3 with a hosted SQLite-compatible database", "Yes", "Keeps most of IR1.1's executed schema; fewer providers and weaker tooling. The fallback if CV-03 goes badly for PostgreSQL")])
o += ["## 4. Findings of this assessment", "",
 "1. **Approval must not be a connector tool.** If the token that proposes can also approve, a manipulated session can approve its own proposal. Approval belongs outside the session (CD-04).",
 "2. **The server should call no model.** Session summaries and proposals are written by Claude in the session and submitted as data. ADR-001 is retained, which keeps cost and attack surface down.",
 "3. **The service does not need GitHub credentials.** Claude Code already works with repositories. The service stores references (CD-08).",
 "4. **'Public information only' no longer describes the content.** Project knowledge, session summaries and code references are private. IR1.1 named a change of classification as the trigger for mandatory encryption and stronger controls (CD-01).",
 "5. **The repositories visible today are public.** The directive speaks of existing private repositories; the five this session can list are all public and none is for this project. Either private ones exist that this session cannot see, or they do not exist yet (CV-01).",
 "6. **Client-side protections are gone.** IR1.1 relied on a sandbox and permission rules in one workspace. Sessions that use the brain will run in other projects, with web access and other tools. Everything the connector receives is untrusted, and anything it returns can leave through the session's other tools.",
 "7. **A project can shadow the connector.** Claude Code resolves a server name defined in several places in the order local, project, user, plugin, claude.ai connector. A repository that defines a server with the connector's name would be used instead, after an approval prompt in interactive sessions. It could not read the brain, but it could feed false context and receive what the session submits (CR-22, CV-06).",
 "8. **Automatic session capture is not universal.** Hooks exist for the end of a turn and of a session and can call an HTTP endpoint or an MCP tool, but cloud sessions do not read a user's own settings, and the session-end hook has a short time budget. Explicit closing with a summary works wherever tools work (CD-07).",
 "9. **PostgreSQL's Arabic behaviour is unmeasured.** IR1.1's normalisation and stemming are in the application and carry over. How the PostgreSQL tokenizer treats the result has not been run (CV-03).",
 "10. **Recovery has a price.** On the one provider checked, the free plan pauses a project after a week without activity and has no automatic backups, and point-in-time recovery costs US$100 a month per seven days. An independent export is the affordable route to a daily recovery point.",
 "11. **Skills change sides.** IR1.1 treated personal and synced skills as a risk to switch off. A bootstrap skill that must be present in every environment is exactly such a skill (CD-14).",
 "12. **The plan grew.** V5.0, still a mandatory reference, criticised infrastructure built before a need was shown. Cloud hosting is now a stated need; the dashboard, repository synchronisation, knowledge graph and mobile interface are not yet (CD-16).", "",
 "## 5. What v6.0-CN1 is and is not", "",
 "It is a transition assessment and an architecture-level successor: dispositions, boundaries, models, decisions, gates. It is not yet an implementation baseline. IR1.1 had an executed schema, a command specification and 143 designed tests; the successor's database schema, tool schemas, rewritten requirements and test cases are written after the owner's answers, because each depends on CD-02, CD-04, CD-05 or CD-06."]
wr("docs/02-CLOUD-TRANSITION-ASSESSMENT.md", o)

pres = [r for r in ALL if IMPACT[r["id"]][0] in ("RETAINED", "DEFERRED")]; mod = [r for r in ALL if IMPACT[r["id"]][0] in ("AMENDED", "SUPERSEDED")]
AREA = {"CR-01": "Cloud hosting", "CR-02": "Remote MCP", "CR-03": "Authentication and authorisation", "CR-04": "Authentication and authorisation", "CR-05": "Authentication and authorisation", "CR-06": "Cross-environment knowledge", "CR-07": "GitHub",
 "CR-08": "Session persistence", "CR-09": "Cross-environment knowledge", "CR-10": "Object storage", "CR-11": "Object storage", "CR-12": "Cloud security", "CR-13": "Cloud security", "CR-14": "Cloud recovery", "CR-15": "Cloud recovery",
 "CR-16": "Remote MCP", "CR-17": "Cloud security", "CR-18": "Authentication and authorisation", "CR-19": "Remote MCP", "CR-20": "Cost", "CR-21": "Obsidian interoperability", "CR-22": "Remote MCP", "CR-23": "Cloud hosting", "CR-24": "Cloud hosting"}
AREA.update(AREA_EXTRA)
o = H("DOC-CN-04A", "Cloud-Native Requirements Coverage Matrix") + ["Three categories, as the owner asked on 2026-11-10, so that the successor is not the old 100 requirements in new words.", "",
 f"- **Preserved: {len(pres)}.** IR1.1 requirements that apply unchanged in behaviour.", f"- **Modified: {len(mod)}.** IR1.1 requirements that must change ({cnt['AMENDED']} amended, {cnt['SUPERSEDED']} superseded).", f"- **New: {len(CR)}.** Requirements that exist only because of cloud hosting, the remote connector, authentication, cross-environment access and cloud recovery.", "",
 "## 1. New requirements by capability", ""] + T(["Capability", "New requirements"], [(a, ", ".join(c for c, _ in CR if AREA[c] == a)) for a in sorted(set(AREA.values()))])
o += T(["ID", "Requirement", "Capability", "Proposed test"], [(c, t, AREA[c], ", ".join(x[0] for x in CT if c in x[2]) or "—") for c, t in CR])
o += ["## 2. Modified", ""] + T(["Requirement", "Title", "Change", "Related new requirement"], [(r["id"], r["title"], IMPACT[r["id"]][0] + ": " + IMPACT[r["id"]][1], IMPACT[r["id"]][2]) for r in mod])
o += ["## 3. Preserved", "", ", ".join(r["id"] for r in pres) + ".", "",
 "## 4. Feasible is not verified", "", "Three different claims, kept apart: **documented** (the vendor's documentation says it works), **observed** (seen once in a real environment), **verified for this system** (tested against this service). Nothing is in the third column yet, because no service exists.", ""]
o += T(["Capability", "Documented", "Observed", "Verified for this system", "What it does not prove"], [
 ("Remote HTTP MCP server with OAuth in Claude Code", "Yes", "No", "No", "That every environment you use connects"),
 ("Connectors configured in claude.ai available to Claude Code", "Yes", "Yes, for vendor connectors, in the cloud session that produced this package", "No", "That a custom server behaves the same"),
 ("Reaching the service from a cloud session", "Network access is configurable per cloud environment", "No", "No", "That the default setting allows your domain"),
 ("Session summary submitted by a tool call", "Follows from tool support", "No", "No", "That it happens without being asked"),
 ("Event capture by hooks", "Yes: end-of-turn and end-of-session hooks, HTTP and MCP-tool types", "No", "No", "Capture in cloud sessions, which do not read your own settings; capture within the short end-of-session budget"),
 ("Complete transcript capture", "A local transcript file exists and is written asynchronously", "No", "No", "Any supported way to collect it from every environment. Not assumed"),
 ("Bootstrap skill present in every session", "Skills load from repository, personal and synced locations", "No", "No", "Presence in a given environment"),
 ("Arabic retrieval on PostgreSQL", "PostgreSQL has full-text search", "No", "No", "Any quality or tokenizer behaviour. The probe was not run"),
 ("Approval prompts before tool calls", "Not stated in the documentation read", "No", "No", "Anything; approval is designed not to depend on it")])
wr("docs/04A-CLOUD-REQUIREMENTS-COVERAGE-MATRIX.md", o)

o = H("DOC-CN-05", "Cloud Target Architecture") + ["## 1. Components", "", "```", "Claude Code session (terminal, desktop, cloud, mobile)", "   │  HTTPS, OAuth, grant: scopes (read, propose, originals), projects, class ceiling", "   ▼", "Remote MCP server ── narrow tools only", "   │", "Knowledge service (Python) ── policy gate, proposals, audit", "   │                    │                      │", "Managed PostgreSQL   Object storage         Scheduler", "registry, search     immutable originals    backup, verify, expiry", "   │                    │", "   └── Independent encrypted export ──► second provider", "", "Owner ── passkey ──► Approval surface and authorisation server (own origin; no connector token accepted)", "GitHub ── code, protocols, releases; referenced by the service, never written by it", "Obsidian ── reads a Markdown export", "```", "",
 "## 2. Responsibilities", ""] + T(["Component", "Does", "Never does"], [
 ("Claude Code", "All reasoning; writes summaries and proposals; does repository work with its own access", "Approves; writes to the database"),
 ("Remote MCP server", "Authenticates, checks scope, validates input, limits rate and size, returns evidence", "Runs SQL or shell from input; exposes approval; writes to GitHub"),
 ("Knowledge service", "Is the only writer: registry, memory lifecycle, proposals, audit chain", "Calls a model"),
 ("PostgreSQL", "Holds governed state and the search index; enforces constraints", "Is reachable from the internet"),
 ("Object storage", "Holds originals, attachments, exports, backup staging; private", "Holds secrets or public objects"),
 ("Approval page", "Shows a proposal's exact change and records the owner's decision", "Accepts a connector token"),
 ("Scheduler", "Backups, verification, expiry, index maintenance", "Runs anything not allowlisted"),
 ("GitHub", "Versions code, protocols, ADRs, releases, and exports if the owner asks", "Acts as the live database")])
o += ["## 3. Flows", "", "- **Retrieve.** Session calls search with a query and optional project; the service returns ranked passages with locators, project and state, inside a size budget.",
 "- **Propose.** Session submits a candidate with its evidence; the service validates, de-duplicates, binds it to the versions it depends on, and queues it within the limits of GAP-033.",
 "- **Approve.** The owner opens the approval page, sees the exact change, approves or rejects with a passkey; the service applies it in one transaction and writes the audit event.",
 "- **Ingest a document.** Upload to staging; the worker inspects and extracts in isolation; the original becomes an immutable object, then the rows commit.",
 "- **Close a session.** Session submits summary, artifact references, open issues and next actions; durable knowledge inside it becomes proposals, not facts.",
 "- **Export.** Deterministic Markdown and JSON to object storage, and to a repository only if the owner asks.",
 "- **Back up.** Provider backup daily; independent encrypted export daily; restore-test on a schedule.", "",
 "## 4. Deliberately absent", "", "A custom chat application; a server-side model; repository writes by the service; third-party MCP servers; vector search before gate RET-G2; a graph database; full transcript storage by default.", "",
 "## 5. First usable slice", "", "Search and retrieve, propose, approval page, session open and close, backups with a passed restore-test. Everything else waits for use to justify it (CD-16)."]
wr("docs/05-CLOUD-TARGET-ARCHITECTURE.md", o)

o = H("DOC-CN-06", "GitHub Repository and Synchronisation Strategy") + ["## 1. What exists (read-only listing, 2026-11-10)", ""] + T(["Repository", "Visibility", "Last push"], [
 ("mh1m1m/CDF_Notification_Generator", "public", "2026-11-09"), ("mh1m1m/CDF_GC_Review", "public", "2026-11-09"), ("mh1m1m/CDF_Case_Management", "public", "2026-11-07"), ("mh1m1m/Prodysia", "public", "2025-08-31"), ("mh1m1m/novel", "public", "2025-08-20")])
o += ["Nothing was created, changed or cloned. None of the five is an AI Second Brain, Morphaze or Maritime AI repository. The owner's directive refers to existing private repositories; none is visible to this session (CV-01). Whether the five above are meant to be public is the owner's call and worth a look before any of them is linked to a knowledge system.", "",
 "## 2. Proposed repositories", ""] + T(["Repository", "Visibility", "Holds", "When"], [
 ("Platform (name to be chosen by the owner)", "Private", "Service and connector source, migrations, tests, infrastructure definitions, the bootstrap skill, this specification and its ADRs, release manifests", "Created only under the Cloud Implementation Instrument"),
 ("Project repositories", "As the owner decides", "Each project's own code and documents", "Existing ones are linked, never duplicated"),
 ("Knowledge export", "Private", "Approved Markdown exports and manifests", "Not at first (CD-09); only if the owner asks for exports in Git")])
o += ["A conversation is not a project, and no repository is created per conversation.", "", "## 3. What the service does with GitHub", "",
 "It stores references: repository, branch, commit, pull request, release. It holds no GitHub credential (CD-08). Commit, push, merge, release and deploy stay separate actions done by Claude Code or the owner under the repository's own protections. A successful commit says nothing about the database, and the reverse.", "",
 "## 4. Governance for the platform repository", "", "Private; protected default branch; pull-request review for consequential changes; secret scanning and dependency scanning; tests in continuous integration; tagged releases with checksums; no deployment triggered by a commit.", "",
 "## 5. Never in a repository", "", "Credentials, tokens, decrypted backups, database dumps, originals, personal knowledge that the owner has not explicitly exported."]
wr("docs/06-GITHUB-REPOSITORY-STRATEGY.md", o)

o = H("DOC-CN-07", "Cloud Data Authority Model") + ["One authority and one writer for each class. Everything else is a copy or a projection and loses any conflict.", ""] + T(["Data class", "Authority", "Writer", "Copies and projections", "Conflict rule"], [
 ("Source code", "GitHub repository", "Claude Code and the owner", "Release archives", "Git"),
 ("Specification and ADRs", "Platform repository", "Owner-approved changes", "This package", "Git"),
 ("Original documents", "Object storage, by content hash", "The service", "Backups", "Immutable; a different hash is a different object"),
 ("Canonical knowledge and memory records", "PostgreSQL", "The service, on approval", "Markdown and JSON export; search index", "Database wins; an edited export is a proposal"),
 ("The owner's notes", "PostgreSQL (recommended, CD-06)", "The service, on the owner's action", "Markdown export", "As above"),
 ("Project memory, decisions, approvals", "PostgreSQL", "The service", "Export", "Database wins"),
 ("Session records", "PostgreSQL", "The service, from what the session submits", "None", "Append-only"),
 ("Audit events", "PostgreSQL, hash-chained", "The service", "Chain head in every backup", "Never edited"),
 ("Search index", "Derived", "The service", "—", "Rebuilt from canonical data"),
 ("Generated Markdown", "Derived", "The service", "Obsidian vault; export repository if used", "Regenerated"),
 ("Backups", "Second provider", "The scheduler", "—", "Verified against manifest"),
 ("Secrets", "Secret manager", "The owner", "None", "Never copied")])
o += ["Synchronisation is one-way from the authority outward. The only inward path is a validated re-import that produces proposals (CR-21)."]
wr("docs/07-CLOUD-DATA-AUTHORITY-MODEL.md", o)

o = H("DOC-CN-08", "Claude Code Remote MCP Integration") + [NOTE, "", "## 1. What the documentation establishes (read 2026-11-10; nothing tested)", "",
 "- HTTP is the recommended transport for remote servers; SSE is deprecated. OAuth works with HTTP servers and tokens are stored and refreshed by Claude Code.",
 "- A server can be configured per user, per project (a file in the repository) or locally. Claude Code also uses connectors configured in the owner's claude.ai account.",
 "- When one name is defined in several places the order is local, project, user, plugin, claude.ai connector. Project-defined servers need approval in interactive sessions.",
 "- Tool output is limited to 25,000 tokens by default, with a warning above 10,000.",
 "- Elicitation is supported in interactive terminal sessions.", "",
 "## 2. Where the connector is configured", ""] + T(["Placement", "Reaches", "Note"], [
 ("Connector in the owner's claude.ai account", "Every surface that uses account connectors", "Lowest precedence, so it can be shadowed (finding 7)"),
 ("User scope on a machine", "All projects on that machine", "Not available to cloud sessions"),
 ("Project file in the platform repository", "Sessions in that repository", "Appropriate there; not in other projects")])
o += ["Recommended: the account connector as the general route, the project file in the platform repository. Which environments this actually covers is CV-02.", "",
 "## 3. Proposed tools", "", "Names are proposals. Every tool validates input against a schema, is rate-limited, returns content marked as data, and writes an audit event.", ""] + T(["Tool", "Scope", "Effect"], [
 ("brain_health", "read", "Identity of the service, version, the caller's scopes"), ("brain_search", "read", "Ranked passages with locators, project and state; at most about 8,000 tokens"),
 ("brain_retrieve", "read", "One record, note or passage by ID"), ("brain_projects_list, brain_projects_get", "read", "Projects, repository references, open decisions"),
 ("brain_sessions_open, brain_sessions_close", "propose", "Register a session; close it with summary, artifact references, open issues, next actions"),
 ("brain_artifacts_register", "propose", "Reference to a file, commit or document"), ("brain_propose", "propose", "A proposed knowledge change with evidence"),
 ("brain_proposals_list", "read", "The queue and each proposal's state, with the link to the approval page"), ("brain_provenance", "read", "Evidence and history of a record"), ("brain_audit_query", "read", "Events for a record or session")])
o += ["Not exposed to any connector token: approve, reject, purge, restore, configuration, raw SQL, shell, repository writes, export to a repository.", "",
 "## 4. Bootstrap", "", "A skill, `brain-bootstrap`, that calls brain_health, compares the service identity with the expected value, resolves the project from the current repository, retrieves open work and reports readiness. It changes nothing. It is a convenience: the service trusts the token, never the skill. Owner prompts such as 'Open project X and continue' are served by brain_projects_get and brain_search.", "",
 "## 5. Limits to state plainly", "", "No tool can make a session call it. Retrieval happens when Claude decides to call the connector or the owner asks. See CLOUD-REQUIREMENTS-COVERAGE-MATRIX §4 for what is documented, observed and verified."]
wr("docs/08-CLAUDE-CODE-MCP-INTEGRATION.md", o)

o = H("DOC-CN-09", "Cross-Project and Cross-Session Memory Architecture") + ["## 1. Entities", "", "Workspace, project, session, artifact, knowledge record. They are related, not nested folders. IR1.1 already has projects, items, decisions, memory records, revisions and evidence links; two entities are added: session and session event.", "",
 "## 2. Three layers", ""] + T(["Layer", "Holds", "How it gets there", "Retention"], [
 ("Session archive", "Session identity, project, times, summary, artifact and commit references, open issues, next actions; events only where a repository opts in", "Submitted by the session", "Configurable; summaries kept, events expiring"),
 ("Project memory", "State, decisions, findings, unresolved questions", "Proposals from sessions and documents, approved by the owner", "Persistent, versioned"),
 ("Canonical knowledge", "Verified, reusable records with evidence", "IR1.1's lifecycle: captured, proposed, verified, disputed, superseded, archived", "Persistent, versioned")])
o += ["A session of two hundred messages may yield five proposals. Nothing an AI wrote becomes canonical without evidence and approval; AI interpretation is stored as such (IR1.1's epistemic types).", "",
 "## 3. Three kinds of capture, kept distinct", ""] + T(["Kind", "Mechanism", "Status"], [
 ("Session summary", "A tool call when the owner closes the session", "Feasible wherever tools work; the recommended baseline (CD-07)"),
 ("Event capture", "End-of-turn or end-of-session hooks posting to the service", "Feasible per repository; not in cloud sessions unless the repository carries the hook; UNVERIFIED (CV-07)"),
 ("Automatic transcript capture", "None supported across environments", "Not promised")])
o += ["## 4. Lifecycle of a memory", "", "Capture eligible material → identify candidates → check duplicates → detect contradictions → attach provenance → propose → apply approval policy → commit → update index → keep the audit trail. Each step exists in IR1.1 (FR-MEM-001 to FR-MEM-012, FR-AGT-003); the cloud changes where candidates come from, not the steps.", "",
 "## 5. Across projects", "", "Every record belongs to a project or to the workspace. What a session can search is decided by its grant and by each project's sharing policy (PROJECT-ACCESS-AND-EXFILTRATION, CD-11); every result names its project. A record reused in another project is linked, not copied, so its provenance stays single."]
wr("docs/09-SESSION-PERSISTENCE-ARCHITECTURE.md", o)

o = H("DOC-CN-10", "Cloud Security and Authorisation Model") + ["Architecture level. The token model, schemas and classification rules are completed after CD-01, CD-04 and CD-05. A prompt instruction is never counted as a control, and neither is any setting of the client.", "",
 "## 1. Trust boundaries", "", "1. Session and its project (untrusted: other tools, web content, repository files, other MCP servers).", "2. Connector edge (authentication, scope, validation, limits).", "3. Service (policy gate, sole writer).", "4. Data stores (private network, separate roles).", "5. Owner's approval and administration path (passkey).", "6. Backup provider (ciphertext only).", "",
 "## 2. Enforcement layers (replacing IR1.1's five)", ""] + T(["Layer", "Mechanism", "Carried from IR1.1"], [
 ("S1", "Identity: OAuth for the connector, passkey for the owner", "New"), ("S2", "Token scope per tool; approval outside every connector scope", "New; replaces Claude Code permission rules"),
 ("S3", "Service policy gate: valid, hash-bound, unexpired, unconsumed approval for the tier", "L3"), ("S4", "Database constraints and triggers; separate database roles", "L4"),
 ("S5", "Detection: audit hash chain, chain head in backups, schema hash, grant inventory, cost alarm", "L5")])
o += ["## 3. Threats", ""] + T(["ID", "Threat", "Control", "Layer", "Remaining uncertainty"], [
 ("CS-01", "Stolen connector token", "Short expiry, revocation, reads only up to its ceiling, proposes only", "S1, S2", "Reading is still exposure of private knowledge"),
 ("CS-02", "Manipulated session approves its own proposal", "Approval not reachable from the connector", "S2, S3", "None by design; depends on CD-04"),
 ("CS-03", "Injected text in a document or web page drives proposals", "Proposals only; queue limits; owner sees the exact change", "S3", "Owner approving without reading"),
 ("CS-04", "Retrieved knowledge leaves through the session's other tools", "None on the client; restricted projects; minimal results", "—", "Accepted risk to decide in CD-13"),
 ("CS-05", "A project shadows the connector's name", "Identity check at bootstrap; unique name", "Detection", "Client behaviour UNVERIFIED (CV-06)"),
 ("CS-06", "Hostile file exploits a parser", "Isolated, limited worker without network", "Service", "Parser flaws inside limits"),
 ("CS-07", "Database reached directly", "No public endpoint; roles; provider network controls", "S4", "Provider-dependent (CV-09)"),
 ("CS-08", "Public bucket or leaked object link", "Private buckets; short-lived signed access", "Service", "Provider-dependent"),
 ("CS-09", "Provider operator or breach", "Encryption at rest; backups encrypted with the owner's key", "—", "Live data is readable by the provider's systems"),
 ("CS-10", "Secrets in repository, prompt or note", "Secret manager; scanning", "Detection", "Human error"),
 ("CS-11", "Tampering with history", "Immutable revisions; audit chain; chain head in backups", "S4, S5", "Detection, not prevention, against a database administrator"),
 ("CS-12", "Runaway usage or cost", "Limits; alarm; ceiling", "S5", "—"),
 ("CS-13", "Loss of the owner's passkey or backup key", "Documented recovery procedure tested in the drill", "Procedure", "A procedure, not a technical control"),
 ("CS-14", "Other MCP servers or skills in the same session", "Nothing trusted from the client; server-side checks only", "S1 to S4", "They can read what the session reads")])
o += ["## 4. What changed for the worse, stated plainly", "", "IR1.1 kept public content on a private disk. The successor keeps private content on a public network. Confidentiality becomes a primary requirement; the service is reachable by anyone who can guess its address; and one person carries patching, key rotation and incident response."]
wr("docs/10-CLOUD-SECURITY-ARCHITECTURE.md", o)

o = H("DOC-CN-11", "Cloud Backup and Disaster Recovery") + ["Replaces the external-disk design of D-06 and ADR-010. The rule of GAP-034 is unchanged: no owner data before a backup has been restored and checked.", ""] + T(["Aspect", "Proposal"], [
 ("What", "Database (logical dump), originals and attachments, configuration and repository mappings, the latest Markdown and JSON export, a manifest with SHA-256 per item, schema version and audit chain head"),
 ("Where", "First line: the provider's own daily backups. Second line: a daily export encrypted before it leaves, stored at a second provider in a separate account"),
 ("Keys", "Public-key encryption. The backup job holds only the public key and can encrypt but not decrypt. The private key is generated and held by the owner, with an offline recovery copy, and is never placed with any provider"),
 ("When", "Daily; before every migration; on demand"),
 ("Verification", "Unattended: after writing, the ciphertext is re-read and its checksum compared with the manifest; the job may read what it wrote but cannot decrypt or delete. Owner-run drill, with the private key: restore into a scratch database and bucket and check integrity, foreign keys, audit chain, sampled originals, index rebuild. Once before any real data, then on the owner's schedule"),
 ("Objectives", "Recovery point 24 hours. Recovery time unmeasured; set after the first drill. IR1.1's provisional figures are not silently changed: the point is the same, the time was never measured"),
 ("Retention", "14 daily and 8 weekly, as proposed in IR1.1, enforced by the backup store's own lifecycle rules, not by the job"),
 ("Point-in-time recovery", "An optional provider add-on; not assumed, because of its price on the provider checked"),
 ("Exit drill", "Once before real data and yearly: load a full export into an empty environment at a different provider (CR-15)"),
 ("Runbooks", "Lost database; lost object store; lost provider account; lost key or passkey; suspected compromise; cost alarm")])
o += ["GitHub history is not a backup of the database or of the originals. Decision: CD-10."]
wr("docs/11-CLOUD-BACKUP-AND-RECOVERY.md", o)

o = H("DOC-CN-12", "Arabic-First Retrieval and Benchmark Strategy") + ["## 1. What carries over unchanged", "", "The normaliser `ar-en-1` and light stemmer `ar-light-1` (application code, engine-independent); indexing normalised text and stemmed text separately; excerpts taken from originals; six outcome classes; benchmark BENCH-1 with its strata; thresholds of NFR-007 (Recall@10 at least 0.90 overall and 0.85 per language, provisional); gates RET-G1 and RET-G2; no vector search before RET-G2.", "",
 "## 2. What changes", "", "Only the engine underneath. Three candidate designs on PostgreSQL:", ""] + T(["Design", "How", "Expectation", "Status"], [
 ("A", "Full-text search with a plain configuration over the application-normalised and stemmed columns", "Closest to IR1.1's measured SQLite behaviour, because the application does the language work", "UNVERIFIED"),
 ("B", "PostgreSQL's built-in Arabic configuration on raw text", "Unknown handling of diacritics, letter variants and clitics", "UNVERIFIED"),
 ("C", "Trigram matching on normalised text", "Tolerant of spelling variants; weaker ranking", "UNVERIFIED")])
o += ["## 3. Evidence that exists and evidence that does not", "", "Measured in IR1.1's sandbox on SQLite: raw indexing failed all nine variant probes; normalised and stemmed indexing answered eight; broken plurals were missed. **Nothing has been run on PostgreSQL.** A probe was proposed in this pass and was not run. Until CV-03 is run, any statement about Arabic retrieval on PostgreSQL is an expectation, not a result, and CD-02 is conditional on it.", "",
 "## 4. Probe and benchmark", "", "CV-03 repeats IR1.1's probe (twelve synthetic sentences, seventeen queries) for designs A, B and C on the candidate provider's PostgreSQL version and compares each result with the SQLite record. The benchmark gate is unchanged and gains two strata for the cloud product: questions whose evidence lies in another project, and questions that must not return a restricted project's records."]
wr("docs/12-ARABIC-RETRIEVAL-AND-BENCHMARK.md", o)

o = H("DOC-CN-13", "Obsidian Interoperability Strategy") + ["Obsidian is an optional reader of an export. It is not the database, and nothing here claims a hosted, browser-based Obsidian.", "", "## 1. Export contract", "",
 "- One folder per project plus a workspace folder; deterministic filenames: title for the owner's notes, ID for managed notes (IR1.1 D-14 carried as convention).", "- Flat YAML properties with the stable `id`, type, project, state, dates and source references.", "- Wikilinks by ID-resolved title; backlinks follow from links; block anchors for memory records in digest notes.",
 "- Attachments referenced by content hash; originals are not duplicated into the vault unless asked.", "- Arabic and mixed-direction text follow IR1.1's right-to-left rules.", "- Identical state produces a byte-identical export.", "",
 "## 2. Getting the export to a device", "", "Download as an archive, or a private export repository cloned by the device (CD-09). Either way the vault is a copy.", "",
 "## 3. Re-import", "", "Optional and later (CD-12). An edited file is parsed, validated against the schema, compared with the record's current version, and turned into a proposal. Managed properties edited by hand are ignored and reported. Nothing is overwritten without conflict detection and approval.", "",
 "## 4. If browser-only visual work is wanted", "", "That is a separate web interface and a separate decision, not Obsidian."]
wr("docs/13-OBSIDIAN-INTEROPERABILITY.md", o)

o = H("DOC-CN-14", "Cloud Provider Comparison and Cost Estimates") + [NOTE, "", "No provider is selected. Only one provider's prices were confirmed in this pass; statements about the others come from general knowledge and are marked UNVERIFIED so that they are checked before any decision (CV-09).", "",
 "## 1. Criteria", "", "Managed PostgreSQL; a place to run a Python service and an isolated worker; private object storage; secret management; backups and their price; region and data residency; private networking; export; recurring cost at one user's scale; how hard it is to leave.", "",
 "## 2. Candidates", ""] + T(["Candidate", "Would provide", "Points to weigh", "Evidence"], [
 ("Supabase", "PostgreSQL, object storage, authentication", "Free plan: project paused after one week of inactivity, limit of two projects, no automatic backups. Pro: from US$25 a month; one project on the default compute comes to about US$25 after the included credit. Point-in-time recovery US$100 a month per seven days of retention. The Python service would run elsewhere. An account connector for it appeared in this session; it was not queried", "Prices VERIFIED 2026-11-10 from its pricing page; the rest UNVERIFIED"),
 ("Neon", "Serverless PostgreSQL", "Scale-to-zero and branching; region list and prices not checked", "UNVERIFIED"),
 ("A large cloud (AWS, Google Cloud, Azure)", "Everything, including regions in the Middle East", "Most control over residency and networking; most configuration and usually the highest floor price", "UNVERIFIED"),
 ("Cloudflare", "Object storage, edge compute, a SQLite-based database", "Relevant to option O4 and as an independent backup target; Python support for its compute not checked", "UNVERIFIED"),
 ("A container host (for the Python service)", "Runs the service and worker beside a managed database", "Needed with any database-only provider", "UNVERIFIED")])
o += ["## 3. Cost", "", "What can be said on today's evidence: a persistent, never-paused managed PostgreSQL with daily backups starts at about US$25 a month on the provider checked; hosting for the Python service, storage beyond the included amount and a second provider for backups come on top and are not priced here. No free tier examined is suitable for a system whose point is persistence. A planning ceiling is the owner's to set (CD-03); a figure from me now would be a guess.", "",
 "## 4. Residency", "", "The owner is in Saudi Arabia. Whether personal knowledge must stay in a particular country or region is a question for the owner, and for whoever owns any non-personal material if CD-01 admits it. I am not a lawyer; this is a factor to decide, not advice.", "",
 "## 5. Leaving a provider", "", "PostgreSQL dumps, S3-style object copies, Markdown and JSON exports. Provider-specific features (their authentication service, their row-level policy language, their functions) are where lock-in enters; the design keeps authorisation in the service for that reason."]
wr("docs/14-CLOUD-PROVIDER-EVALUATION.md", o)

o = H("DOC-CN-15", "Cloud Implementation Roadmap") + ["Nothing below is authorised. Each phase states what authorisation it needs.", ""] + T(["Phase", "Content", "Needs", "Reversible"], [
 ("CP0 Architecture approval", "Owner answers CLOUD-OWNER-DECISIONS; independent review; detailed design: database schema, tool schemas, rewritten requirements and tests", "Specification-only (current)", "Yes"),
 ("CP1 Cloud verification", "CV-01, CV-03 to CV-12 that need no deployed service", "Cloud Verification Instrument", "Yes: read-only and synthetic"),
 ("CP2 Development foundation", "Platform repository; domain model; migrations; tests on an isolated database; continuous integration", "Cloud Implementation Instrument, stage 1", "Yes: no cloud resources, no data"),
 ("CP3 Infrastructure", "Provider accounts, database, storage, secrets, networking", "Stage 2, with provider and cost approved", "Costs begin"),
 ("CP4 Backend", "Registry, ingestion, memory lifecycle, proposals, audit, search; **backup and restore-test pass before any owner data**", "Stage 2", "Yes until data is loaded"),
 ("CP5 MCP integration", "Connector, authentication, scopes, bootstrap skill, approval page; CV-02, CV-13", "Stage 2", "Yes"),
 ("CP6 GitHub integration", "Repository mapping by reference", "Stage 2", "Yes"),
 ("CP7 Knowledge intelligence", "Deduplication, contradiction handling, cross-project retrieval; retrieval gate on the pilot corpus", "Owner's pilot corpus (D-10 carried)", "Yes"),
 ("CP8 Session persistence", "Session open and close; optional event capture", "CD-07", "Yes"),
 ("CP9 Obsidian interoperability", "Export; later re-import", "CD-12", "Yes"),
 ("CP10 Production acceptance", "Security suite, exit drill, restore drill, owner acceptance", "Separate acceptance decision", "—")])
o += ["Order of first use: CP0 → CP1 → CP2 → CP3 → CP4 → CP5, then real data. CP6 to CP9 follow use. Reversible preparatory work is CP0, CP1 and CP2; everything from CP3 on spends money or holds data."]
wr("docs/15-CLOUD-IMPLEMENTATION-ROADMAP.md", o)

o = H("DOC-CN-16", "Updated Acceptance Tests") + [f"Designed, not executed; no service exists. IR1.1's {len(TESTS)} designed tests, classed by the most affected requirement each covers: keep {tcls['keep']}, adapt {tcls['adapt']}, replace {tcls['replace']}. The list below is what the cloud adds. Detailed cases (data, steps, expected result) are written with the detailed design.", ""] + T(["ID", "Test", "Covers", "Area"], CT)
o += ["## End-to-end demonstration, synthetic data only", "", "Initialise a test workspace → create two projects → ingest sample documents in Arabic and English → open and close test sessions → retrieve across projects → propose an update → show an unauthorised change refused → approve a permitted change on the approval page → verify provenance → export Markdown → restore from the independent backup into a scratch environment."]
wr("docs/16-CLOUD-ACCEPTANCE-TESTS.md", o)

o = H("DOC-CN-17", "Consolidated Cloud Owner-Decision Register") + ["> **Nothing here is approved.** Recommendations are PROPOSED. An empty answer means not decided. IMPLEMENTATION NOT AUTHORIZED.", "",
 "## 1. Recorded from the owner on 2026-11-10", "", "- Cloud-native operation is a confirmed product requirement.", "- The transition directive governs; the master implementation directive is design input only.", "- IR1.1 is an immutable historical baseline and is not to be implemented unchanged.", "- Managed PostgreSQL is the leading candidate for the database, not a final selection.", "- GitHub is not the live database. Obsidian is optional.", "- Still in force from before: Arabic first, bilingual (D-02); V5.0 as mandatory reference (D-05).", "",
 "## 2. No longer asked", "", "D-06 as an external disk, D-07 Mac folders, D-08 terminal and prompt channels, D-11 as a workspace setting, D-12 as a deferral of other environments, D-16 Git in a local vault, D-19 Mac instruments, D-20 as written. Each is replaced below.", "",
 "## 3. Decisions", ""] + T(["ID", "Question", "Recommendation", "Main alternative", "Consequence"], CD)
o += ["## 4. Answer record", "", "APPROVE, APPROVE_WITH_AMENDMENT, REJECT or DEFER.", ""] + T(["Item", "Answer", "Note", "Date"], [(c[0] + " " + c[1].split("?")[0].split(" (")[0], "", "", "") for c in CD] + [("Cloud Verification Instrument", "", "", ""), ("Cloud Implementation Instrument", "", "", "")])
wr("docs/17-CLOUD-OWNER-DECISIONS.md", o)

o = H("DOC-CN-18", "Cloud-Transition Readiness Certificate") + ["Concerns this package only. IR1.1's certificate is preserved and says nothing about the cloud successor; its gate G8 remains NOT_VERIFIED.", ""] + T(["Gate", "Subject", "Result", "Basis"], GATES)
o += ["## Verdict", "", "**READY FOR OWNER DECISIONS ON THE ARCHITECTURE. NOT AN IMPLEMENTATION BASELINE.**", "",
 "Four gates pass as proposals, one waits on the owner, four are partial and two are not verified. The partial gates close with the detailed design that follows the owner's answers. The unverified gates close only with checks under the Cloud Verification Instrument and a review by someone other than the author.", "",
 "## Independent review", "", "Not performed. No independent adversarial review report is included, because none took place. The author's own checks are in `tools/cn_lint.py`.", "",
 "## Authorisation", "", "IMPLEMENTATION NOT AUTHORIZED."]
wr("docs/18-CLOUD-READINESS-CERTIFICATE.md", o)

o = H("DOC-CN-20", "Cloud Authorisation Instruments") + ["Both are drafts. Neither is authorised by being written. IR1.1's Instruments A and B concerned a Mac and are historical.", "",
 "## Cloud Verification Instrument (draft, not granted)", "", "Permits read-only and synthetic checks only:", ""] + T(["Item", "Check", "Kind", "Instrument"], [(c[0], c[1], c[2].split(":")[0], "Implementation" if "Implementation Instrument" in c[2] else "Verification") for c in CV])
o += ["Prohibits: creating or changing any repository; provisioning any cloud resource; any cost; any owner data; application code. Two items need something a session does not already have, and the instrument must grant each by name or leave it out: CV-15 needs read-only listing access to the whole account, given by the owner for that purpose; CV-03 needs a temporary PostgreSQL instance holding twelve synthetic sentences. Results go to a verification record with what was observed and where.", "",
 "For CV-03, say where: a temporary instance inside the specification sandbox (no provider, no cost), or leave it to the Implementation Instrument.", "",
 "## Cloud Implementation Instrument (draft template, not granted, not to be issued yet)", "", "To be completed after the successor baseline is approved (CD-17). It must name:", "",
 "- The approved baseline version and ADRs.", "- Stage 1 (no cloud resources): the repository to create, permitted directories, dependency policy, tests required.", "- Stage 2 (cloud resources): provider, region, resources, monthly ceiling, who holds which credential.",
 "- Security controls that must exist before any owner data: authentication, scopes, approval page, encrypted independent backup with a passed restore-test.", "- What remains forbidden: production data migration, deployment from a commit, public resources.", "- Rollback: how every resource is removed and every cost stopped.", "- Stop conditions: a failed verification item, a cost alarm, a security finding.", "",
 "Items that need this instrument because they need a deployed test service: " + ", ".join(c[0] for c in CV if "Implementation Instrument" in c[2]) + "."]
wr("docs/20-CLOUD-AUTHORIZATION-INSTRUMENTS.md", o)

o = ["# AI Second Brain 6.0 — Proposed Cloud-Native Successor Specification (v6.0-CN1)", "", "**Status: PROPOSED. Nothing approved. IMPLEMENTATION NOT AUTHORIZED.** Owner: Mohammed Alsaleh · 2026-11-10", "",
 f"Predecessor: v6.0-IR1.1, preserved unchanged (archive SHA-256 `{ZSHA}`). This package is separate from it and becomes a baseline only on the owner's explicit approval.", "",
 "## Read first", "", "1. `docs/17-CLOUD-OWNER-DECISIONS.md` — twenty decisions, with recommendations.", "2. `docs/03-ADR-TRANSITION-MATRIX.md` — what happens to each of the 20 ADRs.", "3. `docs/04A-CLOUD-REQUIREMENTS-COVERAGE-MATRIX.md` — preserved, modified, new; feasible versus verified.", "4. `docs/02-CLOUD-TRANSITION-ASSESSMENT.md` §4 — twelve findings.", "5. `docs/18-CLOUD-READINESS-CERTIFICATE.md` — gate results.", "",
 "## Deliverables of the owner's directive", ""] + T(["#", "Deliverable", "File"], [
 (1, "Baseline integrity and preservation report", "01-BASELINE-INTEGRITY-REPORT"), (2, "Architecture transition assessment", "02-CLOUD-TRANSITION-ASSESSMENT"), (3, "ADR-by-ADR disposition matrix", "03-ADR-TRANSITION-MATRIX"),
 (4, "Requirement-by-requirement impact matrix", "04-REQUIREMENTS-IMPACT-MATRIX and 04A-CLOUD-REQUIREMENTS-COVERAGE-MATRIX"), (5, "High-level architecture", "05-CLOUD-TARGET-ARCHITECTURE"), (6, "GitHub strategy", "06-GITHUB-REPOSITORY-STRATEGY"),
 (7, "Data authority and storage model", "07-CLOUD-DATA-AUTHORITY-MODEL"), (8, "Remote MCP integration", "08-CLAUDE-CODE-MCP-INTEGRATION"), (9, "Cross-project and cross-session memory", "09-SESSION-PERSISTENCE-ARCHITECTURE"),
 (10, "Security and authorisation model", "10-CLOUD-SECURITY-ARCHITECTURE"), (11, "Backup and disaster recovery", "11-CLOUD-BACKUP-AND-RECOVERY"), (12, "Arabic-first retrieval and benchmark", "12-ARABIC-RETRIEVAL-AND-BENCHMARK"),
 (13, "Obsidian interoperability", "13-OBSIDIAN-INTEROPERABILITY"), (14, "Provider comparison and cost", "14-CLOUD-PROVIDER-EVALUATION"), (15, "Implementation roadmap", "15-CLOUD-IMPLEMENTATION-ROADMAP"),
 (16, "Acceptance tests", "16-CLOUD-ACCEPTANCE-TESTS"), (17, "Owner-decision register", "17-CLOUD-OWNER-DECISIONS"), (18, "Readiness certificate", "18-CLOUD-READINESS-CERTIFICATE"),
 (19, "Independent adversarial review report", "Not produced: no independent review took place"), (20, "Implementation authorisation instrument", "20-CLOUD-AUTHORIZATION-INSTRUMENTS (with the verification instrument)")])
o += ["## Depth", "", "Architecture level. The database schema, tool schemas, rewritten requirements and detailed test cases follow the owner's answers, because each depends on a decision that is still open.", "",
 "## Checking", "", "`python3 -I tools/cn_lint.py <this folder> <IR1.1 folder>` checks that all 20 ADRs and all 100 requirements are covered, that every identifier resolves, and that the answer record is empty. `MANIFEST.md` lists every file with its SHA-256."]
wr("README.md", o)
exec(open(os.path.join(HERE, "cn11_docs.py"), encoding="utf-8").read())
print("docs ok")
