# AI Second Brain 6.0 — Proposed Cloud-Native Successor Specification (v6.0-CN1.1)

**Status: PROPOSED. Nothing approved. IMPLEMENTATION NOT AUTHORIZED.** Owner: Mohammed Alsaleh · 2026-11-10

Predecessor: v6.0-IR1.1, preserved unchanged (archive SHA-256 `0dcc02510a6878079e79a303dc2a5864f204eb1a1766076ff765a6062f09353f`). This package is separate from it and becomes a baseline only on the owner's explicit approval.

## Read first

0. `docs/26-CN1.1-TARGETED-CORRECTIONS-REGISTER.md` — what changed since CN1 and why.
1. `docs/17-CLOUD-OWNER-DECISIONS.md` — twenty decisions, eleven of them revised in CN1.1.
   Then `docs/25-RESIDUAL-RISK-REGISTER.md` — the risks that remain, for you to accept or not.
2. `docs/03-ADR-TRANSITION-MATRIX.md` — what happens to each of the 20 ADRs.
3. `docs/04A-CLOUD-REQUIREMENTS-COVERAGE-MATRIX.md` — preserved, modified, new; feasible versus verified.
4. `docs/02-CLOUD-TRANSITION-ASSESSMENT.md` §4 — twelve findings.
5. `docs/18-CLOUD-READINESS-CERTIFICATE.md` — gate results.

## Deliverables of the owner's directive

| # | Deliverable | File |
|---|---|---|
| 1 | Baseline integrity and preservation report | 01-BASELINE-INTEGRITY-REPORT |
| 2 | Architecture transition assessment | 02-CLOUD-TRANSITION-ASSESSMENT |
| 3 | ADR-by-ADR disposition matrix | 03-ADR-TRANSITION-MATRIX |
| 4 | Requirement-by-requirement impact matrix | 04-REQUIREMENTS-IMPACT-MATRIX and 04A-CLOUD-REQUIREMENTS-COVERAGE-MATRIX |
| 5 | High-level architecture | 05-CLOUD-TARGET-ARCHITECTURE |
| 6 | GitHub strategy | 06-GITHUB-REPOSITORY-STRATEGY |
| 7 | Data authority and storage model | 07-CLOUD-DATA-AUTHORITY-MODEL |
| 8 | Remote MCP integration | 08-CLAUDE-CODE-MCP-INTEGRATION |
| 9 | Cross-project and cross-session memory | 09-SESSION-PERSISTENCE-ARCHITECTURE |
| 10 | Security and authorisation model | 10-CLOUD-SECURITY-ARCHITECTURE |
| 11 | Backup and disaster recovery | 11-CLOUD-BACKUP-AND-RECOVERY |
| 12 | Arabic-first retrieval and benchmark | 12-ARABIC-RETRIEVAL-AND-BENCHMARK |
| 13 | Obsidian interoperability | 13-OBSIDIAN-INTEROPERABILITY |
| 14 | Provider comparison and cost | 14-CLOUD-PROVIDER-EVALUATION |
| 15 | Implementation roadmap | 15-CLOUD-IMPLEMENTATION-ROADMAP |
| 16 | Acceptance tests | 16-CLOUD-ACCEPTANCE-TESTS |
| 17 | Owner-decision register | 17-CLOUD-OWNER-DECISIONS |
| 18 | Readiness certificate | 18-CLOUD-READINESS-CERTIFICATE |
| 19 | Independent adversarial review report | Not produced: no independent review took place |
| 20 | Implementation authorisation instrument | 20-CLOUD-AUTHORIZATION-INSTRUMENTS (with the verification instrument) |

## Added in CN1.1

21 Data classification model · 22 Approval authority architecture · 23 Project access, cross-project sharing and exfiltration limits · 24 Security assurance assessment · 25 Residual-risk register · 26 Targeted corrections register · 27 Adversarial assessment. Documents 01 to 20 are regenerated with amendments; CN1 itself is preserved as delivered (archive SHA-256 `e5e696df0d4a95028c52a1422cc72dd8232260fbd3b53e1b33c2ca3185066222`).

## Depth

Architecture level. The database schema, tool schemas, rewritten requirements and detailed test cases follow the owner's answers, because each depends on a decision that is still open.

## Checking

`python3 -I tools/cn_lint.py <this folder> <IR1.1 folder>` checks that all 20 ADRs and all 100 requirements are covered, that every identifier resolves, and that the answer record is empty. `MANIFEST.md` lists every file with its SHA-256.
