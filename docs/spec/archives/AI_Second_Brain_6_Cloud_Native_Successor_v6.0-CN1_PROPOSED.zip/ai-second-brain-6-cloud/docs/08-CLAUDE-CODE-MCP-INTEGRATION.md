# Claude Code Remote MCP Integration

**DOC-CN-08** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

Evidence words: **VERIFIED** = read in documentation or measured today; **UNVERIFIED** = not checked in this pass; **PROPOSED** = a recommendation awaiting the owner.

## 1. What the documentation establishes (read 2026-11-10; nothing tested)

- HTTP is the recommended transport for remote servers; SSE is deprecated. OAuth works with HTTP servers and tokens are stored and refreshed by Claude Code.
- A server can be configured per user, per project (a file in the repository) or locally. Claude Code also uses connectors configured in the owner's claude.ai account.
- When one name is defined in several places the order is local, project, user, plugin, claude.ai connector. Project-defined servers need approval in interactive sessions.
- Tool output is limited to 25,000 tokens by default, with a warning above 10,000.
- Elicitation is supported in interactive terminal sessions.

## 2. Where the connector is configured

| Placement | Reaches | Note |
|---|---|---|
| Connector in the owner's claude.ai account | Every surface that uses account connectors | Lowest precedence, so it can be shadowed (finding 7) |
| User scope on a machine | All projects on that machine | Not available to cloud sessions |
| Project file in the platform repository | Sessions in that repository | Appropriate there; not in other projects |

Recommended: the account connector as the general route, the project file in the platform repository. Which environments this actually covers is CV-02.

## 3. Proposed tools

Names are proposals. Every tool validates input against a schema, is rate-limited, returns content marked as data, and writes an audit event.

| Tool | Scope | Effect |
|---|---|---|
| brain_health | read | Identity of the service, version, the caller's scopes |
| brain_search | read | Ranked passages with locators, project and state; at most about 8,000 tokens |
| brain_retrieve | read | One record, note or passage by ID |
| brain_projects_list, brain_projects_get | read | Projects, repository references, open decisions |
| brain_sessions_open, brain_sessions_close | propose | Register a session; close it with summary, artifact references, open issues, next actions |
| brain_artifacts_register | propose | Reference to a file, commit or document |
| brain_propose | propose | A proposed knowledge change with evidence |
| brain_proposals_list | read | The queue and each proposal's state, with the link to the approval page |
| brain_provenance | read | Evidence and history of a record |
| brain_audit_query | read | Events for a record or session |

Not exposed to any connector token: approve, reject, purge, restore, configuration, raw SQL, shell, repository writes, export to a repository.

## 4. Bootstrap

A skill, `brain-bootstrap`, that calls brain_health, compares the service identity with the expected value, resolves the project from the current repository, retrieves open work and reports readiness. It changes nothing. It is a convenience: the service trusts the token, never the skill. Owner prompts such as 'Open project X and continue' are served by brain_projects_get and brain_search.

## 5. Limits to state plainly

No tool can make a session call it. Retrieval happens when Claude decides to call the connector or the owner asks. See CLOUD-REQUIREMENTS-COVERAGE-MATRIX §4 for what is documented, observed and verified.
