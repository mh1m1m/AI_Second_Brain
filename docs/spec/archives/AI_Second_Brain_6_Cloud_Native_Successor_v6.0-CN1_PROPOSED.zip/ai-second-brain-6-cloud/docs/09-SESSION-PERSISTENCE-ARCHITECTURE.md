# Cross-Project and Cross-Session Memory Architecture

**DOC-CN-09** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

## 1. Entities

Workspace, project, session, artifact, knowledge record. They are related, not nested folders. IR1.1 already has projects, items, decisions, memory records, revisions and evidence links; two entities are added: session and session event.

## 2. Three layers

| Layer | Holds | How it gets there | Retention |
|---|---|---|---|
| Session archive | Session identity, project, times, summary, artifact and commit references, open issues, next actions; events only where a repository opts in | Submitted by the session | Configurable; summaries kept, events expiring |
| Project memory | State, decisions, findings, unresolved questions | Proposals from sessions and documents, approved by the owner | Persistent, versioned |
| Canonical knowledge | Verified, reusable records with evidence | IR1.1's lifecycle: captured, proposed, verified, disputed, superseded, archived | Persistent, versioned |

A session of two hundred messages may yield five proposals. Nothing an AI wrote becomes canonical without evidence and approval; AI interpretation is stored as such (IR1.1's epistemic types).

## 3. Three kinds of capture, kept distinct

| Kind | Mechanism | Status |
|---|---|---|
| Session summary | A tool call when the owner closes the session | Feasible wherever tools work; the recommended baseline (CD-07) |
| Event capture | End-of-turn or end-of-session hooks posting to the service | Feasible per repository; not in cloud sessions unless the repository carries the hook; UNVERIFIED (CV-07) |
| Automatic transcript capture | None supported across environments | Not promised |

## 4. Lifecycle of a memory

Capture eligible material → identify candidates → check duplicates → detect contradictions → attach provenance → propose → apply approval policy → commit → update index → keep the audit trail. Each step exists in IR1.1 (FR-MEM-001 to FR-MEM-012, FR-AGT-003); the cloud changes where candidates come from, not the steps.

## 5. Across projects

Every record belongs to a project or to the workspace. Search covers all projects unless one is marked restricted, and every result names its project (CD-11). A record reused in another project is linked, not copied, so its provenance stays single.
