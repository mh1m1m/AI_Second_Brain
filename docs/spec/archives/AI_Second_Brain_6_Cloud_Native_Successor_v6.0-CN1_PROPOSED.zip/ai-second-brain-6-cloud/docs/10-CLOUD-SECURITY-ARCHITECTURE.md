# Cloud Security and Authorisation Model

**DOC-CN-10** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

Architecture level. The token model, schemas and classification rules are completed after CD-01, CD-04 and CD-05. A prompt instruction is never counted as a control, and neither is any setting of the client.

## 1. Trust boundaries

1. Session and its project (untrusted: other tools, web content, repository files, other MCP servers).
2. Connector edge (authentication, scope, validation, limits).
3. Service (policy gate, sole writer).
4. Data stores (private network, separate roles).
5. Owner's approval and administration path (second factor).
6. Backup provider (ciphertext only).

## 2. Enforcement layers (replacing IR1.1's five)

| Layer | Mechanism | Carried from IR1.1 |
|---|---|---|
| S1 | Identity: OAuth for the connector, second factor for the owner | New |
| S2 | Token scope per tool; approval outside every connector scope | New; replaces Claude Code permission rules |
| S3 | Service policy gate: valid, hash-bound, unexpired, unconsumed approval for the tier | L3 |
| S4 | Database constraints and triggers; separate database roles | L4 |
| S5 | Detection: audit hash chain, chain head in backups, schema hash, grant inventory, cost alarm | L5 |

## 3. Threats

| ID | Threat | Control | Layer | Remaining uncertainty |
|---|---|---|---|---|
| CS-01 | Stolen connector token | Short expiry, revocation, read and propose only | S1, S2 | Reading is still exposure of private knowledge |
| CS-02 | Manipulated session approves its own proposal | Approval not reachable from the connector | S2, S3 | None by design; depends on CD-04 |
| CS-03 | Injected text in a document or web page drives proposals | Proposals only; queue limits; owner sees the exact change | S3 | Owner approving without reading |
| CS-04 | Retrieved knowledge leaves through the session's other tools | None on the client; restricted projects; minimal results | — | Accepted risk to decide in CD-13 |
| CS-05 | A project shadows the connector's name | Identity check at bootstrap; unique name | Detection | Client behaviour UNVERIFIED (CV-06) |
| CS-06 | Hostile file exploits a parser | Isolated, limited worker without network | Service | Parser flaws inside limits |
| CS-07 | Database reached directly | No public endpoint; roles; provider network controls | S4 | Provider-dependent (CV-09) |
| CS-08 | Public bucket or leaked object link | Private buckets; short-lived signed access | Service | Provider-dependent |
| CS-09 | Provider operator or breach | Encryption at rest; backups encrypted with the owner's key | — | Live data is readable by the provider's systems |
| CS-10 | Secrets in repository, prompt or note | Secret manager; scanning | Detection | Human error |
| CS-11 | Tampering with history | Immutable revisions; audit chain; chain head in backups | S4, S5 | Detection, not prevention, against a database administrator |
| CS-12 | Runaway usage or cost | Limits; alarm; ceiling | S5 | — |
| CS-13 | Loss of the owner's second factor or backup key | Documented recovery procedure tested in the drill | Procedure | A procedure, not a technical control |
| CS-14 | Other MCP servers or skills in the same session | Nothing trusted from the client; server-side checks only | S1 to S4 | They can read what the session reads |

## 4. What changed for the worse, stated plainly

IR1.1 kept public content on a private disk. The successor keeps private content on a public network. Confidentiality becomes a primary requirement; the service is reachable by anyone who can guess its address; and one person carries patching, key rotation and incident response.
