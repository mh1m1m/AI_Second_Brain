# Cloud Backup and Disaster Recovery

**DOC-CN-11** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

Replaces the external-disk design of D-06 and ADR-010. The rule of GAP-034 is unchanged: no owner data before a backup has been restored and checked.

| Aspect | Proposal |
|---|---|
| What | Database (logical dump), originals and attachments, configuration and repository mappings, the latest Markdown and JSON export, a manifest with SHA-256 per item, schema version and audit chain head |
| Where | First line: the provider's own daily backups. Second line: a daily export encrypted before it leaves, stored at a second provider in a separate account |
| Keys | Encryption key generated and held by the owner, with an offline recovery copy; never stored at the primary provider |
| When | Daily; before every migration; on demand |
| Verification | After writing, re-read and compare with the manifest. On a schedule, restore into a scratch database and bucket: integrity, foreign keys, audit chain, sampled originals, index rebuild |
| Objectives | Recovery point 24 hours. Recovery time unmeasured; set after the first drill. IR1.1's provisional figures are not silently changed: the point is the same, the time was never measured |
| Retention | 14 daily and 8 weekly, as proposed in IR1.1, until the owner decides otherwise |
| Point-in-time recovery | An optional provider add-on; not assumed, because of its price on the provider checked |
| Exit drill | Once before real data and yearly: load a full export into an empty environment at a different provider (CR-15) |
| Runbooks | Lost database; lost object store; lost provider account; lost key or second factor; suspected compromise; cost alarm |

GitHub history is not a backup of the database or of the originals. Decision: CD-10.
