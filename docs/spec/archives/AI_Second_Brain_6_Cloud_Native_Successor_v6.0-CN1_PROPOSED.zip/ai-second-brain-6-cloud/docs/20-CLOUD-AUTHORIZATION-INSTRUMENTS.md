# Cloud Authorisation Instruments

**DOC-CN-20** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

Both are drafts. Neither is authorised by being written. IR1.1's Instruments A and B concerned a Mac and are historical.

## Cloud Verification Instrument (draft, not granted)

Permits read-only and synthetic checks only:

| Item | Check | Kind |
|---|---|---|
| CV-01 | Which repositories the account holds, their visibility, and whether private ones are reachable from sessions | Read-only |
| CV-03 | Arabic search on PostgreSQL: the twelve synthetic sentences and seventeen queries of the SQLite probe, on the candidate provider's version | Executable probe, synthetic data |
| CV-04 | Whether each environment prompts before a connector tool call, and whether that can be set per tool | Observation |
| CV-05 | Whether elicitation works outside interactive terminal sessions | Observation |
| CV-06 | What happens when a project defines a server with the connector's name | Observation with a harmless stub |
| CV-07 | Which hooks from a repository's settings run in cloud sessions, and within what time | Observation |
| CV-08 | A cloud environment can reach the service's domain under its network setting | Observation |
| CV-09 | Each shortlisted provider: regions, backup and recovery options and prices, export, private networking, object versioning or lock | Reading and price confirmation |
| CV-10 | Retrieval results stay inside the client's tool-output limit | Observation |
| CV-11 | Where the bootstrap skill is available: repository, personal, synced | Observation |
| CV-12 | An exported vault opens in Obsidian with Arabic displayed right-to-left | Manual check |

Prohibits: creating or changing any repository; provisioning anything; any cost; any owner data; any credential beyond what an existing session already has; application code. Results go to a verification record with what was observed and where.

CV-03 needs somewhere to run PostgreSQL with twelve synthetic sentences. If granted, say where: a temporary instance in the specification sandbox, or a provider's free scratch database.

## Cloud Implementation Instrument (draft template, not granted, not to be issued yet)

To be completed after the successor baseline is approved (CD-17). It must name:

- The approved baseline version and ADRs.
- Stage 1 (no cloud resources): the repository to create, permitted directories, dependency policy, tests required.
- Stage 2 (cloud resources): provider, region, resources, monthly ceiling, who holds which credential.
- Security controls that must exist before any owner data: authentication, scopes, approval page, encrypted independent backup with a passed restore-test.
- What remains forbidden: production data migration, deployment from a commit, public resources.
- Rollback: how every resource is removed and every cost stopped.
- Stop conditions: a failed verification item, a cost alarm, a security finding.

Items that need this instrument because they need a deployed test service: CV-02, CV-13.
