# Cloud-Native Requirements Coverage Matrix

**DOC-CN-04A** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

Three categories, as the owner asked on 2026-11-10, so that the successor is not the old 100 requirements in new words.

- **Preserved: 50.** IR1.1 requirements that apply unchanged in behaviour.
- **Modified: 50.** IR1.1 requirements that must change (39 amended, 11 superseded).
- **New: 24.** Requirements that exist only because of cloud hosting, the remote connector, authentication, cross-environment access and cloud recovery.

## 1. New requirements by capability

| Capability | New requirements |
|---|---|
| Authentication and authorisation | CR-03, CR-04, CR-05, CR-18 |
| Cloud hosting | CR-01, CR-23, CR-24 |
| Cloud recovery | CR-14, CR-15 |
| Cloud security | CR-12, CR-13, CR-17 |
| Cost | CR-20 |
| Cross-environment knowledge | CR-06, CR-09 |
| GitHub | CR-07 |
| Object storage | CR-10, CR-11 |
| Obsidian interoperability | CR-21 |
| Remote MCP | CR-02, CR-16, CR-19, CR-22 |
| Session persistence | CR-08 |

| ID | Requirement | Capability | Proposed test |
|---|---|---|---|
| CR-01 | The service operates with no personal computer online | Cloud hosting | — |
| CR-02 | One remote MCP server over HTTPS with OAuth is the only path for sessions; no other write path exists | Remote MCP | CT-01 |
| CR-03 | Connector tokens carry scopes per tool: read and propose. No connector token can approve | Authentication and authorisation | CT-02 |
| CR-04 | The owner authenticates with a second factor for approvals and administration | Authentication and authorisation | CT-03 |
| CR-05 | Every authorisation is enforced on the server; no client-side control is relied on | Authentication and authorisation | — |
| CR-06 | Registry of workspace, project, session, artifact and knowledge record with stable IDs | Cross-environment knowledge | CT-21 |
| CR-07 | A project may map to repositories by reference; the service holds no repository write credential | GitHub | CT-11 |
| CR-08 | A session is registered and closed with a summary, artifact references, open issues and next actions | Session persistence | CT-09 |
| CR-09 | Retrieval across projects returns provenance and the project of every result | Cross-environment knowledge | CT-04, CT-05 |
| CR-10 | Originals are stored as content-addressed immutable objects and verified by checksum on read | Object storage | CT-10, CT-22 |
| CR-11 | Object-then-row commit with reconciliation of orphan objects | Object storage | CT-18 |
| CR-12 | Encryption in transit and at rest; secrets only in a secret manager; none in prompts, repositories or notes | Cloud security | CT-12 |
| CR-13 | The region and provider of every data store are recorded and enforced by configuration | Cloud security | CT-30 |
| CR-14 | An independent encrypted backup at a second provider, restore-tested before any owner data is stored | Cloud recovery | CT-14, CT-15 |
| CR-15 | A complete export (Markdown, JSON, database dump, originals) and a tested move to another provider | Cloud recovery | CT-24 |
| CR-16 | Rate and size limits on every tool; results sized within the client's tool-output limit | Remote MCP | CT-17, CT-19 |
| CR-17 | A hash-chained audit event for every connector call: identity, token, tool, project, outcome | Cloud security | CT-20 |
| CR-18 | Tokens expire, can be revoked and rotated; active grants can be listed | Authentication and authorisation | CT-01, CT-25 |
| CR-19 | All tool inputs and all returned content are treated as untrusted data and delimited as such | Remote MCP | CT-13, CT-17 |
| CR-20 | A monthly cost ceiling with a usage alarm | Cost | CT-29 |
| CR-21 | Deterministic Markdown export; re-import validated, never overwriting without conflict detection and approval | Obsidian interoperability | CT-23 |
| CR-22 | The bootstrap confirms it is talking to the genuine service before any knowledge is sent | Remote MCP | CT-26 |
| CR-23 | Untrusted files are parsed in an isolated, resource-limited worker | Cloud hosting | CT-27 |
| CR-24 | Scheduled jobs are deterministic only; the server calls no model | Cloud hosting | CT-28 |

## 2. Modified

| Requirement | Title | Change | Related new requirement |
|---|---|---|---|
| FR-ING-002 | Preserve original bytes immutably | AMENDED: Originals in object storage, content-addressed and immutable | CR-10 |
| FR-ING-005 | Identify format and validate intake | AMENDED: Intake runs on the server | CR-23 |
| FR-ING-007 | Extract text from supported formats | AMENDED: Extraction in an isolated worker | CR-23 |
| FR-ING-010 | Process the inbox folder | SUPERSEDED: No inbox folder; an upload path into staging storage | CR-10 |
| FR-KNW-001 | Validate note schema and unique IDs | AMENDED: Note schema becomes the export schema | CR-21 |
| FR-KNW-003 | Generate notes from templates | AMENDED: Templates drive export | CR-21 |
| FR-KNW-004 | Synchronise owner edits | SUPERSEDED: No live vault to synchronise; validated re-import instead | CR-21 |
| FR-KNW-005 | Project managed fields and detect drift | AMENDED: Drift detection moves to re-import | CR-21 |
| FR-KNW-009 | Export a portable bundle | AMENDED: Export becomes the lock-in control | CR-15 |
| FR-MEM-003 | Capture memory candidates as proposals | AMENDED: Candidates also arrive from session summaries | CR-08 |
| FR-RET-001 | Search with filters | AMENDED: Search engine changes; project filter and labels added | CR-09 |
| FR-RET-004 | Rank results deterministically | AMENDED: Ranking re-derived on the new engine | — |
| FR-RET-006 | Log queries | AMENDED: Query log is personal data held by a provider | CR-12 |
| FR-RET-007 | Maintain the index incrementally and propagate deletions | AMENDED: Index maintained by the database | — |
| FR-PRJ-002 | Register a project | AMENDED: Project carries a repository mapping | CR-07 |
| FR-AGT-001 | Require approval for consequential writes | AMENDED: Enforcement on the server | CR-05 |
| FR-AGT-004 | Apply approval tiers and channels | SUPERSEDED: Channels redefined: approval outside the session | CR-03, CR-04 |
| FR-AGT-006 | Record execution history | AMENDED: History includes connector calls | CR-17 |
| FR-AGT-007 | Install the Claude Code operating workspace | SUPERSEDED: No operating workspace; a connector and a bootstrap skill | CR-02, CR-22 |
| FR-AGT-008 | Schedule only deterministic jobs | AMENDED: Cloud scheduler | CR-24 |
| FR-SEC-001 | Enforce path restrictions | SUPERSEDED: Path policy replaced by identity and scope | CR-03, CR-05 |
| FR-SEC-002 | Keep credentials outside the workspace | AMENDED: Secret manager; token lifecycle | CR-12, CR-18 |
| FR-SEC-004 | Reject instruction-bearing and configuration files in data areas | AMENDED: File-name policy at upload; no instruction discovery risk on the server | CR-23 |
| FR-SEC-006 | Use no network by default | SUPERSEDED: The service is networked; replaced by ingress and egress policy | CR-02, CR-12, CR-13 |
| FR-SEC-007 | Keep integrations off unless approved | AMENDED: One integration is approved by design; all others stay off | CR-02 |
| FR-SEC-008 | Harden intake against hostile files | AMENDED: Hardening applies to a server worker | CR-23 |
| FR-OPS-002 | Restore-test a backup in isolation | AMENDED: Restore-test into a scratch database and bucket | CR-14 |
| FR-OPS-003 | Create a consistent backup with manifest | AMENDED: Database dump, objects and configuration to an independent provider | CR-14 |
| FR-OPS-004 | Report system health | AMENDED: Health endpoint and checks | — |
| FR-OPS-005 | Recover on startup | AMENDED: Orphan-object reconciliation | CR-11 |
| FR-OPS-006 | Migrate the schema safely | AMENDED: Migrations on a managed database with a backup first | — |
| FR-OPS-007 | Schedule maintenance with launchd | SUPERSEDED: No launchd | CR-24 |
| FR-OPS-009 | Initialise the workspace | SUPERSEDED: Provisioning replaces init | — |
| FR-OPS-010 | Restore the workspace from a backup | AMENDED: Restore to a new environment | CR-14 |
| FR-OBS-001 | Install vault conventions and templates | AMENDED: Restated for the service | — |
| FR-OBS-002 | Generate dashboards as Markdown | AMENDED: Restated for the service | — |
| NFR-001 | Search latency | AMENDED: Latency target must include the network | — |
| NFR-002 | Source integrity under interruption | AMENDED: Integrity across object store and database | CR-11 |
| NFR-004 | Offline operation | SUPERSEDED: Offline operation is the opposite of the requirement | CR-01, CR-15 |
| NFR-006 | Recovery objectives | AMENDED: Objectives restated for cloud recovery | CR-14 |
| NFR-008 | Ingestion throughput | AMENDED: Throughput re-measured | — |
| NFR-009 | Data egress | SUPERSEDED: Data necessarily leaves the machine; replaced by residency and egress rules | CR-13 |
| NFR-011 | Dependency minimalism | AMENDED: A web framework and database driver are added | — |
| NFR-012 | Scalability | AMENDED: Scale limits of the provider plan | CR-20 |
| NFR-013 | Usability | AMENDED: Usability across environments | — |
| NFR-014 | Observability | AMENDED: Service observability | CR-17 |
| NFR-015 | Cost and token budget | AMENDED: Adds a recurring cost ceiling | CR-20 |
| NFR-017 | Availability without Claude Code or Obsidian | AMENDED: Readable without Claude Code through export | CR-15 |
| NFR-018 | Recoverability | AMENDED: Recoverability restated | CR-14 |
| NFR-020 | Platform compatibility | SUPERSEDED: macOS compatibility replaced by runtime and provider compatibility | CR-01 |

## 3. Preserved

FR-ING-001, FR-ING-003, FR-ING-004, FR-ING-006, FR-ING-008, FR-ING-009, FR-ING-011, FR-KNW-002, FR-KNW-006, FR-KNW-007, FR-KNW-008, FR-MEM-001, FR-MEM-002, FR-MEM-004, FR-MEM-005, FR-MEM-006, FR-MEM-007, FR-MEM-008, FR-MEM-009, FR-MEM-010, FR-MEM-011, FR-MEM-012, FR-RET-002, FR-RET-003, FR-RET-005, FR-RET-008, FR-RET-009, FR-PRJ-001, FR-PRJ-003, FR-PRJ-004, FR-PRJ-005, FR-AGT-002, FR-AGT-003, FR-AGT-005, FR-SEC-003, FR-SEC-005, FR-OPS-001, FR-OPS-008, FR-OBS-003, FR-IMP-001, FR-IMP-002, FR-IMP-003, NFR-003, NFR-005, NFR-007, NFR-010, NFR-016, NFR-019, NFR-021, NFR-022.

## 4. Feasible is not verified

Three different claims, kept apart: **documented** (the vendor's documentation says it works), **observed** (seen once in a real environment), **verified for this system** (tested against this service). Nothing is in the third column yet, because no service exists.

| Capability | Documented | Observed | Verified for this system | What it does not prove |
|---|---|---|---|---|
| Remote HTTP MCP server with OAuth in Claude Code | Yes | No | No | That every environment you use connects |
| Connectors configured in claude.ai available to Claude Code | Yes | Yes, for vendor connectors, in the cloud session that produced this package | No | That a custom server behaves the same |
| Reaching the service from a cloud session | Network access is configurable per cloud environment | No | No | That the default setting allows your domain |
| Session summary submitted by a tool call | Follows from tool support | No | No | That it happens without being asked |
| Event capture by hooks | Yes: end-of-turn and end-of-session hooks, HTTP and MCP-tool types | No | No | Capture in cloud sessions, which do not read your own settings; capture within the short end-of-session budget |
| Complete transcript capture | A local transcript file exists and is written asynchronously | No | No | Any supported way to collect it from every environment. Not assumed |
| Bootstrap skill present in every session | Skills load from repository, personal and synced locations | No | No | Presence in a given environment |
| Arabic retrieval on PostgreSQL | PostgreSQL has full-text search | No | No | Any quality or tokenizer behaviour. The probe was not run |
| Approval prompts before tool calls | Not stated in the documentation read | No | No | Anything; approval is designed not to depend on it |
