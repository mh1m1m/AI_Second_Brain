# Requirements Impact Matrix

**DOC-CN-04** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

All 100 IR1.1 requirements, classified against the cloud-native objective. Classification is **PROPOSED**. Requirement text is not rewritten here: rewriting follows the owner's architecture decisions.

Totals: AMENDED 39, DEFERRED 3, RETAINED 47, SUPERSEDED 11. IR1.1's 143 designed tests, classed by the most affected requirement each covers: keep 66, adapt 61, replace 16.

RETAINED means the behaviour is unchanged; where it rests on database constraints, those are re-expressed and re-probed on the new engine.

## 1. Matrix

| Requirement | Title | Priority | Impact | What changes | New requirement |
|---|---|---|---|---|---|
| FR-ING-001 | Register source artifact | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-ING-002 | Preserve original bytes immutably | MUST | AMENDED | Originals in object storage, content-addressed and immutable | CR-10 |
| FR-ING-003 | Record extraction version and passage locators | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-ING-004 | Detect duplicate content | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-ING-005 | Identify format and validate intake | MUST | AMENDED | Intake runs on the server | CR-23 |
| FR-ING-006 | Register a new version of an existing source | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-ING-007 | Extract text from supported formats | MUST | AMENDED | Extraction in an isolated worker | CR-23 |
| FR-ING-008 | Segment extraction into structure-aware passages | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-ING-009 | Flag sources that yield little or no text | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-ING-010 | Process the inbox folder | SHOULD | SUPERSEDED | No inbox folder; an upload path into staging storage | CR-10 |
| FR-ING-011 | Withdraw a source | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-KNW-001 | Validate note schema and unique IDs | MUST | AMENDED | Note schema becomes the export schema | CR-21 |
| FR-KNW-002 | Retain competing claims and supersession | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-KNW-003 | Generate notes from templates | MUST | AMENDED | Templates drive export | CR-21 |
| FR-KNW-004 | Synchronise owner edits | MUST | SUPERSEDED | No live vault to synchronise; validated re-import instead | CR-21 |
| FR-KNW-005 | Project managed fields and detect drift | MUST | AMENDED | Drift detection moves to re-import | CR-21 |
| FR-KNW-006 | Maintain typed relationships with evidence and validity | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-KNW-007 | Maintain an entity registry with bilingual aliases | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-KNW-008 | Check link integrity | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-KNW-009 | Export a portable bundle | MUST | AMENDED | Export becomes the lock-in control | CR-15 |
| FR-MEM-001 | Enforce the memory state machine | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-002 | Require evidence before verification | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-003 | Capture memory candidates as proposals | MUST | AMENDED | Candidates also arrive from session summaries | CR-08 |
| FR-MEM-004 | Classify kind and epistemic type | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-005 | Detect conflicts deterministically | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-006 | Supersede while preserving history | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-007 | Correct a memory by revision | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-008 | Reconstruct memory as of a date | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-009 | Archive and delete memory | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-010 | Schedule revalidation | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-011 | Consolidate duplicates by key | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-MEM-012 | Accept owner-attested memory | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-RET-001 | Search with filters | MUST | AMENDED | Search engine changes; project filter and labels added | CR-09 |
| FR-RET-002 | Return resolvable evidence locators | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-RET-003 | Normalise Arabic and English text for indexing and queries | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-RET-004 | Rank results deterministically | MUST | AMENDED | Ranking re-derived on the new engine | — |
| FR-RET-005 | Classify the retrieval outcome | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-RET-006 | Log queries | SHOULD | AMENDED | Query log is personal data held by a provider | CR-12 |
| FR-RET-007 | Maintain the index incrementally and propagate deletions | MUST | AMENDED | Index maintained by the database | — |
| FR-RET-008 | Run the retrieval evaluation harness | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-RET-009 | Show evidence for a citation | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-PRJ-001 | Reconstruct project state as of a date | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-PRJ-002 | Register a project | SHOULD | AMENDED | Project carries a repository mapping | CR-07 |
| FR-PRJ-003 | Track milestones, tasks, risks, dependencies, commitments and open questions | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-PRJ-004 | Record decisions with alternatives and evidence | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-PRJ-005 | Produce a cited project status report | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-AGT-001 | Require approval for consequential writes | MUST | AMENDED | Enforcement on the server | CR-05 |
| FR-AGT-002 | Run idempotent, resumable workflows | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-AGT-003 | Manage the proposal lifecycle | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-AGT-004 | Apply approval tiers and channels | MUST | SUPERSEDED | Channels redefined: approval outside the session | CR-03, CR-04 |
| FR-AGT-005 | Support dry-run for mutating commands | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| FR-AGT-006 | Record execution history | MUST | AMENDED | History includes connector calls | CR-17 |
| FR-AGT-007 | Install the Claude Code operating workspace | MUST | SUPERSEDED | No operating workspace; a connector and a bootstrap skill | CR-02, CR-22 |
| FR-AGT-008 | Schedule only deterministic jobs | MUST | AMENDED | Cloud scheduler | CR-24 |
| FR-SEC-001 | Enforce path restrictions | MUST | SUPERSEDED | Path policy replaced by identity and scope | CR-03, CR-05 |
| FR-SEC-002 | Keep credentials outside the workspace | MUST | AMENDED | Secret manager; token lifecycle | CR-12, CR-18 |
| FR-SEC-003 | Treat source content as untrusted data | MUST | RETAINED | Applies to tool inputs and outputs as well | CR-19 |
| FR-SEC-004 | Reject instruction-bearing and configuration files in data areas | MUST | AMENDED | File-name policy at upload; no instruction discovery risk on the server | CR-23 |
| FR-SEC-005 | Keep a tamper-evident audit chain | MUST | RETAINED | Audit chain unchanged; covers connector calls | CR-17 |
| FR-SEC-006 | Use no network by default | MUST | SUPERSEDED | The service is networked; replaced by ingress and egress policy | CR-02, CR-12, CR-13 |
| FR-SEC-007 | Keep integrations off unless approved | MUST | AMENDED | One integration is approved by design; all others stay off | CR-02 |
| FR-SEC-008 | Harden intake against hostile files | MUST | AMENDED | Hardening applies to a server worker | CR-23 |
| FR-OPS-001 | Rebuild the search index from canonical data | MUST | RETAINED | Index rebuild from canonical data | — |
| FR-OPS-002 | Restore-test a backup in isolation | MUST | AMENDED | Restore-test into a scratch database and bucket | CR-14 |
| FR-OPS-003 | Create a consistent backup with manifest | MUST | AMENDED | Database dump, objects and configuration to an independent provider | CR-14 |
| FR-OPS-004 | Report system health | MUST | AMENDED | Health endpoint and checks | — |
| FR-OPS-005 | Recover on startup | MUST | AMENDED | Orphan-object reconciliation | CR-11 |
| FR-OPS-006 | Migrate the schema safely | MUST | AMENDED | Migrations on a managed database with a backup first | — |
| FR-OPS-007 | Schedule maintenance with launchd | SHOULD | SUPERSEDED | No launchd | CR-24 |
| FR-OPS-008 | Write structured logs without content | MUST | RETAINED | Logs without content | — |
| FR-OPS-009 | Initialise the workspace | MUST | SUPERSEDED | Provisioning replaces init | — |
| FR-OPS-010 | Restore the workspace from a backup | MUST | AMENDED | Restore to a new environment | CR-14 |
| FR-OBS-001 | Install vault conventions and templates | MUST | AMENDED | Restated for the service | — |
| FR-OBS-002 | Generate dashboards as Markdown | SHOULD | AMENDED | Restated for the service | — |
| FR-OBS-003 | Handle right-to-left and mixed-direction content | MUST | RETAINED | Right-to-left rules apply to exports | — |
| FR-IMP-001 | Plan a legacy vault import | COULD | DEFERRED | Still deferred | — |
| FR-IMP-002 | Commit a legacy vault import | COULD | DEFERRED | Still deferred | — |
| FR-IMP-003 | Roll back an import batch | COULD | DEFERRED | Still deferred | — |
| NFR-001 | Search latency | SHOULD | AMENDED | Latency target must include the network | — |
| NFR-002 | Source integrity under interruption | MUST | AMENDED | Integrity across object store and database | CR-11 |
| NFR-003 | Portability | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| NFR-004 | Offline operation | MUST | SUPERSEDED | Offline operation is the opposite of the requirement | CR-01, CR-15 |
| NFR-005 | Audit completeness | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| NFR-006 | Recovery objectives | SHOULD | AMENDED | Objectives restated for cloud recovery | CR-14 |
| NFR-007 | Retrieval quality gate | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| NFR-008 | Ingestion throughput | COULD | AMENDED | Throughput re-measured | — |
| NFR-009 | Data egress | MUST | SUPERSEDED | Data necessarily leaves the machine; replaced by residency and egress rules | CR-13 |
| NFR-010 | Maintainability | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| NFR-011 | Dependency minimalism | MUST | AMENDED | A web framework and database driver are added | — |
| NFR-012 | Scalability | SHOULD | AMENDED | Scale limits of the provider plan | CR-20 |
| NFR-013 | Usability | SHOULD | AMENDED | Usability across environments | — |
| NFR-014 | Observability | SHOULD | AMENDED | Service observability | CR-17 |
| NFR-015 | Cost and token budget | SHOULD | AMENDED | Adds a recurring cost ceiling | CR-20 |
| NFR-016 | Accessibility | SHOULD | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| NFR-017 | Availability without Claude Code or Obsidian | MUST | AMENDED | Readable without Claude Code through export | CR-15 |
| NFR-018 | Recoverability | MUST | AMENDED | Recoverability restated | CR-14 |
| NFR-019 | Unauthorised writes | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |
| NFR-020 | Platform compatibility | MUST | SUPERSEDED | macOS compatibility replaced by runtime and provider compatibility | CR-01 |
| NFR-021 | Deterministic rebuild | MUST | RETAINED | Deterministic rebuild | — |
| NFR-022 | Unicode correctness | MUST | RETAINED | Logic unchanged; constraints re-expressed on the new database | — |

## 2. Proposed new requirements

Numbered CR until they are merged into a successor requirements specification.

| ID | Requirement |
|---|---|
| CR-01 | The service operates with no personal computer online |
| CR-02 | One remote MCP server over HTTPS with OAuth is the only path for sessions; no other write path exists |
| CR-03 | Connector tokens carry scopes per tool: read and propose. No connector token can approve |
| CR-04 | The owner authenticates with a second factor for approvals and administration |
| CR-05 | Every authorisation is enforced on the server; no client-side control is relied on |
| CR-06 | Registry of workspace, project, session, artifact and knowledge record with stable IDs |
| CR-07 | A project may map to repositories by reference; the service holds no repository write credential |
| CR-08 | A session is registered and closed with a summary, artifact references, open issues and next actions |
| CR-09 | Retrieval across projects returns provenance and the project of every result |
| CR-10 | Originals are stored as content-addressed immutable objects and verified by checksum on read |
| CR-11 | Object-then-row commit with reconciliation of orphan objects |
| CR-12 | Encryption in transit and at rest; secrets only in a secret manager; none in prompts, repositories or notes |
| CR-13 | The region and provider of every data store are recorded and enforced by configuration |
| CR-14 | An independent encrypted backup at a second provider, restore-tested before any owner data is stored |
| CR-15 | A complete export (Markdown, JSON, database dump, originals) and a tested move to another provider |
| CR-16 | Rate and size limits on every tool; results sized within the client's tool-output limit |
| CR-17 | A hash-chained audit event for every connector call: identity, token, tool, project, outcome |
| CR-18 | Tokens expire, can be revoked and rotated; active grants can be listed |
| CR-19 | All tool inputs and all returned content are treated as untrusted data and delimited as such |
| CR-20 | A monthly cost ceiling with a usage alarm |
| CR-21 | Deterministic Markdown export; re-import validated, never overwriting without conflict detection and approval |
| CR-22 | The bootstrap confirms it is talking to the genuine service before any knowledge is sent |
| CR-23 | Untrusted files are parsed in an isolated, resource-limited worker |
| CR-24 | Scheduled jobs are deterministic only; the server calls no model |

## 3. Governance preserved

| Principle | Carried by |
|---|---|
| Evidence before memory | FR-MEM-002 retained |
| Immutable originals | FR-ING-002 amended, CR-10 |
| Stable identifiers | ADR-016 retained |
| Provenance | FR-ING-003, FR-RET-002 retained; CR-09 |
| Historical reconstruction | FR-MEM-008, FR-PRJ-001 retained |
| Human approval | FR-AGT-001 amended; CR-03, CR-04 |
| Bounded proposal queue (GAP-033) | FR-AGT-003 retained |
| Auditability | FR-SEC-005 retained; CR-17 |
| Backup before valuable ingestion (GAP-034) | CR-14 |
| Tested recovery | FR-OPS-002 amended; CR-14, CR-15 |
| Arabic-first retrieval | FR-RET-003, NFR-007 retained |
| Independent review | Gate CG-12 |
