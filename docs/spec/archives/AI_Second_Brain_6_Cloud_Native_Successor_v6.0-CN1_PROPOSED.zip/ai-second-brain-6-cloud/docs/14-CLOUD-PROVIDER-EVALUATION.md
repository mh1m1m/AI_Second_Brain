# Cloud Provider Comparison and Cost Estimates

**DOC-CN-14** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

Evidence words: **VERIFIED** = read in documentation or measured today; **UNVERIFIED** = not checked in this pass; **PROPOSED** = a recommendation awaiting the owner.

No provider is selected. Only one provider's prices were confirmed in this pass; statements about the others come from general knowledge and are marked UNVERIFIED so that they are checked before any decision (CV-09).

## 1. Criteria

Managed PostgreSQL; a place to run a Python service and an isolated worker; private object storage; secret management; backups and their price; region and data residency; private networking; export; recurring cost at one user's scale; how hard it is to leave.

## 2. Candidates

| Candidate | Would provide | Points to weigh | Evidence |
|---|---|---|---|
| Supabase | PostgreSQL, object storage, authentication | Free plan: project paused after one week of inactivity, limit of two projects, no automatic backups. Pro: from US$25 a month; one project on the default compute comes to about US$25 after the included credit. Point-in-time recovery US$100 a month per seven days of retention. The Python service would run elsewhere. An account connector for it appeared in this session; it was not queried | Prices VERIFIED 2026-11-10 from its pricing page; the rest UNVERIFIED |
| Neon | Serverless PostgreSQL | Scale-to-zero and branching; region list and prices not checked | UNVERIFIED |
| A large cloud (AWS, Google Cloud, Azure) | Everything, including regions in the Middle East | Most control over residency and networking; most configuration and usually the highest floor price | UNVERIFIED |
| Cloudflare | Object storage, edge compute, a SQLite-based database | Relevant to option O4 and as an independent backup target; Python support for its compute not checked | UNVERIFIED |
| A container host (for the Python service) | Runs the service and worker beside a managed database | Needed with any database-only provider | UNVERIFIED |

## 3. Cost

What can be said on today's evidence: a persistent, never-paused managed PostgreSQL with daily backups starts at about US$25 a month on the provider checked; hosting for the Python service, storage beyond the included amount and a second provider for backups come on top and are not priced here. No free tier examined is suitable for a system whose point is persistence. A planning ceiling is the owner's to set (CD-03); a figure from me now would be a guess.

## 4. Residency

The owner is in Saudi Arabia. Whether personal knowledge must stay in a particular country or region is a question for the owner, and for whoever owns any non-personal material if CD-01 admits it. I am not a lawyer; this is a factor to decide, not advice.

## 5. Leaving a provider

PostgreSQL dumps, S3-style object copies, Markdown and JSON exports. Provider-specific features (their authentication service, their row-level policy language, their functions) are where lock-in enters; the design keeps authorisation in the service for that reason.
