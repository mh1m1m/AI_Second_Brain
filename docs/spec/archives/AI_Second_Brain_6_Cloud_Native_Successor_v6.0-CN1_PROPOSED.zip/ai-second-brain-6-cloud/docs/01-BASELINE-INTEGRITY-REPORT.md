# Baseline Integrity and Preservation Report

**DOC-CN-01** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

## 1. What was found

| Source | Identity | Status |
|---|---|---|
| `AI_Second_Brain_6_Implementation_Readiness_Baseline_v6.0-IR1.1.zip` | SHA-256 `0dcc02510a6878079e79a303dc2a5864f204eb1a1766076ff765a6062f09353f`; 171 entries | Authoritative historical baseline. Re-hashed on 2026-11-10 before this work: unchanged |
| Its own checker, `tools/spec_lint.py` | 23 of 23 checks pass | Includes: snapshot hashes match, approval record empty, no ADR marked approved |
| v6.0-IR1 archive | SHA-256 `8c2ab27f1b5b71613f62a1b96b3e5a3affd81c6be5cd37ad7e4461e894ed1eb5` | Superseded by IR1.1; its decision register is preserved inside IR1.1 |
| Earlier V6.0 draft (46 files, 10 ADRs) and the 500-slot audit | Hashed in `docs/_baseline/SNAPSHOT-MANIFEST.md` inside IR1.1 | Superseded; source of the earlier false 'missing ADR' finding |
| Inputs of this pass | Five files under `inputs/`, hashed in MANIFEST.md | Kept as received. The master implementation directive is withdrawn as an authorisation and kept as design input |
| Implementation repository | None supplied | Existence not established |
| GitHub account reachable from this session | Five repositories, all public | Read-only listing; see GITHUB-REPOSITORY-STRATEGY |

## 2. Approval state

Nothing in IR1.1 is approved: its approval record (section G) is empty and all 20 ADRs are PROPOSED. Decided by the owner and still in force: D-02 (Arabic first, bilingual) and D-05 (V5.0 as reference). Replaced by the confirmed cloud-native requirement: D-01 (macOS) and D-04 (local vault). Needing a fresh decision: D-03 (public information only), see CD-01.

## 3. Conflicting versions

One: the earlier draft archive against IR1.1. Resolved in IR1.1's own records (corrections C-01 to C-08). The master implementation directive conflicted with the transition directive; the owner resolved it on 2026-11-10 in favour of the transition directive.

## 4. Missing evidence

- No implementation exists that has been supplied or verified.
- IR1.1 is not a Git repository; its identity is its hash.
- The owner's private repositories, if any, are not visible to this session.
- IR1.1 gate G8 (independent review) remains NOT_VERIFIED and is not affected by this package.

## 5. Preservation

This package lives in a separate folder and refers to IR1.1 by hash. No IR1.1 file was opened for writing. One note for exactness: the working copy's `QUALITY-REPORT.json` is rewritten with a new timestamp whenever the checker runs; the archive, not the working copy, is the baseline.
