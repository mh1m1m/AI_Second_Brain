# Consolidated Cloud Owner-Decision Register

**DOC-CN-17** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

> **Nothing here is approved.** Recommendations are PROPOSED. An empty answer means not decided. IMPLEMENTATION NOT AUTHORIZED.

## 1. Recorded from the owner on 2026-11-10

- Cloud-native operation is a confirmed product requirement.
- The transition directive governs; the master implementation directive is design input only.
- IR1.1 is an immutable historical baseline and is not to be implemented unchanged.
- Managed PostgreSQL is the leading candidate for the database, not a final selection.
- GitHub is not the live database. Obsidian is optional.
- Still in force from before: Arabic first, bilingual (D-02); V5.0 as mandatory reference (D-05).

## 2. No longer asked

D-06 as an external disk, D-07 Mac folders, D-08 terminal and prompt channels, D-11 as a workspace setting, D-12 as a deferral of other environments, D-16 Git in a local vault, D-19 Mac instruments, D-20 as written. Each is replaced below.

## 3. Decisions

| ID | Question | Recommendation | Main alternative | Consequence |
|---|---|---|---|---|
| CD-01 | What may be stored? (replaces D-03) | Treat everything as private personal data: project knowledge, session summaries and code references are not public documents. Keep material that belongs to an employer or a third party out unless you clear it separately | Public sources only, as in IR1.1 | Decides encryption, residency and access rules; IR1.1 made public-only content the reason for several lighter controls |
| CD-02 | Database | Managed PostgreSQL, conditional on the Arabic probe CV-03 | A hosted SQLite-compatible service | PostgreSQL widens provider choice and tooling; the executed SQLite schema evidence must be redone |
| CD-03 | Provider, region and monthly cost ceiling | No selection yet. Shortlist in CLOUD-PROVIDER-EVALUATION, verified under the Cloud Verification Instrument | Choose now on current information | A paid, recurring commitment; where your data sits |
| CD-04 | Where do you approve? | Outside the session, on a small page only you can sign in to. Connector tokens can read and propose, never approve | An approving tool behind the client's permission prompt; pull requests as approvals | Claude cannot approve its own proposal even if a session is manipulated; a minimal web page is needed from the first usable phase |
| CD-05 | How do you and the connector authenticate? | OAuth for the connector with one owner identity; a second factor for approval and administration | A static bearer token | A stolen connector token can read and propose, not approve or delete |
| CD-06 | Where are your own notes authoritative? | In the service, with deterministic Markdown export | Markdown files in a private knowledge repository | Notes are searchable and transactional; Obsidian becomes a reader unless re-import is used |
| CD-07 | What is kept from a session? | A summary you can see, artifact references, open issues and next actions, submitted when you close the session. No transcripts by default | Event capture by hooks in repositories that opt in; a transcript archive with retention | Continuity without storing every message; capture that does not depend on one environment |
| CD-08 | What does the service do with GitHub? | Hold references only (repository, commit, pull request). No GitHub credential in the service. Claude Code keeps doing repository work with its own GitHub access | A GitHub App with write access held by the service | One fewer class of credential to protect; no automatic pushes are possible by design |
| CD-09 | Repositories | One new private platform repository. No knowledge-export repository at first. Link existing project repositories. Review the visibility of the repositories that are public today | Platform plus knowledge repository from the start | Nothing personal is committed to a repository until you ask for an export there |
| CD-10 | Backup and recovery (replaces D-06) | Provider daily backups plus a daily encrypted export to a second provider, key held by you; recovery point 24 hours; recovery time measured at the first drill; restore-tested before any real data | Provider backups only; add point-in-time recovery | A second storage account; point-in-time recovery was priced at US$100 a month per seven days on the one provider checked |
| CD-11 | Search across projects | All your projects searchable by default, each result labelled with its project; a project can be marked restricted | Per-project isolation unless you ask for cross-project | One owner, so isolation protects against mistakes rather than other users |
| CD-12 | Obsidian | Export only at first; validated re-import later if you want it | Two-way synchronisation from the start | No sync conflicts to design before the core works |
| CD-13 | Sessions that use the brain may also browse the web | Accept it; every write is a proposal and every proposal needs you. Retrieved content can still leave through a session's other tools | Restrict the connector to environments without web access | Injection moves from prevention on the client to containment on the server |
| CD-14 | How the bootstrap skill reaches a session | In the platform repository, and as a personal skill for other projects. This reverses IR1.1's proposal to switch synced skills off | Repository only | The skill is a convenience; the service does not trust it |
| CD-15 | Carry forward compatible IR1.1 decisions | D-02 languages, D-05 V5.0 as reference, D-09 formats in stages, D-10 pilot corpus and benchmark, D-13 context budget, D-14 naming as the export convention, D-17 dates | Re-open any of them | No rework where nothing changed |
| CD-16 | First release scope | Retrieval, proposals, approval page, session summaries, backups. Deferred: repository synchronisation, dashboard, knowledge graph, Obsidian sync, mobile interface | Everything in the directive at once | A usable system sooner and a smaller service to secure |
| CD-17 | Successor baseline approval (replaces D-18) | After the detailed design that follows your answers: database schema, tool schemas, rewritten requirements and tests | Approve the architecture now as the baseline | Implementation is held to a complete baseline, not to an outline |
| CD-18 | Authorisations (replaces D-19) | Cloud Verification Instrument first. Cloud Implementation Instrument later and separately | Authorise implementation now | Read-only checks before any cost or code |
| CD-19 | Independent review | Name a reviewer for v6.0-CN1 and give them this package and the IR1.1 archive | Have a separate agent, with no view of this work, attempt the review | Gate CG-12 stays NOT_VERIFIED until someone other than the author reviews |
| CD-20 | Existing codebase | Say whether any exists; none was supplied | — | Carried from IR1.1 |

## 4. Answer record

APPROVE, APPROVE_WITH_AMENDMENT, REJECT or DEFER.

| Item | Answer | Note | Date |
|---|---|---|---|
| CD-01 What may be stored |  |  |  |
| CD-02 Database |  |  |  |
| CD-03 Provider, region and monthly cost ceiling |  |  |  |
| CD-04 Where do you approve |  |  |  |
| CD-05 How do you and the connector authenticate |  |  |  |
| CD-06 Where are your own notes authoritative |  |  |  |
| CD-07 What is kept from a session |  |  |  |
| CD-08 What does the service do with GitHub |  |  |  |
| CD-09 Repositories |  |  |  |
| CD-10 Backup and recovery |  |  |  |
| CD-11 Search across projects |  |  |  |
| CD-12 Obsidian |  |  |  |
| CD-13 Sessions that use the brain may also browse the web |  |  |  |
| CD-14 How the bootstrap skill reaches a session |  |  |  |
| CD-15 Carry forward compatible IR1.1 decisions |  |  |  |
| CD-16 First release scope |  |  |  |
| CD-17 Successor baseline approval |  |  |  |
| CD-18 Authorisations |  |  |  |
| CD-19 Independent review |  |  |  |
| CD-20 Existing codebase |  |  |  |
| Cloud Verification Instrument |  |  |  |
| Cloud Implementation Instrument |  |  |  |
