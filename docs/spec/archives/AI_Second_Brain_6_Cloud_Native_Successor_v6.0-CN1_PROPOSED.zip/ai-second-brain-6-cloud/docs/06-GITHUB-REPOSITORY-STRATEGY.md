# GitHub Repository and Synchronisation Strategy

**DOC-CN-06** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

## 1. What exists (read-only listing, 2026-11-10)

| Repository | Visibility | Last push |
|---|---|---|
| mh1m1m/CDF_Notification_Generator | public | 2026-11-09 |
| mh1m1m/CDF_GC_Review | public | 2026-11-09 |
| mh1m1m/CDF_Case_Management | public | 2026-11-07 |
| mh1m1m/Prodysia | public | 2025-08-31 |
| mh1m1m/novel | public | 2025-08-20 |

Nothing was created, changed or cloned. None of the five is an AI Second Brain, Morphaze or Maritime AI repository. The owner's directive refers to existing private repositories; none is visible to this session (CV-01). Whether the five above are meant to be public is the owner's call and worth a look before any of them is linked to a knowledge system.

## 2. Proposed repositories

| Repository | Visibility | Holds | When |
|---|---|---|---|
| Platform (name to be chosen by the owner) | Private | Service and connector source, migrations, tests, infrastructure definitions, the bootstrap skill, this specification and its ADRs, release manifests | Created only under the Cloud Implementation Instrument |
| Project repositories | As the owner decides | Each project's own code and documents | Existing ones are linked, never duplicated |
| Knowledge export | Private | Approved Markdown exports and manifests | Not at first (CD-09); only if the owner asks for exports in Git |

A conversation is not a project, and no repository is created per conversation.

## 3. What the service does with GitHub

It stores references: repository, branch, commit, pull request, release. It holds no GitHub credential (CD-08). Commit, push, merge, release and deploy stay separate actions done by Claude Code or the owner under the repository's own protections. A successful commit says nothing about the database, and the reverse.

## 4. Governance for the platform repository

Private; protected default branch; pull-request review for consequential changes; secret scanning and dependency scanning; tests in continuous integration; tagged releases with checksums; no deployment triggered by a commit.

## 5. Never in a repository

Credentials, tokens, decrypted backups, database dumps, originals, personal knowledge that the owner has not explicitly exported.
