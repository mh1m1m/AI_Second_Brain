# ADR Transition Matrix

**DOC-CN-03** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

All 20 IR1.1 records, reconciled against the confirmed cloud-native objective. Dispositions are **PROPOSED**. No IR1.1 record is edited; each stays as written in the preserved baseline.

Evidence words: **VERIFIED** = read in documentation or measured today; **UNVERIFIED** = not checked in this pass; **PROPOSED** = a recommendation awaiting the owner.

## 1. Summary

| ADR | Existing decision | Disposition | Replacement | Owner decision |
|---|---|---|---|---|
| ADR-001 | Claude Code is the only AI platform; Python calls no model | RETAINED | — | — |
| ADR-002 | Notes are Markdown files; the file is authoritative for body | AMENDED | ADR-030 | CD-06 |
| ADR-003 | Obsidian is optional; core features only | RETAINED | — | CD-12 |
| ADR-004 | SQLite is the transactional registry | SUPERSEDED | ADR-022 | CD-02 |
| ADR-005 | FTS5 with Arabic normalisation and a stem column in the application | AMENDED | ADR-023 | CD-02 |
| ADR-006 | No vector search until gate RET-G2 | RETAINED | — | — |
| ADR-007 | No graph database; typed relationships in the registry | RETAINED | — | — |
| ADR-008 | One orchestrator; scheduled jobs deterministic; no unattended model runs | AMENDED | ADR-031 | — |
| ADR-009 | Three approval tiers; hash-bound, single-use, expiring approvals | AMENDED | ADR-025 | CD-04, CD-05 |
| ADR-010 | Independent backup with restore tests | AMENDED | ADR-028 | CD-10 |
| ADR-011 | Architecture C+ among V5.0's six alternatives | SUPERSEDED | ADR-021 | CD-16, CD-17 |
| ADR-012 | Governed fields in the registry; notes show projections; memory as digests | AMENDED | ADR-030 | CD-06, CD-12 |
| ADR-013 | Journal for file-plus-database commits on one filesystem | SUPERSEDED | ADR-026 | — |
| ADR-014 | Knowledge kept apart from code by folders | AMENDED | ADR-027 | CD-08, CD-09 |
| ADR-015 | Five enforcement layers on the client; no hooks | SUPERSEDED | ADR-025 | CD-04, CD-05 |
| ADR-016 | Readable sequential IDs; one registry of objects | RETAINED | — | — |
| ADR-017 | Small versioned extractors; OCR deferred | AMENDED | ADR-026 | CD-15 |
| ADR-018 | No MCP server, plugin, web access or browser automation; auto memory off | SUPERSEDED | ADR-024 | CD-13, CD-14 |
| ADR-019 | Legacy vault import deferred; schema ready | DEFERRED | — | — |
| ADR-020 | One memory model: records, revisions, evidence | RETAINED | ADR-029 | CD-07, CD-11 |

Totals: AMENDED 8, DEFERRED 1, RETAINED 6, SUPERSEDED 5. None is REJECTED.

## 2. Detail

### ADR-001 — RETAINED

- **Existing decision.** Claude Code is the only AI platform; Python calls no model.
- **New requirement and conflict.** None. Sessions reach the service through the connector; the service still calls no model.
- **Recommended replacement and alternatives.** Summaries and proposals are written by Claude inside the session and submitted as data. A server that called a model would need a provider key, add cost and add an injection surface.
- **Security implications.** No model credential on the server.
- **Data implications.** None.
- **Cost implications.** No model cost on the server.
- **Migration implications.** None.
- **Test implications.** Keep.
- **Owner decision required.** —.

### ADR-002 — AMENDED

- **Existing decision.** Notes are Markdown files; the file is authoritative for body.
- **New requirement and conflict.** There is no local vault to be authoritative. A file on a laptop cannot be the authority of a cloud system.
- **Recommended replacement and alternatives.** Notes authoritative in the service with deterministic Markdown export (recommended); or Markdown authoritative in a private knowledge repository. Proposed record: ADR-030.
- **Security implications.** Note text leaves the owner's disk and lives with a provider.
- **Data implications.** Body authority moves from file to database row or repository file.
- **Cost implications.** None.
- **Migration implications.** None: no vault exists.
- **Test implications.** Adapt sync and drift tests.
- **Owner decision required.** CD-06.

### ADR-003 — RETAINED

- **Existing decision.** Obsidian is optional; core features only.
- **New requirement and conflict.** None; the cloud requirement makes it more optional, not less.
- **Recommended replacement and alternatives.** —.
- **Security implications.** None.
- **Data implications.** Obsidian reads an export.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** Keep.
- **Owner decision required.** CD-12.

### ADR-004 — SUPERSEDED

- **Existing decision.** SQLite is the transactional registry.
- **New requirement and conflict.** A file database on one Mac cannot serve sessions in other environments.
- **Recommended replacement and alternatives.** Managed PostgreSQL (owner's leading candidate, recommended); a hosted SQLite-compatible service (least change to the executed schema, narrower provider choice). Proposed record: ADR-022.
- **Security implications.** Database reachable only by the service, never from the internet; separate roles for service, migration and backup.
- **Data implications.** 28 tables and 15 triggers must be re-expressed and re-probed; the 27 executed SQLite probes do not carry over as evidence.
- **Cost implications.** A paid managed database.
- **Migration implications.** Nothing to migrate: no data exists.
- **Test implications.** Re-run every schema probe on the new engine.
- **Owner decision required.** CD-02.

### ADR-005 — AMENDED

- **Existing decision.** FTS5 with Arabic normalisation and a stem column in the application.
- **New requirement and conflict.** The engine changes with ADR-004. The design does not: normalisation and stemming happen in the application, so they are engine-independent.
- **Recommended replacement and alternatives.** PostgreSQL full-text search over the application-normalised and stemmed text (recommended); PostgreSQL's built-in Arabic configuration; trigram matching; an external search engine. Proposed record: ADR-023.
- **Security implications.** None.
- **Data implications.** Index text still differs from stored text; excerpts still come from originals.
- **Cost implications.** None beyond the database.
- **Migration implications.** None.
- **Test implications.** The tokenizer probe must be repeated on PostgreSQL before selection (CV-03); gate RET-G1 and the benchmark stay.
- **Owner decision required.** CD-02.

### ADR-006 — RETAINED

- **Existing decision.** No vector search until gate RET-G2.
- **New requirement and conflict.** None. A cloud database makes vectors easy to switch on, which is a reason to keep the gate, not to drop it.
- **Recommended replacement and alternatives.** —.
- **Security implications.** An embedding model would be a second model path (ADR-001).
- **Data implications.** None.
- **Cost implications.** Avoids embedding cost.
- **Migration implications.** None.
- **Test implications.** Keep.
- **Owner decision required.** —.

### ADR-007 — RETAINED

- **Existing decision.** No graph database; typed relationships in the registry.
- **New requirement and conflict.** None.
- **Recommended replacement and alternatives.** —.
- **Security implications.** None.
- **Data implications.** Relationships move with the registry.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** Keep.
- **Owner decision required.** —.

### ADR-008 — AMENDED

- **Existing decision.** One orchestrator; scheduled jobs deterministic; no unattended model runs.
- **New requirement and conflict.** launchd on a Mac cannot schedule cloud jobs. The principle is unaffected.
- **Recommended replacement and alternatives.** A cloud scheduler running the same deterministic commands (recommended); provider cron. Proposed record: ADR-031.
- **Security implications.** Scheduled jobs run with a narrow service identity.
- **Data implications.** None.
- **Cost implications.** Small.
- **Migration implications.** None.
- **Test implications.** Adapt the scheduler tests.
- **Owner decision required.** —.

### ADR-009 — AMENDED

- **Existing decision.** Three approval tiers; hash-bound, single-use, expiring approvals.
- **New requirement and conflict.** The approval channels (Claude Code permission prompt, local terminal) do not exist for a remote service. The record design is unaffected.
- **Recommended replacement and alternatives.** Approval outside the session, on a page only the authenticated owner can use (recommended); an approving tool behind the client's permission prompt (weaker, differs by client); GitHub pull requests as approvals. Proposed record: ADR-025.
- **Security implications.** Stronger than IR1.1 if approval is not available to the token that proposes.
- **Data implications.** Approval rows unchanged.
- **Cost implications.** A minimal approval page must exist early.
- **Migration implications.** None.
- **Test implications.** Adapt all approval tests; add token-scope tests.
- **Owner decision required.** CD-04, CD-05.

### ADR-010 — AMENDED

- **Existing decision.** Independent backup with restore tests.
- **New requirement and conflict.** An external disk attached to a Mac contradicts cloud-only operation.
- **Recommended replacement and alternatives.** Provider backups plus an independent encrypted export to a second provider, keys held by the owner (recommended); provider backups only. Proposed record: ADR-028.
- **Security implications.** Keys outside the primary provider.
- **Data implications.** Backups of database, originals, configuration and exports.
- **Cost implications.** Second storage account; point-in-time recovery is a costly add-on on the one provider priced today.
- **Migration implications.** None.
- **Test implications.** Adapt backup tests; restore into a scratch database.
- **Owner decision required.** CD-10.

### ADR-011 — SUPERSEDED

- **Existing decision.** Architecture C+ among V5.0's six alternatives.
- **New requirement and conflict.** C+ is a local architecture. Its additions (provenance registry, memory lifecycle, approval gate, backups, evaluation harness) survive; its base does not.
- **Recommended replacement and alternatives.** See CLOUD-TRANSITION-ASSESSMENT §3 for the four options compared. Proposed record: ADR-021.
- **Security implications.** A public internet service replaces a private laptop.
- **Data implications.** All.
- **Cost implications.** Recurring.
- **Migration implications.** None.
- **Test implications.** All phases re-planned.
- **Owner decision required.** CD-16, CD-17.

### ADR-012 — AMENDED

- **Existing decision.** Governed fields in the registry; notes show projections; memory as digests.
- **New requirement and conflict.** The principle holds. Projections become an export, not files in a live vault.
- **Recommended replacement and alternatives.** —. Proposed record: ADR-030.
- **Security implications.** None.
- **Data implications.** Hand edits in an exported vault have no effect unless re-imported through validation.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** Adapt drift tests to re-import validation.
- **Owner decision required.** CD-06, CD-12.

### ADR-013 — SUPERSEDED

- **Existing decision.** Journal for file-plus-database commits on one filesystem.
- **New requirement and conflict.** There is no shared local filesystem. Atomic rename and staging directories have no cloud equivalent.
- **Recommended replacement and alternatives.** Write the immutable object first, then commit the database transaction; reconcile orphan objects (recommended); two-phase commit, rejected as unnecessary. Proposed record: ADR-026.
- **Security implications.** None.
- **Data implications.** Notes live in the database, so most of the journal's cases disappear; originals remain the cross-store case.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** The crash suite is redesigned around object-then-row.
- **Owner decision required.** —.

### ADR-014 — AMENDED

- **Existing decision.** Knowledge kept apart from code by folders.
- **New requirement and conflict.** Folders on a Mac no longer separate anything. The objective stands: content must not be able to change the code or permissions that govern it.
- **Recommended replacement and alternatives.** Separation by repository, data store and service identity. Proposed record: ADR-027.
- **Security implications.** Trust boundaries are identities and networks, not paths.
- **Data implications.** None.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** Replace path tests with identity and scope tests.
- **Owner decision required.** CD-08, CD-09.

### ADR-015 — SUPERSEDED

- **Existing decision.** Five enforcement layers on the client; no hooks.
- **New requirement and conflict.** Layers L1 and L2 (sandbox, Claude Code permission rules) protected data on the same machine. The data is no longer there, and sessions run in other projects whose settings this system does not control.
- **Recommended replacement and alternatives.** Server-side layers: identity, token scope, policy gate, database constraints, detection. Layers L3 to L5 carry over; L1 and L2 are replaced by authentication and scope. Proposed record: ADR-025.
- **Security implications.** No client-side control may be counted.
- **Data implications.** None.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** Replace the Mac security protocol with a service security test suite.
- **Owner decision required.** CD-04, CD-05.

### ADR-016 — RETAINED

- **Existing decision.** Readable sequential IDs; one registry of objects.
- **New requirement and conflict.** None. IR1.1 named multi-device writing as the reversal condition because each device would have had its own database. One central database allocates sequences transactionally for any number of sessions.
- **Recommended replacement and alternatives.** UUIDs, if the owner ever wants offline writers.
- **Security implications.** None.
- **Data implications.** None.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** Keep; add a concurrent-allocation test.
- **Owner decision required.** —.

### ADR-017 — AMENDED

- **Existing decision.** Small versioned extractors; OCR deferred.
- **New requirement and conflict.** Parsers would run on a server, on files that are untrusted.
- **Recommended replacement and alternatives.** Extraction in an isolated, resource-limited worker. Proposed record: ADR-026.
- **Security implications.** A parser flaw now affects a service, not a laptop session.
- **Data implications.** None.
- **Cost implications.** Worker runtime.
- **Migration implications.** None.
- **Test implications.** Adapt intake hardening tests.
- **Owner decision required.** CD-15.

### ADR-018 — SUPERSEDED

- **Existing decision.** No MCP server, plugin, web access or browser automation; auto memory off.
- **New requirement and conflict.** A remote MCP connector is the product's interface.
- **Recommended replacement and alternatives.** One first-party MCP server with narrow tools (recommended). Still no third-party servers, plugins or browser automation in the design. Auto memory and web access belong to each session's own project and can no longer be switched off by this system. Proposed record: ADR-024.
- **Security implications.** The connector is the whole attack surface; see CLOUD-SECURITY-ARCHITECTURE.
- **Data implications.** None.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** New connector test suite.
- **Owner decision required.** CD-13, CD-14.

### ADR-019 — DEFERRED

- **Existing decision.** Legacy vault import deferred; schema ready.
- **New requirement and conflict.** None.
- **Recommended replacement and alternatives.** —.
- **Security implications.** None.
- **Data implications.** None.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** Keep as contracts.
- **Owner decision required.** —.

### ADR-020 — RETAINED

- **Existing decision.** One memory model: records, revisions, evidence.
- **New requirement and conflict.** None. It is extended with sessions and with project scoping.
- **Recommended replacement and alternatives.** —. Proposed record: ADR-029.
- **Security implications.** None.
- **Data implications.** Two entities added (session, session event); project already exists.
- **Cost implications.** None.
- **Migration implications.** None.
- **Test implications.** Keep; add session tests.
- **Owner decision required.** CD-07, CD-11.

## 3. Proposed successor records

Titles and lineage only. Full records (context, alternatives, consequences, evidence, reversal, dependencies, acceptance) are written after the owner answers the decisions they depend on, so that no record prejudges a choice.

| Proposed ADR | Title | Amends or supersedes |
|---|---|---|
| ADR-021 | A cloud-hosted knowledge service is the only writer | ADR-011 |
| ADR-022 | Managed PostgreSQL as transactional authority | ADR-004 |
| ADR-023 | PostgreSQL full-text search over application-normalised text | ADR-005 |
| ADR-024 | One first-party remote MCP server as the only integration surface | ADR-018 |
| ADR-025 | Identity, scoped tokens and approval outside the session | ADR-009, ADR-015 |
| ADR-026 | Object storage for immutable originals; object-then-row commit; isolated extraction | ADR-013, ADR-017 |
| ADR-027 | Repositories, data stores and service identities as trust boundaries | ADR-014 |
| ADR-028 | Provider backups plus an independent encrypted export | ADR-010 |
| ADR-029 | Project and session registry; summaries, not transcripts | ADR-020 |
| ADR-030 | Notes authoritative in the service; Markdown as export and validated import | ADR-002, ADR-012 |
| ADR-031 | Cloud scheduler for deterministic jobs; no server-side model calls | ADR-008 |

## 4. Where this differs from the external compatibility review

- **ADR-001.** The review proposed amending it. It is retained: nothing about remote access requires the server to call a model.
- **ADR-006 and ADR-016.** The review proposed reassessing both. They are retained, with reasons in §2.
- **ADR-009.** The review listed an approving tool among the connector's tools. This assessment recommends that approval is not available to the connector at all.
- **ADR-013.** The review proposed a redesign; agreed, and it becomes simpler, not more complex.
