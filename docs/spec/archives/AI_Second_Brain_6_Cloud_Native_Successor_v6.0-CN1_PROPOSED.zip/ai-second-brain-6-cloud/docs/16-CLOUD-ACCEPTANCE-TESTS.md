# Updated Acceptance Tests

**DOC-CN-16** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)

Designed, not executed; no service exists. IR1.1's 143 designed tests, classed by the most affected requirement each covers: keep 66, adapt 61, replace 16. The list below is what the cloud adds. Detailed cases (data, steps, expected result) are written with the detailed design.

| ID | Test | Covers | Area |
|---|---|---|---|
| CT-01 | An unauthenticated or expired token is refused by every tool | CR-02, CR-18 | Authentication |
| CT-02 | A read-scope token cannot propose; no connector token can approve | CR-03 | Authorisation, tool permissions |
| CT-03 | Approval requires the owner's second factor and is bound to the proposal's hash, single-use and expiring | CR-04 | Approval workflow |
| CT-04 | A restricted project's records are not returned to a cross-project search | CR-09 | Project isolation |
| CT-05 | Cross-project search returns the project and source of every result | CR-09 | Cross-project retrieval, provenance |
| CT-06 | Arabic, English and mixed-language benchmark at the retrieval gate | FR-RET-008, NFR-007 | Arabic, English, mixed retrieval |
| CT-07 | A duplicate proposal returns the existing one; queue limits hold | FR-AGT-003 | Deduplication |
| CT-08 | A contradicting record is kept as a conflict, not overwritten | FR-MEM-005 | Contradiction handling |
| CT-09 | A session opens, registers artifacts and closes with a summary tied to its project | CR-08 | Session association |
| CT-10 | A new version of an artifact keeps the earlier one and its checksum | CR-10 | Artifact versioning |
| CT-11 | The service holds no repository write credential; a commit reference resolves | CR-07 | GitHub synchronisation, branch protection |
| CT-12 | No secret appears in logs, exports, tool results or the repository | CR-12 | Secret protection |
| CT-13 | Instruction-bearing text in a document or tool input changes no permission and writes nothing without approval | CR-19 | Prompt-injection resistance |
| CT-14 | A backup verifies against its manifest; a corrupted one fails closed | CR-14 | Backup integrity |
| CT-15 | A backup restores into a scratch environment with integrity, audit chain and sampled originals checked | CR-14 | Restore verification |
| CT-16 | Migrations apply forward on a copy with a backup taken first | FR-OPS-006 | Database migrations |
| CT-17 | Malformed, oversized and out-of-schema tool inputs are rejected with stable errors | CR-16, CR-19 | API validation |
| CT-18 | An interrupted ingest leaves no row without its object and reconciles orphan objects | CR-11 | Failure recovery |
| CT-19 | Requests beyond the limit are refused and recorded | CR-16 | Rate limiting |
| CT-20 | Every connector call has one audit event; the chain verifies | CR-17 | Audit logging |
| CT-21 | Concurrent sessions allocate distinct sequential IDs | CR-06 | Identifiers |
| CT-22 | An original read back matches its checksum; an altered object is detected | CR-10 | Immutable evidence |
| CT-23 | Export is byte-identical for identical state; re-import of an edited file is validated and needs approval | CR-21 | Markdown export |
| CT-24 | A full export loads into an empty environment at another provider | CR-15 | Portability |
| CT-25 | A revoked token stops working at once; active grants are listed | CR-18 | Token lifecycle |
| CT-26 | A stub server using the connector's name is detected by the bootstrap | CR-22 | Connector identity |
| CT-27 | A hostile file cannot exceed the worker's limits or reach the network | CR-23 | Extraction isolation |
| CT-28 | No scheduled job calls a model; only allowlisted jobs exist | CR-24 | Scheduling |
| CT-29 | Usage above the alarm threshold notifies the owner | CR-20 | Cost |
| CT-30 | Data stores report the configured region | CR-13 | Residency |

## End-to-end demonstration, synthetic data only

Initialise a test workspace → create two projects → ingest sample documents in Arabic and English → open and close test sessions → retrieve across projects → propose an update → show an unauthorised change refused → approve a permitted change on the approval page → verify provenance → export Markdown → restore from the independent backup into a scratch environment.
