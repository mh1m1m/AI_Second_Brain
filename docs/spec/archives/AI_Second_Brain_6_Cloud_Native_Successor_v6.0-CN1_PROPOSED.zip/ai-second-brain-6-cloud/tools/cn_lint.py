#!/usr/bin/env python3
"""Consistency checker for the proposed v6.0-CN1 package. Specification tooling; standard library only; reads both folders, writes nothing.
Usage: python3 -I tools/cn_lint.py <CN1 folder> <IR1.1 folder>"""
import json, os, re, sys
CN, IR = sys.argv[1], sys.argv[2]
docs = {f: open(os.path.join(CN, "docs", f), encoding="utf-8").read() for f in sorted(os.listdir(os.path.join(CN, "docs"))) if f.endswith(".md")}
docs["README.md"] = open(os.path.join(CN, "README.md"), encoding="utf-8").read()
allt = "\n".join(docs.values())
R = json.load(open(os.path.join(IR, "docs/specification/data/requirements.json"), encoding="utf-8")); REQ = {r["id"] for r in R["functional"] + R["non_functional"]}
TST = {t["id"] for t in json.load(open(os.path.join(IR, "docs/specification/data/tests.json"), encoding="utf-8"))}
adr, imp, dec, cert = docs["03-ADR-TRANSITION-MATRIX.md"], docs["04-REQUIREMENTS-IMPACT-MATRIX.md"], docs["17-CLOUD-OWNER-DECISIONS.md"], docs["18-CLOUD-READINESS-CERTIFICATE.md"]
def rows(text, pat): return set(re.findall(r"(?m)^\| (%s) \|" % pat, text))
defined = {"ADR": {"ADR-%03d" % n for n in range(1, 21)} | rows(adr, r"ADR-0[23]\d"), "CD": rows(dec, r"CD-\d\d"), "CR": rows(imp, r"CR-\d\d"),
           "CV": rows(docs["20-CLOUD-AUTHORIZATION-INSTRUMENTS.md"], r"CV-\d\d") | {"CV-02", "CV-13"}, "CT": rows(docs["16-CLOUD-ACCEPTANCE-TESTS.md"], r"CT-\d\d"), "CG": rows(cert, r"CG-\d\d"),
           "FR": REQ, "NFR": REQ, "TEST": TST, "D": {"D-%02d" % n for n in range(1, 21)}, "GAP": {"GAP-033", "GAP-034"}}
PAT = {"ADR": r"ADR-\d{3}", "CD": r"CD-\d\d", "CR": r"CR-\d\d", "CV": r"CV-\d\d", "CT": r"CT-\d\d", "CG": r"CG-\d\d", "FR": r"FR-[A-Z]{3}-\d{3}", "NFR": r"NFR-\d{3}", "TEST": r"TEST-[A-Z]{3}-\d{3}", "D": r"(?<![A-Z-])D-\d\d", "GAP": r"GAP-\d{3}"}
dangling = sorted({f"{f}: {m}" for f, t in docs.items() for k, p in PAT.items() for m in re.findall(p, t) if m not in defined[k]})
disp = dict(re.findall(r"(?m)^### (ADR-\d{3}) — (RETAINED|AMENDED|SUPERSEDED|DEFERRED|REJECTED)$", adr))
need = ["Existing decision", "New requirement and conflict", "Recommended replacement and alternatives", "Security implications", "Data implications", "Cost implications", "Migration implications", "Test implications", "Owner decision required"]
secs = re.split(r"(?m)^(?=### ADR-\d{3} — )", adr)[1:]
incomplete = [s[4:11] + ": " + n for s in secs for n in need if f"- **{n}.**" not in s]
req_rows = set(re.findall(r"(?m)^\| ((?:FR-[A-Z]{3}|NFR)-\d{3}) \| .* \| (?:RETAINED|AMENDED|SUPERSEDED|DEFERRED) \|", imp))
ans = dec.split("## 4. Answer record")[1]
filled = [l[:50] for l in ans.split("\n") if l.startswith("| ") and not l.startswith("| Item") and not l.startswith("|---") and any(c.strip() for c in l.strip().strip("|").split("|")[1:])]
approved = [f for f, t in docs.items() if re.search(r"Status: (APPROVED|ACCEPTED)", t)]
gates = rows(cert, r"CG-\d\d")
checks = [("all 20 IR1.1 ADRs have a disposition", sorted({"ADR-%03d" % n for n in range(1, 21)} - set(disp))), ("every ADR entry has all nine fields", incomplete),
          ("all 100 IR1.1 requirements are classified", sorted(REQ - req_rows)), ("every identifier resolves", dangling), ("owner answer record is empty", filled),
          ("no document is marked approved", approved), ("twelve transition gates are reported", [] if len(gates) == 12 else [str(len(gates))]),
          ("implementation is stated as not authorised", [] if "IMPLEMENTATION NOT AUTHORIZED" in cert and "IMPLEMENTATION NOT AUTHORIZED" in dec else ["missing"]),
          ("no application source directory exists", [p for p in ("src", "migrations", "infrastructure", "tests") if os.path.exists(os.path.join(CN, p))])]
bad = 0
for n, f in checks:
    print(("PASS " if not f else "FAIL ") + n + ("" if not f else "  -> " + json.dumps(f[:12], ensure_ascii=False))); bad += bool(f)
sys.exit(1 if bad else 0)
