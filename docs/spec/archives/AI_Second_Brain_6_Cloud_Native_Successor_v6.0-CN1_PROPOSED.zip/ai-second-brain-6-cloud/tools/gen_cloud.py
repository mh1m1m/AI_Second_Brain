#!/usr/bin/env python3
"""Generates the proposed cloud-native successor package v6.0-CN1 from data. Specification tooling; standard library only.
Reads the IR1.1 package (never writes to it). Usage: python3 -I gen_cloud.py IR11_ROOT OUT ZIP_SHA"""
import json, os, sys, collections, hashlib
IR, OUT, ZSHA = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(os.path.join(OUT, "docs"), exist_ok=True)
def wr(name, lines): open(os.path.join(OUT, name), "w", encoding="utf-8").write("\n".join(lines).rstrip("\n") + "\n")
def H(code, title): return [f"# {title}", "", f"**{code}** · v6.0-CN1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Predecessor: v6.0-IR1.1 (unchanged)", ""]
def T(head, rows): return ["| " + " | ".join(head) + " |", "|" + "---|" * len(head)] + ["| " + " | ".join(str(c) for c in r) + " |" for r in rows] + [""]
R = json.load(open(os.path.join(IR, "docs/specification/data/requirements.json"), encoding="utf-8")); ALL = R["functional"] + R["non_functional"]
TESTS = json.load(open(os.path.join(IR, "docs/specification/data/tests.json"), encoding="utf-8"))
NOTE = "Evidence words: **VERIFIED** = read in documentation or measured today; **UNVERIFIED** = not checked in this pass; **PROPOSED** = a recommendation awaiting the owner."

# ------------------------------------------------------------------ ADR dispositions
ADR = [
 ("ADR-001", "Claude Code is the only AI platform; Python calls no model", "RETAINED", "None. Sessions reach the service through the connector; the service still calls no model", "—", "Summaries and proposals are written by Claude inside the session and submitted as data. A server that called a model would need a provider key, add cost and add an injection surface", "No model credential on the server", "None", "No model cost on the server", "None", "Keep", "—"),
 ("ADR-002", "Notes are Markdown files; the file is authoritative for body", "AMENDED", "There is no local vault to be authoritative. A file on a laptop cannot be the authority of a cloud system", "ADR-030", "Notes authoritative in the service with deterministic Markdown export (recommended); or Markdown authoritative in a private knowledge repository", "Note text leaves the owner's disk and lives with a provider", "Body authority moves from file to database row or repository file", "None", "None: no vault exists", "Adapt sync and drift tests", "CD-06"),
 ("ADR-003", "Obsidian is optional; core features only", "RETAINED", "None; the cloud requirement makes it more optional, not less", "—", "—", "None", "Obsidian reads an export", "None", "None", "Keep", "CD-12"),
 ("ADR-004", "SQLite is the transactional registry", "SUPERSEDED", "A file database on one Mac cannot serve sessions in other environments", "ADR-022", "Managed PostgreSQL (owner's leading candidate, recommended); a hosted SQLite-compatible service (least change to the executed schema, narrower provider choice)", "Database reachable only by the service, never from the internet; separate roles for service, migration and backup", "28 tables and 15 triggers must be re-expressed and re-probed; the 27 executed SQLite probes do not carry over as evidence", "A paid managed database", "Nothing to migrate: no data exists", "Re-run every schema probe on the new engine", "CD-02"),
 ("ADR-005", "FTS5 with Arabic normalisation and a stem column in the application", "AMENDED", "The engine changes with ADR-004. The design does not: normalisation and stemming happen in the application, so they are engine-independent", "ADR-023", "PostgreSQL full-text search over the application-normalised and stemmed text (recommended); PostgreSQL's built-in Arabic configuration; trigram matching; an external search engine", "None", "Index text still differs from stored text; excerpts still come from originals", "None beyond the database", "None", "The tokenizer probe must be repeated on PostgreSQL before selection (CV-03); gate RET-G1 and the benchmark stay", "CD-02"),
 ("ADR-006", "No vector search until gate RET-G2", "RETAINED", "None. A cloud database makes vectors easy to switch on, which is a reason to keep the gate, not to drop it", "—", "—", "An embedding model would be a second model path (ADR-001)", "None", "Avoids embedding cost", "None", "Keep", "—"),
 ("ADR-007", "No graph database; typed relationships in the registry", "RETAINED", "None", "—", "—", "None", "Relationships move with the registry", "None", "None", "Keep", "—"),
 ("ADR-008", "One orchestrator; scheduled jobs deterministic; no unattended model runs", "AMENDED", "launchd on a Mac cannot schedule cloud jobs. The principle is unaffected", "ADR-031", "A cloud scheduler running the same deterministic commands (recommended); provider cron", "Scheduled jobs run with a narrow service identity", "None", "Small", "None", "Adapt the scheduler tests", "—"),
 ("ADR-009", "Three approval tiers; hash-bound, single-use, expiring approvals", "AMENDED", "The approval channels (Claude Code permission prompt, local terminal) do not exist for a remote service. The record design is unaffected", "ADR-025", "Approval outside the session, on a page only the authenticated owner can use (recommended); an approving tool behind the client's permission prompt (weaker, differs by client); GitHub pull requests as approvals", "Stronger than IR1.1 if approval is not available to the token that proposes", "Approval rows unchanged", "A minimal approval page must exist early", "None", "Adapt all approval tests; add token-scope tests", "CD-04, CD-05"),
 ("ADR-010", "Independent backup with restore tests", "AMENDED", "An external disk attached to a Mac contradicts cloud-only operation", "ADR-028", "Provider backups plus an independent encrypted export to a second provider, keys held by the owner (recommended); provider backups only", "Keys outside the primary provider", "Backups of database, originals, configuration and exports", "Second storage account; point-in-time recovery is a costly add-on on the one provider priced today", "None", "Adapt backup tests; restore into a scratch database", "CD-10"),
 ("ADR-011", "Architecture C+ among V5.0's six alternatives", "SUPERSEDED", "C+ is a local architecture. Its additions (provenance registry, memory lifecycle, approval gate, backups, evaluation harness) survive; its base does not", "ADR-021", "See CLOUD-TRANSITION-ASSESSMENT §3 for the four options compared", "A public internet service replaces a private laptop", "All", "Recurring", "None", "All phases re-planned", "CD-16, CD-17"),
 ("ADR-012", "Governed fields in the registry; notes show projections; memory as digests", "AMENDED", "The principle holds. Projections become an export, not files in a live vault", "ADR-030", "—", "None", "Hand edits in an exported vault have no effect unless re-imported through validation", "None", "None", "Adapt drift tests to re-import validation", "CD-06, CD-12"),
 ("ADR-013", "Journal for file-plus-database commits on one filesystem", "SUPERSEDED", "There is no shared local filesystem. Atomic rename and staging directories have no cloud equivalent", "ADR-026", "Write the immutable object first, then commit the database transaction; reconcile orphan objects (recommended); two-phase commit, rejected as unnecessary", "None", "Notes live in the database, so most of the journal's cases disappear; originals remain the cross-store case", "None", "None", "The crash suite is redesigned around object-then-row", "—"),
 ("ADR-014", "Knowledge kept apart from code by folders", "AMENDED", "Folders on a Mac no longer separate anything. The objective stands: content must not be able to change the code or permissions that govern it", "ADR-027", "Separation by repository, data store and service identity", "Trust boundaries are identities and networks, not paths", "None", "None", "None", "Replace path tests with identity and scope tests", "CD-08, CD-09"),
 ("ADR-015", "Five enforcement layers on the client; no hooks", "SUPERSEDED", "Layers L1 and L2 (sandbox, Claude Code permission rules) protected data on the same machine. The data is no longer there, and sessions run in other projects whose settings this system does not control", "ADR-025", "Server-side layers: identity, token scope, policy gate, database constraints, detection. Layers L3 to L5 carry over; L1 and L2 are replaced by authentication and scope", "No client-side control may be counted", "None", "None", "None", "Replace the Mac security protocol with a service security test suite", "CD-04, CD-05"),
 ("ADR-016", "Readable sequential IDs; one registry of objects", "RETAINED", "None. IR1.1 named multi-device writing as the reversal condition because each device would have had its own database. One central database allocates sequences transactionally for any number of sessions", "—", "UUIDs, if the owner ever wants offline writers", "None", "None", "None", "None", "Keep; add a concurrent-allocation test", "—"),
 ("ADR-017", "Small versioned extractors; OCR deferred", "AMENDED", "Parsers would run on a server, on files that are untrusted", "ADR-026", "Extraction in an isolated, resource-limited worker", "A parser flaw now affects a service, not a laptop session", "None", "Worker runtime", "None", "Adapt intake hardening tests", "CD-15"),
 ("ADR-018", "No MCP server, plugin, web access or browser automation; auto memory off", "SUPERSEDED", "A remote MCP connector is the product's interface", "ADR-024", "One first-party MCP server with narrow tools (recommended). Still no third-party servers, plugins or browser automation in the design. Auto memory and web access belong to each session's own project and can no longer be switched off by this system", "The connector is the whole attack surface; see CLOUD-SECURITY-ARCHITECTURE", "None", "None", "None", "New connector test suite", "CD-13, CD-14"),
 ("ADR-019", "Legacy vault import deferred; schema ready", "DEFERRED", "None", "—", "—", "None", "None", "None", "None", "Keep as contracts", "—"),
 ("ADR-020", "One memory model: records, revisions, evidence", "RETAINED", "None. It is extended with sessions and with project scoping", "ADR-029", "—", "None", "Two entities added (session, session event); project already exists", "None", "None", "Keep; add session tests", "CD-07, CD-11")]
NEW_ADR = [("ADR-021", "A cloud-hosted knowledge service is the only writer", "ADR-011"), ("ADR-022", "Managed PostgreSQL as transactional authority", "ADR-004"),
 ("ADR-023", "PostgreSQL full-text search over application-normalised text", "ADR-005"), ("ADR-024", "One first-party remote MCP server as the only integration surface", "ADR-018"),
 ("ADR-025", "Identity, scoped tokens and approval outside the session", "ADR-009, ADR-015"), ("ADR-026", "Object storage for immutable originals; object-then-row commit; isolated extraction", "ADR-013, ADR-017"),
 ("ADR-027", "Repositories, data stores and service identities as trust boundaries", "ADR-014"), ("ADR-028", "Provider backups plus an independent encrypted export", "ADR-010"),
 ("ADR-029", "Project and session registry; summaries, not transcripts", "ADR-020"), ("ADR-030", "Notes authoritative in the service; Markdown as export and validated import", "ADR-002, ADR-012"),
 ("ADR-031", "Cloud scheduler for deterministic jobs; no server-side model calls", "ADR-008")]

# ------------------------------------------------------------------ requirement impact
DEF = {"FR-ING": "RETAINED", "FR-RET": "RETAINED", "FR-MEM": "RETAINED", "FR-KNW": "RETAINED", "FR-PRJ": "RETAINED", "FR-AGT": "RETAINED", "FR-SEC": "AMENDED", "FR-OPS": "AMENDED", "FR-OBS": "AMENDED", "FR-IMP": "DEFERRED", "NFR": "RETAINED"}
IMP = {
 "FR-ING-002": ("AMENDED", "Originals in object storage, content-addressed and immutable", "CR-10"), "FR-ING-005": ("AMENDED", "Intake runs on the server", "CR-23"),
 "FR-ING-007": ("AMENDED", "Extraction in an isolated worker", "CR-23"), "FR-ING-010": ("SUPERSEDED", "No inbox folder; an upload path into staging storage", "CR-10"),
 "FR-RET-001": ("AMENDED", "Search engine changes; project filter and labels added", "CR-09"), "FR-RET-004": ("AMENDED", "Ranking re-derived on the new engine", "—"),
 "FR-RET-006": ("AMENDED", "Query log is personal data held by a provider", "CR-12"), "FR-RET-007": ("AMENDED", "Index maintained by the database", "—"),
 "FR-MEM-003": ("AMENDED", "Candidates also arrive from session summaries", "CR-08"),
 "FR-KNW-001": ("AMENDED", "Note schema becomes the export schema", "CR-21"), "FR-KNW-003": ("AMENDED", "Templates drive export", "CR-21"),
 "FR-KNW-004": ("SUPERSEDED", "No live vault to synchronise; validated re-import instead", "CR-21"), "FR-KNW-005": ("AMENDED", "Drift detection moves to re-import", "CR-21"),
 "FR-KNW-009": ("AMENDED", "Export becomes the lock-in control", "CR-15"), "FR-PRJ-002": ("AMENDED", "Project carries a repository mapping", "CR-07"),
 "FR-AGT-001": ("AMENDED", "Enforcement on the server", "CR-05"), "FR-AGT-004": ("SUPERSEDED", "Channels redefined: approval outside the session", "CR-03, CR-04"),
 "FR-AGT-006": ("AMENDED", "History includes connector calls", "CR-17"), "FR-AGT-007": ("SUPERSEDED", "No operating workspace; a connector and a bootstrap skill", "CR-02, CR-22"),
 "FR-AGT-008": ("AMENDED", "Cloud scheduler", "CR-24"),
 "FR-SEC-001": ("SUPERSEDED", "Path policy replaced by identity and scope", "CR-03, CR-05"), "FR-SEC-002": ("AMENDED", "Secret manager; token lifecycle", "CR-12, CR-18"),
 "FR-SEC-003": ("RETAINED", "Applies to tool inputs and outputs as well", "CR-19"), "FR-SEC-004": ("AMENDED", "File-name policy at upload; no instruction discovery risk on the server", "CR-23"),
 "FR-SEC-005": ("RETAINED", "Audit chain unchanged; covers connector calls", "CR-17"), "FR-SEC-006": ("SUPERSEDED", "The service is networked; replaced by ingress and egress policy", "CR-02, CR-12, CR-13"),
 "FR-SEC-007": ("AMENDED", "One integration is approved by design; all others stay off", "CR-02"), "FR-SEC-008": ("AMENDED", "Hardening applies to a server worker", "CR-23"),
 "FR-OPS-001": ("RETAINED", "Index rebuild from canonical data", "—"), "FR-OPS-002": ("AMENDED", "Restore-test into a scratch database and bucket", "CR-14"), "FR-OPS-003": ("AMENDED", "Database dump, objects and configuration to an independent provider", "CR-14"),
 "FR-OPS-004": ("AMENDED", "Health endpoint and checks", "—"), "FR-OPS-005": ("AMENDED", "Orphan-object reconciliation", "CR-11"), "FR-OPS-006": ("AMENDED", "Migrations on a managed database with a backup first", "—"),
 "FR-OPS-007": ("SUPERSEDED", "No launchd", "CR-24"), "FR-OPS-008": ("RETAINED", "Logs without content", "—"), "FR-OPS-009": ("SUPERSEDED", "Provisioning replaces init", "—"), "FR-OPS-010": ("AMENDED", "Restore to a new environment", "CR-14"),
 "FR-OBS-003": ("RETAINED", "Right-to-left rules apply to exports", "—"),
 "NFR-001": ("AMENDED", "Latency target must include the network", "—"), "NFR-002": ("AMENDED", "Integrity across object store and database", "CR-11"), "NFR-004": ("SUPERSEDED", "Offline operation is the opposite of the requirement", "CR-01, CR-15"),
 "NFR-006": ("AMENDED", "Objectives restated for cloud recovery", "CR-14"), "NFR-008": ("AMENDED", "Throughput re-measured", "—"), "NFR-009": ("SUPERSEDED", "Data necessarily leaves the machine; replaced by residency and egress rules", "CR-13"),
 "NFR-011": ("AMENDED", "A web framework and database driver are added", "—"), "NFR-012": ("AMENDED", "Scale limits of the provider plan", "CR-20"), "NFR-013": ("AMENDED", "Usability across environments", "—"),
 "NFR-014": ("AMENDED", "Service observability", "CR-17"), "NFR-015": ("AMENDED", "Adds a recurring cost ceiling", "CR-20"), "NFR-017": ("AMENDED", "Readable without Claude Code through export", "CR-15"),
 "NFR-018": ("AMENDED", "Recoverability restated", "CR-14"), "NFR-020": ("SUPERSEDED", "macOS compatibility replaced by runtime and provider compatibility", "CR-01"), "NFR-021": ("RETAINED", "Deterministic rebuild", "—")}
def impact(r):
    if r["id"] in IMP: return IMP[r["id"]]
    c = DEF[r["id"].rsplit("-", 1)[0]]
    return (c, {"RETAINED": "Logic unchanged; constraints re-expressed on the new database", "AMENDED": "Restated for the service", "DEFERRED": "Still deferred"}[c], "—")
IMPACT = {r["id"]: impact(r) for r in ALL}
CR = [("CR-01", "The service operates with no personal computer online"), ("CR-02", "One remote MCP server over HTTPS with OAuth is the only path for sessions; no other write path exists"),
 ("CR-03", "Connector tokens carry scopes per tool: read and propose. No connector token can approve"), ("CR-04", "The owner authenticates with a second factor for approvals and administration"),
 ("CR-05", "Every authorisation is enforced on the server; no client-side control is relied on"), ("CR-06", "Registry of workspace, project, session, artifact and knowledge record with stable IDs"),
 ("CR-07", "A project may map to repositories by reference; the service holds no repository write credential"), ("CR-08", "A session is registered and closed with a summary, artifact references, open issues and next actions"),
 ("CR-09", "Retrieval across projects returns provenance and the project of every result"), ("CR-10", "Originals are stored as content-addressed immutable objects and verified by checksum on read"),
 ("CR-11", "Object-then-row commit with reconciliation of orphan objects"), ("CR-12", "Encryption in transit and at rest; secrets only in a secret manager; none in prompts, repositories or notes"),
 ("CR-13", "The region and provider of every data store are recorded and enforced by configuration"), ("CR-14", "An independent encrypted backup at a second provider, restore-tested before any owner data is stored"),
 ("CR-15", "A complete export (Markdown, JSON, database dump, originals) and a tested move to another provider"), ("CR-16", "Rate and size limits on every tool; results sized within the client's tool-output limit"),
 ("CR-17", "A hash-chained audit event for every connector call: identity, token, tool, project, outcome"), ("CR-18", "Tokens expire, can be revoked and rotated; active grants can be listed"),
 ("CR-19", "All tool inputs and all returned content are treated as untrusted data and delimited as such"), ("CR-20", "A monthly cost ceiling with a usage alarm"),
 ("CR-21", "Deterministic Markdown export; re-import validated, never overwriting without conflict detection and approval"), ("CR-22", "The bootstrap confirms it is talking to the genuine service before any knowledge is sent"),
 ("CR-23", "Untrusted files are parsed in an isolated, resource-limited worker"), ("CR-24", "Scheduled jobs are deterministic only; the server calls no model")]
cnt = collections.Counter(v[0] for v in IMPACT.values())
tcls = collections.Counter()
ORDER = {"RETAINED": 0, "DEFERRED": 0, "AMENDED": 1, "SUPERSEDED": 2}
for t in TESTS:
    w = max((ORDER[IMPACT[r][0]] for r in t["requirements"] if r in IMPACT), default=0); tcls[["keep", "adapt", "replace"][w]] += 1

o = H("DOC-CN-03", "ADR Transition Matrix") + ["All 20 IR1.1 records, reconciled against the confirmed cloud-native objective. Dispositions are **PROPOSED**. No IR1.1 record is edited; each stays as written in the preserved baseline.", "", NOTE, "",
     "## 1. Summary", ""] + T(["ADR", "Existing decision", "Disposition", "Replacement", "Owner decision"], [(a[0], a[1], a[2], a[4], a[11]) for a in ADR])
dc = collections.Counter(a[2] for a in ADR)
o += ["Totals: " + ", ".join(f"{k} {v}" for k, v in sorted(dc.items())) + ". None is REJECTED.", "", "## 2. Detail", ""]
for a in ADR:
    o += [f"### {a[0]} — {a[2]}", "", f"- **Existing decision.** {a[1]}.", f"- **New requirement and conflict.** {a[3]}.", f"- **Recommended replacement and alternatives.** {a[5]}." + (f" Proposed record: {a[4]}." if a[4] != '—' else ""),
          f"- **Security implications.** {a[6]}.", f"- **Data implications.** {a[7]}.", f"- **Cost implications.** {a[8]}.", f"- **Migration implications.** {a[9]}.", f"- **Test implications.** {a[10]}.", f"- **Owner decision required.** {a[11]}.", ""]
o += ["## 3. Proposed successor records", "", "Titles and lineage only. Full records (context, alternatives, consequences, evidence, reversal, dependencies, acceptance) are written after the owner answers the decisions they depend on, so that no record prejudges a choice.", ""] + T(["Proposed ADR", "Title", "Amends or supersedes"], NEW_ADR)
o += ["## 4. Where this differs from the external compatibility review", "", "- **ADR-001.** The review proposed amending it. It is retained: nothing about remote access requires the server to call a model.",
      "- **ADR-006 and ADR-016.** The review proposed reassessing both. They are retained, with reasons in §2.", "- **ADR-009.** The review listed an approving tool among the connector's tools. This assessment recommends that approval is not available to the connector at all.",
      "- **ADR-013.** The review proposed a redesign; agreed, and it becomes simpler, not more complex."]
wr("docs/03-ADR-TRANSITION-MATRIX.md", o)

o = H("DOC-CN-04", "Requirements Impact Matrix") + ["All 100 IR1.1 requirements, classified against the cloud-native objective. Classification is **PROPOSED**. Requirement text is not rewritten here: rewriting follows the owner's architecture decisions.", "",
     f"Totals: " + ", ".join(f"{k} {v}" for k, v in sorted(cnt.items())) + f". IR1.1's {len(TESTS)} designed tests, classed by the most affected requirement each covers: keep {tcls['keep']}, adapt {tcls['adapt']}, replace {tcls['replace']}.", "",
     "RETAINED means the behaviour is unchanged; where it rests on database constraints, those are re-expressed and re-probed on the new engine.", "", "## 1. Matrix", ""]
o += T(["Requirement", "Title", "Priority", "Impact", "What changes", "New requirement"], [(r["id"], r["title"], r["prio"], *IMPACT[r["id"]]) for r in ALL])
o += ["## 2. Proposed new requirements", "", "Numbered CR until they are merged into a successor requirements specification.", ""] + T(["ID", "Requirement"], CR)
o += ["## 3. Governance preserved", ""] + T(["Principle", "Carried by"], [("Evidence before memory", "FR-MEM-002 retained"), ("Immutable originals", "FR-ING-002 amended, CR-10"), ("Stable identifiers", "ADR-016 retained"), ("Provenance", "FR-ING-003, FR-RET-002 retained; CR-09"),
     ("Historical reconstruction", "FR-MEM-008, FR-PRJ-001 retained"), ("Human approval", "FR-AGT-001 amended; CR-03, CR-04"), ("Bounded proposal queue (GAP-033)", "FR-AGT-003 retained"), ("Auditability", "FR-SEC-005 retained; CR-17"),
     ("Backup before valuable ingestion (GAP-034)", "CR-14"), ("Tested recovery", "FR-OPS-002 amended; CR-14, CR-15"), ("Arabic-first retrieval", "FR-RET-003, NFR-007 retained"), ("Independent review", "Gate CG-12")])
wr("docs/04-REQUIREMENTS-IMPACT-MATRIX.md", o)
json.dump({"adr": [{"id": a[0], "disposition": a[2], "replacement": a[4]} for a in ADR], "requirements": {k: {"impact": v[0], "new": v[2]} for k, v in IMPACT.items()}, "cloud_requirements": [c[0] for c in CR]},
          open(os.path.join(OUT, "docs/transition-data.json"), "w", encoding="utf-8"), indent=1)
print("matrices ok", dict(dc), dict(cnt), dict(tcls))
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "gen_cloud_docs.py"), encoding="utf-8").read())
