# Architecture Simplification

**DOC-A1-05** · v6.0-CN1.1-A1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Addendum to v6.0-CN1.1 (unchanged)

Amendment AD-05. Independent owner approval stays mandatory in every option: no connector token can approve.

## 1. Authentication and approval: three options

|  | A. Custom (CN1.1) | B. Managed authentication | C. Approval through GitHub |
|---|---|---|---|
| What | Own authorisation server and approval surface; passkey; assertion bound to the proposal hash | A managed identity service handles owner login, passkeys or MFA, sessions and recovery, and, if it can, OAuth for the connector. A small approval page remains | Proposals appear as pull requests in a private repository; merging approves |
| Security | Strongest binding of gesture to payload. All of it must be built correctly by one person | Login, MFA and recovery are maintained by specialists. Binding is server-side: fresh re-authentication, then the approval row is tied to the stored hash | Uses GitHub's login and MFA. Proposal text sits in a repository; the service needs GitHub access; binding rests on commit contents |
| Operating cost | No fee; highest effort | Included in the costed configuration A; otherwise unpriced | No fee |
| Maintenance | Highest: identity code is security-critical | Low for identity; the approval page remains | Low; adds a dependency on GitHub for approvals |
| Recovery | Own procedure | Provider's account recovery, which is also an attack path | GitHub account recovery |
| Build complexity | High | Moderate | Moderate; awkward for bidirectional text and for classification rules |
| Unknowns | None external | Whether the provider can act as the OAuth server for a remote MCP connector and can require step-up authentication: UNVERIFIED (CV-19) | Contradicts 'no GitHub credential in the service' |

**Recommendation.** Option B for the first release if CV-19 passes; option A only if it does not. Option C is not recommended. With B, requirement CR-31 (assertion whose challenge contains the proposal hash) becomes a target to meet if the provider supports it, and otherwise is replaced by fresh re-authentication plus server-side binding. That is weaker than A against a compromised browser session and equal against a manipulated Claude session, which is the threat the separation exists for.

## 2. First-release profile

| Component | CN1.1 | First release | Why |
|---|---|---|---|
| Owner login and approval | Custom authorisation server, passkey, payload-bound assertion | Managed authentication plus a small approval page (if CV-19 passes) | Least security-critical code for one person to own |
| Grants | Several, with ceilings, projects, elevation | One account-wide grant, ceiling K1, shared projects | No isolation is verified (AD-02) |
| Per-project connections | Proposed | Deferred | Needs CV-17 |
| Elevation | Time-boxed | Deferred | AD-02 |
| Extraction worker | Isolated worker for all formats | Markdown and text only, parsed in the service; PDF, DOCX and HTML with the isolated worker in the next stage | Formats were already staged; the worker arrives with the parsers that need it |
| Backups | Provider plus independent encrypted export | Unchanged | Recovery is not where to save |
| Classification | Five classes | Unchanged; K3 not admitted; K2 stored but not served | Governance costs little to keep |
| Session memory | Unreviewed, same project | Unchanged, with the tiers of MEMORY-TRUST-BOUNDARIES | Core of the product |

Effect on the monthly estimate of CN1.1 (configuration A): about US$32 instead of about US$40, since the always-on worker is not needed at first. Still part verified, part estimate.

What is not simplified: server-side authorisation of every call, the approval separation, the audit chain, classification, restore-tested backups before real data.
