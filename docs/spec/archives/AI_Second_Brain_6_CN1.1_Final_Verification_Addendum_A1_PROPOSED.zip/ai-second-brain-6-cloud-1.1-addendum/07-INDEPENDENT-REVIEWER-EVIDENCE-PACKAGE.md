# Evidence Package for an Independent Reviewer

**DOC-A1-07** · v6.0-CN1.1-A1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Addendum to v6.0-CN1.1 (unchanged)

The independent-review gate is NOT_VERIFIED. This is what a reviewer needs, and what they should not take on trust.

## Archives

| Archive | SHA-256 | Role |
|---|---|---|
| v6.0-IR1.1 | `0dcc02510a6878079e79a303dc2a5864f204eb1a1766076ff765a6062f09353f` | Local-first historical baseline; governance to be preserved |
| v6.0-CN1 | `e5e696df0d4a95028c52a1422cc72dd8232260fbd3b53e1b33c2ca3185066222` | First cloud-native proposal |
| v6.0-CN1.1 | `5bae75c2c640bcf60e183ebd8a034613d118645ddd4f78412a3aa2e58dbc0a0f` | Corrected proposal with adversarial assessment |
| v6.0-CN1.1-A1 | See MANIFEST.md | This addendum |

## Reading order

1. This addendum: 01 briefing, 03, 04, 05, 06, 02.
2. CN1.1: 27 adversarial assessment, 25 residual risks, 24 security assurance, 22 approval authority, 23 project access, 21 classification, 17 decisions.
3. CN1.1: 03 and 04 for what was kept from IR1.1.

## Unresolved findings

- Connector shadowing: no effective mitigation (RR-02).
- Released content can leave through the session (RR-01).
- Unreviewed session notes can influence later sessions of the same project (RR-13).
- No isolation of credentials per session, project or environment (RR-14, deferred with the feature).
- Whether sessions consult the brain unprompted (UX-B) is unknown.
- Arabic retrieval on PostgreSQL is unmeasured.
- The dispositions of the twelve adversarial findings were applied by the author and re-checked by no one.

## Verification limitations

- Nothing has been built, deployed or connected. Every statement about Claude Code comes from documentation read on 2026-11-10.
- The only executed evidence is from IR1.1: a SQLite schema with 27 probes and an Arabic tokenizer probe, both in a sandbox.
- Prices: one provider read on its own page; the rest from secondary sources or estimates, each marked.
- The repository listing is one session's view.
- The package's checkers test coverage and identifiers, not the soundness of any control.
- The adversarial assessment was by a separate agent of the same model as the author.

## Questions worth a reviewer's time

1. Is option B (managed authentication) sound enough for approvals, or is payload-bound assertion necessary?
2. Is the K1 ceiling for all connectors an adequate answer to shadowing and exfiltration for a personal system?
3. Does anything in the memory tiers still let unreviewed text gain authority?
4. Is the first-release profile small enough for one person to operate safely?
