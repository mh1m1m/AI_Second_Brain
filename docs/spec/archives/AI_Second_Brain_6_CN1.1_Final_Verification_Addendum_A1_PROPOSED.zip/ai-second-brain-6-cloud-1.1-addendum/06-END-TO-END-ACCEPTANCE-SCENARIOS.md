# End-to-End Acceptance Scenarios

**DOC-A1-06** · v6.0-CN1.1-A1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Addendum to v6.0-CN1.1 (unchanged)

Amendment AD-06. These ten scenarios are acceptance criteria for the product, on top of the component tests of CN1.1. A system that is secure and that sessions rarely consult fails UX-B and therefore fails.

| ID | Scenario | Given | Passes when | Verified first by | Status today |
|---|---|---|---|---|---|
| UX-A | A new authorised session discovers and connects | The account connector is authorised once; a session starts in any environment the owner uses, in a repository never used before | The connector's tools are available without per-session setup; `brain_health` shows the grant | CV-02, CV-08 | Documented for account connectors; not verified for a custom server |
| UX-B | The session retrieves relevant prior decisions | A project with approved decisions; the owner asks a question those decisions bear on, without naming the brain | The session calls the connector unprompted and cites the decisions. Measured over a set of trial sessions, not once | CV-20 | **Unproven.** Nothing forces a session to call a tool; instructions in the repository and the bootstrap skill raise the odds |
| UX-C | The session continues unfinished work | A closed session left open issues and next actions | A new session in the same project presents them and resumes from them | UX-B, UX-E | Unproven |
| UX-D | The session submits a summary and proposed updates | Work was done; the owner says 'close this session' | Summary, artifact references, open issues and next actions are stored as M3; durable findings arrive as proposals; nothing becomes knowledge | CV-07 for any automatic variant | Feasible on request; automatic closing is not assumed |
| UX-E | A later session retrieves that summary and keeps it apart | UX-D happened; the summary is not yet approved | The summary comes only from `brain_session_context`, in its envelope, and the session's answer distinguishes it from approved knowledge | — | Storage and labelling are enforceable; the model's behaviour is observed, not guaranteed |
| UX-F | Approved knowledge from another project | A record promoted to workspace level, or a shared K1 project | A session in a different project retrieves it with its origin shown | — | By design |
| UX-G | No restricted or unauthorised material | A closed project, a K2 record, a project outside the grant | No content, count or hint is returned, whatever project the session claims | — | By design; the centre of the security tests |
| UX-H | Available with the Mac offline | The owner's computer is switched off | A cloud or mobile-started session completes UX-A to UX-E | CV-02, CV-08 | Unverified |
| UX-I | Recovery without losing provenance or approvals | A backup made after UX-D and one approval | After restoring into an empty environment, records, evidence links, approvals and the audit chain verify, and UX-B works again | CV-13 | Unverified |
| UX-J | Usable within the approved budget | One month of the trial workload | Measured spend is under the ceiling the owner set; the alarm fires in a forced test | CV-16 | Estimate only |

## The scenario that decides the product

UX-B. Retrieval happens only when the model chooses to call the connector or the owner asks. What can be done: a line in each project's instruction file telling Claude to consult the brain at the start of work and before decisions; a bootstrap skill; clear tool descriptions. What cannot be done: guarantee it. CV-20 therefore measures it: a fixed set of trial tasks where relevant knowledge exists, run with and without those aids, counting the sessions that retrieved it unprompted. The owner should set the pass mark before the trial; I suggest that anything under about four in five with the aids in place means the design needs a different trigger.
