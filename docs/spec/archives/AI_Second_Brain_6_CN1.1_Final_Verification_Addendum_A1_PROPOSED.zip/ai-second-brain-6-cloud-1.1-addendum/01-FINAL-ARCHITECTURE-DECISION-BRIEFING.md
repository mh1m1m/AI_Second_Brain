# Final Architecture Decision Briefing

**DOC-A1-01** · v6.0-CN1.1-A1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Addendum to v6.0-CN1.1 (unchanged)

> Nothing here is approved. IMPLEMENTATION NOT AUTHORIZED. IR1.1, CN1 and CN1.1 are unchanged; this addendum amends CN1.1's recommendations in seven places.

## 1. The architecture in five lines

A hosted Python service is the only writer to a managed PostgreSQL database and a private object store. Claude Code sessions reach it through one remote MCP connector that can read and propose. You approve on a separate surface that no connector token can use. GitHub holds code and is referenced, not copied. Backups are encrypted to your key and restore-tested before any real data.

## 2. What this addendum changes

| ID | Change | Document |
|---|---|---|
| AD-01 | Four memory tiers; unreviewed session context has its own tool, envelope, expiry and no authority | 03 |
| AD-02 | No cross-project confidential elevation in the first release; every connector grant has ceiling K1; K2 is stored but not served | 04 |
| AD-03 | A private repository's project is K1 by default; K2 is your deliberate marking | 04 |
| AD-04 | Connector shadowing: controls sorted by who enforces them; none claimed effective | 04 |
| AD-05 | First release simplified: managed authentication if verifiable, one grant, text formats first | 05 |
| AD-06 | Ten end-to-end scenarios become acceptance criteria | 06 |
| AD-07 | Decisions regrouped; no blanket approval asked | this document |

## 3. Will it achieve the goal?

The goal is that Claude Code remembers and reuses your knowledge across projects and sessions without your supplying context again. Storage, retrieval, governance and recovery are credibly designed. Three things the goal depends on are not established: that one connection works in every environment you use, that a session consults the brain at the right moment without being told, and that closing and resuming work carries context forward reliably. Scenario UX-B is the one that decides it, and no design can guarantee it. That is why verification, not more specification, is the next step.

## 4. Decisions, in four groups

### A. Can be decided now

These do not depend on verification and carry no residual risk beyond what any choice would.

| Item | What you would be deciding | Answer | Date |
|---|---|---|---|
| CD-01 | Five-class model; first release stores K0, K1, K2; K3 not admitted; K4 never. K2 is not served to connectors (AD-02) |  |  |
| CD-06 | Your notes are authoritative in the service, with Markdown export |  |  |
| CD-08 | GitHub by reference only; no GitHub credential in the service |  |  |
| CD-12 | Obsidian: export only at first |  |  |
| CD-14 | Bootstrap skill from the private platform repository; it holds no authority |  |  |
| CD-15 | Carry forward the compatible IR1.1 decisions |  |  |
| CD-16 | First-release scope, reduced further by ARCHITECTURE-SIMPLIFICATION §2 |  |  |
| CD-18 | Verification before any implementation authorisation |  |  |
| CD-19 | Name an independent reviewer |  |  |

### B. Conditional on verification

Decide after the named result.

| Item | What you would be deciding | Answer | Date |
|---|---|---|---|
| CD-02 | PostgreSQL, if CV-03 shows Arabic search at least matching the SQLite record |  |  |
| CD-03 | Provider, region and cost ceiling, after CV-09 and CV-16 |  |  |
| CD-04, CD-05 | Managed authentication with a small approval page if CV-19 passes; custom otherwise |  |  |
| CD-10 | Backup design as proposed; details follow the provider |  |  |
| CD-09, CD-20 | Repository plan and the question of an earlier codebase, after the account inventory CV-15 |  |  |
| CD-11 | Shared K0 and K1 projects now; anything more only after CV-17 |  |  |

### C. Needs your explicit acceptance of a residual risk

Each is a yes or no to a named risk, not to a design.

| Item | What you would be deciding | Answer | Date |
|---|---|---|---|
| CD-13 with RR-01 | Content released to a session can leave through that session's other tools and is processed by the model provider |  |  |
| RR-02 | A repository can substitute a server for the connector; nothing in this system prevents it |  |  |
| CD-07 with RR-13 | Unreviewed session notes are readable by later sessions of the same project before you approve them |  |  |
| RR-05 | The hosting provider's systems can read live data |  |  |
| RR-08 | One person maintains an internet-facing service |  |  |
| RR-12 | No independent review has taken place yet |  |  |

### D. Deferred

Not part of the first release; no decision asked.

| Item | What you would be deciding | Answer | Date |
|---|---|---|---|
| CD-13 elevation | Cross-project confidential elevation, with RR-14 |  |  |
| Per-project connections | Until CV-17 |  |  |
| K3 material | Until you have a clearance route you can record |  |  |
| Service-side GitHub reading and any automation | Later decisions |  |  |
| Event capture by hooks; Obsidian re-import; dashboard; knowledge graph; point-in-time recovery | Driven by use |  |  |
| CD-17 | Approval of a successor baseline: after verification and the detailed design |  |  |

## 5. What happens next

1. You answer group A and group C, and decide whether to issue Verification Stage A (text in UPDATED-VERIFICATION-PLAN; no code, no cost).
2. Stage A reports. You decide Stage B, the throwaway test connector.
3. With the results, you answer group B once. The detailed design (schema, tool schemas, rewritten requirements and tests) is written in one pass for the option chosen, and goes to your reviewer.
4. You issue, or do not issue, the Cloud Implementation Instrument.

There is no further specification revision planned between these steps. If verification contradicts the architecture, the decision returns to you with the evidence.
