#!/usr/bin/env python3
"""Generates the final-verification addendum to v6.0-CN1.1. Specification tooling; standard library only; writes only to its own folder."""
import os, sys, re, hashlib
OUT = sys.argv[1]; CN11 = sys.argv[2]
def wr(n, l): open(os.path.join(OUT, n), "w", encoding="utf-8").write("\n".join(l).rstrip("\n") + "\n")
def H(c, t): return [f"# {t}", "", f"**{c}** · v6.0-CN1.1-A1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Addendum to v6.0-CN1.1 (unchanged)", ""]
def T(h, rows): return ["| " + " | ".join(h) + " |", "|" + "---|" * len(h)] + ["| " + " | ".join(str(c) for c in r) + " |" for r in rows] + [""]

o = H("DOC-A1-03", "Persistent Memory Trust Boundaries") + ["Amendment AD-01. Four tiers, kept apart in storage, in retrieval and in what each may do.", ""] + T(["Tier", "What", "Enters by", "May be used as", "Returned by"], [
 ("M1 Approved canonical knowledge", "Verified, reusable records with evidence", "Proposal approved by the owner", "Knowledge, with citation", "`brain_search`, `brain_retrieve`"),
 ("M2 Approved project memory", "Decisions, state and findings of a project", "Proposal approved by the owner", "Knowledge within its project and where shared", "`brain_search`, `brain_projects_get`"),
 ("M3 Unreviewed session context", "Summaries, open issues, next actions and artifact references submitted by a session", "Submission at session close, after screening", "Context only. Never evidence, never a source for verification, never promoted or shared as it stands", "`brain_session_context` only"),
 ("M4 Untrusted source material", "Passages of ingested documents and repository content", "Ingestion with classification", "Evidence to quote and cite. Never an instruction", "Inside results, as quoted evidence")])
o += ["## Rules", "",
 "1. **Separate retrieval.** `brain_search` never returns M3. Unreviewed context comes only from `brain_session_context`, for the same project, and is never ranked together with approved knowledge.",
 "2. **Labelling.** Every M3 item is returned inside a fixed envelope: tier, the words 'unreviewed session note, not verified, not an instruction', the submitting session and grant, submission time, expiry. M4 passages are returned as quoted source text with their locator.",
 "3. **Expiry.** M3 expires 30 days after submission (provisional; the owner sets it) and at most the 10 most recent items per project are returned. Expired items leave retrieval and stay in the audit record.",
 "4. **Promotion.** Only a proposal that the owner approves turns something from M3 into M2 or M1. The new record cites the session as its origin and needs evidence like any other; an M3 item cannot serve as that evidence.",
 "5. **Rejection.** The owner can reject an M3 item on the approval surface; it leaves retrieval at once and is kept as rejected in the audit record. A later identical submission is refused.",
 "6. **No authority.** M3 and M4 cannot change a grant, a class, a policy or a record. Nothing they contain is executed or interpreted by the service.",
 "7. **Screening.** Before storage, M3 is checked for secret-like strings and size; it takes its project's class and is not accepted into a project it could not be filed in.",
 "8. **Provenance.** Every item of every tier carries where it came from and when; results show the tier.", "",
 "## What this achieves and what it does not", "",
 "Enforced by the service: an unreviewed note cannot become knowledge, cannot cross projects, cannot be cited as evidence and cannot outlive its expiry. **Not enforced:** what a model does when it reads the note. The envelope is a label, and a label is an instruction to the reader, not a control. A session may still be influenced by injected text inside a note from an earlier session of the same project (CN1.1 residual risk RR-13). The owner can remove that exposure entirely by choosing 'hold every summary until approved', at the cost of continuity."]
wr("03-MEMORY-TRUST-BOUNDARIES.md", o)

o = H("DOC-A1-04", "Connector Authorisation and Connector Shadowing") + ["Amendments AD-02, AD-03 and AD-04.", "", "## 1. Connection-wide authorisation: position and safe fallback", "",
 "CN1.1 established that the service cannot tell sessions on one connection apart. No supported way of isolating credentials per session, per project or per environment has been verified. Therefore:", "",
 "- **Cross-project confidential elevation is not a first-release capability.** It is withdrawn from the recommendation (CN1.1 CD-13 and requirement CR-39) and deferred until isolation is demonstrated (CV-17). Residual risk RR-14 is deferred with it.",
 "- **Safe fallback.** Every connector grant has ceiling K1. Confidential (K2) material is stored, classified and backed up, and is visible to the owner on the owner's surface and in exports; it is not served to any connector. Cross-project knowledge works for K0 and K1 through shared projects and approved promotion.",
 "- **A private repository's project is K1 by default.** K2 is something the owner marks deliberately, for material whose disclosure would do harm. This replaces CN1.1's rule that a locator into a private repository is at least K2, which would have put ordinary project memory out of reach.",
 "- **If isolation is later verified**, the first step is a per-project connection limited to that project's own K2, not elevation across projects.", "",
 "## 2. Connector shadowing: what can and cannot be done", "", "Documentation read on 2026-11-10 adds two facts to CN1.1: a server added in Claude Code takes precedence over an account connector that points at the same URL as well as over one with the same name; and allowlists and denylists of MCP servers exist as managed settings, with a managed configuration file that takes exclusive control on the host where it is present. In cloud sessions connectors are passed in by the cloud host and governed by account or organisation settings and by any such list that reaches the session.", ""] + T(["Control", "Enforced by", "Evidence", "Assessment"], [
 ("Approval prompt before a project-defined server is used", "Client", "Documented for interactive sessions; unverified elsewhere", "Depends on the owner refusing; may be absent in non-interactive sessions"),
 ("Allowlist or denylist of MCP servers by name or URL", "Client, through managed settings", "Documented. Whether an individual account can apply it on its own machines and in cloud sessions is UNVERIFIED (CV-18)", "The only candidate for an enforceable control. Not claimed"),
 ("Managed configuration file with exclusive control", "Client, on the host", "Documented; drops account connectors on that host", "Usable on a machine the owner administers; not in Anthropic-hosted cloud sessions. UNVERIFIED"),
 ("Trusted endpoint, TLS, OAuth issuer and audience", "Client and server", "Standard; client behaviour UNVERIFIED (CV-14)", "Protects the real service and a correctly configured client. Does not stop substitution"),
 ("Token audience bound to the service", "Server", "Design", "A substituted server gets no token the service would accept and no data from it"),
 ("Distinctive connector name; bootstrap identity comparison", "User and skill", "Design", "Reduces accidents. A deliberate impostor passes the comparison"),
 ("Working only in repositories the owner trusts; reading the server list before sensitive work", "User behaviour", "—", "Real but unenforceable"),
 ("A substituted server misleading a session, or receiving what the session sends it", "Nothing", "—", "**Cannot currently be mitigated by this system.** Residual risk RR-02")])
o += ["No mitigation is claimed as effective. CV-18 and CV-21 establish what the client actually supports; until then the honest position is that this risk is open and the first release limits its cost by serving nothing above K1."]
wr("04-CONNECTOR-AUTHORISATION-AND-SHADOWING.md", o)

o = H("DOC-A1-05", "Architecture Simplification") + ["Amendment AD-05. Independent owner approval stays mandatory in every option: no connector token can approve.", "", "## 1. Authentication and approval: three options", ""] + T(["", "A. Custom (CN1.1)", "B. Managed authentication", "C. Approval through GitHub"], [
 ("What", "Own authorisation server and approval surface; passkey; assertion bound to the proposal hash", "A managed identity service handles owner login, passkeys or MFA, sessions and recovery, and, if it can, OAuth for the connector. A small approval page remains", "Proposals appear as pull requests in a private repository; merging approves"),
 ("Security", "Strongest binding of gesture to payload. All of it must be built correctly by one person", "Login, MFA and recovery are maintained by specialists. Binding is server-side: fresh re-authentication, then the approval row is tied to the stored hash", "Uses GitHub's login and MFA. Proposal text sits in a repository; the service needs GitHub access; binding rests on commit contents"),
 ("Operating cost", "No fee; highest effort", "Included in the costed configuration A; otherwise unpriced", "No fee"),
 ("Maintenance", "Highest: identity code is security-critical", "Low for identity; the approval page remains", "Low; adds a dependency on GitHub for approvals"),
 ("Recovery", "Own procedure", "Provider's account recovery, which is also an attack path", "GitHub account recovery"),
 ("Build complexity", "High", "Moderate", "Moderate; awkward for bidirectional text and for classification rules"),
 ("Unknowns", "None external", "Whether the provider can act as the OAuth server for a remote MCP connector and can require step-up authentication: UNVERIFIED (CV-19)", "Contradicts 'no GitHub credential in the service'")])
o += ["**Recommendation.** Option B for the first release if CV-19 passes; option A only if it does not. Option C is not recommended. With B, requirement CR-31 (assertion whose challenge contains the proposal hash) becomes a target to meet if the provider supports it, and otherwise is replaced by fresh re-authentication plus server-side binding. That is weaker than A against a compromised browser session and equal against a manipulated Claude session, which is the threat the separation exists for.", "",
 "## 2. First-release profile", ""] + T(["Component", "CN1.1", "First release", "Why"], [
 ("Owner login and approval", "Custom authorisation server, passkey, payload-bound assertion", "Managed authentication plus a small approval page (if CV-19 passes)", "Least security-critical code for one person to own"),
 ("Grants", "Several, with ceilings, projects, elevation", "One account-wide grant, ceiling K1, shared projects", "No isolation is verified (AD-02)"),
 ("Per-project connections", "Proposed", "Deferred", "Needs CV-17"),
 ("Elevation", "Time-boxed", "Deferred", "AD-02"),
 ("Extraction worker", "Isolated worker for all formats", "Markdown and text only, parsed in the service; PDF, DOCX and HTML with the isolated worker in the next stage", "Formats were already staged; the worker arrives with the parsers that need it"),
 ("Backups", "Provider plus independent encrypted export", "Unchanged", "Recovery is not where to save"),
 ("Classification", "Five classes", "Unchanged; K3 not admitted; K2 stored but not served", "Governance costs little to keep"),
 ("Session memory", "Unreviewed, same project", "Unchanged, with the tiers of MEMORY-TRUST-BOUNDARIES", "Core of the product")])
o += ["Effect on the monthly estimate of CN1.1 (configuration A): about US$32 instead of about US$40, since the always-on worker is not needed at first. Still part verified, part estimate.", "",
 "What is not simplified: server-side authorisation of every call, the approval separation, the audit chain, classification, restore-tested backups before real data."]
wr("05-ARCHITECTURE-SIMPLIFICATION.md", o)

UX = [("UX-A", "A new authorised session discovers and connects", "The account connector is authorised once; a session starts in any environment the owner uses, in a repository never used before", "The connector's tools are available without per-session setup; `brain_health` shows the grant", "CV-02, CV-08", "Documented for account connectors; not verified for a custom server"),
 ("UX-B", "The session retrieves relevant prior decisions", "A project with approved decisions; the owner asks a question those decisions bear on, without naming the brain", "The session calls the connector unprompted and cites the decisions. Measured over a set of trial sessions, not once", "CV-20", "**Unproven.** Nothing forces a session to call a tool; instructions in the repository and the bootstrap skill raise the odds"),
 ("UX-C", "The session continues unfinished work", "A closed session left open issues and next actions", "A new session in the same project presents them and resumes from them", "UX-B, UX-E", "Unproven"),
 ("UX-D", "The session submits a summary and proposed updates", "Work was done; the owner says 'close this session'", "Summary, artifact references, open issues and next actions are stored as M3; durable findings arrive as proposals; nothing becomes knowledge", "CV-07 for any automatic variant", "Feasible on request; automatic closing is not assumed"),
 ("UX-E", "A later session retrieves that summary and keeps it apart", "UX-D happened; the summary is not yet approved", "The summary comes only from `brain_session_context`, in its envelope, and the session's answer distinguishes it from approved knowledge", "—", "Storage and labelling are enforceable; the model's behaviour is observed, not guaranteed"),
 ("UX-F", "Approved knowledge from another project", "A record promoted to workspace level, or a shared K1 project", "A session in a different project retrieves it with its origin shown", "—", "By design"),
 ("UX-G", "No restricted or unauthorised material", "A closed project, a K2 record, a project outside the grant", "No content, count or hint is returned, whatever project the session claims", "—", "By design; the centre of the security tests"),
 ("UX-H", "Available with the Mac offline", "The owner's computer is switched off", "A cloud or mobile-started session completes UX-A to UX-E", "CV-02, CV-08", "Unverified"),
 ("UX-I", "Recovery without losing provenance or approvals", "A backup made after UX-D and one approval", "After restoring into an empty environment, records, evidence links, approvals and the audit chain verify, and UX-B works again", "CV-13", "Unverified"),
 ("UX-J", "Usable within the approved budget", "One month of the trial workload", "Measured spend is under the ceiling the owner set; the alarm fires in a forced test", "CV-16", "Estimate only")]
o = H("DOC-A1-06", "End-to-End Acceptance Scenarios") + ["Amendment AD-06. These ten scenarios are acceptance criteria for the product, on top of the component tests of CN1.1. A system that is secure and that sessions rarely consult fails UX-B and therefore fails.", ""] + T(["ID", "Scenario", "Given", "Passes when", "Verified first by", "Status today"], UX)
o += ["## The scenario that decides the product", "", "UX-B. Retrieval happens only when the model chooses to call the connector or the owner asks. What can be done: a line in each project's instruction file telling Claude to consult the brain at the start of work and before decisions; a bootstrap skill; clear tool descriptions. What cannot be done: guarantee it. CV-20 therefore measures it: a fixed set of trial tasks where relevant knowledge exists, run with and without those aids, counting the sessions that retrieved it unprompted. The owner should set the pass mark before the trial; I suggest that anything under about four in five with the aids in place means the design needs a different trigger."]
wr("06-END-TO-END-ACCEPTANCE-SCENARIOS.md", o)

CV = [("1", "CV-02", "Does one authorised connection work in every environment the owner uses?", "B", "UX-A, UX-H", "Limit the product to the environments where it works, and say which"),
 ("1", "CV-08", "Can a cloud session reach the service's address?", "B", "UX-H", "Adjust the cloud environment's network setting, if the plan allows"),
 ("1", "CV-18", "Can an individual account enforce which MCP servers a session may use, locally and in cloud sessions?", "A", "Shadowing", "RR-02 stays open; K1 ceiling stays"),
 ("1", "CV-21", "What does each client do when a repository defines a server with the connector's name or URL?", "B", "Shadowing", "As above"),
 ("1", "CV-14", "How does each client handle issuer, audience and token destination?", "B", "Service authenticity", "Server-side checks only"),
 ("1", "CV-17", "Can a credential be isolated to one project or connection?", "B", "K2 access", "K2 stays unserved (AD-02)"),
 ("2", "CV-20", "Do sessions consult the brain unprompted, and how often?", "B", "UX-B, UX-C", "Change the trigger: explicit owner command at session start"),
 ("2", "CV-07", "Which hooks run where, and in what time?", "A", "Optional capture", "Explicit closing only"),
 ("2", "CV-10", "Do results fit the client's output limit?", "B", "UX-B", "Smaller budgets"),
 ("2", "CV-03", "Does Arabic search on PostgreSQL match the SQLite record?", "A", "CD-02", "Option O4, or a different index design"),
 ("3", "CV-19", "Can a managed identity service act as OAuth server for the connector and require step-up authentication?", "A, then B", "Simplification", "Custom authentication (option A)"),
 ("3", "CV-09, CV-16", "Confirmed prices and regions for the two configurations", "A", "UX-J, CD-03", "Reprice; revisit scope"),
 ("3", "CV-13", "Restore drill with synthetic data", "B", "UX-I", "No real data until it passes"),
 ("—", "CV-01, CV-15", "Read-only inventory of the whole GitHub account", "A", "CD-09, CD-20", "—"),
 ("—", "CV-04, CV-05, CV-11, CV-12", "Tool prompts, elicitation, skill availability, Obsidian display", "A or B", "Minor", "—")]
o = H("DOC-A1-02", "Updated Verification Plan") + ["Verification is in two stages because some questions can be answered by reading and observing, and the ones that matter most need something to connect to. Neither stage is authorised.", "",
 "## Priorities", "", "1. **Integration**: does the same authenticated brain work across the owner's environments, and can a session be kept on the genuine connector?", "2. **Persistent memory**: is context carried forward and actually consulted, without unreviewed material becoming authoritative?", "3. **Operating feasibility**: can the controls be delivered within a reasonable monthly cost and effort?", ""] + T(["Priority", "Item", "Question", "Stage", "Decides", "If it fails"], CV)
o += ["## Stage A — reading, inventory and observation (no code, no deployment, no cost)", "", "Instrument text, ready to issue if the owner chooses:", "", "```", "I authorise Cloud Verification Stage A for AI Second Brain 6.0. Mode remains SPECIFICATION-ONLY.",
 "Permitted: (1) reading public documentation and price pages; (2) a read-only listing of all repositories in my GitHub account, which I will enable for this purpose: names, visibility, last push and description only, nothing cloned or changed; (3) observing how connectors that already exist in my account behave in the environments I use; (4) one temporary PostgreSQL instance inside the specification sandbox, holding only the twelve synthetic sentences of the existing probe, deleted afterwards.",
 "Prohibited: application code; any cloud resource or account; any cost; any of my documents or knowledge; creating, changing or cloning any repository; changing any setting.", "Record every result with how it was obtained. Stop and report when done.", "```", "",
 "## Stage B — a throwaway test connector (draft; needs its own explicit authorisation)", "", "Most of priority 1 and all of UX-A to UX-E can only be observed against a real remote MCP server. Stage B would deploy a minimal stub that serves fixed synthetic answers, on a free tier, with no database and no owner data, and remove it afterwards. This is code and a deployment, although not the product, so it is outside specification-only mode and outside Stage A. Expected cost is zero; that is an expectation, not a quoted price. The owner should decide Stage B after seeing Stage A's results.", "",
 "## Exit", "", "Verification ends when each item above has a recorded result or a recorded reason it could not be obtained. The architecture decision is then taken once, on those results. This plan does not provide for another revision cycle."]
wr("02-UPDATED-VERIFICATION-PLAN.md", o)

o = H("DOC-A1-07", "Evidence Package for an Independent Reviewer") + ["The independent-review gate is NOT_VERIFIED. This is what a reviewer needs, and what they should not take on trust.", "", "## Archives", ""] + T(["Archive", "SHA-256", "Role"], [
 ("v6.0-IR1.1", "`0dcc02510a6878079e79a303dc2a5864f204eb1a1766076ff765a6062f09353f`", "Local-first historical baseline; governance to be preserved"),
 ("v6.0-CN1", "`e5e696df0d4a95028c52a1422cc72dd8232260fbd3b53e1b33c2ca3185066222`", "First cloud-native proposal"),
 ("v6.0-CN1.1", "`5bae75c2c640bcf60e183ebd8a034613d118645ddd4f78412a3aa2e58dbc0a0f`", "Corrected proposal with adversarial assessment"),
 ("v6.0-CN1.1-A1", "See MANIFEST.md", "This addendum")])
o += ["## Reading order", "", "1. This addendum: 01 briefing, 03, 04, 05, 06, 02.", "2. CN1.1: 27 adversarial assessment, 25 residual risks, 24 security assurance, 22 approval authority, 23 project access, 21 classification, 17 decisions.", "3. CN1.1: 03 and 04 for what was kept from IR1.1.", "",
 "## Unresolved findings", "", "- Connector shadowing: no effective mitigation (RR-02).", "- Released content can leave through the session (RR-01).", "- Unreviewed session notes can influence later sessions of the same project (RR-13).", "- No isolation of credentials per session, project or environment (RR-14, deferred with the feature).", "- Whether sessions consult the brain unprompted (UX-B) is unknown.", "- Arabic retrieval on PostgreSQL is unmeasured.", "- The dispositions of the twelve adversarial findings were applied by the author and re-checked by no one.", "",
 "## Verification limitations", "", "- Nothing has been built, deployed or connected. Every statement about Claude Code comes from documentation read on 2026-11-10.", "- The only executed evidence is from IR1.1: a SQLite schema with 27 probes and an Arabic tokenizer probe, both in a sandbox.", "- Prices: one provider read on its own page; the rest from secondary sources or estimates, each marked.", "- The repository listing is one session's view.", "- The package's checkers test coverage and identifiers, not the soundness of any control.", "- The adversarial assessment was by a separate agent of the same model as the author.", "",
 "## Questions worth a reviewer's time", "", "1. Is option B (managed authentication) sound enough for approvals, or is payload-bound assertion necessary?", "2. Is the K1 ceiling for all connectors an adequate answer to shadowing and exfiltration for a personal system?", "3. Does anything in the memory tiers still let unreviewed text gain authority?", "4. Is the first-release profile small enough for one person to operate safely?"]
wr("07-INDEPENDENT-REVIEWER-EVIDENCE-PACKAGE.md", o)

G = [("A. Can be decided now", "These do not depend on verification and carry no residual risk beyond what any choice would.", [
   ("CD-01", "Five-class model; first release stores K0, K1, K2; K3 not admitted; K4 never. K2 is not served to connectors (AD-02)"), ("CD-06", "Your notes are authoritative in the service, with Markdown export"), ("CD-08", "GitHub by reference only; no GitHub credential in the service"),
   ("CD-12", "Obsidian: export only at first"), ("CD-14", "Bootstrap skill from the private platform repository; it holds no authority"), ("CD-15", "Carry forward the compatible IR1.1 decisions"),
   ("CD-16", "First-release scope, reduced further by ARCHITECTURE-SIMPLIFICATION §2"), ("CD-18", "Verification before any implementation authorisation"), ("CD-19", "Name an independent reviewer")]),
 ("B. Conditional on verification", "Decide after the named result.", [
   ("CD-02", "PostgreSQL, if CV-03 shows Arabic search at least matching the SQLite record"), ("CD-03", "Provider, region and cost ceiling, after CV-09 and CV-16"), ("CD-04, CD-05", "Managed authentication with a small approval page if CV-19 passes; custom otherwise"),
   ("CD-10", "Backup design as proposed; details follow the provider"), ("CD-09, CD-20", "Repository plan and the question of an earlier codebase, after the account inventory CV-15"), ("CD-11", "Shared K0 and K1 projects now; anything more only after CV-17")]),
 ("C. Needs your explicit acceptance of a residual risk", "Each is a yes or no to a named risk, not to a design.", [
   ("CD-13 with RR-01", "Content released to a session can leave through that session's other tools and is processed by the model provider"), ("RR-02", "A repository can substitute a server for the connector; nothing in this system prevents it"),
   ("CD-07 with RR-13", "Unreviewed session notes are readable by later sessions of the same project before you approve them"), ("RR-05", "The hosting provider's systems can read live data"), ("RR-08", "One person maintains an internet-facing service"), ("RR-12", "No independent review has taken place yet")]),
 ("D. Deferred", "Not part of the first release; no decision asked.", [
   ("CD-13 elevation", "Cross-project confidential elevation, with RR-14"), ("Per-project connections", "Until CV-17"), ("K3 material", "Until you have a clearance route you can record"), ("Service-side GitHub reading and any automation", "Later decisions"),
   ("Event capture by hooks; Obsidian re-import; dashboard; knowledge graph; point-in-time recovery", "Driven by use"), ("CD-17", "Approval of a successor baseline: after verification and the detailed design")])]
o = H("DOC-A1-01", "Final Architecture Decision Briefing") + ["> Nothing here is approved. IMPLEMENTATION NOT AUTHORIZED. IR1.1, CN1 and CN1.1 are unchanged; this addendum amends CN1.1's recommendations in seven places.", "",
 "## 1. The architecture in five lines", "", "A hosted Python service is the only writer to a managed PostgreSQL database and a private object store. Claude Code sessions reach it through one remote MCP connector that can read and propose. You approve on a separate surface that no connector token can use. GitHub holds code and is referenced, not copied. Backups are encrypted to your key and restore-tested before any real data.", "",
 "## 2. What this addendum changes", ""] + T(["ID", "Change", "Document"], [
 ("AD-01", "Four memory tiers; unreviewed session context has its own tool, envelope, expiry and no authority", "03"), ("AD-02", "No cross-project confidential elevation in the first release; every connector grant has ceiling K1; K2 is stored but not served", "04"),
 ("AD-03", "A private repository's project is K1 by default; K2 is your deliberate marking", "04"), ("AD-04", "Connector shadowing: controls sorted by who enforces them; none claimed effective", "04"),
 ("AD-05", "First release simplified: managed authentication if verifiable, one grant, text formats first", "05"), ("AD-06", "Ten end-to-end scenarios become acceptance criteria", "06"), ("AD-07", "Decisions regrouped; no blanket approval asked", "this document")])
o += ["## 3. Will it achieve the goal?", "", "The goal is that Claude Code remembers and reuses your knowledge across projects and sessions without your supplying context again. Storage, retrieval, governance and recovery are credibly designed. Three things the goal depends on are not established: that one connection works in every environment you use, that a session consults the brain at the right moment without being told, and that closing and resuming work carries context forward reliably. Scenario UX-B is the one that decides it, and no design can guarantee it. That is why verification, not more specification, is the next step.", "",
 "## 4. Decisions, in four groups", ""]
for title, note, rows in G:
    o += [f"### {title}", "", note, ""] + T(["Item", "What you would be deciding", "Answer", "Date"], [(a, b, "", "") for a, b in rows])
o += ["## 5. What happens next", "", "1. You answer group A and group C, and decide whether to issue Verification Stage A (text in UPDATED-VERIFICATION-PLAN; no code, no cost).", "2. Stage A reports. You decide Stage B, the throwaway test connector.", "3. With the results, you answer group B once. The detailed design (schema, tool schemas, rewritten requirements and tests) is written in one pass for the option chosen, and goes to your reviewer.", "4. You issue, or do not issue, the Cloud Implementation Instrument.", "",
 "There is no further specification revision planned between these steps. If verification contradicts the architecture, the decision returns to you with the evidence."]
wr("01-FINAL-ARCHITECTURE-DECISION-BRIEFING.md", o)

wr("README.md", ["# AI Second Brain 6.0 — Final Verification Addendum to v6.0-CN1.1 (v6.0-CN1.1-A1)", "", "**Status: PROPOSED. Nothing approved. IMPLEMENTATION NOT AUTHORIZED.** Owner: Mohammed Alsaleh · 2026-11-10", "",
 "A short addendum, not a new revision. v6.0-IR1.1, v6.0-CN1 and v6.0-CN1.1 are unchanged and referenced by hash in document 07. Where this addendum and CN1.1 differ, the addendum is the current recommendation.", "",
 "1. `01-FINAL-ARCHITECTURE-DECISION-BRIEFING.md` — start here.", "2. `02-UPDATED-VERIFICATION-PLAN.md`", "3. `03-MEMORY-TRUST-BOUNDARIES.md`", "4. `04-CONNECTOR-AUTHORISATION-AND-SHADOWING.md`", "5. `05-ARCHITECTURE-SIMPLIFICATION.md`", "6. `06-END-TO-END-ACCEPTANCE-SCENARIOS.md`", "7. `07-INDEPENDENT-REVIEWER-EVIDENCE-PACKAGE.md`", "", "`inputs/` holds the review that asked for this addendum, as received. `MANIFEST.md` lists every file with its SHA-256."])
# ---- checks
known = set()
for f in os.listdir(os.path.join(CN11, "docs")):
    if f.endswith(".md"): known |= set(re.findall(r"(?m)^\| ((?:CD|CV|CR|RR|CT)-\d\d) \|", open(os.path.join(CN11, "docs", f), encoding="utf-8").read()))
known |= {"CV-18", "CV-19", "CV-20", "CV-21"}
bad = sorted({f"{f}: {m}" for f in os.listdir(OUT) if f.endswith(".md") and f != "MANIFEST.md" for m in re.findall(r"(?:CD|CV|CR|RR|CT)-\d\d", open(os.path.join(OUT, f), encoding="utf-8").read()) if m not in known})
print("unresolved identifiers:", bad)
rows = []
for b, _, fs in os.walk(OUT):
    for f in sorted(fs):
        p = os.path.relpath(os.path.join(b, f), OUT)
        if p != "MANIFEST.md": d = open(os.path.join(b, f), "rb").read(); rows.append((p, len(d), hashlib.sha256(d).hexdigest()))
wr("MANIFEST.md", ["# Manifest — v6.0-CN1.1-A1 (proposed)", "", "| File | Bytes | SHA-256 |", "|---|---|---|"] + [f"| `{p}` | {n} | `{h}` |" for p, n, h in sorted(rows)])
print(len(rows), "files")
