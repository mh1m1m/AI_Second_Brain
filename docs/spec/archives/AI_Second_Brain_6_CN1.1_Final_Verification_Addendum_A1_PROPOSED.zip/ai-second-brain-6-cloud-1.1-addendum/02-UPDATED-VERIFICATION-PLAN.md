# Updated Verification Plan

**DOC-A1-02** · v6.0-CN1.1-A1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Addendum to v6.0-CN1.1 (unchanged)

Verification is in two stages because some questions can be answered by reading and observing, and the ones that matter most need something to connect to. Neither stage is authorised.

## Priorities

1. **Integration**: does the same authenticated brain work across the owner's environments, and can a session be kept on the genuine connector?
2. **Persistent memory**: is context carried forward and actually consulted, without unreviewed material becoming authoritative?
3. **Operating feasibility**: can the controls be delivered within a reasonable monthly cost and effort?

| Priority | Item | Question | Stage | Decides | If it fails |
|---|---|---|---|---|---|
| 1 | CV-02 | Does one authorised connection work in every environment the owner uses? | B | UX-A, UX-H | Limit the product to the environments where it works, and say which |
| 1 | CV-08 | Can a cloud session reach the service's address? | B | UX-H | Adjust the cloud environment's network setting, if the plan allows |
| 1 | CV-18 | Can an individual account enforce which MCP servers a session may use, locally and in cloud sessions? | A | Shadowing | RR-02 stays open; K1 ceiling stays |
| 1 | CV-21 | What does each client do when a repository defines a server with the connector's name or URL? | B | Shadowing | As above |
| 1 | CV-14 | How does each client handle issuer, audience and token destination? | B | Service authenticity | Server-side checks only |
| 1 | CV-17 | Can a credential be isolated to one project or connection? | B | K2 access | K2 stays unserved (AD-02) |
| 2 | CV-20 | Do sessions consult the brain unprompted, and how often? | B | UX-B, UX-C | Change the trigger: explicit owner command at session start |
| 2 | CV-07 | Which hooks run where, and in what time? | A | Optional capture | Explicit closing only |
| 2 | CV-10 | Do results fit the client's output limit? | B | UX-B | Smaller budgets |
| 2 | CV-03 | Does Arabic search on PostgreSQL match the SQLite record? | A | CD-02 | Option O4, or a different index design |
| 3 | CV-19 | Can a managed identity service act as OAuth server for the connector and require step-up authentication? | A, then B | Simplification | Custom authentication (option A) |
| 3 | CV-09, CV-16 | Confirmed prices and regions for the two configurations | A | UX-J, CD-03 | Reprice; revisit scope |
| 3 | CV-13 | Restore drill with synthetic data | B | UX-I | No real data until it passes |
| — | CV-01, CV-15 | Read-only inventory of the whole GitHub account | A | CD-09, CD-20 | — |
| — | CV-04, CV-05, CV-11, CV-12 | Tool prompts, elicitation, skill availability, Obsidian display | A or B | Minor | — |

## Stage A — reading, inventory and observation (no code, no deployment, no cost)

Instrument text, ready to issue if the owner chooses:

```
I authorise Cloud Verification Stage A for AI Second Brain 6.0. Mode remains SPECIFICATION-ONLY.
Permitted: (1) reading public documentation and price pages; (2) a read-only listing of all repositories in my GitHub account, which I will enable for this purpose: names, visibility, last push and description only, nothing cloned or changed; (3) observing how connectors that already exist in my account behave in the environments I use; (4) one temporary PostgreSQL instance inside the specification sandbox, holding only the twelve synthetic sentences of the existing probe, deleted afterwards.
Prohibited: application code; any cloud resource or account; any cost; any of my documents or knowledge; creating, changing or cloning any repository; changing any setting.
Record every result with how it was obtained. Stop and report when done.
```

## Stage B — a throwaway test connector (draft; needs its own explicit authorisation)

Most of priority 1 and all of UX-A to UX-E can only be observed against a real remote MCP server. Stage B would deploy a minimal stub that serves fixed synthetic answers, on a free tier, with no database and no owner data, and remove it afterwards. This is code and a deployment, although not the product, so it is outside specification-only mode and outside Stage A. Expected cost is zero; that is an expectation, not a quoted price. The owner should decide Stage B after seeing Stage A's results.

## Exit

Verification ends when each item above has a recorded result or a recorded reason it could not be obtained. The architecture decision is then taken once, on those results. This plan does not provide for another revision cycle.
