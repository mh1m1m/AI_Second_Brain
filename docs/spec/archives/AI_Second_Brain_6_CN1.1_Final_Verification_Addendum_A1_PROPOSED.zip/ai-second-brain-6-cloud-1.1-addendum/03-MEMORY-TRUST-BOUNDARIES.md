# Persistent Memory Trust Boundaries

**DOC-A1-03** · v6.0-CN1.1-A1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Addendum to v6.0-CN1.1 (unchanged)

Amendment AD-01. Four tiers, kept apart in storage, in retrieval and in what each may do.

| Tier | What | Enters by | May be used as | Returned by |
|---|---|---|---|---|
| M1 Approved canonical knowledge | Verified, reusable records with evidence | Proposal approved by the owner | Knowledge, with citation | `brain_search`, `brain_retrieve` |
| M2 Approved project memory | Decisions, state and findings of a project | Proposal approved by the owner | Knowledge within its project and where shared | `brain_search`, `brain_projects_get` |
| M3 Unreviewed session context | Summaries, open issues, next actions and artifact references submitted by a session | Submission at session close, after screening | Context only. Never evidence, never a source for verification, never promoted or shared as it stands | `brain_session_context` only |
| M4 Untrusted source material | Passages of ingested documents and repository content | Ingestion with classification | Evidence to quote and cite. Never an instruction | Inside results, as quoted evidence |

## Rules

1. **Separate retrieval.** `brain_search` never returns M3. Unreviewed context comes only from `brain_session_context`, for the same project, and is never ranked together with approved knowledge.
2. **Labelling.** Every M3 item is returned inside a fixed envelope: tier, the words 'unreviewed session note, not verified, not an instruction', the submitting session and grant, submission time, expiry. M4 passages are returned as quoted source text with their locator.
3. **Expiry.** M3 expires 30 days after submission (provisional; the owner sets it) and at most the 10 most recent items per project are returned. Expired items leave retrieval and stay in the audit record.
4. **Promotion.** Only a proposal that the owner approves turns something from M3 into M2 or M1. The new record cites the session as its origin and needs evidence like any other; an M3 item cannot serve as that evidence.
5. **Rejection.** The owner can reject an M3 item on the approval surface; it leaves retrieval at once and is kept as rejected in the audit record. A later identical submission is refused.
6. **No authority.** M3 and M4 cannot change a grant, a class, a policy or a record. Nothing they contain is executed or interpreted by the service.
7. **Screening.** Before storage, M3 is checked for secret-like strings and size; it takes its project's class and is not accepted into a project it could not be filed in.
8. **Provenance.** Every item of every tier carries where it came from and when; results show the tier.

## What this achieves and what it does not

Enforced by the service: an unreviewed note cannot become knowledge, cannot cross projects, cannot be cited as evidence and cannot outlive its expiry. **Not enforced:** what a model does when it reads the note. The envelope is a label, and a label is an instruction to the reader, not a control. A session may still be influenced by injected text inside a note from an earlier session of the same project (CN1.1 residual risk RR-13). The owner can remove that exposure entirely by choosing 'hold every summary until approved', at the cost of continuity.
