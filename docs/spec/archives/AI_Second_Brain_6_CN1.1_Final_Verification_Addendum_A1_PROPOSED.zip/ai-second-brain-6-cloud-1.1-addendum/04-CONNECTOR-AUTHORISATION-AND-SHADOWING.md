# Connector Authorisation and Connector Shadowing

**DOC-A1-04** · v6.0-CN1.1-A1 · 2026-11-10 · Status: PROPOSED, not approved · Owner: Mohammed Alsaleh · Addendum to v6.0-CN1.1 (unchanged)

Amendments AD-02, AD-03 and AD-04.

## 1. Connection-wide authorisation: position and safe fallback

CN1.1 established that the service cannot tell sessions on one connection apart. No supported way of isolating credentials per session, per project or per environment has been verified. Therefore:

- **Cross-project confidential elevation is not a first-release capability.** It is withdrawn from the recommendation (CN1.1 CD-13 and requirement CR-39) and deferred until isolation is demonstrated (CV-17). Residual risk RR-14 is deferred with it.
- **Safe fallback.** Every connector grant has ceiling K1. Confidential (K2) material is stored, classified and backed up, and is visible to the owner on the owner's surface and in exports; it is not served to any connector. Cross-project knowledge works for K0 and K1 through shared projects and approved promotion.
- **A private repository's project is K1 by default.** K2 is something the owner marks deliberately, for material whose disclosure would do harm. This replaces CN1.1's rule that a locator into a private repository is at least K2, which would have put ordinary project memory out of reach.
- **If isolation is later verified**, the first step is a per-project connection limited to that project's own K2, not elevation across projects.

## 2. Connector shadowing: what can and cannot be done

Documentation read on 2026-11-10 adds two facts to CN1.1: a server added in Claude Code takes precedence over an account connector that points at the same URL as well as over one with the same name; and allowlists and denylists of MCP servers exist as managed settings, with a managed configuration file that takes exclusive control on the host where it is present. In cloud sessions connectors are passed in by the cloud host and governed by account or organisation settings and by any such list that reaches the session.

| Control | Enforced by | Evidence | Assessment |
|---|---|---|---|
| Approval prompt before a project-defined server is used | Client | Documented for interactive sessions; unverified elsewhere | Depends on the owner refusing; may be absent in non-interactive sessions |
| Allowlist or denylist of MCP servers by name or URL | Client, through managed settings | Documented. Whether an individual account can apply it on its own machines and in cloud sessions is UNVERIFIED (CV-18) | The only candidate for an enforceable control. Not claimed |
| Managed configuration file with exclusive control | Client, on the host | Documented; drops account connectors on that host | Usable on a machine the owner administers; not in Anthropic-hosted cloud sessions. UNVERIFIED |
| Trusted endpoint, TLS, OAuth issuer and audience | Client and server | Standard; client behaviour UNVERIFIED (CV-14) | Protects the real service and a correctly configured client. Does not stop substitution |
| Token audience bound to the service | Server | Design | A substituted server gets no token the service would accept and no data from it |
| Distinctive connector name; bootstrap identity comparison | User and skill | Design | Reduces accidents. A deliberate impostor passes the comparison |
| Working only in repositories the owner trusts; reading the server list before sensitive work | User behaviour | — | Real but unenforceable |
| A substituted server misleading a session, or receiving what the session sends it | Nothing | — | **Cannot currently be mitigated by this system.** Residual risk RR-02 |

No mitigation is claimed as effective. CV-18 and CV-21 establish what the client actually supports; until then the honest position is that this risk is open and the first release limits its cost by serving nothing above K1.
