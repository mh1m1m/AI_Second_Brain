# AI Second Brain 6.0 — Implementation-Readiness Specification Baseline (v6.0-IR1.1)

**Status: PROPOSED. Specification only. Implementation not authorised. Verdict: NOT READY FOR IMPLEMENTATION; ready for owner review.**
Date 2026-11-10 · Owner: Mohammed Alsaleh

## 1. What this is

A revision of the V6.0 specification draft into one consistent, traceable, testable baseline for a local-first personal knowledge system: Claude Code as the only AI platform, a deterministic Python CLI that owns all writes, SQLite and Markdown for persistence, Obsidian as an optional interface, Arabic-first bilingual search.

It contains no application code. Three things were executed while writing it: the database schema with constraint probes, a probe of SQLite full-text search on Arabic text, and a consistency checker over the documents.

## 2. Read in this order (owner)

1. `docs/governance/IMPLEMENTATION-READINESS.md` — verdict and why (2 pages).
2. `docs/governance/DECISIONS-FOR-APPROVAL.md` — the 15 decisions, 20 ADRs and 3 findings waiting for you. Sections A, B.1 and G are enough to answer; the rest gives the reasons.
   Then `docs/governance/PRE-IMPLEMENTATION-READINESS-CERTIFICATE.md` — gate results and what is still owed.
3. `docs/specification/GAP-REGISTER.md` §3 — disposition of the fifteen audit findings.
4. `docs/governance/ADVERSARIAL-REVIEW.md` — what is weak, and ten ways to make it smaller.
5. `docs/architecture/HLD.md` and `docs/architecture/AGENTIC-ARCHITECTURE.md` — how it works.

## 3. Contents

| Area | Documents |
|---|---|
| Baseline and registers (`docs/specification/`) | BASELINE-INVENTORY, GAP-REGISTER, CHANGE-REGISTER, V5-COMPLIANCE-MATRIX, 500-SLOT-COVERAGE; `data/` (machine-readable requirements, tests, tasks, catalogue, slot coverage); `evidence/` (probes, schema, outputs) |
| Requirements (`docs/requirements/`) | BRD, PRD, SRS, TRACEABILITY-MATRIX |
| Architecture (`docs/architecture/`) | HLD, LLD, DATA-ARCHITECTURE, DATABASE-SCHEMA, OBSIDIAN-SCHEMAS, MEMORY-ARCHITECTURE, RETRIEVAL-ARCHITECTURE, KNOWLEDGE-GRAPH, AGENTIC-ARCHITECTURE, WORKFLOW-CONTRACTS |
| Engineering (`docs/engineering/`) | CLAUDE-CODE-CONTRACTS, CLI-SPECIFICATION |
| Security, operations, testing | SECURITY-ARCHITECTURE; DEPLOYMENT-SPECIFICATION; TEST-STRATEGY, TEST-CASES |
| Planning (`docs/planning/`) | IMPLEMENTATION-BACKLOG, IMPLEMENTATION-ROADMAP, FILE-BUILD-PLAN |
| Decisions (`docs/decisions/`) | ADR-REGISTER (20 records) |
| Governance (`docs/governance/`) | IMPLEMENTATION-READINESS, DECISIONS-FOR-APPROVAL, PRE-IMPLEMENTATION-READINESS-CERTIFICATE, TARGETED-CORRECTIONS-REGISTER, ENGINEERING-HANDOFF, ADVERSARIAL-REVIEW, PHASE-1-AUTHORIZATION-PROMPT, QUALITY-REPORT.json |
| Snapshot (`docs/_baseline/`) | The V6.0 draft (46 files) and the audit package (25 files) exactly as received, with a hash manifest. Never edited |
| Root | `CLAUDE.md` (specification-only instructions for the development repository), `tools/spec_lint.py` |

## 4. Numbers

| | |
|---|---|
| Requirements | 78 functional, 22 non-functional (71 MUST) |
| Test cases designed | 143 (63 adversarial); 0 executed |
| Tasks | 52 across phases 0–10 |
| Implementation files planned | 91 |
| Database | 28 tables, FTS5 index, 17 indexes, 15 triggers; DDL executed, 27 of 27 probes as specified |
| Decisions | 5 decided, 15 open |
| ADRs | 20, all proposed |
| Gaps | 38 (16 resolved in specification, 11 awaiting verification, 8 awaiting decisions, 1 open, 1 open input, 1 superseded) |
| Audit findings | 15 dispositioned; 1 blocks specification approval (the approvals themselves) |
| 500 investigation slots | Specification level: 366 specified, 98 partly, 10 awaiting decisions, 4 open findings, 22 not applicable in v1. Implementation: all 500 pending |
| Consistency checks | 14 of 14 pass |

## 5. What changed from the draft, in five lines

- The specified search tokenizer does not work for Arabic; replaced by application-level normalisation with a measured probe (RETRIEVAL-ARCHITECTURE §2).
- Two contradictory data models replaced by one; schema rewritten, executed and probed.
- "Human approval" and "sandbox" turned into three approval tiers and five enforcement layers, checked against current Claude Code documentation, with fifteen items to verify on the Mac.
- Requirements, tests, tasks and traceability are generated from one data source and checked automatically.
- The audit's fifteen findings and five hundred slots are dispositioned without claiming anything about an implementation, because none has been supplied or verified.

## 5a. Revision IR1.1 (same day)

Corrections after three external reviews and two directives: a backup destination on the same physical disk is no longer accepted; the owner's own data is no longer treated as public; status wording no longer asserts that no implementation exists, only that none was supplied or verified; skill supply-chain behaviour is documented with a new threat, verification item and decision. The decision sheet was rebuilt as package 2.0; every ADR was completed with dependencies and acceptance; the proposal queue was bounded and backup moved to Phase 2; six assurance reports were added (corrections register, ADR completeness, requirements traceability, security assurance, change manifest, readiness certificate). Every current document carries the label v6.0-IR1.1; the change register (CHG-026 to CHG-035) and SPECIFICATION-CHANGE-MANIFEST.md list what changed. No amendment that depends on an owner decision has been applied.

## 6. Maintaining the documents

`SRS.md`, `TEST-CASES.md`, `TRACEABILITY-MATRIX.md`, `IMPLEMENTATION-BACKLOG.md`, `FILE-BUILD-PLAN.md`, `DATABASE-SCHEMA.md`, `BASELINE-INVENTORY.md` and `500-SLOT-COVERAGE.md` were generated from structured data; the JSON under `docs/specification/data/` is the source of truth for requirements, tests and tasks. After any edit run `python3 -I tools/spec_lint.py .`; it rewrites `QUALITY-REPORT.json` and fails on any broken reference or coverage gap. The generator scripts are not part of this package; the first task of any revision is to regenerate the affected document from the JSON or edit both consistently.

## 7. What is not here

No code. No installed dependency. No measurement of retrieval quality, performance or capacity. No verification on the owner's Mac. No review by anyone other than the author.
