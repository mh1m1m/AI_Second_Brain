# Architecture Decision Register

**DOC-ADR** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `ADR-REGISTER.md` and `ADR-PROPOSALS.md` of the V6.0 draft, which were summary tables without context, consequences or evidence (snapshot kept in `docs/_baseline/`). ADR-001 to ADR-010 keep their subjects; four are revised; ADR-011 to ADR-020 are new. **Every ADR is PROPOSED.** None is approved until the owner answers its row in DECISIONS-FOR-APPROVAL.md section G. Previously settled directions (V5.0) are not reopened without new evidence; where this register changes one, the new evidence is stated.

**IR1.1 (correction C-09):** every record now states context, alternatives, consequences, dependencies and acceptance; the lines added are marked by their field names and change no decision. Fields are checked by `tools/spec_lint.py`.

Evidence labels: **[DOC]** official documentation read on 2026-11-10; **[PROBE]** executed in the specification sandbox, files in `docs/specification/evidence/`; **[OWNER]** owner decision recorded on 2026-11-10; **[V5]** V5.0 adversarial review; **[REASON]** design reasoning without measurement.

---

### ADR-001 Claude Code is the only AI platform
- **Context.** Owner constraint since 4.0; principle P01.
- **Decision.** All model reasoning happens in Claude Code sessions. The Python package calls no model API.
- **Alternatives.** Other assistants or orchestration frameworks; direct API calls from Python for extraction.
- **Consequences.** No batch semantic processing without a session; no embeddings from the same provider path, so any dense retrieval would introduce a second model (see ADR-006).
- **Evidence.** [OWNER], [V5].
- **Reversal.** Explicit owner change of the constraint.
- **Depends on.** None (ADR-006 and ADR-008 follow from it).
- **Acceptance.** No module of the package imports a model client or opens a network connection (FR-SEC-006, NFR-004, NFR-009).

### ADR-002 Markdown with YAML frontmatter for narrative notes
- **Context.** Portability (P08) and Obsidian compatibility.
- **Decision.** Human notes are Markdown files; the file is authoritative for body and descriptive properties.
- **Alternatives.** Notes in the database with generated Markdown; a proprietary note format.
- **Consequences.** An uncoordinated editor (Obsidian) writes authoritative files; requires sync and conflict rules (ADR-012).
- **Evidence.** [V5]; [DOC] Obsidian properties are flat YAML.
- **Reversal.** Structured editing needs dominate and notes become forms.
- **Depends on.** None (ADR-003 and ADR-012 build on it).
- **Acceptance.** A generated or adopted note opens in any Markdown editor and exports without the tool (NFR-003); Unicode round-trip holds (NFR-022).

### ADR-003 Obsidian is an optional interface
- **Context.** V5.0 warned against making a note application a system component; the owner has no vault yet (D-04).
- **Decision.** No function depends on Obsidian running or on any plugin. Core plugins only in the installed vault configuration.
- **Alternatives.** Dataview or Templater based dashboards; an Obsidian plugin for approvals; a custom application.
- **Consequences.** Dashboards are generated Markdown; approvals happen in Claude Code or a terminal.
- **Evidence.** [DOC] RTL and mixed-direction support is built in since 1.6; Bases exists as a core plugin since 1.9 and is not relied on. [V5].
- **Reversal.** The owner finds generated dashboards insufficient; Bases views would be the first candidate.
- **Depends on.** ADR-002; decision D-14.
- **Acceptance.** Every command works with Obsidian closed (NFR-017); generated notes display correctly with core plugins only (V-11).

### ADR-004 SQLite as the transactional registry
- **Context.** The registry needs transactions, constraints and one file to back up on a single Mac; V5.0 kept SQLite.
- **Decision.** One SQLite file in WAL mode, STRICT tables, foreign keys on, schema in DATABASE-SCHEMA.
- **Alternatives.** PostgreSQL; JSON or Markdown files as registry; an embedded key-value store.
- **Consequences.** Single writer; file-level backup through the online backup API; the database owner can alter anything (mitigated by ADR-015).
- **Evidence.** [PROBE] DDL executes on SQLite 3.53.1 with 27 of 27 constraint probes behaving as specified. [V5].
- **Reversal.** Multi-user or multi-device writing becomes a requirement; measured contention.
- **Depends on.** Verification V-01 (ADR-013 and ADR-016 build on it).
- **Acceptance.** The DDL executes with all constraint probes on the Mac's SQLite (V-01); migrations follow FR-OPS-006.

### ADR-005 FTS5 baseline with application-level Arabic normalisation (revised)
- **Context.** The draft specified `tokenize='unicode61'` and listed Arabic tokenisation as a medium-severity gap to benchmark later.
- **Decision.** Keep FTS5 as the baseline, but normalise text in the application (`ar-en-1`), index a light-stemmed column, and wrap `unicode61` in `porter` for English. Variant chosen by gate RET-G1.
- **Alternatives.** Raw `unicode61` (draft); `trigram` tokenizer; SQLite ICU extension; an external search engine.
- **Consequences.** Index text differs from stored text; excerpts come from originals; a normaliser change needs a rebuild; light stemming misses broken plurals.
- **Evidence.** [PROBE] raw `unicode61` indexed `مُحَمَّدٌ` as four single letters and failed all nine variant probes; the normalised and stemmed index answered eight of them (broken plurals remain missed); details in RETRIEVAL-ARCHITECTURE §2. This is tokenizer behaviour, not a quality measurement.
- **Reversal.** NFR-007 not met on holdout after RET-G1.
- **Depends on.** ADR-004; decision D-10; gate RET-G1.
- **Acceptance.** NFR-007 measured on the holdout set at the Phase 4 gate through FR-RET-008; the tokenizer probe reproduces on the Mac (V-09).

### ADR-006 Defer vector retrieval
- **Context.** 4.0 put a vector database at the centre before any retrieval measurement existed (V5.0 finding 5).
- **Decision.** No embeddings or vector store until gate RET-G2 is met.
- **Alternatives.** Qdrant (4.0); an embedded vector extension; hybrid from the start.
- **Consequences.** No semantic matching; cross-language questions rely on query translation in the session.
- **Evidence.** [V5] finding 5. [REASON] an embedding model would be a second model provider or a local model, against P01 without explicit approval.
- **Reversal.** RET-G2 criteria, with recorded numbers.
- **Depends on.** ADR-001, ADR-005; gate RET-G2.
- **Acceptance.** A capacity and quality record at Phase 8 states either "not justified" with numbers or an experiment plan for approval.

### ADR-007 Defer a graph database
- **Context.** 4.0 proposed Neo4j and GraphRAG; V5.0 finding 6 found no query that needed them.
- **Decision.** Typed relationships in SQLite with recursive queries.
- **Alternatives.** Neo4j; GraphRAG pipelines.
- **Evidence.** [V5] finding 6. [REASON] no required query exceeds a depth-3 traversal.
- **Reversal.** KNOWLEDGE-GRAPH §6.
- **Consequences.** Relationship questions are limited to shallow traversals; no community detection or graph algorithms.
- **Depends on.** ADR-004, ADR-016.
- **Acceptance.** Required relationship traversals run as recursive SQL in the as-of reconstruction tests; the decision is reconsidered only on the gate in KNOWLEDGE-GRAPH §6.

### ADR-008 One orchestrator, deterministic services, no unattended model runs
- **Context.** 4.0 proposed nine agents and autonomous scheduled runs (V5.0 findings 4 and 7).
- **Decision.** One interactive Claude Code session orchestrates; Python does everything that must be reproducible; launchd runs only deterministic commands; no custom subagent in the operating workspace.
- **Alternatives.** Nine agents (4.0); scheduled `claude -p` jobs for ingestion and reconciliation.
- **Consequences.** Semantic work happens only when the owner is present. Bulk proposal drafting is manual-paced.
- **Evidence.** [V5] findings 4 and 7. [DOC] non-interactive runs show no trust dialog and no per-server approval prompt, and deny what would prompt.
- **Reversal.** A measured backlog of semantic work the owner wants processed unattended, with a separate security design.
- **Depends on.** ADR-001, ADR-009.
- **Acceptance.** Scheduled jobs contain only allowlisted deterministic commands (FR-AGT-008, TEST-AGT-012); no model run is scheduled.

### ADR-009 Approval-gated promotion with three tiers (revised)
- **Context.** The draft required "human approval" for all knowledge writes without saying how a human is distinguished from the agent.
- **Decision.** Tier 0 (none), tier 1 (owner at a Claude Code permission prompt or terminal), tier 2 (terminal with typed confirmation). Approvals are rows bound to the proposal's payload hash, single-use, expiring.
- **Alternatives.** Approve everything at a terminal (safest, most friction); approve nothing below deletion (least friction); an Obsidian-based approval.
- **Consequences.** Tier 1 in-session approval rests on Claude Code's `ask` rule behaviour (V-06). Friction is unmeasured.
- **Evidence.** [DOC] ask rules prompt regardless of allow rules and hooks; bypass and auto modes can be disabled by setting. [PROBE] triggers T8–T10.
- **Reversal.** V-06 fails (→ terminal-only tier 1), or the 30-day review shows the tiers are wrong.
- **Depends on.** ADR-015; decision D-08; verification V-06.
- **Acceptance.** Replayed, expired, mismatched and wrong-channel approvals are refused (FR-AGT-001, FR-AGT-004; TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-AGT-008); limits per GAP-033 hold (TEST-AGT-013).

### ADR-010 Independent backup with restore testing; encryption optional (revised)
- **Context.** V5.0 finding 9: Git history was being treated as recovery. The draft required encrypted independent backups.
- **Decision.** Backups to a destination on another device, with manifest, verification after write and scheduled restore tests. Encryption off by default.
- **Alternatives.** Git only; Time Machine only; encrypted by default (draft).
- **Consequences.** Unencrypted copies of public content; one more thing the owner must provide (a destination).
- **Evidence.** [V5] finding 9. [OWNER] content is public (D-03), which removes the confidentiality reason for mandatory encryption.
- **Reversal.** Content classification changes; then encryption and key handling become mandatory before further ingestion.
- **Depends on.** Decision D-06; findings GAP-034, GAP-037, GAP-038.
- **Acceptance.** FR-OPS-002, FR-OPS-003, FR-OPS-010 and NFR-006 pass; the destination is a separate physical device (DOC-BKP-05); a restore-tested backup exists before any owner document is ingested (DOC-BKP-04).
- **Pending amendment.** Decision D-06 is open. Amendment AM-01 would replace "encryption off by default" with an encrypted backup volume and documented key recovery. The decision text above is unchanged until the owner answers.

### ADR-011 Architecture C+ among the V5.0 alternatives
- **Context.** V5.0 compared six architectures (A to F) and recommended the middle one with governance added.
- **Decision.** Alternative C (Claude Code, Obsidian, FTS5) plus provenance registry, memory lifecycle, commit journal, approval gate, backups and evaluation harness.
- **Alternatives.** A, B, D, E, F as defined by V5.0 (HLD §11).
- **Consequences.** More machinery than A–C; much less than D–F.
- **Evidence.** [V5] recommended production architecture. [REASON] each addition maps to a MUST requirement (TRACEABILITY).
- **Reversal.** A gate result showing a retained component is unnecessary or an omitted one is needed.
- **Depends on.** ADR-001 to ADR-010.
- **Acceptance.** Every retained component traces to at least one MUST requirement (TRACEABILITY-MATRIX; checked by `tools/spec_lint.py`).

### ADR-012 Governed fields live in SQLite; Markdown shows projections; memory appears as digests
- **Context.** V5.0 finding 1; audit issue 0012. The draft left "reconciliation" undefined.
- **Decision.** Authority map of DATA-ARCHITECTURE §2. Managed frontmatter keys are projections and never read back. Memory is projected as digest notes per subject, project or month.
- **Alternatives.** Markdown authoritative for everything; database authoritative for everything; one note per memory record.
- **Consequences.** A hand edit of a managed key is ignored and reported; fewer generated files.
- **Evidence.** [REASON]; [DOC] Obsidian block anchors and flat properties.
- **Reversal.** The owner needs to edit governed fields in Obsidian; then an explicit "edit becomes proposal" path would be designed.
- **Depends on.** ADR-002, ADR-004; decision D-14.
- **Acceptance.** A hand edit of a managed key is reported and re-projected, never read back (OBSIDIAN-SCHEMAS rule OBS-D01).

### ADR-013 Application journal for file-plus-database commits
- **Context.** A change touches files and the database; neither can roll the other back (V5.0 finding 1, audit issue on transactional integrity).
- **Decision.** Protocol S0–S7 with intents, atomic rename, a database commit point, roll-forward recovery and a read-only mode for unknown states.
- **Alternatives.** Database first, files second; files only with the database rebuilt from them; storing originals as BLOBs.
- **Consequences.** A recovery step before every mutating command; runs limited to one original and one note group.
- **Evidence.** [REASON]. Unverified until the crash suite runs; `rename` and full-fsync behaviour on the Mac is V-10.
- **Reversal.** The crash suite shows an unrecoverable interleaving.
- **Depends on.** ADR-004; verification V-10.
- **Acceptance.** The randomised crash loop ends with zero invariant violations (NFR-002, NFR-018, TEST-REC-010).

### ADR-014 Operating home separate from the development repository
- **Context.** The directive's proposed layout put `vault/` and `data/` inside the code repository.
- **Decision.** Code in `~/Developer/ai-second-brain`; knowledge in `~/SecondBrain` with its own instructions and settings; the CLI installed outside both.
- **Alternatives.** One repository for everything.
- **Consequences.** Two Claude Code contexts; knowledge never enters the code repository's Git history; a session that reads knowledge cannot edit the code that guards it.
- **Evidence.** [DOC] the sandbox makes the working directory writable by default and settings are per project; [REASON].
- **Reversal.** Owner preference for a single folder, accepting weaker separation.
- **Depends on.** Decision D-07 (ADR-015 builds on it).
- **Acceptance.** Path rules and instruction-file rejection hold (FR-SEC-001, FR-SEC-004); V-03, V-04 and V-07 pass on the Mac.
- **Pending amendment.** Decision D-07 is open. Amendment AM-04 would move the session folder to `~/SecondBrain/workspace` with the vault and data beside it.

### ADR-015 Layered write enforcement; no hooks in version 1
- **Context.** "Human approval" and "sandbox" in the draft named no mechanism. Claude Code documentation shows no single mechanism covers all write paths.
- **Decision.** Five layers (SECURITY-ARCHITECTURE §5). The installed CLI is the only command excluded from the sandbox.
- **Alternatives.** Prompts only; a PreToolUse hook as gatekeeper; a separate macOS user account for the data; a local daemon owning the data.
- **Consequences.** Depends on V-03 to V-06. Fallback if V-05 fails: drop the exclusion and rely on L2–L5. A separate OS account would be stronger and is rejected as disproportionate for public content.
- **Evidence.** [DOC] the sandbox covers Bash and its children but not built-in file tools, hooks or MCP servers; hooks run with full user permissions; Bash permission rules are not a security boundary.
- **Reversal.** V-items fail without a workable fallback; or content classification changes.
- **Depends on.** ADR-014; decision D-20; verification V-03 to V-06 and V-15 (ADR-009 and ADR-018 build on it).
- **Acceptance.** Zero unauthorised writes in the security protocol (NFR-019); each layer's verification item passes or its documented fallback is adopted.
- **Pending amendment.** Decision D-20 is open. Amendment AM-05 adds the skill rules of CLAUDE-CODE-CONTRACTS §4.1. The phrase "disproportionate for public content" predates correction CHG-028 and should read "disproportionate for a single-user system" when the ADR is next amended.

### ADR-016 Sequential typed identifiers and an objects registry
- **Context.** Citations must be readable by a person and resolvable by the system; the draft mixed ID styles.
- **Decision.** IDs like `MEM-000101`, allocated in-transaction; every object registered in `objects`.
- **Alternatives.** UUID or ULID; per-table integer keys with polymorphic text references.
- **Consequences.** Readable citations; real foreign keys for cross-type links; unsuitable for multi-device writing.
- **Evidence.** [PROBE] constraints P22–P24.
- **Reversal.** Multi-device writing.
- **Depends on.** ADR-004; decision D-12.
- **Acceptance.** IDs are unique, never reused and resolve through `objects` (schema probes P22 to P24).

### ADR-017 Extraction: small parsers, versioned extractions, OCR deferred
- **Context.** 4.0 proposed Docling.
- **Decision.** Standard-library extractors for text, Markdown and HTML; one small library each for DOCX and PDF; extractor name and version on every extraction; scanned content flagged, not processed. The PDF library is chosen by a measured spike on Arabic fixtures (V-12).
- **Alternatives.** Docling or a similar model-based pipeline; OCR in version 1; reading PDFs through Claude in a session.
- **Consequences.** Tables and layout are extracted poorly; scanned Arabic documents are not searchable until a later decision.
- **Evidence.** [REASON] dependency minimalism (NFR-011). No library has been tested: **unverified**.
- **Reversal.** Spike shows no small library gives acceptable Arabic reading order; or the pilot corpus is mostly scans.
- **Depends on.** Decisions D-09 and D-15; verification V-12.
- **Acceptance.** Each format is enabled only when its extraction tests pass (FR-ING-003, FR-ING-007, FR-ING-009); the PDF library is chosen from the recorded spike.
- **Pending amendment.** Decision D-09 is open. The recommendation is now to enable formats in stages, each on passing its extraction tests.

### ADR-018 No MCP server, plugin, web access or browser automation; Claude Code auto memory off
- **Context.** 4.0 included browser automation and MCP servers; each adds a path by which outside text or code reaches a session that can propose writes.
- **Decision.** None of these in the operating workspace in version 1.
- **Alternatives.** Obsidian MCP server; Playwright (4.0); web research in session.
- **Consequences.** No web research inside the Second Brain workspace (decision D-11 may reopen).
- **Evidence.** [DOC] MCP servers and hooks run outside the sandbox; servers that fetch external content expose sessions to injection; auto memory stores project notes outside any governance.
- **Reversal.** Owner approves a specific integration with an ADR.
- **Depends on.** Decisions D-11 and D-20; ADR-015.
- **Acceptance.** No network use by default and no integration without approval (FR-SEC-006, FR-SEC-007, NFR-009); V-02, V-08 and V-15 pass.
- **Pending amendment.** Decision D-11 is open. Amendment AM-06 would add an optional, separate research workspace.

### ADR-019 Legacy vault import deferred, schema-ready
- **Context.** The owner starts with a fresh vault and asked that a later import stay possible, with preview, attachments, links, duplicates and rollback.
- **Decision.** Not built in version 1. The schema already carries what import needs: `origin_kind = legacy_vault`, `change_origin = import`, `created_by_run` for batch rollback, entity aliases for reconciliation. Contracts FR-IMP-001..003.
- **Evidence.** [OWNER] fresh vault; no existing vault (D-04).
- **Reversal.** Owner requests import; it becomes a Phase 10 item with its own approval.
- **Alternatives.** Build the import now; never support import.
- **Consequences.** Nothing to build or test until a vault exists; three requirements stay as contracts.
- **Depends on.** Decision D-04 (decided); ADR-016.
- **Acceptance.** FR-IMP-001 to FR-IMP-003 remain contracts; version 1 ships no import code; the schema fields named above exist.

### ADR-020 One memory model
- **Context.** The draft contained `claims` in one document and `knowledge_records` plus `memory_records` in another.
- **Decision.** `memory_records` + `memory_revisions` + `evidence_links`; notes are separate.
- **Alternatives.** Claims embedded in notes; separate tables per memory kind.
- **Evidence.** [PROBE] lifecycle and evidence triggers; [V5] findings 2 and 3.
- **Reversal.** A memory kind needs fields the shared shape cannot hold.
- **Consequences.** A memory is a record with history, not a note; notes and memory are linked, not merged; one shape must fit all seven kinds.
- **Depends on.** ADR-004, ADR-009, ADR-012.
- **Acceptance.** Lifecycle and evidence triggers hold from raw SQL (schema probes); no verified record exists without live evidence (doctor check DOC-MEM-01).
