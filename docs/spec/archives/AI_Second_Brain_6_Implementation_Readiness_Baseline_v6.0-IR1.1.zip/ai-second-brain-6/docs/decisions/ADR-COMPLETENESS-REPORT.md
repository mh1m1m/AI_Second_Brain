# ADR Completeness Report

**DOC-ACR** · v6.0-IR1.1 · 2026-11-10 · Status: ASSURANCE REPORT · Owner: Mohammed Alsaleh

## 1. Inventory

- Records found: **20** (ADR-001 to ADR-020), all sections of one file, `docs/decisions/ADR-REGISTER.md`. There are no per-ADR files.
- Records in the IR1 snapshot of that file (`docs/_baseline/v6.0-IR1-decision-register/ADR-REGISTER.md`, SHA-256 `248f9ec0ef6e9d201de21539b46cb95c9ba4e1b5d50b63d53f0e0f5da4a85458`): 20.
- Complete (all eight fields): 20. Status of every record: PROPOSED. Approved: 0.

## 2. The 10-versus-20 discrepancy

An external review found 10 ADRs and reported ADR-011 to ADR-020 as not present. It was working from `AI_Second_Brain_6_Implementation_Ready_Specification_Draft.zip`, the earlier V6.0 draft, whose `ADR-REGISTER.md` is a ten-row table (preserved in `docs/_baseline/v6.0-expanded-draft/`). The IR1 baseline replaced that table with full records and added ADR-011 to ADR-020 for decisions the draft had made implicitly or left contradictory. This is case B of the directive: the records exist in a newer baseline. Nothing was created now to reach a count. ADR-001 to ADR-010 keep the draft's subjects, so the reviewer's provisional recommendations for them carry over.

## 3. Completeness matrix

| ADR | Title | Line | Context | Decision | Alternatives | Consequences | Evidence | Reversal | Depends on | Acceptance | Section SHA-256 (first 16) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| ADR-001 | Claude Code is the only AI platform | 13 | yes | yes | yes | yes | yes | yes | yes | yes | `22324732155cf314` |
| ADR-002 | Markdown with YAML frontmatter for narrative notes | 23 | yes | yes | yes | yes | yes | yes | yes | yes | `caa061969802fdc9` |
| ADR-003 | Obsidian is an optional interface | 33 | yes | yes | yes | yes | yes | yes | yes | yes | `3e306f1ae628bb3a` |
| ADR-004 | SQLite as the transactional registry | 43 | yes | yes | yes | yes | yes | yes | yes | yes | `41016863bf031e77` |
| ADR-005 | FTS5 baseline with application-level Arabic normalisation (revised) | 53 | yes | yes | yes | yes | yes | yes | yes | yes | `a3d9c43814375f39` |
| ADR-006 | Defer vector retrieval | 63 | yes | yes | yes | yes | yes | yes | yes | yes | `6dd7f668f67026bb` |
| ADR-007 | Defer a graph database | 73 | yes | yes | yes | yes | yes | yes | yes | yes | `fa15021594b64e69` |
| ADR-008 | One orchestrator, deterministic services, no unattended model runs | 83 | yes | yes | yes | yes | yes | yes | yes | yes | `054b90d1f1e10760` |
| ADR-009 | Approval-gated promotion with three tiers (revised) | 93 | yes | yes | yes | yes | yes | yes | yes | yes | `fda40b4134ef48ff` |
| ADR-010 | Independent backup with restore testing; encryption optional (revised) | 103 | yes | yes | yes | yes | yes | yes | yes | yes | `5ae8fd62246c6424` |
| ADR-011 | Architecture C+ among the V5.0 alternatives | 114 | yes | yes | yes | yes | yes | yes | yes | yes | `d1cb53be39042f53` |
| ADR-012 | Governed fields live in SQLite; Markdown shows projections; memory appears as digests | 124 | yes | yes | yes | yes | yes | yes | yes | yes | `814fa0d3e5d3f2ee` |
| ADR-013 | Application journal for file-plus-database commits | 134 | yes | yes | yes | yes | yes | yes | yes | yes | `b158a05410abb2a0` |
| ADR-014 | Operating home separate from the development repository | 144 | yes | yes | yes | yes | yes | yes | yes | yes | `c0038fbbb2a5e999` |
| ADR-015 | Layered write enforcement; no hooks in version 1 | 155 | yes | yes | yes | yes | yes | yes | yes | yes | `9829f8b2ceae755f` |
| ADR-016 | Sequential typed identifiers and an objects registry | 166 | yes | yes | yes | yes | yes | yes | yes | yes | `4f55c98c0f845d8b` |
| ADR-017 | Extraction: small parsers, versioned extractions, OCR deferred | 176 | yes | yes | yes | yes | yes | yes | yes | yes | `aafa63b61c68e248` |
| ADR-018 | No MCP server, plugin, web access or browser automation; Claude Code auto memory off | 187 | yes | yes | yes | yes | yes | yes | yes | yes | `c7a3b40264833240` |
| ADR-019 | Legacy vault import deferred, schema-ready | 198 | yes | yes | yes | yes | yes | yes | yes | yes | `64c8d2f66e86fbc3` |
| ADR-020 | One memory model | 208 | yes | yes | yes | yes | yes | yes | yes | yes | `899cdfab40cca2c7` |

Before IR1.1, IR1 records had no dependency or acceptance field, eleven lacked a context line, and three lacked consequences or alternatives. Those lines were added (correction C-09) without changing any decision.

## 4. Dependencies

| ADR | Depends on (ADRs) | Open decisions | Amendment pending | Requirements governed |
|---|---|---|---|---|
| ADR-001 | — | — | no | 3 |
| ADR-002 | — | — | no | 10 |
| ADR-003 | ADR-002 | D-14 | no | 6 |
| ADR-004 | — | — | no | 11 |
| ADR-005 | ADR-004 | D-10 | no | 13 |
| ADR-006 | ADR-001, ADR-005 | — | no | 2 |
| ADR-007 | ADR-004, ADR-016 | — | no | 2 |
| ADR-008 | ADR-001, ADR-009 | — | no | 6 |
| ADR-009 | ADR-015 | D-08 | no | 17 |
| ADR-010 | — | D-06 | yes | 5 |
| ADR-011 | ADR-001, ADR-002, ADR-003, ADR-004, ADR-005, ADR-006, ADR-007, ADR-008, ADR-009, ADR-010 | — | no | 2 |
| ADR-012 | ADR-002, ADR-004 | D-14 | no | 7 |
| ADR-013 | ADR-004 | — | no | 7 |
| ADR-014 | — | D-07 | yes | 5 |
| ADR-015 | ADR-014 | D-20 | yes | 12 |
| ADR-016 | ADR-004 | D-12 | no | 9 |
| ADR-017 | — | D-09, D-15 | yes | 8 |
| ADR-018 | ADR-015 | D-11, D-20 | yes | 6 |
| ADR-019 | ADR-016 | D-04 | no | 3 |
| ADR-020 | ADR-004, ADR-009, ADR-012 | — | no | 16 |

Dependency cycle among ADRs: none (computed).

## 5. Contradictions and tensions

No ADR contradicts another. Recorded tensions:

1. ADR-001 and ADR-006: any embedding model would be a second model path and needs its own approval.
2. ADR-008: workflow automation in this system is assisted, never unattended.
3. ADR-014 and ADR-015 rest on documented Claude Code behaviour that is unverified on the Mac (V-03 to V-07, V-15).
4. ADR-010 still reads "encryption off by default" while DEPLOYMENT-SPECIFICATION §6 recommends an encrypted volume. Held open deliberately until decision D-06; the ADR carries a pending-amendment line.
5. ADR-015 gives "public content" as the reason for rejecting a separate OS account; after correction CHG-028 the reason is the single-user scale. Wording to change with amendment AM-05.

## 6. Recommendations

Per-ADR recommendations are in DECISIONS-FOR-APPROVAL section C: 15 RECOMMEND_APPROVAL (three conditional on a measurement), 5 RECOMMEND_APPROVAL_WITH_AMENDMENT, none for deferral or rejection. Acceptance criteria are testable for every record; none has been tested.
