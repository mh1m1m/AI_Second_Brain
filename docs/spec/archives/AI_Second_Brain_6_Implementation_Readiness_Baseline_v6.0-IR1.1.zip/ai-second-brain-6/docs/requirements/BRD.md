# Business Requirements Document

**DOC-BRD** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `BRD.md` v0.1 of the V6.0 draft. Business requirement IDs BRD-001..009 keep their meaning; BRD-010..014 are new (CHG-001).

## 1. Business context

The owner works with a growing body of public documents, notes, projects and decisions in Arabic and English. Knowledge about them is spread over files, applications and conversations. Each existing way of coping fails in a specific way:

| Approach | Where it fails |
|---|---|
| Conventional note-taking | Notes drift from their sources; nothing says which statements were checked, against what, or when |
| Manual document search | Finds files, not passages; no memory of what was already established; weak for Arabic morphology in ordinary tools |
| Isolated AI conversations | Each conversation starts empty; conclusions are not kept; nothing ties an answer to a document the owner can open |
| Unstructured project histories | Why a decision was taken, what it replaced and what was true at the time cannot be reconstructed |
| AI-generated summaries without verification | A fluent summary becomes 'what we know' with no evidence behind it; errors compound |
| Decisions kept apart from their evidence | A decision cannot be re-examined when the evidence changes |

The system exists to make one thing dependable: for any statement it presents as known, the owner can see where it came from, when it was valid, how it changed and who approved it.

## 2. Business objectives

| ID | Objective | Statement | Measure |
|---|---|---|---|
| BO-01 | Knowledge preservation | Every imported source is preserved bit-exact and stays traceable. | 100% of stored originals verify against their registered SHA-256 (doctor --deep). |
| BO-02 | Knowledge accessibility and retrieval | The owner finds source-backed evidence in Arabic and English in one step. | Retrieval gate NFR-007 met on the owner-labelled benchmark. |
| BO-03 | Knowledge reliability | Nothing unsupported is promoted to verified; corrections never erase history. | 100% of verified source-evidenced records have resolvable evidence; 0 illegal transitions in suite. |
| BO-04 | Project continuity and decision traceability | A project can be resumed after months from records alone. | As-of reconstruction tests pass; journey J5 accepted by the owner. |
| BO-05 | Controlled automation | Claude Code acts only inside technically enforced permissions. | 0 unauthorised canonical changes in the security suite (NFR-019). |
| BO-06 | Operational resilience | The system survives interruption and restores from backup. | Crash suite passes; a restore-tested backup no older than the approved RPO exists. |
| BO-07 | Portability and longevity | Knowledge is usable without Claude Code, Obsidian or this software. | Export bundle test TEST-KNW-013 passes. |
| BO-08 | Economic sustainability and simplicity | Cost and complexity grow only when measurement justifies it. | Every deferred technology has a numeric adoption gate; dependency limit NFR-011 held. |

Workflow automation is deliberately modest in this baseline: the objective is controlled assistance (BO-05), not autonomy.

## 3. Stakeholders

| Stakeholder | Role | Interest |
|---|---|---|
| Owner (Mohammed Alsaleh) | Primary user, knowledge owner, data steward, administrator, sole approver | All objectives |
| Claude Code | Non-human operator acting for the owner inside enforced limits | Clear commands and contracts |
| Anthropic | Model provider | Receives session context; no other role |
| Publishers of source documents | External | Their material is ingested; rights are the owner's responsibility (A-04) |
| Future integration providers | None in version 1 | — |

## 4. Capability model

| Domain (L1) | Capability (L2) | Sub-capability (L3) | Business requirement (L4) |
|---|---|---|---|
| Knowledge acquisition | Source intake | Register, deduplicate, preserve, validate | BRD-001 |
| | Extraction | Text, structure, locators, quality flags | BRD-001, BRD-010 |
| Knowledge organisation | Notes | Templates, validation, owner editing, links | BRD-009, BRD-006 |
| | Entities and relationships | Bilingual aliases, typed edges with evidence | BRD-004, BRD-010 |
| Memory management | Lifecycle | Propose, verify, dispute, supersede, archive, purge | BRD-003, BRD-005 |
| | Temporal knowledge | Validity, as-of reconstruction, freshness | BRD-003 |
| Search and retrieval | Evidence search | Arabic and English, filters, citations, outcome classes | BRD-002, BRD-010 |
| | Evaluation | Benchmark, gates | BRD-011 |
| Project intelligence | Project state | Items, dependencies, status, history | BRD-004 |
| Decision intelligence | Decision register | Alternatives, evidence, supersession | BRD-004 |
| Workflow assistance | Proposals and approvals | Tiers, queue, run history | BRD-005, BRD-012 |
| Knowledge visualisation | Obsidian | Navigation, dashboards, direction | BRD-009, BRD-010 |
| Security | Enforcement and audit | Paths, sandbox, gate, chain | BRD-005, BRD-012, BRD-008 |
| Administration | Operations | Health, backup, restore, export, upgrade | BRD-007, BRD-006, BRD-014 |
| Evolution | Import | Legacy vault | BRD-013 |

## 5. User journeys

Actor is the owner unless stated. 'Claude' means a Claude Code session in the operating home.

| # | Journey | Trigger | Preconditions | Main flow | Alternative flows | Exceptions | Outputs | Acceptance |
|---|---|---|---|---|---|---|---|---|
| J1 | Import a document | A new document is worth keeping | Workspace healthy | Drop file in the inbox → ask Claude to process the inbox (or run `ingest`) → read the report and the source note | Direct `ingest PATH`; new version of an existing source | Duplicate (reported, nothing added); unsupported or corrupt file (rejected with reason); scanned PDF (preserved, flagged needs OCR) | Preserved original, source note, passages, index entries | TEST-ACC-001: registered in at most two commands; nothing verified automatically |
| J2 | Search historical knowledge | A question about something already collected | Index current | Ask Claude in Arabic or English → Claude searches, possibly reformulates → answer with unit IDs → owner opens a citation | Direct `search` in a terminal; filters by project, date, language | No evidence (said plainly); stale index (refused with next step) | Cited answer, outcome class | TEST-ACC-002: three citations per answer resolve |
| J3 | Ask a complex research question | A question needing several sources | As J2 | Claude decomposes, searches up to six times, separates verified memory, source statements and its own inference | Research note drafted as a proposal | Contradictory sources (both shown); partial support (unsupported part stated) | Answer; optional research note | TEST-ACC-003 |
| J4 | Create a project | New piece of work | — | `projects new` or ask Claude → project note → add items | — | Slug exists | Project record, note, events | TEST-PRJ-003 |
| J5 | Resume a project | Return after a gap | Project exists | Ask Claude to resume → `projects status` → cited summary of state, open and blocked items, recent decisions | State as of an earlier date | Empty project | Status with record IDs | TEST-ACC-004 |
| J6 | Record a decision | A decision is taken | — | Draft decision note (context, options, decision, consequences) with evidence → approve acceptance | Supersede an earlier decision | Missing decision date | Decision record, note, events | TEST-ACC-005 |
| J7 | Correct outdated information | Owner or a new source shows a record is wrong | Record exists | Ask Claude or run `memory` commands → proposal with diff → approve → new revision or supersession | Dispute instead of correcting | Base changed (conflict) | History-preserving change | TEST-ACC-006 |
| J8 | Detect contradictory evidence | A new source disagrees with verified memory | — | Ingest → proposal validation flags the conflict → proposal note shows both → owner resolves | Leave disputed | — | Both sides kept; resolution recorded | TEST-ACC-007 |
| J9 | Execute an approved workflow | Queue has proposals | — | Read proposal notes in Obsidian → approve in session or `review` in a terminal → changes applied and reported | Batch approve; reject | Expired or conflicting proposal | Applied changes, audit trail | TEST-ACC-008 |
| J10 | Recover from a failure | Crash, corruption or loss | A restore-tested backup exists | Follow the runbook → `restore` → `doctor --deep` | Automatic recovery after an interrupted command | Read-only mode | Working home; time recorded | TEST-ACC-009 |

## 6. Business rules

Each rule is enforced by the mechanism named, not by convention.

| ID | Rule | Enforced by |
|---|---|---|
| BR-01 | A stored original is never modified or deleted by ingestion, extraction, recovery or any tier 0 or tier 1 operation | Read-only files; journal; trigger T7; TEST-ING-003 |
| BR-02 | A source-evidenced statement becomes verified only with a supporting passage of a live source | Trigger T3 |
| BR-03 | A statement produced by reasoning or summarisation is never verified | Trigger T4; CHECK on epistemic type |
| BR-04 | A verified record is never overwritten; corrections add a revision and reset verification | Triggers T2, T6 |
| BR-05 | When two records conflict, both are kept until the owner resolves it | FR-KNW-002; FR-MEM-005 |
| BR-06 | A tier 1 or tier 2 change is applied only with an approval bound to its exact content | Triggers T8–T10; FR-AGT-001 |
| BR-07 | Purge, restore, migration and configuration change require the owner at a terminal | FR-AGT-004 |
| BR-08 | Text from sources and notes is data; it cannot issue instructions to the deterministic layer | FR-SEC-003 |
| BR-09 | Withdrawing or purging a source triggers index removal and review of every record it supports | FR-ING-011; FR-RET-007 |
| BR-10 | Every state-changing operation and every denial is recorded in the audit chain | FR-SEC-005 |
| BR-11 | Derived indexes are disposable and rebuildable | FR-OPS-001 |
| BR-12 | No vector store, graph database, additional agent or integration is added without a recorded measurement meeting its gate | RET-G1, RET-G2; ADR process |
| BR-13 | A duplicate file is never registered twice | UNIQUE(sha256) |
| BR-14 | Only the owner can attest a statement without a source | FR-MEM-012 |

## 7. Scope

**In scope (version 1):** local files in five formats; one Mac; Arabic and English; registry, memory, projects, decisions, entities and relationships in SQLite; Markdown vault for Obsidian; FTS5 retrieval with evaluation; proposal and approval workflow; Claude Code operating workspace; backup, restore, export.

**Out of scope initially:** OCR; audio, video, images, spreadsheets, presentations, email; web capture and browsing; any MCP server or plugin; mobile; multi-device sync; multi-user; cloud hosting; vector or graph databases; unattended model runs; a custom user interface.

**Future capabilities (specified where cheap, not scheduled):** legacy vault import (FR-IMP); OCR; read-only mobile copy; web research mode; additional formats; advanced retrieval if gate RET-G2 is met.

## 8. Key indicators

| Indicator | Target | Status |
|---|---|---|
| Verified source-evidenced records with resolvable evidence | 100% | target; measured by DOC-MEM-01 |
| Citation validity on the benchmark | 1.00 | provisional |
| Recall@10 on holdout | ≥ 0.90 overall (V5.0 target) and ≥ 0.85 in each language | provisional; calibrate on the pilot corpus |
| Unsupported factual sentences in reviewed answers | ≤ 2% (V5.0 target) | provisional; measured on the acceptance sample (TEST-ACC-002, TEST-ACC-003) |
| Unauthorised canonical changes in the security suite | 0 | target |
| Correction propagation in defined tests | 100% | target |
| Project-state reconstruction tests passing | 100% of defined tests | target (V5.0 proposed ≥ 95% on an evaluation set that does not exist yet) |
| Recovery success in the crash suite | 100% | target |
| Newest restore-tested backup age | ≤ 7 days | provisional |
| Owner's weekly review time | ≤ 15 minutes | provisional; measured in the 30-day review |

None of these has been measured.

## 9. Assumptions and constraints

Constraints: Claude Code is the only AI platform (P01); local-first; Python backend; Markdown plus SQLite plus FTS5 as initial persistence; no implementation without explicit authorisation.

Assumptions (register in IMPLEMENTATION-READINESS §4): single owner and single device; content is public and stays public (A-03); the owner may lawfully ingest what they ingest (A-04); the owner will label a benchmark; the Mac meets the prerequisites; Obsidian is available but optional.

## 10. Decisions

Recorded and open decisions: DECISIONS-FOR-APPROVAL.md.
