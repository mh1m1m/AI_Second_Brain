# Requirements Traceability Matrix

**DOC-RTM** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `TRACEABILITY-MATRIX.md` (8 rows) and `TRACEABILITY-IMPLEMENTATION.md` (16 rows, objectives `OBJ-01..06` that were defined nowhere) of the V6.0 draft. Generated; the consistency rules in §4 are enforced by `tools/spec_lint.py`.

Status of every row: **PROPOSED / NOT IMPLEMENTED**. A requirement is complete only when its tests pass and the result is recorded (Definition of Done, IMPLEMENTATION-ROADMAP §3).

## 1. Business objective → business requirement

| Objective | Statement | Measure | Business requirements |
|---|---|---|---|
| BO-01 Knowledge preservation | Every imported source is preserved bit-exact and stays traceable. | 100% of stored originals verify against their registered SHA-256 (doctor --deep). | BRD-001 |
| BO-02 Knowledge accessibility and retrieval | The owner finds source-backed evidence in Arabic and English in one step. | Retrieval gate NFR-007 met on the owner-labelled benchmark. | BRD-002, BRD-009, BRD-010 |
| BO-03 Knowledge reliability | Nothing unsupported is promoted to verified; corrections never erase history. | 100% of verified source-evidenced records have resolvable evidence; 0 illegal transitions in suite. | BRD-001, BRD-003 |
| BO-04 Project continuity and decision traceability | A project can be resumed after months from records alone. | As-of reconstruction tests pass; journey J5 accepted by the owner. | BRD-004 |
| BO-05 Controlled automation | Claude Code acts only inside technically enforced permissions. | 0 unauthorised canonical changes in the security suite (NFR-019). | BRD-005, BRD-008, BRD-012 |
| BO-06 Operational resilience | The system survives interruption and restores from backup. | Crash suite passes; a restore-tested backup no older than the approved RPO exists. | BRD-007 |
| BO-07 Portability and longevity | Knowledge is usable without Claude Code, Obsidian or this software. | Export bundle test TEST-KNW-013 passes. | BRD-006, BRD-013 |
| BO-08 Economic sustainability and simplicity | Cost and complexity grow only when measurement justifies it. | Every deferred technology has a numeric adoption gate; dependency limit NFR-011 held. | BRD-011, BRD-014 |

## 2. Business requirement → product feature → requirements

| BRD | Requirement | Priority | Features | Functional and non-functional requirements |
|---|---|---|---|---|
| BRD-001 | Preserve source artifacts and trace every promoted claim to a source location | MUST | PRD-001 | FR-ING-001, FR-ING-002, FR-ING-003, FR-ING-004, FR-ING-005, FR-ING-010, FR-MEM-002, FR-SEC-008, NFR-002, NFR-008 |
| BRD-002 | Search and answer with inspectable evidence | MUST | PRD-002, PRD-004 | FR-ING-008, FR-ING-009, FR-RET-001, FR-RET-002, FR-RET-004, FR-RET-005, FR-RET-007, FR-RET-009, NFR-001, NFR-013 |
| BRD-003 | Maintain corrected and superseded knowledge without erasing history | MUST | PRD-011 | FR-ING-006, FR-ING-011, FR-KNW-002, FR-MEM-001, FR-MEM-004, FR-MEM-005, FR-MEM-006, FR-MEM-007, FR-MEM-008, FR-MEM-009, FR-MEM-010, FR-MEM-011 |
| BRD-004 | Organise project state and decision history | SHOULD | PRD-012, PRD-013, PRD-016 | FR-KNW-006, FR-PRJ-001, FR-PRJ-002, FR-PRJ-003, FR-PRJ-004, FR-PRJ-005 |
| BRD-005 | Propose changes and obtain approval for consequential ones | MUST | PRD-003, PRD-014 | FR-KNW-005, FR-MEM-003, FR-MEM-012, FR-AGT-001, FR-AGT-003, FR-AGT-004, FR-AGT-005, FR-AGT-007, FR-AGT-008, FR-SEC-001, FR-SEC-002, FR-SEC-003, FR-SEC-004, FR-SEC-006, NFR-009, NFR-019 |
| BRD-006 | Operate without Obsidian and without Claude Code for deterministic functions | MUST | PRD-007 | FR-KNW-001, FR-KNW-004, FR-KNW-009, FR-OPS-009, NFR-003, NFR-004, NFR-017, NFR-020 |
| BRD-007 | Recover from interruption and from verified backups | MUST | PRD-015 | FR-AGT-002, FR-OPS-001, FR-OPS-002, FR-OPS-003, FR-OPS-004, FR-OPS-005, FR-OPS-006, FR-OPS-007, FR-OPS-010, NFR-006, NFR-018 |
| BRD-008 | Integrate external applications only through separately approved scopes | COULD | PRD-010 | FR-SEC-007 |
| BRD-009 | Navigate links and dashboards in Obsidian | SHOULD | PRD-005, PRD-006, PRD-008 | FR-KNW-003, FR-KNW-008, FR-OBS-001, FR-OBS-002, NFR-016 |
| BRD-010 | Work Arabic-first and bilingually, right-to-left and left-to-right | MUST | PRD-017 | FR-ING-007, FR-KNW-007, FR-RET-003, FR-OBS-003, NFR-022 |
| BRD-011 | Gate added complexity on measurement | MUST | PRD-009, PRD-019 | FR-RET-006, FR-RET-008, NFR-007, NFR-010, NFR-012, NFR-021 |
| BRD-012 | Keep an audit trail of state changes and denials | MUST | — | FR-AGT-006, FR-SEC-005, FR-OPS-008, NFR-005, NFR-014 |
| BRD-013 | Allow a legacy vault to be imported later without redesign | COULD | PRD-018 | FR-IMP-001, FR-IMP-002, FR-IMP-003 |
| BRD-014 | Keep operating cost bounded and visible | SHOULD | — | NFR-011, NFR-015 |

## 3. Requirement → component → contract → task → test → acceptance

| Requirement | Pri | Objective | BRD | Feature | Component | Interface or data contract | Tasks | Tests | Acceptance criterion (first) | Phase |
|---|---|---|---|---|---|---|---|---|---|---|
| FR-ING-001 Register source artifact | MUST | BO-01 | BRD-001 | PRD-001 | CMP-ING | CLI `ingest`; `SourceRegistry.register`; tables sources, source_versions | TASK-0205 | TEST-ING-001, TEST-ING-002 | Same bytes always yield the same sha256 and never a second source_version row | 2 |
| FR-ING-002 Preserve original bytes immutably | MUST | BO-01 | BRD-001 | PRD-001 | CMP-STO | `OriginalStore.put/verify`; table journal_ops | TASK-0203 | TEST-ING-003, TEST-REC-001, TEST-REC-002, TEST-REC-008 | Stored file hash equals the registered sha256 after every processing step | 2 |
| FR-ING-003 Record extraction version and passage locators | MUST | BO-01 | BRD-001 | PRD-002 | CMP-EXT | `Extractor.extract`; tables extractions, passages | TASK-0207, TASK-0209 | TEST-ING-004, TEST-ING-005 | Every passage locator validates against the locator schema for its media type | 2 |
| FR-ING-004 Detect duplicate content | MUST | BO-01 | BRD-001 | PRD-001 | CMP-ING | `SourceRegistry.register`; UNIQUE(source_versions.sha256) | TASK-0205 | TEST-ING-002, TEST-ING-006 | A renamed copy of a registered file is reported as duplicate | 2 |
| FR-ING-005 Identify format and validate intake | MUST | BO-01 | BRD-001 | PRD-001 | CMP-ING | `intake.inspect`; config `[intake]` | TASK-0204 | TEST-ING-007, TEST-SEC-008 | A file whose extension disagrees with its signature is rejected | 2 |
| FR-ING-006 Register a new version of an existing source | SHOULD | BO-03 | BRD-003 | PRD-001 | CMP-ING | CLI `ingest --new-version-of`; table source_versions | TASK-0205 | TEST-ING-008 | Version numbers are gapless per source | 2 |
| FR-ING-007 Extract text from supported formats | MUST | BO-02 | BRD-010 | PRD-001 | CMP-EXT | `Extractor` protocol; modules extract/*.py | TASK-0207, TASK-0208 | TEST-ING-009, TEST-ING-010, TEST-ING-011 | Arabic fixture text is returned in logical order with presentation forms folded by NFKC only in the index, never in stored passage text | 2 |
| FR-ING-008 Segment extraction into structure-aware passages | MUST | BO-02 | BRD-002 | PRD-002 | CMP-EXT | `segment.segment`; table passages | TASK-0209 | TEST-ING-012 | Concatenating passage text in ordinal order reproduces the extraction text hash | 2 |
| FR-ING-009 Flag sources that yield little or no text | MUST | BO-02 | BRD-002 | PRD-015 | CMP-EXT | extractions.status; `doctor` check DOC-EXT-01 | TASK-0208 | TEST-ING-013 | A scanned-image PDF fixture is registered, preserved and reported as needs_ocr | 2 |
| FR-ING-010 Process the inbox folder | SHOULD | BO-01 | BRD-001 | PRD-001 | CMP-ING | CLI `ingest --inbox`; `inbox.sweep` | TASK-0210 | TEST-ING-014 | A failure on one file does not stop the others | 2 |
| FR-ING-011 Withdraw a source | SHOULD | BO-03 | BRD-003 | PRD-011 | CMP-ING | CLI `sources withdraw`; evidence_links.anchor_state | TASK-0504 | TEST-ING-015, TEST-RET-010 | Withdrawn passages are absent from search within the same run | 5 |
| FR-KNW-001 Validate note schema and unique IDs | MUST | BO-07 | BRD-006 | PRD-006 | CMP-NOT | CLI `validate`; `schemas.validate_note` | TASK-0301 | TEST-KNW-001, TEST-KNW-002 | Each violation names the rule (OBS-Rnn) | 3 |
| FR-KNW-002 Retain competing claims and supersession | MUST | BO-03 | BRD-003 | PRD-011 | CMP-MEM | tables memory_records, relationships | TASK-0503 | TEST-KNW-003, TEST-MEM-006 | A SUPERSEDES cycle is rejected | 5 |
| FR-KNW-003 Generate notes from templates | MUST | BO-02 | BRD-009 | PRD-005 | CMP-NOT | CLI `notes new`; `render.render_note` | TASK-0302 | TEST-KNW-004, TEST-OBS-002 | A generated note passes `validate` unchanged | 3 |
| FR-KNW-004 Synchronise owner edits | MUST | BO-07 | BRD-006 | PRD-006 | CMP-NOT | CLI `notes sync`; tables notes, note_revisions | TASK-0303 | TEST-KNW-005, TEST-KNW-006, TEST-REC-006 | A body edit creates revision n+1 and updates the index | 3 |
| FR-KNW-005 Project managed fields and detect drift | MUST | BO-05 | BRD-005 | PRD-011 | CMP-NOT | `notes.project`; OBSIDIAN-SCHEMAS managed keys | TASK-0303 | TEST-KNW-007, TEST-SEC-006 | Editing `status: verified` by hand never changes a memory state | 3 |
| FR-KNW-006 Maintain typed relationships with evidence and validity | SHOULD | BO-04 | BRD-004 | PRD-016 | CMP-GRF | CLI `relations`; table relationships | TASK-0603 | TEST-KNW-008, TEST-KNW-009 | An edge to an unknown object is rejected by foreign key | 6 |
| FR-KNW-007 Maintain an entity registry with bilingual aliases | SHOULD | BO-02 | BRD-010 | PRD-016 | CMP-GRF | CLI `entities`; tables entities, entity_aliases | TASK-0603 | TEST-KNW-010, TEST-KNW-011 | An Arabic alias and its English form resolve to one entity after an approved merge | 6 |
| FR-KNW-008 Check link integrity | SHOULD | BO-02 | BRD-009 | PRD-006 | CMP-NOT | `links.check`; `validate --links` | TASK-0304 | TEST-KNW-012 | Links are resolved by Obsidian's shortest-path rule and by ID alias | 3 |
| FR-KNW-009 Export a portable bundle | MUST | BO-07 | BRD-006 | PRD-015 | CMP-OPS | CLI `export` | TASK-0902 | TEST-KNW-013 | Every memory statement and its evidence chain can be read from the bundle with a text editor | 9 |
| FR-MEM-001 Enforce the memory state machine | MUST | BO-03 | BRD-003 | PRD-011 | CMP-MEM | `lifecycle.transition`; trigger trg_memory_transition | TASK-0502 | TEST-MEM-001, TEST-MEM-002 | Every transition outside the table is rejected with SB-MEM-001 | 5 |
| FR-MEM-002 Require evidence before verification | MUST | BO-01 | BRD-001 | PRD-011 | CMP-MEM | triggers trg_memory_verify_needs_evidence, trg_memory_verify_not_derived | TASK-0502 | TEST-MEM-003, TEST-MEM-004, TEST-SEC-006 | 100% of verified source-evidenced records resolve to a stored original whose hash verifies | 5 |
| FR-MEM-003 Capture memory candidates as proposals | MUST | BO-05 | BRD-005 | PRD-014 | CMP-MEM | CLI `memory propose`; schema PRP-MEM-1 | TASK-0502 | TEST-MEM-005, TEST-AGT-002 | A candidate with an unknown passage ID is rejected whole | 5 |
| FR-MEM-004 Classify kind and epistemic type | MUST | BO-03 | BRD-003 | PRD-011 | CMP-MEM | memory_records CHECK constraints | TASK-0502 | TEST-MEM-004, TEST-MEM-007 | Changing epistemic type creates a new revision and requires tier 1 approval | 5 |
| FR-MEM-005 Detect conflicts deterministically | MUST | BO-03 | BRD-003 | PRD-011 | CMP-MEM | `conflicts.find` | TASK-0503 | TEST-MEM-006, TEST-MEM-008, TEST-ACC-007 | The dated-deadline fixture (June vs September) is flagged | 5 |
| FR-MEM-006 Supersede while preserving history | MUST | BO-03 | BRD-003 | PRD-011 | CMP-MEM | `lifecycle.supersede` | TASK-0503 | TEST-MEM-006, TEST-MEM-009 | The old statement text is unchanged byte for byte | 5 |
| FR-MEM-007 Correct a memory by revision | MUST | BO-03 | BRD-003 | PRD-011 | CMP-MEM | table memory_revisions | TASK-0502 | TEST-MEM-010, TEST-SEC-006, TEST-ACC-006 | Earlier revisions cannot be updated or deleted (SB-INT-004) | 5 |
| FR-MEM-008 Reconstruct memory as of a date | MUST | BO-03 | BRD-003 | PRD-011 | CMP-MEM | CLI `memory history`; `history.as_of` | TASK-0504 | TEST-MEM-009, TEST-MEM-011 | Both time axes return the expected fixture rows | 5 |
| FR-MEM-009 Archive and delete memory | SHOULD | BO-03 | BRD-003 | PRD-011 | CMP-MEM | CLI `memory purge`; trigger trg_memrev_immutable exception | TASK-0504 | TEST-MEM-012, TEST-RET-010 | After purge no query returns the statement | 5 |
| FR-MEM-010 Schedule revalidation | SHOULD | BO-03 | BRD-003 | PRD-011 | CMP-MEM | CLI `memory review-queue`; config `[freshness]` | TASK-0504 | TEST-MEM-013 | A record past its review date appears in the queue and search labels it outdated | 5 |
| FR-MEM-011 Consolidate duplicates by key | SHOULD | BO-03 | BRD-003 | PRD-011 | CMP-MEM | `conflicts.find_duplicates` | TASK-0503 | TEST-MEM-014 | Records differing in value are never offered for consolidation | 5 |
| FR-MEM-012 Accept owner-attested memory | MUST | BO-05 | BRD-005 | PRD-011 | CMP-MEM | CLI `memory attest` | TASK-0502 | TEST-MEM-015 | Search results show owner-attested records with that label | 5 |
| FR-RET-001 Search with filters | MUST | BO-02 | BRD-002 | PRD-002 | CMP-RET | CLI `search`; `search.search` | TASK-0403 | TEST-RET-001, TEST-RET-002 | Every filter in the contract is exercised by a fixture | 4 |
| FR-RET-002 Return resolvable evidence locators | MUST | BO-02 | BRD-002 | PRD-002 | CMP-RET | `evidence.resolve`; CLI `evidence show` | TASK-0404 | TEST-RET-003, TEST-ING-005 | 100% of returned locators resolve on the fixture corpus | 4 |
| FR-RET-003 Normalise Arabic and English text for indexing and queries | MUST | BO-02 | BRD-010 | PRD-017 | CMP-NRM | `normalize.normalise`; `stem_ar.light_stem`; search_fts columns | TASK-0401 | TEST-RET-004, TEST-RET-005, TEST-RET-006 | The golden table of normalisation pairs passes exactly | 4 |
| FR-RET-004 Rank results deterministically | MUST | BO-02 | BRD-002 | PRD-002 | CMP-RET | `query.rank`; config `[ranking]` | TASK-0403 | TEST-RET-007 | Score components are returned with --explain | 4 |
| FR-RET-005 Classify the retrieval outcome | MUST | BO-02 | BRD-002 | PRD-002 | CMP-RET | `search.classify_outcome` | TASK-0403 | TEST-RET-008, TEST-RET-009, TEST-ACC-003 | Each class is produced by at least one fixture | 4 |
| FR-RET-006 Log queries | SHOULD | BO-08 | BRD-011 | PRD-019 | CMP-RET | table query_log | TASK-0403 | TEST-RET-011 | A failed log write is reported as a warning and the search still returns | 4 |
| FR-RET-007 Maintain the index incrementally and propagate deletions | MUST | BO-02 | BRD-002 | PRD-002 | CMP-RET | `indexer.apply_delta`; tables search_units, search_fts, index_state | TASK-0402 | TEST-RET-010, TEST-REC-003 | After withdrawal or purge the content is unreachable by any query | 4 |
| FR-RET-008 Run the retrieval evaluation harness | MUST | BO-08 | BRD-011 | PRD-019 | CMP-EVL | CLI `eval run`; schema BENCH-1 | TASK-0405 | TEST-RET-012 | Metric functions reproduce hand-computed values on the unit fixture | 4 |
| FR-RET-009 Show evidence for a citation | MUST | BO-02 | BRD-002 | PRD-002 | CMP-RET | CLI `evidence show` | TASK-0404 | TEST-RET-003, TEST-OBS-003 | The original's hash is verified before display | 4 |
| FR-PRJ-001 Reconstruct project state as of a date | SHOULD | BO-04 | BRD-004 | PRD-012 | CMP-PRJ | CLI `projects show --as-of`; `history.replay` | TASK-0601 | TEST-PRJ-001, TEST-PRJ-002 | Replay to 'now' equals the current-state tables exactly | 6 |
| FR-PRJ-002 Register a project | SHOULD | BO-04 | BRD-004 | PRD-012 | CMP-PRJ | CLI `projects new` | TASK-0601 | TEST-PRJ-003 | Arabic project names are accepted with an ASCII slug | 6 |
| FR-PRJ-003 Track milestones, tasks, risks, dependencies, commitments and open questions | SHOULD | BO-04 | BRD-004 | PRD-012 | CMP-PRJ | CLI `projects item`; table project_items | TASK-0601 | TEST-PRJ-004 | A dependency cycle is rejected | 6 |
| FR-PRJ-004 Record decisions with alternatives and evidence | SHOULD | BO-04 | BRD-004 | PRD-013 | CMP-PRJ | CLI `decisions`; table decisions | TASK-0602 | TEST-PRJ-005, TEST-PRJ-006, TEST-ACC-005 | Accepting or superseding a decision is tier 1 | 6 |
| FR-PRJ-005 Produce a cited project status report | SHOULD | BO-04 | BRD-004 | PRD-012 | CMP-PRJ | CLI `projects status --json` | TASK-0601 | TEST-PRJ-007, TEST-ACC-004 | Every line of the report carries the ID of the record it came from | 6 |
| FR-AGT-001 Require approval for consequential writes | MUST | BO-05 | BRD-005 | PRD-003 | CMP-PRP | `approvals.require`; triggers trg_approval_* | TASK-0701 | TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-SEC-006 | Zero canonical changes result from any unapproved tier 1/2 attempt in the security suite | 7 |
| FR-AGT-002 Run idempotent, resumable workflows | MUST | BO-06 | BRD-007 | PRD-014 | CMP-WFL | `runner.run`; tables workflow_runs, journal_ops | TASK-0201 | TEST-AGT-005, TEST-REC-001, TEST-REC-002, TEST-REC-004, TEST-REC-007 | Killing the process at each of the defined crash points and re-running yields exactly one committed result | 2 |
| FR-AGT-003 Manage the proposal lifecycle | MUST | BO-05 | BRD-005 | PRD-003 | CMP-PRP | CLI `proposals`; table proposals | TASK-0501 | TEST-AGT-002, TEST-AGT-006, TEST-AGT-013 | Payload is frozen after validation (SB-AGT-001) | 7 |
| FR-AGT-004 Apply approval tiers and channels | MUST | BO-05 | BRD-005 | PRD-014 | CMP-PRP | `policy.tier_of`; CLI `proposals approve`, `review` | TASK-0701 | TEST-AGT-007, TEST-AGT-008, TEST-SEC-007, TEST-ACC-008 | The tier of each operation matches AGENTIC-ARCHITECTURE §5 exactly | 7 |
| FR-AGT-005 Support dry-run for mutating commands | MUST | BO-05 | BRD-005 | PRD-003 | CMP-CLI | CLI global option | TASK-0201 | TEST-AGT-009 | A before/after hash of the workspace is identical for every mutating command in dry-run | 2 |
| FR-AGT-006 Record execution history | MUST | BO-05 | BRD-012 | PRD-014 | CMP-WFL | CLI `runs`, `proposals list`, `audit tail` | TASK-0702 | TEST-AGT-010 | Every mutating command in the test suite appears in the listing with a terminal state | 7 |
| FR-AGT-007 Install the Claude Code operating workspace | MUST | BO-05 | BRD-005 | PRD-014 | CMP-CCW | CLI `init`, `workspace verify`; workspace_template/ | TASK-0703 | TEST-AGT-011, TEST-SEC-009 | Installed settings contain only keys listed in the contract | 7 |
| FR-AGT-008 Schedule only deterministic jobs | MUST | BO-05 | BRD-005 | PRD-014 | CMP-OPS | `scheduler.render`; ADR-008 | TASK-0902 | TEST-AGT-012 | The generated launchd definitions invoke only allowlisted subcommands | 9 |
| FR-SEC-001 Enforce path restrictions | MUST | BO-05 | BRD-005 | PRD-015 | CMP-SEC | `paths.resolve_in_root` | TASK-0104 | TEST-SEC-001, TEST-SEC-002 | `../` traversal, absolute paths outside roots and symlinks to outside files are all denied | 1 |
| FR-SEC-002 Keep credentials outside the workspace | MUST | BO-05 | BRD-005 | PRD-015 | CMP-CFG | `config.load`; pre-commit secret scan | TASK-0102, TASK-0103 | TEST-SEC-003 | A secret-pattern scan of repo, vault, logs and export fixtures finds nothing | 1 |
| FR-SEC-003 Treat source content as untrusted data | MUST | BO-05 | BRD-005 | PRD-014 | CMP-SEC | CLI output envelope; skills | TASK-0703 | TEST-SEC-004, TEST-SEC-005 | Deterministic code paths are unaffected by any text content (fuzz fixture) | 7 |
| FR-SEC-004 Reject instruction-bearing and configuration files in data areas | MUST | BO-05 | BRD-005 | PRD-015 | CMP-SEC | `paths.is_forbidden_name`; setting claudeMdExcludes | TASK-0104 | TEST-SEC-009, TEST-SEC-010 | An inbox file named CLAUDE.md is rejected | 1 |
| FR-SEC-005 Keep a tamper-evident audit chain | MUST | BO-05 | BRD-012 | PRD-015 | CMP-AUD | `audit.append/verify`; CLI `audit verify` | TASK-0106 | TEST-SEC-011, TEST-SEC-012 | Updates and deletes on audit_events are rejected (SB-INT-001) | 1 |
| FR-SEC-006 Use no network by default | MUST | BO-05 | BRD-005 | PRD-007 | CMP-SEC | settings.json permissions and sandbox.network | TASK-0107 | TEST-SEC-013 | The full test suite passes with networking disabled | 1 |
| FR-SEC-007 Keep integrations off unless approved | MUST | BO-05 | BRD-008 | PRD-010 | CMP-CCW | doctor checks DOC-SEC-03, DOC-SEC-04 | TASK-0902 | TEST-SEC-014 | The operating home contains no .mcp.json | 9 |
| FR-SEC-008 Harden intake against hostile files | MUST | BO-01 | BRD-001 | PRD-001 | CMP-EXT | `extract.run_bounded`; config `[intake]` | TASK-0204 | TEST-SEC-008, TEST-SEC-015 | A decompression-bomb DOCX fixture stops at the limit | 2 |
| FR-OPS-001 Rebuild the search index from canonical data | MUST | BO-06 | BRD-007 | PRD-015 | CMP-RET | CLI `index rebuild` | TASK-0402 | TEST-OPS-001, TEST-OPS-002 | Search results before corruption and after rebuild are identical on the fixture set | 4 |
| FR-OPS-002 Restore-test a backup in isolation | MUST | BO-06 | BRD-007 | PRD-015 | CMP-OPS | CLI `backup restore-test` | TASK-0212 | TEST-OPS-003, TEST-OPS-004 | A corrupted backup fails closed and is never marked verified | 2 |
| FR-OPS-003 Create a consistent backup with manifest | MUST | BO-06 | BRD-007 | PRD-015 | CMP-OPS | CLI `backup create` | TASK-0212 | TEST-OPS-005, TEST-OPS-006 | A backup taken during a concurrent write restores to a state that passes integrity checks | 2 |
| FR-OPS-004 Report system health | MUST | BO-06 | BRD-007 | PRD-015 | CMP-OPS | CLI `doctor`; OPERATIONS check catalogue | TASK-0107 | TEST-OPS-007, TEST-OPS-008, TEST-REC-009 | Each check ID has a fixture that makes it fail | 1 |
| FR-OPS-005 Recover on startup | MUST | BO-06 | BRD-007 | PRD-015 | CMP-JRN | `recovery.reconcile` | TASK-0202 | TEST-REC-001, TEST-REC-002, TEST-REC-004, TEST-REC-005 | Recovery run twice gives the same result as once | 2 |
| FR-OPS-006 Migrate the schema safely | MUST | BO-06 | BRD-007 | PRD-015 | CMP-DB | `migrate.apply`; table schema_migrations | TASK-0105 | TEST-OPS-009, TEST-OPS-010 | A failing migration leaves the schema version unchanged | 1 |
| FR-OPS-007 Schedule maintenance with launchd | SHOULD | BO-06 | BRD-007 | PRD-015 | CMP-OPS | CLI `schedule install\|status\|remove` | TASK-0902 | TEST-OPS-011 | Generated plists validate with `plutil -lint` | 9 |
| FR-OPS-008 Write structured logs without content | MUST | BO-05 | BRD-012 | PRD-015 | CMP-OPS | `logging.configure` | TASK-0103 | TEST-OPS-012 | A log scan after the full suite finds no fixture content strings | 1 |
| FR-OPS-009 Initialise the workspace | MUST | BO-07 | BRD-006 | PRD-015 | CMP-OPS | CLI `init` | TASK-0107 | TEST-OPS-013, TEST-OPS-014 | doctor passes immediately after init | 1 |
| FR-OPS-010 Restore the workspace from a backup | MUST | BO-06 | BRD-007 | PRD-015 | CMP-OPS | CLI `restore` | TASK-0901 | TEST-OPS-015, TEST-ACC-009 | A failed restore leaves the original home in place | 9 |
| FR-OBS-001 Install vault conventions and templates | MUST | BO-02 | BRD-009 | PRD-006 | CMP-NOT | workspace_template/vault/ | TASK-0302 | TEST-OBS-001 | Folder names and templates match OBSIDIAN-SCHEMAS §2 and §4 | 3 |
| FR-OBS-002 Generate dashboards as Markdown | SHOULD | BO-02 | BRD-009 | PRD-015 | CMP-NOT | CLI `dashboards build` | TASK-0604 | TEST-OBS-004 | Dashboards render in a plain Markdown viewer | 6 |
| FR-OBS-003 Handle right-to-left and mixed-direction content | MUST | BO-02 | BRD-010 | PRD-017 | CMP-NOT | `text.bidi`, `text.lang` | TASK-0206, TASK-0302 | TEST-OBS-002, TEST-OBS-003, TEST-OBS-005 | Generated Arabic notes carry `dir: rtl` | 3 |
| FR-IMP-001 Plan a legacy vault import | COULD | BO-07 | BRD-013 | PRD-018 | CMP-IMP | CLI `import plan` (not built before a separate approval) | TASK-1001 | TEST-IMP-001 | The plan run changes nothing in either vault | 10 |
| FR-IMP-002 Commit a legacy vault import | COULD | BO-07 | BRD-013 | PRD-018 | CMP-IMP | CLI `import commit`; created_by_run columns | TASK-1001 | TEST-IMP-002 | Every imported note links to the source version holding its legacy bytes | 10 |
| FR-IMP-003 Roll back an import batch | COULD | BO-07 | BRD-013 | PRD-018 | CMP-IMP | CLI `import rollback` | TASK-1001 | TEST-IMP-003 | Rollback immediately after import restores the pre-import vault hash | 10 |
| NFR-001 Search latency | SHOULD | BO-02 | BRD-002 | — | CMP-RET | Benchmark harness latency percentiles over >= 200 queries; hardware and corpus recorded | TASK-0407 | TEST-NFR-001 | p95 <= 1000 ms, p50 <= 200 ms at profile S2 (1,000 documents, ~50,000 passages), warm cache | 4 |
| NFR-002 Source integrity under interruption | MUST | BO-01 | BRD-001 | — | CMP-STO | Hash of every original before and after each injected crash | TASK-0202, TASK-0211 | TEST-REC-001, TEST-REC-010 | 0 modified or lost originals across the crash-injection suite | 2 |
| NFR-003 Portability | MUST | BO-07 | BRD-006 | — | CMP-OPS | Inspection of export bundle by script that uses no project code | TASK-0902 | TEST-KNW-013 | Export bundle readable with a text editor and the sqlite3 shell; vault is plain Markdown with YAML frontmatter | 9 |
| NFR-004 Offline operation | MUST | BO-07 | BRD-006 | — | CMP-CLI | Test run inside a network-denied sandbox profile | TASK-0107 | TEST-SEC-013 | 100% of the test suite passes with network disabled | 1 |
| NFR-005 Audit completeness | MUST | BO-05 | BRD-012 | — | CMP-AUD | Automated comparison of executed mutating commands with audit rows | TASK-0106 | TEST-AGT-010, TEST-SEC-011 | 100% of mutating commands in the suite produce >= 1 linked audit event | 1 |
| NFR-006 Recovery objectives | SHOULD | BO-06 | BRD-007 | — | CMP-OPS | Timed restore drill; age of newest restore-tested backup | TASK-0901 | TEST-OPS-003, TEST-NFR-006 | RPO 24 h; RTO 4 h at profile S2 | 9 |
| NFR-007 Retrieval quality gate | MUST | BO-08 | BRD-011 | — | CMP-EVL | Evaluation harness on the holdout split of benchmark BENCH-1 (>= 100 questions) | TASK-0406, TASK-0407 | TEST-RET-012, TEST-NFR-007 | Recall@10 >= 0.90 overall (the V5.0 target) and >= 0.85 in each language; citation validity = 1.00; abstention precision >= 0.90 | 4 |
| NFR-008 Ingestion throughput | COULD | BO-01 | BRD-001 | — | CMP-ING | Timed ingestion of the synthetic corpus | TASK-0211 | TEST-NFR-008 | >= 20 documents per minute for documents <= 50 pages at profile S2 | 2 |
| NFR-009 Data egress | MUST | BO-05 | BRD-005 | — | CMP-SEC | Static import check and network-denied test run | TASK-0107 | TEST-SEC-013 | 0 outbound connections from the Python package; egress paths enumerated in SECURITY-ARCHITECTURE §3 | 1 |
| NFR-010 Maintainability | SHOULD | BO-08 | BRD-011 | — | CMP-CLI | CI-equivalent local script `make check` | TASK-0102 | TEST-NFR-010 | mypy --strict clean; ruff clean; line coverage >= 85% on src/second_brain excluding cli/ | 1 |
| NFR-011 Dependency minimalism | MUST | BO-08 | BRD-014 | — | CMP-CLI | Inspection of pyproject.toml and lockfile | TASK-0102 | TEST-NFR-011 | <= 4 runtime packages (proposed: PyYAML, pypdf, python-docx, and at most one more by ADR); lockfile with hashes | 1 |
| NFR-012 Scalability | SHOULD | BO-08 | BRD-011 | — | CMP-RET | Synthetic corpus generator at S2 and S3; latency and size recorded | TASK-0801 | TEST-NFR-012 | S1-S3 (<= 10,000 documents) supported; S4 requires a measured review; S5 out of scope | 8 |
| NFR-013 Usability | SHOULD | BO-02 | BRD-002 | — | CMP-CLI | Acceptance tests and error catalogue inspection | TASK-0705 | TEST-ACC-001, TEST-ACC-002, TEST-NFR-013 | Journeys J1, J2 and J7 complete in <= 2 commands each; every error has a code, a one-line cause and a next step | 7 |
| NFR-014 Observability | SHOULD | BO-05 | BRD-012 | — | CMP-OPS | Timed doctor run; log schema validation | TASK-0103 | TEST-OPS-007, TEST-OPS-012 | `doctor` quick mode <= 30 s at S2; all logs JSON Lines | 1 |
| NFR-015 Cost and token budget | SHOULD | BO-08 | BRD-014 | — | CMP-RET | Payload size check in search; static check for absence of model API clients | TASK-0403 | TEST-NFR-015 | Default search payload <= 6,000 tokens (estimated at 4 characters per token for Latin and 2 for Arabic); no model call from the Python package | 4 |
| NFR-016 Accessibility | SHOULD | BO-02 | BRD-009 | — | CMP-CLI | Inspection and snapshot tests | TASK-0604 | TEST-NFR-016 | No information conveyed by colour alone; CLI honours NO_COLOR; dashboards are plain tables | 6 |
| NFR-017 Availability without Claude Code or Obsidian | MUST | BO-07 | BRD-006 | — | CMP-CLI | Test environment without either application | TASK-0407 | TEST-NFR-017 | All CLI acceptance tests pass on a machine image without Claude Code and without Obsidian | 4 |
| NFR-018 Recoverability | MUST | BO-06 | BRD-007 | — | CMP-JRN | Crash-injection suite with timing | TASK-0202, TASK-0211 | TEST-REC-010 | Recovery <= 60 s for <= 100 pending operations; 0 committed runs lost in the crash suite | 2 |
| NFR-019 Unauthorised writes | MUST | BO-05 | BRD-005 | — | CMP-PRP | Workspace hash before and after each attack scenario | TASK-0701, TASK-0704 | TEST-SEC-006, TEST-SEC-007 | 0 unauthorised canonical changes across the security suite | 7 |
| NFR-020 Platform compatibility | MUST | BO-07 | BRD-006 | — | CMP-OPS | `doctor` environment checks on the target machine | TASK-0101 | TEST-OPS-014 | macOS (version to be recorded at Phase 1); Python >= 3.12; SQLite >= 3.45 with FTS5 and JSON functions | 1 |
| NFR-021 Deterministic rebuild | MUST | BO-08 | BRD-011 | — | CMP-RET | Benchmark diff across rebuild | TASK-0402 | TEST-OPS-001 | Identical ranked results for the benchmark before and after rebuild | 4 |
| NFR-022 Unicode correctness | MUST | BO-02 | BRD-010 | — | CMP-NOT | Validator rule OBS-R14 over fixtures | TASK-0301 | TEST-OBS-002, TEST-KNW-004 | 0 non-NFC paths or IDs; 0 system-inserted override characters | 3 |

## 4. Consistency findings (computed)

- Requirements: 100. Tests: 143. Tasks: 52. Components: 21.
- Requirements without a test: none.
- Tests without a requirement: none.
- MUST requirements without an implementation task: none.
- Requirements of any priority without a task: none.
- Components without a requirement: none.
- Tests not scheduled in any task: none.
- Dangling references found by the generator: 0.

## 5. V5.0 findings

The mapping of the ten V5.0 findings to requirements, components, tests and ADRs is in `docs/specification/V5-COMPLIANCE-MATRIX.md`.
