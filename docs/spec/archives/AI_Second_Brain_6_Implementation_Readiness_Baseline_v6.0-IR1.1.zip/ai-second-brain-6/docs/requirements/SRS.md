# Software Requirements Specification

**DOC-SRS** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `SRS.md` (21 requirements) and `ATOMIC-REQUIREMENTS.md` (16 requirements) of the V6.0 draft; see CHANGE-REGISTER. Generated from `docs/specification/data/requirements.json`; edit the data, not this file.

## 1. Scope and conventions

- 78 functional requirements (58 MUST, 17 SHOULD, 3 COULD) and 22 non-functional requirements (13 MUST, 8 SHOULD, 1 COULD).
- Priority: MUST = required for the phase gate named in `phase`; SHOULD = required for production readiness unless waived by the owner; COULD = specified, not scheduled.
- Every requirement is **PROPOSED** until the owner approves the baseline (TASK-0001). None is implemented.
- Exceptions name error codes from CLI-SPECIFICATION §5. Shared postconditions for every mutating requirement: one workflow run, at least one audit event, no partial canonical change on error (FR-AGT-002, FR-SEC-005).
- Timestamps are UTC ISO 8601; dates are ISO 8601 calendar dates; all stored text is Unicode NFC in logical order.
- Baseline IDs FR-ING-001..003, FR-KNW-001..002, FR-MEM-001..002, FR-RET-001..002, FR-PRJ-001, FR-AGT-001..002, FR-SEC-001..002, FR-OPS-001..002 and NFR-001..006 keep their V6.0 draft meaning. FR-AGT-002 was raised from SHOULD to MUST (CHG-011).

## 2. Functional requirements

### 2.1 FR-ING — Ingestion

#### FR-ING-001 Register source artifact

```yaml
requirement_id: FR-ING-001
title: Register source artifact
priority: MUST
phase: 2
description: >
  The system shall register each imported file as a source version with a unique identifier, SHA-256 checksum, byte size, media type and original filename, inside one workflow run.
rationale: Provenance needs a stable identity for every piece of evidence.
depends_on:
  - FR-OPS-009
  - FR-AGT-002
preconditions:
  - Workspace initialised
  - File exists and is a readable regular file
inputs:
  - source_path
  - optional title, source_date, authority, lang
outputs:
  - source_id
  - source_version_id
  - sha256
  - status (registered|duplicate)
exceptions:
  - E_NOT_FOUND file missing
  - E_FORBIDDEN path outside allowed roots or unreadable
  - E_INVALID_INPUT not a regular file
component: CMP-ING
interface: "CLI `ingest`; `SourceRegistry.register`; tables sources, source_versions"
traces_to: [BRD-001, PRD-001]
verification:
  method: automated_test
  test_ids: [TEST-ING-001, TEST-ING-002]
acceptance:
  - Same bytes always yield the same sha256 and never a second source_version row
  - IDs follow the SRC-/SVR- pattern and are never reused
  - An audit event records actor, correlation ID and outcome
```

#### FR-ING-002 Preserve original bytes immutably

```yaml
requirement_id: FR-ING-002
title: Preserve original bytes immutably
priority: MUST
phase: 2
description: >
  The system shall copy the original bytes to content-addressed storage (`data/originals/<aa>/<sha256>`), set the stored file read-only, and never modify it afterwards.
rationale: Evidence must stay verifiable against the artifact the owner supplied.
depends_on:
  - FR-ING-001
preconditions:
  - Source registered in the same run
  - Free space >= 2 x file size
inputs:
  - source bytes
outputs:
  - stored_relpath
  - verification result
exceptions:
  - E_UNAVAILABLE disk full
  - E_INTEGRITY stored hash differs from computed hash
  - E_CONFLICT different bytes already at the target path
component: CMP-STO
interface: "`OriginalStore.put/verify`; table journal_ops"
traces_to: [BRD-001, PRD-001]
verification:
  method: automated_test
  test_ids: [TEST-ING-003, TEST-REC-001, TEST-REC-002, TEST-REC-008]
acceptance:
  - Stored file hash equals the registered sha256 after every processing step
  - Stored file mode is 0444 and its directory is not writable by sandboxed Claude sessions
  - The source file in the inbox is moved to `01-Inbox/.processed/` only after commit
```

#### FR-ING-003 Record extraction version and passage locators

```yaml
requirement_id: FR-ING-003
title: Record extraction version and passage locators
priority: MUST
phase: 2
description: >
  The system shall record, for every extraction, the extractor name and version, status, text hash and warnings, and for every passage an ordinal and a locator that resolves to a position in the original.
rationale: Citations must survive parser upgrades and remain resolvable.
depends_on:
  - FR-ING-007
  - FR-ING-008
preconditions:
  - Source version present
inputs:
  - source_version_id
  - extractor id and version
outputs:
  - extraction_id
  - passage_count
  - warnings
exceptions:
  - E_UNAVAILABLE extractor not installed
  - E_INVALID_INPUT unsupported media type
  - E_INTEGRITY original hash mismatch before extraction
component: CMP-EXT
interface: "`Extractor.extract`; tables extractions, passages"
traces_to: [BRD-001, PRD-002]
verification:
  method: automated_test
  test_ids: [TEST-ING-004, TEST-ING-005]
acceptance:
  - Every passage locator validates against the locator schema for its media type
  - Re-extraction with a new extractor version creates a new extraction and leaves earlier passages resolvable
  - At most one extraction per source version is active
```

#### FR-ING-004 Detect duplicate content

```yaml
requirement_id: FR-ING-004
title: Detect duplicate content
priority: MUST
phase: 2
description: >
  The system shall detect an import whose SHA-256 equals an existing source version and return the existing identifiers without creating rows or copying bytes.
rationale: Duplicate evidence inflates retrieval results and storage.
depends_on:
  - FR-ING-001
preconditions:
  - At least one source version registered
inputs:
  - source_path
outputs:
  - status=duplicate
  - existing source_id and source_version_id
exceptions:
  - E_INTEGRITY existing stored original fails verification
component: CMP-ING
interface: "`SourceRegistry.register`; UNIQUE(source_versions.sha256)"
traces_to: [BRD-001, PRD-001]
verification:
  method: automated_test
  test_ids: [TEST-ING-002, TEST-ING-006]
acceptance:
  - A renamed copy of a registered file is reported as duplicate
  - Row counts in sources and source_versions are unchanged
  - The duplicate attempt is audited
```

#### FR-ING-005 Identify format and validate intake

```yaml
requirement_id: FR-ING-005
title: Identify format and validate intake
priority: MUST
phase: 2
description: >
  The system shall identify the media type from content signatures (not only the extension), enforce a configurable size limit (default 200 MB) and an allowlist of media types, and reject anything else before any canonical change.
rationale: Untrusted files are the main attack surface; rejection must be side-effect free.
depends_on:
  - FR-SEC-001
preconditions:
  - File readable
inputs:
  - source_path
  - config intake limits
outputs:
  - media_type
  - accept/reject decision with reason
exceptions:
  - E_INVALID_INPUT unsupported or mismatched type, oversize, empty file, archive, encrypted document
component: CMP-ING
interface: "`intake.inspect`; config `[intake]`"
traces_to: [BRD-001, PRD-001]
verification:
  method: automated_test
  test_ids: [TEST-ING-007, TEST-SEC-008]
acceptance:
  - A file whose extension disagrees with its signature is rejected
  - Rejected files leave no rows, no stored bytes and no staging residue
  - Archives are never unpacked automatically
```

#### FR-ING-006 Register a new version of an existing source

```yaml
requirement_id: FR-ING-006
title: Register a new version of an existing source
priority: SHOULD
phase: 2
description: >
  The system shall let the owner register different bytes as the next version of an existing source, keeping all earlier versions and their passages.
rationale: Documents are revised; supersession needs both versions.
depends_on:
  - FR-ING-001
preconditions:
  - Target source exists and is active
inputs:
  - source_path
  - "--new-version-of SOURCE_ID"
outputs:
  - new source_version_id with version_no = previous + 1
exceptions:
  - E_NOT_FOUND unknown source
  - E_CONFLICT identical bytes already registered
component: CMP-ING
interface: "CLI `ingest --new-version-of`; table source_versions"
traces_to: [BRD-003, PRD-001]
verification:
  method: automated_test
  test_ids: [TEST-ING-008]
acceptance:
  - Version numbers are gapless per source
  - Evidence links to the earlier version are untouched and flagged for review
```

#### FR-ING-007 Extract text from supported formats

```yaml
requirement_id: FR-ING-007
title: Extract text from supported formats
priority: MUST
phase: 2
description: >
  The system shall extract text in logical reading order from Markdown, plain text, HTML, DOCX and text-layer PDF, applying Unicode NFC, preserving Arabic and Latin scripts, and recording structure (headings, pages, paragraphs).
rationale: Retrieval quality is bounded by extraction quality, especially for Arabic PDFs.
depends_on:
  - FR-ING-005
preconditions:
  - Media type on the allowlist
  - Extractor available
inputs:
  - source_version_id
outputs:
  - ordered text blocks with structural metadata
exceptions:
  - E_UNAVAILABLE optional dependency missing
  - E_INVALID_INPUT corrupt or password-protected document
component: CMP-EXT
interface: "`Extractor` protocol; modules extract/*.py"
traces_to: [BRD-010, PRD-001]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-ING-009, TEST-ING-010, TEST-ING-011]
acceptance:
  - Arabic fixture text is returned in logical order with presentation forms folded by NFKC only in the index, never in stored passage text
  - Extraction is deterministic for a fixed extractor version
  - A corrupt file yields status failed and no passages
```

#### FR-ING-008 Segment extraction into structure-aware passages

```yaml
requirement_id: FR-ING-008
title: Segment extraction into structure-aware passages
priority: MUST
phase: 2
description: >
  The system shall split extracted text into passages on structural boundaries (heading, page, paragraph), targeting 200-1200 characters with a hard maximum of 2000, without splitting inside a word or a grapheme cluster.
rationale: Passages are the unit of evidence and citation.
depends_on:
  - FR-ING-007
preconditions:
  - Extraction produced text
inputs:
  - text blocks
  - segmentation config
outputs:
  - ordered passages with locators and language tags
exceptions:
  - E_INTEGRITY concatenated passages do not reproduce the extraction text
component: CMP-EXT
interface: "`segment.segment`; table passages"
traces_to: [BRD-002, PRD-002]
verification:
  method: automated_test
  test_ids: [TEST-ING-012]
acceptance:
  - Concatenating passage text in ordinal order reproduces the extraction text hash
  - No passage exceeds 2000 characters
  - Each passage is tagged ar, en, mixed or und by script ratio
```

#### FR-ING-009 Flag sources that yield little or no text

```yaml
requirement_id: FR-ING-009
title: Flag sources that yield little or no text
priority: MUST
phase: 2
description: >
  The system shall mark an extraction `needs_ocr` when a PDF page set yields fewer than a configured number of characters per page, and `partial` when some pages fail, and shall surface both in doctor and in the source note.
rationale: A scanned Arabic PDF silently indexed as empty is a false 'no evidence'.
depends_on:
  - FR-ING-007
preconditions:
  - PDF extraction attempted
inputs:
  - per-page character counts
  - threshold (default 50 chars/page)
outputs:
  - extraction status
  - warnings list
exceptions:
  - none (status, not error)
component: CMP-EXT
interface: "extractions.status; `doctor` check DOC-EXT-01"
traces_to: [BRD-002, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-ING-013]
acceptance:
  - A scanned-image PDF fixture is registered, preserved and reported as needs_ocr
  - It never appears as a searchable passage
  - Search over its topic returns outcome no_evidence with a hint listing un-extracted sources
```

#### FR-ING-010 Process the inbox folder

```yaml
requirement_id: FR-ING-010
title: Process the inbox folder
priority: SHOULD
phase: 2
description: >
  The system shall ingest every regular file in `vault/01-Inbox/` on request, one workflow run per file, moving processed files to `.processed/` and rejected files to `.rejected/` with a reason file.
rationale: Dropping a file into a folder is the lowest-friction capture path from Obsidian and Finder.
depends_on:
  - FR-ING-001
  - FR-ING-005
preconditions:
  - Inbox exists
inputs:
  - inbox path
  - "--dry-run"
outputs:
  - per-file result table
exceptions:
  - E_CONFLICT another inbox sweep holds the writer lock
component: CMP-ING
interface: "CLI `ingest --inbox`; `inbox.sweep`"
traces_to: [BRD-001, PRD-001]
verification:
  method: automated_test
  test_ids: [TEST-ING-014]
acceptance:
  - A failure on one file does not stop the others
  - Dry-run lists actions and changes nothing
  - Symlinks and hidden files are skipped and reported
```

#### FR-ING-011 Withdraw a source

```yaml
requirement_id: FR-ING-011
title: Withdraw a source
priority: SHOULD
phase: 5
description: >
  The system shall let the owner withdraw a source logically: state becomes withdrawn, its passages leave the search index, evidence links are flagged `source_withdrawn`, and dependent verified memories are listed for review; bytes are kept.
rationale: A discredited or mistaken source must stop supporting knowledge without destroying history.
depends_on:
  - FR-AGT-001
  - FR-RET-007
preconditions:
  - Source active
  - Tier 1 approval
inputs:
  - source_id
  - reason
outputs:
  - "impact report: affected evidence links and memory records"
exceptions:
  - E_APPROVAL_REQUIRED
  - E_NOT_FOUND
component: CMP-ING
interface: "CLI `sources withdraw`; evidence_links.anchor_state"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-ING-015, TEST-RET-010]
acceptance:
  - Withdrawn passages are absent from search within the same run
  - Each memory whose only support is withdrawn moves to disputed via proposal
  - Original bytes still verify
```

### 2.2 FR-KNW — Knowledge

#### FR-KNW-001 Validate note schema and unique IDs

```yaml
requirement_id: FR-KNW-001
title: Validate note schema and unique IDs
priority: MUST
phase: 3
description: >
  The system shall validate every vault note against the versioned frontmatter schema for its type and reject duplicate IDs, invalid dates, unknown types and malformed YAML.
rationale: Notes are a canonical store; malformed metadata corrupts every downstream view.
depends_on:
  - FR-OBS-001
preconditions:
  - Vault readable
inputs:
  - note path or scope
outputs:
  - list of violations with file, key, rule ID
exceptions:
  - E_INVALID_INPUT unparsable frontmatter (reported per file, command continues)
component: CMP-NOT
interface: "CLI `validate`; `schemas.validate_note`"
traces_to: [BRD-006, PRD-006]
verification:
  method: automated_test
  test_ids: [TEST-KNW-001, TEST-KNW-002]
acceptance:
  - Each violation names the rule (OBS-Rnn)
  - A note with a duplicate ID is reported on both files
  - Validation is read-only
```

#### FR-KNW-002 Retain competing claims and supersession

```yaml
requirement_id: FR-KNW-002
title: Retain competing claims and supersession
priority: MUST
phase: 5
description: >
  The system shall keep both sides of a contradiction as separate memory records linked by CONTRADICTS or SUPERSEDES relationships, and shall return both to history queries.
rationale: Silent overwrite is how false memory enters a knowledge base.
depends_on:
  - FR-MEM-005
  - FR-KNW-006
preconditions:
  - Two records share subject and predicate
inputs:
  - memory ids
outputs:
  - relationship rows
  - history view
exceptions:
  - E_CONFLICT cycle in SUPERSEDES chain
component: CMP-MEM
interface: "tables memory_records, relationships"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-KNW-003, TEST-MEM-006]
acceptance:
  - A SUPERSEDES cycle is rejected
  - History for the subject lists every version with validity windows
  - No statement text is lost
```

#### FR-KNW-003 Generate notes from templates

```yaml
requirement_id: FR-KNW-003
title: Generate notes from templates
priority: MUST
phase: 3
description: >
  The system shall create source, concept, entity, project, decision and research notes from versioned templates with complete frontmatter, NFC-normalised filenames and a direction hint for Arabic content.
rationale: Consistent notes make validation and Obsidian views dependable.
depends_on:
  - FR-KNW-001
  - FR-OBS-003
preconditions:
  - Template for the type installed
inputs:
  - note type
  - title
  - field values
outputs:
  - note path
  - note_id
exceptions:
  - E_CONFLICT filename exists in the target folder
  - E_INVALID_INPUT title empty or contains path separators or bidi control characters
component: CMP-NOT
interface: "CLI `notes new`; `render.render_note`"
traces_to: [BRD-009, PRD-005]
verification:
  method: automated_test
  test_ids: [TEST-KNW-004, TEST-OBS-002]
acceptance:
  - A generated note passes `validate` unchanged
  - Titles containing Arabic produce valid NFC filenames
  - The notes row and the file are committed through the journal
```

#### FR-KNW-004 Synchronise owner edits

```yaml
requirement_id: FR-KNW-004
title: Synchronise owner edits
priority: MUST
phase: 3
description: >
  The system shall detect notes created, changed, moved or removed outside the CLI by comparing path and content hash with the registry, record a note revision with origin owner_direct, and re-index the note.
rationale: The owner edits freely in Obsidian; the registry must follow, not fight.
depends_on:
  - FR-KNW-001
preconditions:
  - Writer lock available
inputs:
  - vault path
  - "--dry-run"
outputs:
  - "sync report: added, changed, moved, missing, invalid"
exceptions:
  - E_CONFLICT writer lock held
  - E_INVALID_INPUT note fails validation (left unregistered, reported)
component: CMP-NOT
interface: "CLI `notes sync`; tables notes, note_revisions"
traces_to: [BRD-006, PRD-006]
verification:
  method: automated_test
  test_ids: [TEST-KNW-005, TEST-KNW-006, TEST-REC-006]
acceptance:
  - A body edit creates revision n+1 and updates the index
  - A move is detected by ID, not path
  - A removed file marks the note missing and never deletes database history
```

#### FR-KNW-005 Project managed fields and detect drift

```yaml
requirement_id: FR-KNW-005
title: Project managed fields and detect drift
priority: MUST
phase: 3
description: >
  The system shall write governed values (status, evidence, validity) into frontmatter only as projections of SQLite, and shall report as drift any managed key whose file value differs from the database, never adopting the file value.
rationale: Two writable copies of the same fact always diverge; one must be declared the projection.
depends_on:
  - FR-KNW-004
preconditions:
  - Note registered
inputs:
  - note path
outputs:
  - drift findings
  - repaired projection on request
exceptions:
  - E_CONFLICT note body changed since projection was computed
component: CMP-NOT
interface: "`notes.project`; OBSIDIAN-SCHEMAS managed keys"
traces_to: [BRD-005, PRD-011]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-KNW-007, TEST-SEC-006]
acceptance:
  - "Editing `status: verified` by hand never changes a memory state"
  - "`notes sync --repair` restores the projection and records it"
  - Drift is listed by doctor
```

#### FR-KNW-006 Maintain typed relationships with evidence and validity

```yaml
requirement_id: FR-KNW-006
title: Maintain typed relationships with evidence and validity
priority: SHOULD
phase: 6
description: >
  The system shall store typed relationships between registered objects with state, optional validity window and evidence links, starting in state proposed.
rationale: Navigation links are not knowledge; typed edges need provenance.
depends_on:
  - FR-AGT-001
preconditions:
  - Subject and object exist in objects
inputs:
  - subject_id
  - predicate
  - object_id
  - validity
  - evidence passage ids
outputs:
  - relationship_id
exceptions:
  - E_INVALID_INPUT predicate outside vocabulary, self-reference
  - E_CONFLICT live duplicate edge
component: CMP-GRF
interface: "CLI `relations`; table relationships"
traces_to: [BRD-004, PRD-016]
verification:
  method: automated_test
  test_ids: [TEST-KNW-008, TEST-KNW-009]
acceptance:
  - An edge to an unknown object is rejected by foreign key
  - A verified factual edge has at least one supports evidence link
  - Wikilinks never create rows here
```

#### FR-KNW-007 Maintain an entity registry with bilingual aliases

```yaml
requirement_id: FR-KNW-007
title: Maintain an entity registry with bilingual aliases
priority: SHOULD
phase: 6
description: >
  The system shall register entities with a canonical name and any number of Arabic and English aliases, match candidates on normalised alias equality only, and merge entities by proposal while keeping the merged ID resolvable.
rationale: The same person or organisation appears in two scripts; fragmentation breaks retrieval and history.
depends_on:
  - FR-RET-003
  - FR-AGT-001
preconditions:
  - Normaliser available
inputs:
  - entity type
  - canonical name
  - aliases
outputs:
  - entity_id
  - candidate matches
exceptions:
  - E_CONFLICT alias already belongs to another active entity (returned as merge candidate)
component: CMP-GRF
interface: "CLI `entities`; tables entities, entity_aliases"
traces_to: [BRD-010, PRD-016]
verification:
  method: automated_test
  test_ids: [TEST-KNW-010, TEST-KNW-011]
acceptance:
  - An Arabic alias and its English form resolve to one entity after an approved merge
  - No merge happens without approval
  - A merged ID resolves to its successor
```

#### FR-KNW-008 Check link integrity

```yaml
requirement_id: FR-KNW-008
title: Check link integrity
priority: SHOULD
phase: 3
description: >
  The system shall report wikilinks in registered notes that do not resolve to a file or alias in the vault.
rationale: Broken navigation erodes trust in generated notes.
depends_on:
  - FR-KNW-004
preconditions:
  - Vault synced
inputs:
  - scope
outputs:
  - list of unresolved links
exceptions:
  - "none"
component: CMP-NOT
interface: "`links.check`; `validate --links`"
traces_to: [BRD-009, PRD-006]
verification:
  method: automated_test
  test_ids: [TEST-KNW-012]
acceptance:
  - Links are resolved by Obsidian's shortest-path rule and by ID alias
  - Links inside code blocks are ignored
```

#### FR-KNW-009 Export a portable bundle

```yaml
requirement_id: FR-KNW-009
title: Export a portable bundle
priority: MUST
phase: 9
description: >
  The system shall export the vault, a source manifest (ID, sha256, filename, path) and JSON Lines dumps of every canonical table to a directory readable without this software, Claude Code or Obsidian.
rationale: Knowledge must outlive every tool in the stack.
depends_on:
  - FR-OPS-004
preconditions:
  - doctor reports no integrity errors
inputs:
  - destination directory
outputs:
  - bundle with manifest and checksums
exceptions:
  - E_CONFLICT destination not empty
  - E_INTEGRITY
component: CMP-OPS
interface: "CLI `export`"
traces_to: [BRD-006, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-KNW-013]
acceptance:
  - Every memory statement and its evidence chain can be read from the bundle with a text editor
  - Bundle checksums verify
  - Export changes nothing in the workspace
```

### 2.3 FR-MEM — Memory

#### FR-MEM-001 Enforce the memory state machine

```yaml
requirement_id: FR-MEM-001
title: Enforce the memory state machine
priority: MUST
phase: 5
description: >
  The system shall allow only the transitions defined in WORKFLOW-CONTRACTS WF-2 between captured, proposed, verified, disputed, superseded, archived and deleted, in the application and by database trigger.
rationale: State is what distinguishes knowledge from candidate text.
depends_on:
  - FR-OPS-006
preconditions:
  - Record exists
inputs:
  - memory_id
  - target state
  - reason
outputs:
  - new state
  - audit event
exceptions:
  - E_CONFLICT illegal transition
  - E_APPROVAL_REQUIRED
component: CMP-MEM
interface: "`lifecycle.transition`; trigger trg_memory_transition"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-MEM-001, TEST-MEM-002]
acceptance:
  - Every transition outside the table is rejected with SB-MEM-001
  - A rejected transition leaves the row unchanged
  - Each accepted transition emits one audit event
```

#### FR-MEM-002 Require evidence before verification

```yaml
requirement_id: FR-MEM-002
title: Require evidence before verification
priority: MUST
phase: 5
description: >
  The system shall refuse to mark a source-evidenced record verified unless its current revision has at least one supports link to a passage of a present version of an active source, and shall refuse to verify any derived statement.
rationale: Evidence before memory is the governing principle of the system.
depends_on:
  - FR-ING-003
  - FR-MEM-001
preconditions:
  - Record in proposed or disputed
inputs:
  - memory_id
  - evidence passage ids
outputs:
  - state verified
exceptions:
  - E_INTEGRITY missing or unresolvable evidence (SB-MEM-002)
  - E_CONFLICT derived statement (SB-MEM-003)
component: CMP-MEM
interface: "triggers trg_memory_verify_needs_evidence, trg_memory_verify_not_derived"
traces_to: [BRD-001, PRD-011]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-MEM-003, TEST-MEM-004, TEST-SEC-006]
acceptance:
  - 100% of verified source-evidenced records resolve to a stored original whose hash verifies
  - A hypothesis, interpretation or prediction can never reach verified
  - The rule holds when the application layer is bypassed
```

#### FR-MEM-003 Capture memory candidates as proposals

```yaml
requirement_id: FR-MEM-003
title: Capture memory candidates as proposals
priority: MUST
phase: 5
description: >
  The system shall accept memory candidates only as proposals containing statement, kind, epistemic type, attestation and evidence references, and shall create the record in state proposed without approval.
rationale: Claude drafts; the gate decides. Capture must be cheap and harmless.
depends_on:
  - FR-AGT-003
preconditions:
  - Proposal JSON validates against schema PRP-MEM-1
inputs:
  - proposal file
outputs:
  - proposal_id
  - memory_id in state proposed
exceptions:
  - E_INVALID_INPUT schema violation, unknown passage id
component: CMP-MEM
interface: "CLI `memory propose`; schema PRP-MEM-1"
traces_to: [BRD-005, PRD-014]
verification:
  method: automated_test
  test_ids: [TEST-MEM-005, TEST-AGT-002]
acceptance:
  - A candidate with an unknown passage ID is rejected whole
  - Proposed records are excluded from 'verified' search results by default
  - Creation is tier 0
```

#### FR-MEM-004 Classify kind and epistemic type

```yaml
requirement_id: FR-MEM-004
title: Classify kind and epistemic type
priority: MUST
phase: 5
description: >
  The system shall store for each record one kind (semantic, episodic, procedural, decision, project, preference, operational) and one epistemic type (fact, claim, hypothesis, interpretation, preference, decision, prediction), and shall restrict verification to fact, decision and preference.
rationale: "V5.0 finding 3: interpretations must not be promoted to facts."
depends_on:
  - FR-MEM-003
preconditions: []
inputs:
  - kind
  - epistemic_type
outputs:
  - stored classification
exceptions:
  - E_INVALID_INPUT value outside vocabulary
component: CMP-MEM
interface: "memory_records CHECK constraints"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-MEM-004, TEST-MEM-007]
acceptance:
  - Changing epistemic type creates a new revision and requires tier 1 approval
  - A claim attributed to a source is stored as claim with the source as evidence, not as fact
```

#### FR-MEM-005 Detect conflicts deterministically

```yaml
requirement_id: FR-MEM-005
title: Detect conflicts deterministically
priority: MUST
phase: 5
description: >
  The system shall flag as conflict candidates any two non-archived records with the same subject_id and predicate whose validity windows overlap and whose value_json differ, at proposal validation time.
rationale: Contradiction detection must not depend on a model noticing.
depends_on:
  - FR-MEM-003
preconditions:
  - Record has subject_id and predicate
inputs:
  - proposal
outputs:
  - conflict list in validation_json
exceptions:
  - none (finding, not error)
component: CMP-MEM
interface: "`conflicts.find`"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-MEM-006, TEST-MEM-008, TEST-ACC-007]
acceptance:
  - The dated-deadline fixture (June vs September) is flagged
  - Records without subject and predicate are reported as 'not conflict-checkable'
  - Semantic conflict hints from Claude are stored as proposals, never as verdicts
```

#### FR-MEM-006 Supersede while preserving history

```yaml
requirement_id: FR-MEM-006
title: Supersede while preserving history
priority: MUST
phase: 5
description: >
  The system shall supersede a record by setting its state to superseded with a pointer to the successor, closing its validity window, creating a SUPERSEDES relationship and re-indexing both, in one database transaction.
rationale: Current answers change; past answers must stay reconstructable.
depends_on:
  - FR-MEM-001
  - FR-AGT-001
preconditions:
  - Successor verified
  - Tier 1 approval
inputs:
  - old memory_id
  - new memory_id
  - effective date
outputs:
  - updated records
  - relationship_id
exceptions:
  - E_CONFLICT successor not verified, cycle
  - E_APPROVAL_REQUIRED
component: CMP-MEM
interface: "`lifecycle.supersede`"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-MEM-006, TEST-MEM-009]
acceptance:
  - The old statement text is unchanged byte for byte
  - A query as of a date before the effective date returns the old value
  - Default search returns only the successor
```

#### FR-MEM-007 Correct a memory by revision

```yaml
requirement_id: FR-MEM-007
title: Correct a memory by revision
priority: MUST
phase: 5
description: >
  The system shall apply corrections as a new immutable revision with reason, actor and proposal reference, and shall return a corrected verified record to proposed until re-verified.
rationale: A corrected statement has not yet been checked against evidence.
depends_on:
  - FR-MEM-001
preconditions:
  - Record not deleted
inputs:
  - memory_id
  - new statement and value
  - reason
outputs:
  - revision number
exceptions:
  - E_CONFLICT base revision changed since the proposal was created
component: CMP-MEM
interface: "table memory_revisions"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-MEM-010, TEST-SEC-006, TEST-ACC-006]
acceptance:
  - Earlier revisions cannot be updated or deleted (SB-INT-004)
  - Evidence links are per revision and are not inherited silently
```

#### FR-MEM-008 Reconstruct memory as of a date

```yaml
requirement_id: FR-MEM-008
title: Reconstruct memory as of a date
priority: MUST
phase: 5
description: >
  The system shall answer 'what was held true about subject S on date D' from validity windows and 'what did the system record by date D' from recorded_at, as two distinct queries.
rationale: Valid time and transaction time answer different questions.
depends_on:
  - FR-MEM-006
preconditions: []
inputs:
  - subject or memory id
  - "--as-of"
  - "--recorded-by"
outputs:
  - records with revision and validity
exceptions:
  - E_INVALID_INPUT malformed date
component: CMP-MEM
interface: "CLI `memory history`; `history.as_of`"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-MEM-009, TEST-MEM-011]
acceptance:
  - Both time axes return the expected fixture rows
  - Results cite the revision and its evidence
```

#### FR-MEM-009 Archive and delete memory

```yaml
requirement_id: FR-MEM-009
title: Archive and delete memory
priority: SHOULD
phase: 5
description: >
  The system shall archive records (kept, hidden from default search) and shall delete only archived records by tier 2 purge, which blanks statement text, keeps the row shape and tombstone, removes index entries and records backup expiry implications.
rationale: Deletion must be real where requested, and history shape must survive.
depends_on:
  - FR-MEM-001
  - FR-AGT-004
preconditions:
  - Record archived
  - Tier 2 approval
inputs:
  - memory_id
  - reason
outputs:
  - tombstone
  - purge report
exceptions:
  - E_APPROVAL_REQUIRED
  - E_CONFLICT record not archived
component: CMP-MEM
interface: "CLI `memory purge`; trigger trg_memrev_immutable exception"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-MEM-012, TEST-RET-010]
acceptance:
  - After purge no query returns the statement
  - The purge report lists backups that still contain the text and their expiry dates
  - The audit chain still verifies
```

#### FR-MEM-010 Schedule revalidation

```yaml
requirement_id: FR-MEM-010
title: Schedule revalidation
priority: SHOULD
phase: 5
description: >
  The system shall list verified records whose review date has passed, whose evidence anchor is stale or withdrawn, or whose source has a newer version, and shall label them outdated in search results.
rationale: Old facts presented as current are the quiet failure of personal knowledge bases.
depends_on:
  - FR-MEM-002
preconditions: []
inputs:
  - freshness policy from config
outputs:
  - review queue
exceptions:
  - "none"
component: CMP-MEM
interface: "CLI `memory review-queue`; config `[freshness]`"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-MEM-013]
acceptance:
  - A record past its review date appears in the queue and search labels it outdated
  - Nothing changes state without a proposal
```

#### FR-MEM-011 Consolidate duplicates by key

```yaml
requirement_id: FR-MEM-011
title: Consolidate duplicates by key
priority: SHOULD
phase: 5
description: >
  The system shall propose consolidation only for records with identical subject, predicate, value and overlapping validity, merging evidence onto the survivor and archiving the rest; similarity alone never triggers consolidation.
rationale: Merging on resemblance destroys distinctions the evidence supports.
depends_on:
  - FR-MEM-005
preconditions:
  - Duplicate set found
inputs:
  - memory ids
outputs:
  - consolidation proposal
exceptions:
  - "none"
component: CMP-MEM
interface: "`conflicts.find_duplicates`"
traces_to: [BRD-003, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-MEM-014]
acceptance:
  - Records differing in value are never offered for consolidation
  - The survivor carries the union of evidence links
```

#### FR-MEM-012 Accept owner-attested memory

```yaml
requirement_id: FR-MEM-012
title: Accept owner-attested memory
priority: MUST
phase: 5
description: >
  The system shall let the owner record preferences and first-hand statements with attestation owner_attested and no source evidence, verifiable only through a terminal or in-session approval by the owner.
rationale: Not everything the owner knows has a document behind it; the attestation must be explicit.
depends_on:
  - FR-AGT-004
preconditions: []
inputs:
  - statement
  - kind
  - epistemic type
outputs:
  - memory_id
exceptions:
  - E_INVALID_INPUT attestation owner_attested supplied with actor_kind other than owner
component: CMP-MEM
interface: "CLI `memory attest`"
traces_to: [BRD-005, PRD-011]
verification:
  method: automated_test
  test_ids: [TEST-MEM-015]
acceptance:
  - Search results show owner-attested records with that label
  - Claude sessions cannot create owner_attested revisions
```

### 2.4 FR-RET — Retrieval

#### FR-RET-001 Search with filters

```yaml
requirement_id: FR-RET-001
title: Search with filters
priority: MUST
phase: 4
description: >
  The system shall search passages, note sections and memory statements through SQLite FTS5 and filter by unit kind, project, source, language, state, date range and authority.
rationale: Lexical search over evidence is the baseline every later technique must beat.
depends_on:
  - FR-RET-003
  - FR-RET-007
preconditions:
  - Index present and not stale, or --allow-stale given
inputs:
  - query string
  - filters
  - limit (1-100, default 10)
outputs:
  - ranked EvidenceHit list
  - outcome class
exceptions:
  - E_INVALID_INPUT empty query, unknown filter
  - E_UNAVAILABLE index absent
  - E_INTEGRITY index stale
component: CMP-RET
interface: "CLI `search`; `search.search`"
traces_to: [BRD-002, PRD-002]
verification:
  method: automated_test
  test_ids: [TEST-RET-001, TEST-RET-002]
acceptance:
  - Every filter in the contract is exercised by a fixture
  - User text is always passed as quoted FTS5 strings so query syntax cannot be injected
  - Results are identical across two runs on the same index
```

#### FR-RET-002 Return resolvable evidence locators

```yaml
requirement_id: FR-RET-002
title: Return resolvable evidence locators
priority: MUST
phase: 4
description: >
  The system shall return for every hit the source ID, source version, passage ID, locator, excerpt, dates, state and retrieval method, such that the locator resolves to text in the stored original.
rationale: A citation that cannot be opened is not evidence.
depends_on:
  - FR-ING-003
preconditions:
  - Hit refers to a passage, note section or memory
inputs:
  - hit
outputs:
  - EvidenceHit fields per RETRIEVAL-ARCHITECTURE §4
exceptions:
  - E_INTEGRITY locator does not resolve (hit suppressed and reported)
component: CMP-RET
interface: "`evidence.resolve`; CLI `evidence show`"
traces_to: [BRD-002, PRD-002]
verification:
  method: automated_test
  test_ids: [TEST-RET-003, TEST-ING-005]
acceptance:
  - 100% of returned locators resolve on the fixture corpus
  - "Page numbers are never synthesised: formats without pages return null"
  - Excerpts are original text, not normalised text
```

#### FR-RET-003 Normalise Arabic and English text for indexing and queries

```yaml
requirement_id: FR-RET-003
title: Normalise Arabic and English text for indexing and queries
priority: MUST
phase: 4
description: >
  The system shall apply the versioned normaliser (ar-en-1) identically to indexed text and to queries: NFKC, removal of tashkeel, tatweel and bidi controls, folding of alef, alef-maqsura, ta-marbuta and Persian kaf/yeh variants, mapping of Arabic-Indic digits, and case folding; and shall index a light-stemmed Arabic form in a separate column.
rationale: Probe evidence shows raw FTS5 fragments vocalised Arabic and misses letter variants.
depends_on: []
preconditions: []
inputs:
  - text
outputs:
  - text_norm
  - text_stem
exceptions:
  - none (pure function)
component: CMP-NRM
interface: "`normalize.normalise`; `stem_ar.light_stem`; search_fts columns"
traces_to: [BRD-010, PRD-017]
verification:
  method: automated_test
  test_ids: [TEST-RET-004, TEST-RET-005, TEST-RET-006]
acceptance:
  - The golden table of normalisation pairs passes exactly
  - normalise(normalise(x)) equals normalise(x)
  - Stored passage text is never altered by normalisation
  - A norm_version change marks the index stale
```

#### FR-RET-004 Rank results deterministically

```yaml
requirement_id: FR-RET-004
title: Rank results deterministically
priority: MUST
phase: 4
description: >
  The system shall order hits by bm25 over (title, normalised text, stemmed text) with configured weights, then by state rank, source authority and recency, then by unit ID.
rationale: Evaluation is impossible if ranking is not reproducible.
depends_on:
  - FR-RET-001
preconditions: []
inputs:
  - candidate hits
  - ranking config
outputs:
  - ordered hits with score components
exceptions:
  - "none"
component: CMP-RET
interface: "`query.rank`; config `[ranking]`"
traces_to: [BRD-002, PRD-002]
verification:
  method: automated_test
  test_ids: [TEST-RET-007]
acceptance:
  - Score components are returned with --explain
  - Ties never depend on insertion order
  - Weights are configuration, versioned in query_log
```

#### FR-RET-005 Classify the retrieval outcome

```yaml
requirement_id: FR-RET-005
title: Classify the retrieval outcome
priority: MUST
phase: 4
description: >
  The system shall label each search result set as verified_evidence, evidence_unverified, insufficient, contradictory, outdated or no_evidence using the rules in RETRIEVAL-ARCHITECTURE §6.
rationale: Claude must be told when to abstain, in data rather than by judgement.
depends_on:
  - FR-RET-001
preconditions: []
inputs:
  - hits with states and relationships
outputs:
  - outcome_class
  - reasons
exceptions:
  - "none"
component: CMP-RET
interface: "`search.classify_outcome`"
traces_to: [BRD-002, PRD-002]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-RET-008, TEST-RET-009, TEST-ACC-003]
acceptance:
  - Each class is produced by at least one fixture
  - Hits linked by CONTRADICTS among verified records yield contradictory
  - Zero hits yields no_evidence, never an empty success
```

#### FR-RET-006 Log queries

```yaml
requirement_id: FR-RET-006
title: Log queries
priority: SHOULD
phase: 4
description: >
  The system shall record each query, its normalised form, filters, outcome class, top unit IDs, latency and normaliser version, retained for a configurable period (default 180 days).
rationale: The query log is the raw material for the benchmark and for regressions.
depends_on:
  - FR-RET-001
preconditions:
  - Logging enabled in config
inputs:
  - query execution
outputs:
  - query_log row
exceptions:
  - none (logging failure never fails the search)
component: CMP-RET
interface: "table query_log"
traces_to: [BRD-011, PRD-019]
verification:
  method: automated_test
  test_ids: [TEST-RET-011]
acceptance:
  - A failed log write is reported as a warning and the search still returns
  - Retention pruning removes only rows older than the limit
```

#### FR-RET-007 Maintain the index incrementally and propagate deletions

```yaml
requirement_id: FR-RET-007
title: Maintain the index incrementally and propagate deletions
priority: MUST
phase: 4
description: >
  The system shall add, replace and remove index units in the same workflow run as the canonical change, mark the index stale if a run ends before indexing, and exclude withdrawn, purged, superseded-extraction and removed-note units.
rationale: A stale hit to deleted content is a citation to nothing.
depends_on:
  - FR-OPS-001
preconditions:
  - Canonical change committed
inputs:
  - changed object ids
outputs:
  - index delta
  - index_state
exceptions:
  - E_INTEGRITY unit count mismatch after update
component: CMP-RET
interface: "`indexer.apply_delta`; tables search_units, search_fts, index_state"
traces_to: [BRD-002, PRD-002]
verification:
  method: automated_test
  test_ids: [TEST-RET-010, TEST-REC-003]
acceptance:
  - After withdrawal or purge the content is unreachable by any query
  - An interrupted update is detected by doctor and repaired by rebuild
  - Index state records norm_version and last rebuild
```

#### FR-RET-008 Run the retrieval evaluation harness

```yaml
requirement_id: FR-RET-008
title: Run the retrieval evaluation harness
priority: MUST
phase: 4
description: >
  The system shall run a versioned benchmark file of labelled questions against the index and report Recall@5, Recall@10, Precision@5, MRR, nDCG@10, citation validity, abstention precision and latency percentiles, per language and overall.
rationale: "V5.0 finding 10: no complexity without measurement."
depends_on:
  - FR-RET-001
preconditions:
  - Benchmark file validates
inputs:
  - benchmark path
  - index
outputs:
  - metrics report (JSON and Markdown) with corpus and config fingerprints
exceptions:
  - E_INVALID_INPUT benchmark schema violation, gold passage ID unknown
component: CMP-EVL
interface: "CLI `eval run`; schema BENCH-1"
traces_to: [BRD-011, PRD-019]
verification:
  method: automated_test
  test_ids: [TEST-RET-012]
acceptance:
  - Metric functions reproduce hand-computed values on the unit fixture
  - The report records SQLite version, norm_version, corpus hash and benchmark version
  - No metric is reported for a stratum with fewer than 5 questions
```

#### FR-RET-009 Show evidence for a citation

```yaml
requirement_id: FR-RET-009
title: Show evidence for a citation
priority: MUST
phase: 4
description: >
  The system shall print, for a passage ID, the passage text, its locator, the source title and the path of the stored original, with bidi isolation in human output.
rationale: The owner must be able to check any citation in one step.
depends_on:
  - FR-RET-002
preconditions:
  - Passage exists
inputs:
  - passage_id
outputs:
  - passage record
  - original path
exceptions:
  - E_NOT_FOUND
  - E_INTEGRITY original missing or hash mismatch
component: CMP-RET
interface: "CLI `evidence show`"
traces_to: [BRD-002, PRD-002]
verification:
  method: automated_test
  test_ids: [TEST-RET-003, TEST-OBS-003]
acceptance:
  - The original's hash is verified before display
  - Withdrawn sources are shown with a withdrawn banner
```

### 2.5 FR-PRJ — Projects and decisions

#### FR-PRJ-001 Reconstruct project state as of a date

```yaml
requirement_id: FR-PRJ-001
title: Reconstruct project state as of a date
priority: SHOULD
phase: 6
description: >
  The system shall rebuild the state of a project, its items and its decisions at a given date by replaying project_events ordered by effective_at and sequence.
rationale: Resuming a project months later requires what was true then, not only now.
depends_on:
  - FR-PRJ-002
preconditions:
  - Project exists
inputs:
  - project_id
  - "--as-of"
outputs:
  - project snapshot
exceptions:
  - E_NOT_FOUND
  - E_INVALID_INPUT date before project creation
component: CMP-PRJ
interface: "CLI `projects show --as-of`; `history.replay`"
traces_to: [BRD-004, PRD-012]
verification:
  method: automated_test
  test_ids: [TEST-PRJ-001, TEST-PRJ-002]
acceptance:
  - Replay to 'now' equals the current-state tables exactly
  - The three-date fixture returns three distinct correct snapshots
```

#### FR-PRJ-002 Register a project

```yaml
requirement_id: FR-PRJ-002
title: Register a project
priority: SHOULD
phase: 6
description: >
  The system shall create a project with ID, slug, name, state and a project note, and record a created event.
rationale: Projects are the scope for filters, dashboards and continuity.
depends_on:
  - FR-KNW-003
preconditions:
  - Slug unique
inputs:
  - name
  - slug
outputs:
  - project_id
  - note path
exceptions:
  - E_CONFLICT slug exists
  - E_INVALID_INPUT slug not lowercase ASCII
component: CMP-PRJ
interface: "CLI `projects new`"
traces_to: [BRD-004, PRD-012]
verification:
  method: automated_test
  test_ids: [TEST-PRJ-003]
acceptance:
  - Arabic project names are accepted with an ASCII slug
  - Project creation is tier 0
```

#### FR-PRJ-003 Track milestones, tasks, risks, dependencies, commitments and open questions

```yaml
requirement_id: FR-PRJ-003
title: Track milestones, tasks, risks, dependencies, commitments and open questions
priority: SHOULD
phase: 6
description: >
  The system shall record project items of six types (milestone, task, risk, dependency, commitment, open question) with state, optional assignee, optional due date and optional dependency, writing an event for every change.
rationale: Continuity needs the open work and what blocks it.
depends_on:
  - FR-PRJ-002
preconditions:
  - Project exists
inputs:
  - item fields
outputs:
  - item_id
exceptions:
  - E_CONFLICT dependency cycle
  - E_NOT_FOUND
component: CMP-PRJ
interface: "CLI `projects item`; table project_items"
traces_to: [BRD-004, PRD-012]
verification:
  method: automated_test
  test_ids: [TEST-PRJ-004]
acceptance:
  - A dependency cycle is rejected
  - Every state change has exactly one event
```

#### FR-PRJ-004 Record decisions with alternatives and evidence

```yaml
requirement_id: FR-PRJ-004
title: Record decisions with alternatives and evidence
priority: SHOULD
phase: 6
description: >
  The system shall record decisions with title, state, decision date, decider, alternatives and rationale in the decision note, evidence links, and supersession by a later decision.
rationale: A decision without its alternatives and evidence cannot be re-examined.
depends_on:
  - FR-KNW-003
  - FR-AGT-001
preconditions: []
inputs:
  - decision fields
  - evidence passage ids
outputs:
  - decision_id
  - note path
exceptions:
  - E_INVALID_INPUT accepted without decision date
  - E_CONFLICT supersession cycle
component: CMP-PRJ
interface: "CLI `decisions`; table decisions"
traces_to: [BRD-004, PRD-013]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-PRJ-005, TEST-PRJ-006, TEST-ACC-005]
acceptance:
  - Accepting or superseding a decision is tier 1
  - A superseded decision stays readable with a link to its successor
```

#### FR-PRJ-005 Produce a cited project status report

```yaml
requirement_id: FR-PRJ-005
title: Produce a cited project status report
priority: SHOULD
phase: 6
description: >
  The system shall output, for a project, its state, open items, blocked items, overdue items and recent decisions as structured data with object IDs, for Claude to summarise with citations.
rationale: Status must come from records, not from the model's recollection.
depends_on:
  - FR-PRJ-001
preconditions:
  - Project exists
inputs:
  - project_id
outputs:
  - status JSON
exceptions:
  - E_NOT_FOUND
component: CMP-PRJ
interface: "CLI `projects status --json`"
traces_to: [BRD-004, PRD-012]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-PRJ-007, TEST-ACC-004]
acceptance:
  - Every line of the report carries the ID of the record it came from
  - An empty project yields an explicit empty report
```

### 2.6 FR-AGT — Agentic execution

#### FR-AGT-001 Require approval for consequential writes

```yaml
requirement_id: FR-AGT-001
title: Require approval for consequential writes
priority: MUST
phase: 7
description: >
  The system shall apply a tier 1 or tier 2 change only when an unexpired, unconsumed approval exists whose hash equals the proposal payload hash, and shall consume the approval in the same transaction as the change.
rationale: Controlled autonomy means the gate is in code, not in instructions.
depends_on:
  - FR-AGT-003
  - FR-AGT-004
preconditions:
  - Proposal validated
inputs:
  - proposal_id
outputs:
  - applied change
  - consumed approval
exceptions:
  - E_APPROVAL_REQUIRED none, expired, consumed or mismatched approval
  - E_CONFLICT base versions changed
component: CMP-PRP
interface: "`approvals.require`; triggers trg_approval_*"
traces_to: [BRD-005, PRD-003]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-SEC-006]
acceptance:
  - Zero canonical changes result from any unapproved tier 1/2 attempt in the security suite
  - A modified proposal invalidates its approval
  - An approval cannot be replayed
```

#### FR-AGT-002 Run idempotent, resumable workflows

```yaml
requirement_id: FR-AGT-002
title: Run idempotent, resumable workflows
priority: MUST
phase: 2
description: >
  The system shall execute every mutating command as a workflow run with an idempotency key, a persisted state and step, and a journal of file operations, so that re-running after interruption completes or rolls back without duplicate effects.
rationale: "V5.0 finding 7: durable execution must not depend on a Claude session staying alive."
depends_on:
  - FR-OPS-005
preconditions:
  - Database reachable
inputs:
  - command and arguments
outputs:
  - workflow_run_id
  - final state
exceptions:
  - E_CONFLICT same idempotency key in progress
  - E_INTEGRITY journal inconsistent
component: CMP-WFL
interface: "`runner.run`; tables workflow_runs, journal_ops"
traces_to: [BRD-007, PRD-014]
verification:
  method: automated_test
  test_ids: [TEST-AGT-005, TEST-REC-001, TEST-REC-002, TEST-REC-004, TEST-REC-007]
acceptance:
  - Killing the process at each of the defined crash points and re-running yields exactly one committed result
  - A completed key returns the stored result without re-executing
```

#### FR-AGT-003 Manage the proposal lifecycle

```yaml
requirement_id: FR-AGT-003
title: Manage the proposal lifecycle
priority: MUST
phase: 7
description: >
  The system shall validate proposals against their schema, record the versions of every object they depend on, expire them after a configurable period (default 14 days), mark them conflict when a dependency changes before application, refuse creation beyond a configurable number of open proposals (default 200) or of proposals created by one run (default 50), and return the existing proposal when an identical payload is already open.
rationale: A proposal is a diff against a known state; a stale diff must not apply.
depends_on:
  - FR-OPS-006
preconditions: []
inputs:
  - proposal JSON
outputs:
  - proposal_id
  - state
  - validation findings
exceptions:
  - E_INVALID_INPUT schema or reference violation
  - E_UNAVAILABLE open-proposal or per-run limit reached (nothing created
  - the run records the limit and the count)
component: CMP-PRP
interface: "CLI `proposals`; table proposals"
traces_to: [BRD-005, PRD-003]
verification:
  method: automated_test
  test_ids: [TEST-AGT-002, TEST-AGT-006, TEST-AGT-013]
acceptance:
  - Payload is frozen after validation (SB-AGT-001)
  - An expired proposal cannot be approved or applied
  - Rejection leaves canonical data byte-identical
  - At either limit the command fails, creates nothing and reports the limit and the current count
  - A payload identical to an open proposal returns that proposal's ID instead of creating another
  - Expired proposals are kept as records in state expired and are never deleted silently
```

#### FR-AGT-004 Apply approval tiers and channels

```yaml
requirement_id: FR-AGT-004
title: Apply approval tiers and channels
priority: MUST
phase: 7
description: >
  The system shall classify every mutating operation as tier 0 (no approval), tier 1 (owner approval in a Claude Code permission prompt or in a terminal) or tier 2 (owner approval in an interactive terminal with typed confirmation of the proposal hash prefix), and shall refuse tier 2 approval when standard input is not a terminal.
rationale: One approval mechanism for everything is either unsafe or unusable.
depends_on:
  - FR-AGT-001
preconditions:
  - Policy table loaded
inputs:
  - operation type
outputs:
  - tier
  - accepted channels
exceptions:
  - E_FORBIDDEN channel not permitted for tier
  - E_APPROVAL_REQUIRED
component: CMP-PRP
interface: "`policy.tier_of`; CLI `proposals approve`, `review`"
traces_to: [BRD-005, PRD-014]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-AGT-007, TEST-AGT-008, TEST-SEC-007, TEST-ACC-008]
acceptance:
  - The tier of each operation matches AGENTIC-ARCHITECTURE §5 exactly
  - A piped or scripted tier 2 approval is refused
  - The approval row records the channel
```

#### FR-AGT-005 Support dry-run for mutating commands

```yaml
requirement_id: FR-AGT-005
title: Support dry-run for mutating commands
priority: MUST
phase: 2
description: >
  The system shall accept --dry-run on every mutating command and report the planned operations without changing files, database rows or the index.
rationale: The owner and Claude both need to see consequences before causing them.
depends_on: []
preconditions: []
inputs:
  - command with --dry-run
outputs:
  - plan
exceptions:
  - same validation errors as the real command
component: CMP-CLI
interface: "CLI global option"
traces_to: [BRD-005, PRD-003]
verification:
  method: automated_test
  test_ids: [TEST-AGT-009]
acceptance:
  - A before/after hash of the workspace is identical for every mutating command in dry-run
  - "Dry-run output uses the same JSON schema with `dry_run: true`"
```

#### FR-AGT-006 Record execution history

```yaml
requirement_id: FR-AGT-006
title: Record execution history
priority: MUST
phase: 7
description: >
  The system shall let the owner list workflow runs and proposals with state, timestamps, actor kind, error code and correlation ID, and follow a correlation ID through the audit log.
rationale: The owner must be able to see what was proposed, executed, succeeded and failed.
depends_on:
  - FR-SEC-005
preconditions: []
inputs:
  - filters
outputs:
  - run and proposal listings
exceptions:
  - "none"
component: CMP-WFL
interface: "CLI `runs`, `proposals list`, `audit tail`"
traces_to: [BRD-012, PRD-014]
verification:
  method: automated_test
  test_ids: [TEST-AGT-010]
acceptance:
  - Every mutating command in the test suite appears in the listing with a terminal state
  - A correlation ID links command, run, journal and audit rows
```

#### FR-AGT-007 Install the Claude Code operating workspace

```yaml
requirement_id: FR-AGT-007
title: Install the Claude Code operating workspace
priority: MUST
phase: 7
description: >
  The system shall install into the operating home a CLAUDE.md, rules, skills and a project settings file exactly as specified in CLAUDE-CODE-CONTRACTS, and shall verify on doctor that the installed files match their packaged hashes.
rationale: Operating instructions and permission rules are part of the security design and must not drift.
depends_on:
  - FR-OPS-009
preconditions:
  - Operating home initialised
inputs:
  - packaged workspace template
outputs:
  - installed files
  - hash manifest
exceptions:
  - E_CONFLICT locally modified file (reported, not overwritten without --force in a terminal)
component: CMP-CCW
interface: "CLI `init`, `workspace verify`; workspace_template/"
traces_to: [BRD-005, PRD-014]
verification:
  method: automated_test
  test_ids: [TEST-AGT-011, TEST-SEC-009]
acceptance:
  - Installed settings contain only keys listed in the contract
  - A modified settings file is reported by doctor
  - Auto memory is disabled in the operating workspace
```

#### FR-AGT-008 Schedule only deterministic jobs

```yaml
requirement_id: FR-AGT-008
title: Schedule only deterministic jobs
priority: MUST
phase: 9
description: >
  The system shall restrict scheduled execution to deterministic commands (backup, verify, doctor, index check, inbox registration) and shall not start a model session from the scheduler in version 1.
rationale: Unattended model runs on untrusted content are the highest-risk configuration and are not needed for the baseline.
depends_on:
  - FR-OPS-007
preconditions: []
inputs:
  - schedule definition
outputs:
  - launchd job set
exceptions:
  - E_INVALID_INPUT job outside the allowlist
component: CMP-OPS
interface: "`scheduler.render`; ADR-008"
traces_to: [BRD-005, PRD-014]
verification:
  method: automated_test
  test_ids: [TEST-AGT-012]
acceptance:
  - The generated launchd definitions invoke only allowlisted subcommands
  - No scheduled job requires network access
```

### 2.7 FR-SEC — Security

#### FR-SEC-001 Enforce path restrictions

```yaml
requirement_id: FR-SEC-001
title: Enforce path restrictions
priority: MUST
phase: 1
description: >
  The system shall resolve every path argument to its real path, reject paths outside the configured roots, reject symlinks in intake, and open files relative to directory descriptors where the platform allows.
rationale: Path handling is where file tools are most often abused.
depends_on:
  - FR-OPS-009
preconditions:
  - Roots configured
inputs:
  - path argument
outputs:
  - allow or deny
exceptions:
  - E_FORBIDDEN traversal, symlink escape, root mismatch
component: CMP-SEC
interface: "`paths.resolve_in_root`"
traces_to: [BRD-005, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-SEC-001, TEST-SEC-002]
acceptance:
  - "`../` traversal, absolute paths outside roots and symlinks to outside files are all denied"
  - Denials are audited
  - No partial copy remains
```

#### FR-SEC-002 Keep credentials outside the workspace

```yaml
requirement_id: FR-SEC-002
title: Keep credentials outside the workspace
priority: MUST
phase: 1
description: >
  The system shall store no credential in the repository, vault, database, logs or exports; any secret a later integration needs shall be referenced by name and read from the macOS Keychain at use.
rationale: Version 1 needs no secret; the rule prevents the first integration from adding one carelessly.
depends_on: []
preconditions: []
inputs:
  - configuration
  - log records
outputs:
  - secret reference only
exceptions:
  - E_INVALID_INPUT config value matches a secret pattern
component: CMP-CFG
interface: "`config.load`; pre-commit secret scan"
traces_to: [BRD-005, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-SEC-003]
acceptance:
  - A secret-pattern scan of repo, vault, logs and export fixtures finds nothing
  - Config loading rejects inline secrets
```

#### FR-SEC-003 Treat source content as untrusted data

```yaml
requirement_id: FR-SEC-003
title: Treat source content as untrusted data
priority: MUST
phase: 7
description: >
  The system shall never execute, import, evaluate or follow instructions found in source or note content; CLI output that carries source text shall wrap it in explicit data delimiters with a provenance header; operating skills shall instruct Claude to treat delimited text as data.
rationale: Prompt injection through ingested documents is the primary threat to an agent-operated knowledge base.
depends_on:
  - FR-AGT-007
preconditions: []
inputs:
  - source text
outputs:
  - delimited output
exceptions:
  - "none"
component: CMP-SEC
interface: "CLI output envelope; skills"
traces_to: [BRD-005, PRD-014]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-SEC-004, TEST-SEC-005]
acceptance:
  - Deterministic code paths are unaffected by any text content (fuzz fixture)
  - With the injection fixture ingested, no canonical write occurs without an approval
  - Residual risk of semantic manipulation is recorded, not denied
```

#### FR-SEC-004 Reject instruction-bearing and configuration files in data areas

```yaml
requirement_id: FR-SEC-004
title: Reject instruction-bearing and configuration files in data areas
priority: MUST
phase: 1
description: >
  The system shall refuse to create or register, and shall report on validate and doctor, any file named CLAUDE.md, CLAUDE.local.md, AGENTS.md or .mcp.json and any directory named .claude under the vault or data directories.
rationale: Claude Code loads such files from subdirectories on demand as instructions and configuration; inside the vault they would be an injection path.
depends_on:
  - FR-KNW-001
preconditions: []
inputs:
  - file path
outputs:
  - rejection or finding
exceptions:
  - E_FORBIDDEN
component: CMP-SEC
interface: "`paths.is_forbidden_name`; setting claudeMdExcludes"
traces_to: [BRD-005, PRD-015]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-SEC-009, TEST-SEC-010]
acceptance:
  - An inbox file named CLAUDE.md is rejected
  - A hand-placed `.claude/` folder in the vault is reported as critical by doctor
  - The operating settings exclude vault and data instruction files
```

#### FR-SEC-005 Keep a tamper-evident audit chain

```yaml
requirement_id: FR-SEC-005
title: Keep a tamper-evident audit chain
priority: MUST
phase: 1
description: >
  The system shall append one audit event for every state-changing operation and every denial, each carrying the SHA-256 of the previous event, and shall verify the chain on request and in doctor.
rationale: Single-user systems cannot prevent the owner account from editing the log; they can make edits evident.
depends_on:
  - FR-OPS-006
preconditions: []
inputs:
  - operation outcome
outputs:
  - audit event
  - chain verification result
exceptions:
  - E_INTEGRITY chain broken (first bad sequence reported)
component: CMP-AUD
interface: "`audit.append/verify`; CLI `audit verify`"
traces_to: [BRD-012, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-SEC-011, TEST-SEC-012]
acceptance:
  - Updates and deletes on audit_events are rejected (SB-INT-001)
  - Altering any stored event with triggers dropped is detected by verification
  - The chain head is written to each backup manifest
```

#### FR-SEC-006 Use no network by default

```yaml
requirement_id: FR-SEC-006
title: Use no network by default
priority: MUST
phase: 1
description: >
  The system's Python package shall make no outbound network connection in version 1, and the operating Claude Code settings shall deny WebFetch and WebSearch and keep the sandbox network allowlist empty.
rationale: With no egress path, exfiltration and remote content injection are out of reach of the deterministic layer.
depends_on:
  - FR-AGT-007
preconditions: []
inputs: []
outputs: []
exceptions:
  - "none"
component: CMP-SEC
interface: "settings.json permissions and sandbox.network"
traces_to: [BRD-005, PRD-007]
verification:
  method: automated_test
  test_ids: [TEST-SEC-013]
acceptance:
  - The full test suite passes with networking disabled
  - Static check finds no socket, urllib, http or requests import in src/
```

#### FR-SEC-007 Keep integrations off unless approved

```yaml
requirement_id: FR-SEC-007
title: Keep integrations off unless approved
priority: MUST
phase: 9
description: >
  The system shall ship with no MCP server, no Obsidian community plugin and no browser automation, and shall treat the addition of any as a tier 2 configuration change recorded in the ADR register.
rationale: Each integration is new code with the owner's privileges.
depends_on:
  - FR-AGT-004
preconditions: []
inputs: []
outputs:
  - integration inventory
exceptions:
  - "none"
component: CMP-CCW
interface: "doctor checks DOC-SEC-03, DOC-SEC-04"
traces_to: [BRD-008, PRD-010]
verification:
  method: automated_test
  test_ids: [TEST-SEC-014]
acceptance:
  - The operating home contains no .mcp.json
  - doctor reports any enabled community plugin in the vault's .obsidian folder
```

#### FR-SEC-008 Harden intake against hostile files

```yaml
requirement_id: FR-SEC-008
title: Harden intake against hostile files
priority: MUST
phase: 2
description: >
  The system shall bound extraction by time (default 120 s per file) and output size (default 50 MB of text), run extractors without shell invocation, and quarantine files that crash or exceed limits.
rationale: Parsers fail on hostile input; failure must be contained and visible.
depends_on:
  - FR-ING-005
preconditions: []
inputs:
  - source file
outputs:
  - extraction or quarantine record
exceptions:
  - E_UNAVAILABLE limit exceeded (run ends FAILED_TERMINAL, original stays registered)
component: CMP-EXT
interface: "`extract.run_bounded`; config `[intake]`"
traces_to: [BRD-001, PRD-001]
verification:
  method: automated_test
  test_ids: [TEST-SEC-008, TEST-SEC-015]
acceptance:
  - A decompression-bomb DOCX fixture stops at the limit
  - No extractor path builds a shell command
  - The quarantined file is listed by doctor
```

### 2.8 FR-OPS — Operations

#### FR-OPS-001 Rebuild the search index from canonical data

```yaml
requirement_id: FR-OPS-001
title: Rebuild the search index from canonical data
priority: MUST
phase: 4
description: >
  The system shall rebuild search_units and search_fts completely from passages of active extractions, registered note files and current memory revisions, and report unit counts by kind.
rationale: A derived index must be disposable.
depends_on:
  - FR-RET-003
preconditions:
  - Writer lock available
inputs:
  - "--dry-run"
outputs:
  - counts
  - norm_version
  - duration
exceptions:
  - E_CONFLICT lock held
  - E_INTEGRITY canonical inconsistency found during rebuild
component: CMP-RET
interface: "CLI `index rebuild`"
traces_to: [BRD-007, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-OPS-001, TEST-OPS-002]
acceptance:
  - Search results before corruption and after rebuild are identical on the fixture set
  - Rebuild after a norm_version change clears the stale flag
```

#### FR-OPS-002 Restore-test a backup in isolation

```yaml
requirement_id: FR-OPS-002
title: Restore-test a backup in isolation
priority: MUST
phase: 2
description: >
  The system shall restore a chosen backup into a new temporary directory, verify every file against the manifest, run database integrity and foreign-key checks, verify the audit chain and a sample of originals, and only then mark the backup restore_tested.
rationale: A backup is a hypothesis until a restore succeeds.
depends_on:
  - FR-OPS-003
preconditions:
  - Backup exists and is readable
inputs:
  - backup_id
outputs:
  - verification report
exceptions:
  - E_NOT_FOUND
  - E_INTEGRITY any mismatch (backup marked failed)
component: CMP-OPS
interface: "CLI `backup restore-test`"
traces_to: [BRD-007, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-OPS-003, TEST-OPS-004]
acceptance:
  - A corrupted backup fails closed and is never marked verified
  - The live workspace is not touched
  - Report lists counts and hashes
```

#### FR-OPS-003 Create a consistent backup with manifest

```yaml
requirement_id: FR-OPS-003
title: Create a consistent backup with manifest
priority: MUST
phase: 2
description: >
  The system shall produce a backup containing a consistent SQLite snapshot (online backup API), the vault, the originals not already present at the destination, the configuration and a manifest with SHA-256 per file, schema version and audit chain head.
rationale: "V5.0 finding 9: Git is history, not recovery."
depends_on:
  - FR-OPS-004
preconditions:
  - Destination configured and writable
  - Destination outside the workspace
  - Destination on a different physical device from the home
inputs:
  - destination label
outputs:
  - backup_id
  - manifest hash
exceptions:
  - E_UNAVAILABLE destination missing or full
  - E_FORBIDDEN destination inside workspace
component: CMP-OPS
interface: "CLI `backup create`"
traces_to: [BRD-007, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-OPS-005, TEST-OPS-006]
acceptance:
  - A backup taken during a concurrent write restores to a state that passes integrity checks
  - Originals are copied incrementally by hash
  - Manifest verifies
  - "`doctor` fails when the configured destination shares a physical device with the home (DOC-BKP-05)"
```

#### FR-OPS-004 Report system health

```yaml
requirement_id: FR-OPS-004
title: Report system health
priority: MUST
phase: 1
description: >
  The system shall run named checks covering configuration, permissions, SQLite and FTS5 availability, schema version, foreign keys, pending journal operations, index freshness, originals (sampled or full with --deep), drift, forbidden files, workspace file hashes, backup age and restore-test age, and return a machine-readable verdict.
rationale: Health must be one command and one exit code.
depends_on:
  - FR-OPS-009
preconditions: []
inputs:
  - "--deep"
  - "--json"
outputs:
  - per-check status ok, warn, fail
  - overall exit code
exceptions:
  - E_INTEGRITY when any check fails
component: CMP-OPS
interface: "CLI `doctor`; OPERATIONS check catalogue"
traces_to: [BRD-007, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-OPS-007, TEST-OPS-008, TEST-REC-009]
acceptance:
  - Each check ID has a fixture that makes it fail
  - doctor is read-only
  - Quick mode finishes within the NFR-014 budget
```

#### FR-OPS-005 Recover on startup

```yaml
requirement_id: FR-OPS-005
title: Recover on startup
priority: MUST
phase: 2
description: >
  The system shall, before any mutating command, complete or undo every journal operation left in state intent and move unreferenced staged files to quarantine, following the recovery table in DATA-ARCHITECTURE §5.
rationale: Recovery must be automatic, idempotent and conservative.
depends_on:
  - FR-AGT-002
preconditions:
  - Database opens
inputs:
  - pending journal operations
outputs:
  - recovery report
exceptions:
  - E_INTEGRITY state not covered by the recovery table (system enters read-only mode)
component: CMP-JRN
interface: "`recovery.reconcile`"
traces_to: [BRD-007, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-REC-001, TEST-REC-002, TEST-REC-004, TEST-REC-005]
acceptance:
  - Recovery run twice gives the same result as once
  - No original is ever deleted by recovery
  - An uncovered state blocks writes and is reported by doctor
```

#### FR-OPS-006 Migrate the schema safely

```yaml
requirement_id: FR-OPS-006
title: Migrate the schema safely
priority: MUST
phase: 1
description: >
  The system shall apply numbered, checksummed, forward-only migrations inside a transaction after taking a verified pre-migration backup, and shall refuse to run against a database with an unknown or newer schema version.
rationale: Schema change is the most destructive routine operation.
depends_on:
  - FR-OPS-003
preconditions:
  - Tier 2 approval for any migration after 0001
inputs:
  - target version
outputs:
  - applied versions
exceptions:
  - E_CONFLICT checksum of an applied migration differs
  - E_INTEGRITY post-migration foreign-key check fails (transaction rolled back)
component: CMP-DB
interface: "`migrate.apply`; table schema_migrations"
traces_to: [BRD-007, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-OPS-009, TEST-OPS-010]
acceptance:
  - A failing migration leaves the schema version unchanged
  - Rollback path is restore of the pre-migration backup and is exercised by test
```

#### FR-OPS-007 Schedule maintenance with launchd

```yaml
requirement_id: FR-OPS-007
title: Schedule maintenance with launchd
priority: SHOULD
phase: 9
description: >
  The system shall generate and install user-level launchd agents for the daily backup, daily doctor and weekly deep verification, each writing a status file and structured log.
rationale: Maintenance that depends on memory does not happen.
depends_on:
  - FR-AGT-008
preconditions:
  - macOS user session
inputs:
  - schedule configuration
outputs:
  - plist files under ~/Library/LaunchAgents
  - status files
exceptions:
  - E_UNAVAILABLE launchctl failure
component: CMP-OPS
interface: "CLI `schedule install|status|remove`"
traces_to: [BRD-007, PRD-015]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-OPS-011]
acceptance:
  - Generated plists validate with `plutil -lint`
  - A missed run (machine asleep) is caught by backup-age check
```

#### FR-OPS-008 Write structured logs without content

```yaml
requirement_id: FR-OPS-008
title: Write structured logs without content
priority: MUST
phase: 1
description: >
  The system shall write JSON Lines logs with timestamp, level, component, event, correlation ID, workflow run ID, duration and error code, and shall never log source text, note bodies or statement text.
rationale: Logs are copied and shared; they must be safe and greppable.
depends_on: []
preconditions: []
inputs:
  - log events
outputs:
  - log files rotated by size
exceptions:
  - "none"
component: CMP-OPS
interface: "`logging.configure`"
traces_to: [BRD-012, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-OPS-012]
acceptance:
  - A log scan after the full suite finds no fixture content strings
  - Every error log has an error code from the catalogue
```

#### FR-OPS-009 Initialise the workspace

```yaml
requirement_id: FR-OPS-009
title: Initialise the workspace
priority: MUST
phase: 1
description: >
  The system shall create the operating home, vault skeleton, data directories with the specified modes, configuration file, empty database at the current schema and Claude Code workspace files, and shall refuse to initialise a non-empty directory.
rationale: A reproducible start state is the base of every test and every recovery.
depends_on: []
preconditions:
  - Tier 2 (terminal) confirmation
inputs:
  - home path
outputs:
  - manifest of created paths
exceptions:
  - E_CONFLICT directory not empty
  - E_UNAVAILABLE SQLite without FTS5 or below minimum version
component: CMP-OPS
interface: "CLI `init`"
traces_to: [BRD-006, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-OPS-013, TEST-OPS-014]
acceptance:
  - doctor passes immediately after init
  - Running init twice fails without changes
  - Directory modes match DEPLOYMENT-SPECIFICATION §4
```

#### FR-OPS-010 Restore the workspace from a backup

```yaml
requirement_id: FR-OPS-010
title: Restore the workspace from a backup
priority: MUST
phase: 9
description: >
  The system shall restore a restore-tested backup over the operating home only after moving the current home aside, verifying the restored copy, and receiving tier 2 approval; the previous home is kept until the owner removes it.
rationale: Restore is destructive by nature; it must be reversible for one step.
depends_on:
  - FR-OPS-002
preconditions:
  - Backup in state restore_tested
inputs:
  - backup_id
outputs:
  - restored home
  - path of the set-aside copy
exceptions:
  - E_APPROVAL_REQUIRED
  - E_CONFLICT backup not restore-tested
component: CMP-OPS
interface: "CLI `restore`"
traces_to: [BRD-007, PRD-015]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-OPS-015, TEST-ACC-009]
acceptance:
  - A failed restore leaves the original home in place
  - After restore, doctor --deep passes
```

### 2.9 FR-OBS — Obsidian

#### FR-OBS-001 Install vault conventions and templates

```yaml
requirement_id: FR-OBS-001
title: Install vault conventions and templates
priority: MUST
phase: 3
description: >
  The system shall create the vault folder structure, note templates and a minimal `.obsidian` configuration that enables only core plugins and sets no community plugin.
rationale: The vault must open correctly in Obsidian with no manual setup and no third-party code.
depends_on:
  - FR-OPS-009
preconditions: []
inputs: []
outputs:
  - vault skeleton
exceptions:
  - "none"
component: CMP-NOT
interface: "workspace_template/vault/"
traces_to: [BRD-009, PRD-006]
verification:
  method: automated_test
  test_ids: [TEST-OBS-001]
acceptance:
  - Folder names and templates match OBSIDIAN-SCHEMAS §2 and §4
  - "`community-plugins.json` is absent or empty"
```

#### FR-OBS-002 Generate dashboards as Markdown

```yaml
requirement_id: FR-OBS-002
title: Generate dashboards as Markdown
priority: SHOULD
phase: 6
description: >
  The system shall generate dashboard notes (inbox and extraction status, proposal queue, memory review queue, projects, decisions, system health) as plain Markdown tables with wikilinks, regenerated on request and by the daily job.
rationale: Dashboards must work with no plugin and survive without the generator.
depends_on:
  - FR-KNW-005
preconditions: []
inputs: []
outputs:
  - managed notes in 07-Dashboards
exceptions:
  - "none"
component: CMP-NOT
interface: "CLI `dashboards build`"
traces_to: [BRD-009, PRD-015]
verification:
  method: automated_test
  test_ids: [TEST-OBS-004]
acceptance:
  - Dashboards render in a plain Markdown viewer
  - Regeneration is idempotent when nothing changed (same content hash)
```

#### FR-OBS-003 Handle right-to-left and mixed-direction content

```yaml
requirement_id: FR-OBS-003
title: Handle right-to-left and mixed-direction content
priority: MUST
phase: 3
description: >
  The system shall store text in logical order, set `lang` and `dir` properties on generated notes from script detection, keep property keys in ASCII, never insert bidi override characters, and wrap mixed-direction values in isolates only in human-readable CLI output.
rationale: Arabic is the main language; direction errors make notes unreadable and can hide content.
depends_on: []
preconditions: []
inputs:
  - text values
outputs:
  - notes and CLI output
exceptions:
  - E_INVALID_INPUT input containing bidi override characters in a title or identifier field
component: CMP-NOT
interface: "`text.bidi`, `text.lang`"
traces_to: [BRD-010, PRD-017]
verification:
  method: automated_test_plus_manual_or_measured
  test_ids: [TEST-OBS-002, TEST-OBS-003, TEST-OBS-005]
acceptance:
  - "Generated Arabic notes carry `dir: rtl`"
  - JSON output contains no isolate or override characters added by the system
  - Override characters in titles are rejected
```

### 2.10 FR-IMP — Legacy import (future capability)

#### FR-IMP-001 Plan a legacy vault import

```yaml
requirement_id: FR-IMP-001
title: Plan a legacy vault import
priority: COULD
phase: 10
description: >
  The system shall analyse an existing Markdown or Obsidian vault read-only and produce an import plan: notes, attachments, frontmatter keys, wikilinks, duplicates by hash, ID collisions and entity match candidates.
rationale: The owner has no vault today; the capability must exist later without redesign.
depends_on:
  - FR-KNW-001
  - FR-KNW-007
preconditions:
  - Legacy vault path readable
inputs:
  - legacy vault path
outputs:
  - import plan (JSON and Markdown)
exceptions:
  - E_FORBIDDEN path inside the operating home
component: CMP-IMP
interface: "CLI `import plan` (not built before a separate approval)"
traces_to: [BRD-013, PRD-018]
verification:
  method: automated_test
  test_ids: [TEST-IMP-001]
acceptance:
  - The plan run changes nothing in either vault
  - Every legacy file is classified import, skip or conflict with a reason
```

#### FR-IMP-002 Commit a legacy vault import

```yaml
requirement_id: FR-IMP-002
title: Commit a legacy vault import
priority: COULD
phase: 10
description: >
  The system shall import by plan: register every legacy file as a source artifact, create notes with new IDs and origin import, preserve attachments and unknown frontmatter keys, and rewrite wikilinks through a recorded mapping.
rationale: Preserving the legacy bytes as sources makes the import lossless and reversible.
depends_on:
  - FR-IMP-001
  - FR-AGT-004
preconditions:
  - Approved plan (tier 2)
  - Plan hash matches
inputs:
  - import plan
outputs:
  - import batch (workflow run) with mapping table
exceptions:
  - E_CONFLICT legacy vault changed since plan
component: CMP-IMP
interface: "CLI `import commit`; created_by_run columns"
traces_to: [BRD-013, PRD-018]
verification:
  method: automated_test
  test_ids: [TEST-IMP-002]
acceptance:
  - Every imported note links to the source version holding its legacy bytes
  - Wikilinks resolve after import
  - No legacy file is modified
```

#### FR-IMP-003 Roll back an import batch

```yaml
requirement_id: FR-IMP-003
title: Roll back an import batch
priority: COULD
phase: 10
description: >
  The system shall remove every note and withdraw every source created by one import batch that has not since been edited or cited, and list the rest for manual decision.
rationale: A bulk operation needs a bulk undo.
depends_on:
  - FR-IMP-002
preconditions:
  - Tier 2 approval
inputs:
  - import batch ID
outputs:
  - rollback report
exceptions:
  - E_APPROVAL_REQUIRED
component: CMP-IMP
interface: "CLI `import rollback`"
traces_to: [BRD-013, PRD-018]
verification:
  method: automated_test
  test_ids: [TEST-IMP-003]
acceptance:
  - Rollback immediately after import restores the pre-import vault hash
  - Edited or cited items are never removed automatically
```

## 3. Non-functional requirements

Targets marked PROVISIONAL are engineering proposals. None has been measured. A target becomes VALIDATED only when the named test has run on the target machine and the result is recorded under `docs/specification/evidence/`.

| ID | Requirement | Priority | Target | Target status | Measurement | Tests | Phase |
|---|---|---|---|---|---|---|---|
| NFR-001 | **Search latency.** Interactive search shall return within the target on the reference corpus. *Why:* Retrieval is called many times per Claude session. | SHOULD | p95 <= 1000 ms, p50 <= 200 ms at profile S2 (1,000 documents, ~50,000 passages), warm cache | PROVISIONAL | Benchmark harness latency percentiles over >= 200 queries; hardware and corpus recorded | TEST-NFR-001 | 4 |
| NFR-002 | **Source integrity under interruption.** No stored original shall be modified, truncated or lost by any interrupted operation. *Why:* Originals are the root of all provenance. | MUST | 0 modified or lost originals across the crash-injection suite | PROVISIONAL (target fixed; evidence pending implementation) | Hash of every original before and after each injected crash | TEST-REC-001, TEST-REC-010 | 2 |
| NFR-003 | **Portability.** All knowledge shall be readable without this software, Claude Code or Obsidian. *Why:* Principle P08. | MUST | Export bundle readable with a text editor and the sqlite3 shell; vault is plain Markdown with YAML frontmatter | PROVISIONAL | Inspection of export bundle by script that uses no project code | TEST-KNW-013 | 9 |
| NFR-004 | **Offline operation.** Every CLI function shall work with networking disabled. *Why:* Local-first; no hidden dependency on a service. | MUST | 100% of the test suite passes with network disabled | PROVISIONAL | Test run inside a network-denied sandbox profile | TEST-SEC-013 | 1 |
| NFR-005 | **Audit completeness.** Every state-changing operation and every denial shall produce an audit event with actor, actor kind, correlation ID, UTC timestamp and outcome. *Why:* Traceability of who changed what. | MUST | 100% of mutating commands in the suite produce >= 1 linked audit event | PROVISIONAL | Automated comparison of executed mutating commands with audit rows | TEST-AGT-010, TEST-SEC-011 | 1 |
| NFR-006 | **Recovery objectives.** Backups and restore shall meet the recovery point and recovery time objectives. *Why:* V5.0 proposed these values as illustrative; they need owner approval. | SHOULD | RPO 24 h; RTO 4 h at profile S2 | PROVISIONAL (decision D-06) | Timed restore drill; age of newest restore-tested backup | TEST-OPS-003, TEST-NFR-006 | 9 |
| NFR-007 | **Retrieval quality gate.** Baseline retrieval shall meet the quality gate on the labelled benchmark, for Arabic and for English separately. *Why:* The gate decides whether FTS5 is sufficient and whether any advanced technique is justified. | MUST | Recall@10 >= 0.90 overall (the V5.0 target) and >= 0.85 in each language; citation validity = 1.00; abstention precision >= 0.90 | PROVISIONAL (calibrate on the pilot corpus) | Evaluation harness on the holdout split of benchmark BENCH-1 (>= 100 questions) | TEST-RET-012, TEST-NFR-007 | 4 |
| NFR-008 | **Ingestion throughput.** Batch ingestion of text-layer documents shall keep pace with personal use. *Why:* A slow inbox discourages capture. | COULD | >= 20 documents per minute for documents <= 50 pages at profile S2 | PROVISIONAL | Timed ingestion of the synthetic corpus | TEST-NFR-008 | 2 |
| NFR-009 | **Data egress.** The deterministic layer shall send no data off the machine; content reaches Anthropic only as context of a Claude Code session the owner started. *Why:* The owner classifies content as public, but egress paths must still be known and few. | MUST | 0 outbound connections from the Python package; egress paths enumerated in SECURITY-ARCHITECTURE §3 | PROVISIONAL | Static import check and network-denied test run | TEST-SEC-013 | 1 |
| NFR-010 | **Maintainability.** Code shall be typed, linted and covered by tests. *Why:* A personal system is maintained by one person and by Claude Code sessions with no memory of earlier work. | SHOULD | mypy --strict clean; ruff clean; line coverage >= 85% on src/second_brain excluding cli/ | PROVISIONAL | CI-equivalent local script `make check` | TEST-NFR-010 | 1 |
| NFR-011 | **Dependency minimalism.** Runtime third-party dependencies shall be few, pinned and hash-locked. *Why:* Each dependency is supply-chain exposure and upgrade work. | MUST | <= 4 runtime packages (proposed: PyYAML, pypdf, python-docx, and at most one more by ADR); lockfile with hashes | PROVISIONAL (package set to be verified, see D-15 and ADR-017) | Inspection of pyproject.toml and lockfile | TEST-NFR-011 | 1 |
| NFR-012 | **Scalability.** The architecture shall serve profile S3 without structural change and shall define measured thresholds for migration. *Why:* V5.0 required capacity profiles S1-S5. | SHOULD | S1-S3 (<= 10,000 documents) supported; S4 requires a measured review; S5 out of scope | PROVISIONAL (estimates in HLD §9 are unmeasured) | Synthetic corpus generator at S2 and S3; latency and size recorded | TEST-NFR-012 | 8 |
| NFR-013 | **Usability.** Common journeys shall need few commands and errors shall say what to do next. *Why:* The system competes with not bothering. | SHOULD | Journeys J1, J2 and J7 complete in <= 2 commands each; every error has a code, a one-line cause and a next step | PROVISIONAL | Acceptance tests and error catalogue inspection | TEST-ACC-001, TEST-ACC-002, TEST-NFR-013 | 7 |
| NFR-014 | **Observability.** Health shall be quick to check and logs structured. *Why:* Problems must surface before they are needed. | SHOULD | `doctor` quick mode <= 30 s at S2; all logs JSON Lines | PROVISIONAL | Timed doctor run; log schema validation | TEST-OPS-007, TEST-OPS-012 | 1 |
| NFR-015 | **Cost and token budget.** Evidence returned to a Claude session shall be bounded, and model usage shall be observable. *Why:* V5.0 required economic sustainability; unbounded context is the main cost driver. | SHOULD | Default search payload <= 6,000 tokens (estimated at 4 characters per token for Latin and 2 for Arabic); no model call from the Python package | PROVISIONAL (decision D-13) | Payload size check in search; static check for absence of model API clients | TEST-NFR-015 | 4 |
| NFR-016 | **Accessibility.** Notes and CLI output shall be usable without colour, plugins or a mouse. *Why:* Plain Markdown is the accessibility baseline. | SHOULD | No information conveyed by colour alone; CLI honours NO_COLOR; dashboards are plain tables | PROVISIONAL | Inspection and snapshot tests | TEST-NFR-016 | 6 |
| NFR-017 | **Availability without Claude Code or Obsidian.** The CLI shall provide ingest, search, validation, backup and restore when Claude Code and Obsidian are not running or not installed. *Why:* Principle P08 and failure handling in HLD §8. | MUST | All CLI acceptance tests pass on a machine image without Claude Code and without Obsidian | PROVISIONAL | Test environment without either application | TEST-NFR-017 | 4 |
| NFR-018 | **Recoverability.** Startup recovery shall be fast and lose no committed write. *Why:* Recovery runs before every mutating command. | MUST | Recovery <= 60 s for <= 100 pending operations; 0 committed runs lost in the crash suite | PROVISIONAL | Crash-injection suite with timing | TEST-REC-010 | 2 |
| NFR-019 | **Unauthorised writes.** No canonical change shall occur without the approval its tier requires. *Why:* V5.0 success criterion. | MUST | 0 unauthorised canonical changes across the security suite | PROVISIONAL (target fixed; evidence pending implementation) | Workspace hash before and after each attack scenario | TEST-SEC-006, TEST-SEC-007 | 7 |
| NFR-020 | **Platform compatibility.** The system shall run on the owner's macOS installation with a supported Python and SQLite. *Why:* The environment is known to be macOS; versions are not yet verified. | MUST | macOS (version to be recorded at Phase 1); Python >= 3.12; SQLite >= 3.45 with FTS5 and JSON functions | PROVISIONAL (verification item V-01) | `doctor` environment checks on the target machine | TEST-OPS-014 | 1 |
| NFR-021 | **Deterministic rebuild.** Rebuilding derived data from the same canonical data shall produce identical search results. *Why:* Reproducibility is the precondition for evaluation. | MUST | Identical ranked results for the benchmark before and after rebuild | PROVISIONAL | Benchmark diff across rebuild | TEST-OPS-001 | 4 |
| NFR-022 | **Unicode correctness.** Stored identifiers, paths and frontmatter shall be NFC; text shall be stored in logical order; the system shall not introduce bidi override characters. *Why:* Arabic-first content on APFS, Git and Obsidian needs one normal form. | MUST | 0 non-NFC paths or IDs; 0 system-inserted override characters | PROVISIONAL | Validator rule OBS-R14 over fixtures | TEST-OBS-002, TEST-KNW-004 | 3 |

## 4. External interfaces

- Command line: CLI-SPECIFICATION.md (the only write path to canonical stores).
- Files: OBSIDIAN-SCHEMAS.md (vault), DATA-ARCHITECTURE.md §3 (directory layout).
- Database: DATABASE-SCHEMA.md (schema v1).
- Claude Code: CLAUDE-CODE-CONTRACTS.md (instructions, skills, settings).
- No network interface, daemon, or public API exists in version 1 (FR-SEC-006).
