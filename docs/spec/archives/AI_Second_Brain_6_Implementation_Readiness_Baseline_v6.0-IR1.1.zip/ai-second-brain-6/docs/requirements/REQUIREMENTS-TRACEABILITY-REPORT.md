# Requirements Traceability Report

**DOC-RTR** · v6.0-IR1.1 · 2026-11-10 · Status: ASSURANCE REPORT · Owner: Mohammed Alsaleh

Computed from `docs/specification/data/` by `gen_assurance.py`; the same facts are enforced by `tools/spec_lint.py`. TRACEABILITY-MATRIX.md remains the full matrix (objective, feature, component, contract, task, test). This report adds the trace to ADRs and to open decisions (correction C-16) and states what is unresolved.

## 1. Inventory

- Requirements: **100** (78 functional, 22 non-functional). MUST: 71.
- Functional families: FR-AGT 8, FR-IMP 3, FR-ING 11, FR-KNW 9, FR-MEM 12, FR-OBS 3, FR-OPS 10, FR-PRJ 5, FR-RET 9, FR-SEC 8.
- Requirements without a test: 0. MUST requirements without a task: 0. Requirements without an ADR: 0.
- Test cases: 143 designed, 0 executed. Tasks: 52.
- Changed in IR1.1: FR-AGT-003 (proposal limits, GAP-033), FR-OPS-002 and FR-OPS-003 (moved to Phase 2, separate device, GAP-034 and GAP-037). One test added (TEST-AGT-013). The count of requirements is unchanged.
- No requirement is approved. All are PROPOSED until decision D-18 is answered.

## 2. Requirements that depend on an open decision

A requirement listed here has acceptance criteria that could change with the owner's answer.

| Decision | Requirements |
|---|---|
| D-06 | FR-OPS-002, FR-OPS-003, FR-OPS-007, FR-OPS-010, NFR-006 |
| D-07 | FR-ING-010, FR-AGT-007, FR-SEC-001, FR-SEC-004, FR-OPS-009 |
| D-08 | FR-ING-011, FR-MEM-001, FR-MEM-002, FR-MEM-003, FR-MEM-004, FR-MEM-006, FR-MEM-007, FR-MEM-009, FR-MEM-012, FR-PRJ-004, FR-AGT-001, FR-AGT-004, NFR-013, NFR-019 |
| D-09 | FR-ING-003, FR-ING-005, FR-ING-007, FR-ING-009, FR-SEC-008 |
| D-10 | FR-RET-003, FR-RET-005, FR-RET-008, NFR-007 |
| D-11 | FR-SEC-003, FR-SEC-006, FR-SEC-007, NFR-009 |
| D-12 | FR-KNW-009, NFR-003, NFR-017 |
| D-13 | FR-RET-001, NFR-015 |
| D-14 | FR-KNW-001, FR-KNW-003, FR-KNW-005, FR-OBS-001 |
| D-15 | FR-ING-007, NFR-010, NFR-011, NFR-020 |
| D-16 | FR-KNW-004, FR-OBS-001 |
| D-17 | FR-MEM-008, FR-PRJ-001 |
| D-20 | FR-AGT-007, FR-SEC-007, NFR-019 |

52 requirements depend on at least one open decision; 48 depend on none. Every requirement also depends on its ADRs being approved (D-18).

Requirements whose target is provisional: NFR-006 (D-06), NFR-007 (D-10), NFR-015 (D-13). Requirement whose verification needs the Mac: NFR-020 (V-01).

## 3. Requirement to ADR and decision

| Requirement | Title | Priority | Phase | ADRs | Open decisions | Tests | Tasks |
|---|---|---|---|---|---|---|---|
| FR-ING-001 | Register source artifact | MUST | 2 | ADR-004, ADR-016 | — | 2 | TASK-0205 |
| FR-ING-002 | Preserve original bytes immutably | MUST | 2 | ADR-013 | — | 4 | TASK-0203 |
| FR-ING-003 | Record extraction version and passage locators | MUST | 2 | ADR-017 | D-09 | 2 | TASK-0207, TASK-0209 |
| FR-ING-004 | Detect duplicate content | MUST | 2 | ADR-004 | — | 2 | TASK-0205 |
| FR-ING-005 | Identify format and validate intake | MUST | 2 | ADR-017 | D-09 | 2 | TASK-0204 |
| FR-ING-006 | Register a new version of an existing source | SHOULD | 2 | ADR-004, ADR-016 | — | 1 | TASK-0205 |
| FR-ING-007 | Extract text from supported formats | MUST | 2 | ADR-017 | D-09, D-15 | 3 | TASK-0207, TASK-0208 |
| FR-ING-008 | Segment extraction into structure-aware passages | MUST | 2 | ADR-017, ADR-005 | — | 1 | TASK-0209 |
| FR-ING-009 | Flag sources that yield little or no text | MUST | 2 | ADR-017 | D-09 | 1 | TASK-0208 |
| FR-ING-010 | Process the inbox folder | SHOULD | 2 | ADR-014, ADR-008 | D-07 | 1 | TASK-0210 |
| FR-ING-011 | Withdraw a source | SHOULD | 5 | ADR-009, ADR-020 | D-08 | 2 | TASK-0504 |
| FR-KNW-001 | Validate note schema and unique IDs | MUST | 3 | ADR-002, ADR-016 | D-14 | 2 | TASK-0301 |
| FR-KNW-002 | Retain competing claims and supersession | MUST | 5 | ADR-020, ADR-012 | — | 2 | TASK-0503 |
| FR-KNW-003 | Generate notes from templates | MUST | 3 | ADR-002, ADR-003 | D-14 | 2 | TASK-0302 |
| FR-KNW-004 | Synchronise owner edits | MUST | 3 | ADR-002, ADR-012 | D-16 | 3 | TASK-0303 |
| FR-KNW-005 | Project managed fields and detect drift | MUST | 3 | ADR-002, ADR-012 | D-14 | 2 | TASK-0303 |
| FR-KNW-006 | Maintain typed relationships with evidence and validity | SHOULD | 6 | ADR-007, ADR-016 | — | 2 | TASK-0603 |
| FR-KNW-007 | Maintain an entity registry with bilingual aliases | SHOULD | 6 | ADR-007, ADR-016 | — | 2 | TASK-0603 |
| FR-KNW-008 | Check link integrity | SHOULD | 3 | ADR-002 | — | 1 | TASK-0304 |
| FR-KNW-009 | Export a portable bundle | MUST | 9 | ADR-002 | D-12 | 1 | TASK-0902 |
| FR-MEM-001 | Enforce the memory state machine | MUST | 5 | ADR-020, ADR-009 | D-08 | 2 | TASK-0502 |
| FR-MEM-002 | Require evidence before verification | MUST | 5 | ADR-020, ADR-009 | D-08 | 3 | TASK-0502 |
| FR-MEM-003 | Capture memory candidates as proposals | MUST | 5 | ADR-020, ADR-009 | D-08 | 2 | TASK-0502 |
| FR-MEM-004 | Classify kind and epistemic type | MUST | 5 | ADR-020, ADR-009 | D-08 | 2 | TASK-0502 |
| FR-MEM-005 | Detect conflicts deterministically | MUST | 5 | ADR-020 | — | 3 | TASK-0503 |
| FR-MEM-006 | Supersede while preserving history | MUST | 5 | ADR-020, ADR-009 | D-08 | 2 | TASK-0503 |
| FR-MEM-007 | Correct a memory by revision | MUST | 5 | ADR-020, ADR-009 | D-08 | 3 | TASK-0502 |
| FR-MEM-008 | Reconstruct memory as of a date | MUST | 5 | ADR-020 | D-17 | 2 | TASK-0504 |
| FR-MEM-009 | Archive and delete memory | SHOULD | 5 | ADR-020, ADR-009 | D-08 | 2 | TASK-0504 |
| FR-MEM-010 | Schedule revalidation | SHOULD | 5 | ADR-020, ADR-008 | — | 1 | TASK-0504 |
| FR-MEM-011 | Consolidate duplicates by key | SHOULD | 5 | ADR-020 | — | 1 | TASK-0503 |
| FR-MEM-012 | Accept owner-attested memory | MUST | 5 | ADR-020, ADR-009 | D-08 | 1 | TASK-0502 |
| FR-RET-001 | Search with filters | MUST | 4 | ADR-005 | D-13 | 2 | TASK-0403 |
| FR-RET-002 | Return resolvable evidence locators | MUST | 4 | ADR-005, ADR-016 | — | 2 | TASK-0404 |
| FR-RET-003 | Normalise Arabic and English text for indexing and queries | MUST | 4 | ADR-005 | D-10 | 3 | TASK-0401 |
| FR-RET-004 | Rank results deterministically | MUST | 4 | ADR-005 | — | 1 | TASK-0403 |
| FR-RET-005 | Classify the retrieval outcome | MUST | 4 | ADR-005 | D-10 | 3 | TASK-0403 |
| FR-RET-006 | Log queries | SHOULD | 4 | ADR-004 | — | 1 | TASK-0403 |
| FR-RET-007 | Maintain the index incrementally and propagate deletions | MUST | 4 | ADR-005, ADR-013 | — | 2 | TASK-0402 |
| FR-RET-008 | Run the retrieval evaluation harness | MUST | 4 | ADR-005, ADR-006 | D-10 | 1 | TASK-0405 |
| FR-RET-009 | Show evidence for a citation | MUST | 4 | ADR-016 | — | 2 | TASK-0404 |
| FR-PRJ-001 | Reconstruct project state as of a date | SHOULD | 6 | ADR-020 | D-17 | 2 | TASK-0601 |
| FR-PRJ-002 | Register a project | SHOULD | 6 | ADR-004, ADR-016 | — | 1 | TASK-0601 |
| FR-PRJ-003 | Track milestones, tasks, risks, dependencies, commitments and open questions | SHOULD | 6 | ADR-004, ADR-012 | — | 1 | TASK-0601 |
| FR-PRJ-004 | Record decisions with alternatives and evidence | SHOULD | 6 | ADR-020, ADR-012, ADR-009 | D-08 | 3 | TASK-0602 |
| FR-PRJ-005 | Produce a cited project status report | SHOULD | 6 | ADR-012, ADR-016 | — | 2 | TASK-0601 |
| FR-AGT-001 | Require approval for consequential writes | MUST | 7 | ADR-009, ADR-015 | D-08 | 4 | TASK-0701 |
| FR-AGT-002 | Run idempotent, resumable workflows | MUST | 2 | ADR-013, ADR-008 | — | 5 | TASK-0201 |
| FR-AGT-003 | Manage the proposal lifecycle | MUST | 7 | ADR-009 | — | 3 | TASK-0501 |
| FR-AGT-004 | Apply approval tiers and channels | MUST | 7 | ADR-009 | D-08 | 4 | TASK-0701 |
| FR-AGT-005 | Support dry-run for mutating commands | MUST | 2 | ADR-013 | — | 1 | TASK-0201 |
| FR-AGT-006 | Record execution history | MUST | 7 | ADR-009, ADR-004 | — | 1 | TASK-0702 |
| FR-AGT-007 | Install the Claude Code operating workspace | MUST | 7 | ADR-014, ADR-015, ADR-018 | D-07, D-20 | 2 | TASK-0703 |
| FR-AGT-008 | Schedule only deterministic jobs | MUST | 9 | ADR-008 | — | 1 | TASK-0902 |
| FR-SEC-001 | Enforce path restrictions | MUST | 1 | ADR-014, ADR-015 | D-07 | 2 | TASK-0104 |
| FR-SEC-002 | Keep credentials outside the workspace | MUST | 1 | ADR-015 | — | 1 | TASK-0102, TASK-0103 |
| FR-SEC-003 | Treat source content as untrusted data | MUST | 7 | ADR-015, ADR-018 | D-11 | 2 | TASK-0703 |
| FR-SEC-004 | Reject instruction-bearing and configuration files in data areas | MUST | 1 | ADR-014, ADR-015 | D-07 | 2 | TASK-0104 |
| FR-SEC-005 | Keep a tamper-evident audit chain | MUST | 1 | ADR-004, ADR-015 | — | 2 | TASK-0106 |
| FR-SEC-006 | Use no network by default | MUST | 1 | ADR-018, ADR-001 | D-11 | 1 | TASK-0107 |
| FR-SEC-007 | Keep integrations off unless approved | MUST | 9 | ADR-018 | D-11, D-20 | 1 | TASK-0902 |
| FR-SEC-008 | Harden intake against hostile files | MUST | 2 | ADR-017 | D-09 | 2 | TASK-0204 |
| FR-OPS-001 | Rebuild the search index from canonical data | MUST | 4 | ADR-005 | — | 2 | TASK-0402 |
| FR-OPS-002 | Restore-test a backup in isolation | MUST | 2 | ADR-010 | D-06 | 2 | TASK-0212 |
| FR-OPS-003 | Create a consistent backup with manifest | MUST | 2 | ADR-010 | D-06 | 2 | TASK-0212 |
| FR-OPS-004 | Report system health | MUST | 1 | ADR-015 | — | 3 | TASK-0107 |
| FR-OPS-005 | Recover on startup | MUST | 2 | ADR-013 | — | 4 | TASK-0202 |
| FR-OPS-006 | Migrate the schema safely | MUST | 1 | ADR-004 | — | 2 | TASK-0105 |
| FR-OPS-007 | Schedule maintenance with launchd | SHOULD | 9 | ADR-008, ADR-010 | D-06 | 1 | TASK-0902 |
| FR-OPS-008 | Write structured logs without content | MUST | 1 | ADR-015 | — | 1 | TASK-0103 |
| FR-OPS-009 | Initialise the workspace | MUST | 1 | ADR-014 | D-07 | 2 | TASK-0107 |
| FR-OPS-010 | Restore the workspace from a backup | MUST | 9 | ADR-010, ADR-009 | D-06 | 2 | TASK-0901 |
| FR-OBS-001 | Install vault conventions and templates | MUST | 3 | ADR-002, ADR-003 | D-14, D-16 | 1 | TASK-0302 |
| FR-OBS-002 | Generate dashboards as Markdown | SHOULD | 6 | ADR-003, ADR-012 | — | 1 | TASK-0604 |
| FR-OBS-003 | Handle right-to-left and mixed-direction content | MUST | 3 | ADR-002, ADR-003 | — | 3 | TASK-0206, TASK-0302 |
| FR-IMP-001 | Plan a legacy vault import | COULD | 10 | ADR-019 | — | 1 | TASK-1001 |
| FR-IMP-002 | Commit a legacy vault import | COULD | 10 | ADR-019 | — | 1 | TASK-1001 |
| FR-IMP-003 | Roll back an import batch | COULD | 10 | ADR-019 | — | 1 | TASK-1001 |
| NFR-001 | Search latency | SHOULD | 4 | ADR-005 | — | 1 | TASK-0407 |
| NFR-002 | Source integrity under interruption | MUST | 2 | ADR-013 | — | 2 | TASK-0202, TASK-0211 |
| NFR-003 | Portability | MUST | 9 | ADR-002 | D-12 | 1 | TASK-0902 |
| NFR-004 | Offline operation | MUST | 1 | ADR-001, ADR-018 | — | 1 | TASK-0107 |
| NFR-005 | Audit completeness | MUST | 1 | ADR-015 | — | 2 | TASK-0106 |
| NFR-006 | Recovery objectives | SHOULD | 9 | ADR-010 | D-06 | 2 | TASK-0901 |
| NFR-007 | Retrieval quality gate | MUST | 4 | ADR-005 | D-10 | 2 | TASK-0406, TASK-0407 |
| NFR-008 | Ingestion throughput | COULD | 2 | ADR-017 | — | 1 | TASK-0211 |
| NFR-009 | Data egress | MUST | 1 | ADR-018 | D-11 | 1 | TASK-0107 |
| NFR-010 | Maintainability | SHOULD | 1 | ADR-011 | D-15 | 1 | TASK-0102 |
| NFR-011 | Dependency minimalism | MUST | 1 | ADR-017, ADR-011 | D-15 | 1 | TASK-0102 |
| NFR-012 | Scalability | SHOULD | 8 | ADR-004, ADR-006 | — | 1 | TASK-0801 |
| NFR-013 | Usability | SHOULD | 7 | ADR-009 | D-08 | 3 | TASK-0705 |
| NFR-014 | Observability | SHOULD | 1 | ADR-015 | — | 2 | TASK-0103 |
| NFR-015 | Cost and token budget | SHOULD | 4 | ADR-001 | D-13 | 1 | TASK-0403 |
| NFR-016 | Accessibility | SHOULD | 6 | ADR-003 | — | 1 | TASK-0604 |
| NFR-017 | Availability without Claude Code or Obsidian | MUST | 4 | ADR-003, ADR-008 | D-12 | 1 | TASK-0407 |
| NFR-018 | Recoverability | MUST | 2 | ADR-013 | — | 1 | TASK-0202, TASK-0211 |
| NFR-019 | Unauthorised writes | MUST | 7 | ADR-015, ADR-009 | D-08, D-20 | 2 | TASK-0701, TASK-0704 |
| NFR-020 | Platform compatibility | MUST | 1 | ADR-004 | D-15 | 1 | TASK-0101 |
| NFR-021 | Deterministic rebuild | MUST | 4 | ADR-005 | — | 1 | TASK-0402 |
| NFR-022 | Unicode correctness | MUST | 3 | ADR-002, ADR-005 | — | 2 | TASK-0301 |

## 4. ADR to requirements

| ADR | Requirements governed |
|---|---|
| ADR-001 | 3: FR-SEC-006, NFR-004, NFR-015 |
| ADR-002 | 10: FR-KNW-001, FR-KNW-003, FR-KNW-004, FR-KNW-005, FR-KNW-008, FR-KNW-009, FR-OBS-001, FR-OBS-003, NFR-003, NFR-022 |
| ADR-003 | 6: FR-KNW-003, FR-OBS-001, FR-OBS-002, FR-OBS-003, NFR-016, NFR-017 |
| ADR-004 | 11: FR-AGT-006, FR-ING-001, FR-ING-004, FR-ING-006, FR-OPS-006, FR-PRJ-002, FR-PRJ-003, FR-RET-006, FR-SEC-005, NFR-012, NFR-020 |
| ADR-005 | 13: FR-ING-008, FR-OPS-001, FR-RET-001, FR-RET-002, FR-RET-003, FR-RET-004, FR-RET-005, FR-RET-007, FR-RET-008, NFR-001, NFR-007, NFR-021, NFR-022 |
| ADR-006 | 2: FR-RET-008, NFR-012 |
| ADR-007 | 2: FR-KNW-006, FR-KNW-007 |
| ADR-008 | 6: FR-AGT-002, FR-AGT-008, FR-ING-010, FR-MEM-010, FR-OPS-007, NFR-017 |
| ADR-009 | 17: FR-AGT-001, FR-AGT-003, FR-AGT-004, FR-AGT-006, FR-ING-011, FR-MEM-001, FR-MEM-002, FR-MEM-003, FR-MEM-004, FR-MEM-006, FR-MEM-007, FR-MEM-009, FR-MEM-012, FR-OPS-010, FR-PRJ-004, NFR-013, NFR-019 |
| ADR-010 | 5: FR-OPS-002, FR-OPS-003, FR-OPS-007, FR-OPS-010, NFR-006 |
| ADR-011 | 2: NFR-010, NFR-011 |
| ADR-012 | 7: FR-KNW-002, FR-KNW-004, FR-KNW-005, FR-OBS-002, FR-PRJ-003, FR-PRJ-004, FR-PRJ-005 |
| ADR-013 | 7: FR-AGT-002, FR-AGT-005, FR-ING-002, FR-OPS-005, FR-RET-007, NFR-002, NFR-018 |
| ADR-014 | 5: FR-AGT-007, FR-ING-010, FR-OPS-009, FR-SEC-001, FR-SEC-004 |
| ADR-015 | 12: FR-AGT-001, FR-AGT-007, FR-OPS-004, FR-OPS-008, FR-SEC-001, FR-SEC-002, FR-SEC-003, FR-SEC-004, FR-SEC-005, NFR-005, NFR-014, NFR-019 |
| ADR-016 | 9: FR-ING-001, FR-ING-006, FR-KNW-001, FR-KNW-006, FR-KNW-007, FR-PRJ-002, FR-PRJ-005, FR-RET-002, FR-RET-009 |
| ADR-017 | 8: FR-ING-003, FR-ING-005, FR-ING-007, FR-ING-008, FR-ING-009, FR-SEC-008, NFR-008, NFR-011 |
| ADR-018 | 6: FR-AGT-007, FR-SEC-003, FR-SEC-006, FR-SEC-007, NFR-004, NFR-009 |
| ADR-019 | 3: FR-IMP-001, FR-IMP-002, FR-IMP-003 |
| ADR-020 | 16: FR-ING-011, FR-KNW-002, FR-MEM-001, FR-MEM-002, FR-MEM-003, FR-MEM-004, FR-MEM-005, FR-MEM-006, FR-MEM-007, FR-MEM-008, FR-MEM-009, FR-MEM-010, FR-MEM-011, FR-MEM-012, FR-PRJ-001, FR-PRJ-004 |

## 5. Unresolved

- Owner approval of the baseline (D-18) and of the decisions in §2.
- Amendments held for the owner's answers (DECISIONS-FOR-APPROVAL section I); AM-05 would add one requirement and one test.
- No test has been executed; traceability is of design, not of results.
