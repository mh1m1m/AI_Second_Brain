# Product Requirements Document

**DOC-PRD** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `PRD.md` v0.1 of the V6.0 draft. Feature IDs PRD-001..010 keep their meaning; PRD-011..019 are new (CHG-002).

## 1. Vision and user

A Second Brain the owner can trust because every answer can be checked. One user: the owner, Arabic-first and bilingual, comfortable with a terminal and Obsidian, working on one Mac. There is no second persona; 'reviewer' and 'administrator' in the draft were the same person in different moments.

## 2. Product experiences and where they live

| Experience | In Claude Code (conversation) | In Obsidian (reading and editing) | In a terminal (CLI directly) |
|---|---|---|---|
| Knowledge Inbox | 'Process the inbox' | Drop files into `01-Inbox`; read source notes | `ingest` |
| Knowledge Explorer | Ask about entities and relationships | Concept and entity notes, backlinks, graph view (navigation only) | `entities`, `relations` |
| Evidence Search | Ask questions; get cited answers | Follow links from answers to source notes | `search`, `evidence show` |
| Memory Manager | 'Propose what this source establishes'; 'correct …' | Memory digests; proposal notes | `memory …` |
| Project Workspace | 'Resume project …' | Project notes with managed status and items | `projects …` |
| Decision Register | 'Record this decision' | Decision notes | `decisions …` |
| Agentic Task Center | Approve tier 1 at the permission prompt | Proposal notes; queue dashboard | `review`, `proposals …`, `runs` |
| System Health | 'Is everything healthy?' | Health dashboard | `doctor`, `backup …` |

No custom web or desktop application is built. The three surfaces above cover every requirement; a fourth would add a codebase, a security surface and maintenance for no requirement that needs it.

## 3. Features

| ID | Feature | Priority | User problem | Product behaviour | Interaction | Functional requirements | Failure states | Acceptance |
|---|---|---|---|---|---|---|---|---|
| PRD-001 | Knowledge Inbox: import with duplicate warning | Must | Documents pile up unprocessed; duplicates and unreadable files go unnoticed | Owner drops a file into `01-Inbox` or names a path. The system registers, preserves and extracts it, creates a source note, and reports duplicates, rejections and files needing OCR | Obsidian folder; `ingest`; skill `ingest-document` | FR-ING-001, FR-ING-002, FR-ING-004, FR-ING-005, FR-ING-006, FR-ING-007, FR-ING-010, FR-SEC-008 | Rejected file moved to `.rejected` with a reason; partial extraction flagged; nothing lost | Acceptance criteria of the listed requirements |
| PRD-002 | Evidence Search with file and section locators | Must | Search returns files, not the passage, and cannot be trusted | Search returns ranked passages, note sections and memory records with source, location, dates, state and an outcome class | `search`, `evidence show`; skill `answer-with-evidence` | FR-ING-003, FR-ING-008, FR-RET-001, FR-RET-002, FR-RET-004, FR-RET-005, FR-RET-007, FR-RET-009 | No evidence; stale index; unresolved locator suppressed and reported | Acceptance criteria of the listed requirements |
| PRD-003 | Proposal review with diff | Must | Changes proposed by an assistant are hard to inspect | Each proposal has a note showing what changes, the before and after, the evidence beside the statement, conflicts found, its tier and the exact approval command | Proposal notes in Obsidian; `proposals show` | FR-AGT-001, FR-AGT-003, FR-AGT-005 | Expired; conflict; rejected | Acceptance criteria of the listed requirements |
| PRD-004 | Filtered search by project, date, source, state, language | Must | Too many results | Filters by kind, project, source, language, state, authority and dates | `search` options | — | Unknown filter rejected | Acceptance criteria of the listed requirements |
| PRD-005 | Note templates for sources, concepts, entities, projects, decisions, research | Should | Inconsistent notes | Templates per note type with required properties and sections, in the note's language | Obsidian templates; `notes new` | FR-KNW-003 | Filename exists; invalid title | Acceptance criteria of the listed requirements |
| PRD-006 | Obsidian navigation, backlinks and validation | Should | Notes and registry drift apart | Owner edits freely; `notes sync` adopts edits, tracks moves, reports drift and broken links | Obsidian; `notes sync`, `validate` | FR-KNW-001, FR-KNW-004, FR-KNW-008, FR-OBS-001 | Invalid frontmatter reported, file untouched | Acceptance criteria of the listed requirements |
| PRD-007 | Offline lexical search | Must | Dependence on a network or a service | All CLI functions work offline | CLI | FR-SEC-006 | — | Acceptance criteria of the listed requirements |
| PRD-008 | Mobile access (read-only copy) | Could | Reading on a phone | A read-only copy of the vault could be opened on a mobile device | Deferred (D-12) | — | Not offered in version 1 | Acceptance criteria of the listed requirements |
| PRD-009 | Semantic or vector search | Could | Lexical search misses paraphrase | Dense or hybrid retrieval | Only if gate RET-G2 is met | — | Not offered in version 1 | Acceptance criteria of the listed requirements |
| PRD-010 | Autonomous cross-application actions | Won't initially | — | Actions in other applications | Not built | FR-SEC-007 | Not offered | Acceptance criteria of the listed requirements |
| PRD-011 | Memory Manager: review, correct, supersede, archive | Must | No control over what the system 'knows' | List, inspect, verify, dispute, correct, supersede, archive and purge memory with full history; review queue for stale records; digests in the vault | `memory …`; digest notes; skills `propose-memory`, `reconcile-conflict` | FR-ING-011, FR-KNW-002, FR-KNW-005, FR-MEM-001, FR-MEM-002, FR-MEM-004, FR-MEM-005, FR-MEM-006, FR-MEM-007, FR-MEM-008, FR-MEM-009, FR-MEM-010, FR-MEM-011, FR-MEM-012 | Illegal transition; missing evidence; conflict | Acceptance criteria of the listed requirements |
| PRD-012 | Project Workspace: state, items, status, as-of view | Should | Projects cannot be resumed after a gap | Project record with items, dependencies, status report and state as of any date | `projects …`; project notes; skill `review-project` | FR-PRJ-001, FR-PRJ-002, FR-PRJ-003, FR-PRJ-005 | Dependency cycle; unknown project | Acceptance criteria of the listed requirements |
| PRD-013 | Decision Register with evidence and supersession | Should | Decisions lose their reasons | Decision notes with context, options, decision, consequences, evidence, state and supersession | `decisions …`; decision notes | FR-PRJ-004 | Acceptance without date; supersession cycle | Acceptance criteria of the listed requirements |
| PRD-014 | Agentic Task Center: proposal queue and run history | Must | Unclear what the assistant proposed and did | Queue of proposals; history of runs with state and errors; audit trail by correlation ID | `proposals list`, `review`, `runs`, `audit`; dashboard | FR-MEM-003, FR-AGT-002, FR-AGT-004, FR-AGT-006, FR-AGT-007, FR-AGT-008, FR-SEC-003 | — | Acceptance criteria of the listed requirements |
| PRD-015 | System Health: doctor, dashboards, backups | Must | Silent degradation | One health command; dashboard; scheduled backup, verification and restore-test; export | `doctor`, `backup`, `restore`, `export`, `schedule`; dashboard | FR-ING-009, FR-KNW-009, FR-SEC-001, FR-SEC-002, FR-SEC-004, FR-SEC-005, FR-OPS-001, FR-OPS-002, FR-OPS-003, FR-OPS-004, FR-OPS-005, FR-OPS-006, FR-OPS-007, FR-OPS-008, FR-OPS-009, FR-OPS-010, FR-OBS-002 | Each failing check named with next step | Acceptance criteria of the listed requirements |
| PRD-016 | Knowledge Explorer: entities and typed relationships | Should | The same thing has several names in two languages | Entities with Arabic and English aliases; typed relationships with evidence, shown on entity notes | `entities`, `relations`; entity notes | FR-KNW-006, FR-KNW-007 | Merge candidate; invalid predicate | Acceptance criteria of the listed requirements |
| PRD-017 | Bilingual experience: Arabic-first, RTL and LTR | Must | Arabic content handled as an afterthought | Arabic-aware search; right-to-left notes; mixed-direction-safe terminal output; error messages in both languages | All surfaces | FR-RET-003, FR-OBS-003 | Override characters rejected in titles | Acceptance criteria of the listed requirements |
| PRD-018 | Legacy vault import | Won't initially | An existing vault cannot be brought in | Plan (dry-run), commit and rollback of a legacy vault import | `import …` (future) | FR-IMP-001, FR-IMP-002, FR-IMP-003 | Not offered in version 1 | Acceptance criteria of the listed requirements |
| PRD-019 | Evaluation harness and benchmark | Must | Retrieval quality is a matter of opinion | Benchmark file, metrics per language, reports with fingerprints, gates | `eval run` | FR-RET-006, FR-RET-008 | Invalid benchmark | Acceptance criteria of the listed requirements |

Features without functional requirements (PRD-008, PRD-009, PRD-010) are recorded decisions not to build, with the condition that would reopen each.

## 4. Obsidian interaction model

Obsidian is a reader and editor of the vault folder. The system never drives the Obsidian application and needs no plugin. The owner: reads generated notes; writes and edits concept, entity, research, project and decision prose; drops files into the inbox; reads proposal notes before approving. The system: generates and regenerates managed notes and managed sections; adopts the owner's edits at the next `notes sync`; never overwrites prose. Details: OBSIDIAN-SCHEMAS.

## 5. Claude Code interaction model

The owner starts Claude Code in the operating home and talks to it. Claude uses five skills and the CLI. It can read vault notes and run read-only and proposing commands freely; approval commands show a permission prompt; restricted commands are unavailable to it. Details: AGENTIC-ARCHITECTURE, CLAUDE-CODE-CONTRACTS.

## 6. Search experience

A question in either language returns either a cited answer or a plain statement that nothing supports one. Every factual sentence carries a unit ID. The answer states its outcome class in words ('supported by verified memory', 'sources say, not yet verified', 'sources disagree', 'may be outdated', 'not enough evidence', 'nothing found'). The owner can open any citation with one command or by following the link to the source note.

## 7. Navigation, dashboards, notifications, administration

- Navigation: wikilinks, backlinks and properties in Obsidian; digests by subject and project.
- Dashboards (`07-Dashboards`): Inbox and extraction; Proposal queue; Memory review queue; Projects; Decisions; System health. Plain Markdown tables regenerated on demand and daily.
- Notifications: none pushed in version 1. The health dashboard and `doctor` are the signal. (Could: a macOS notification from the daily job.)
- Administrative controls: all tier 2 operations, in a terminal.

## 8. Accessibility and language

Plain Markdown and plain terminal text; no information by colour alone; `NO_COLOR` honoured; statuses are words. Property keys and commands are English; content, titles, headings in generated notes and error explanations are available in Arabic and English.

## 9. Mobile

Not supported in version 1. The safe future form is a read-only copy of the vault; anything that writes from a second device needs a conflict design first (D-12).

## 10. Product acceptance

The product is accepted when the owner has completed journeys J1–J10 with their own pilot corpus and signs the production readiness criteria (IMPLEMENTATION-ROADMAP §4).
