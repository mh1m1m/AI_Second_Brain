# CLI Specification

**DOC-CLI** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Executable `second-brain`. **Not implemented.** Supersedes `CLI-SPECIFICATION.md` of the V6.0 draft. The CLI is the only component that writes authoritative data; Claude Code, the owner in a terminal and launchd all use it.

## 1. Global behaviour

- Home: `--home PATH`, else `SECOND_BRAIN_HOME`, else `~/SecondBrain`. Commands refuse to run if the home fails the path policy.
- Global options: `--json` (machine output), `--dry-run` (every mutating command), `--correlation-id ID` (default: generated), `--quiet`, `--no-color` (also `NO_COLOR`), `--help`, `--version`.
- Standard output carries the result; standard error carries progress and warnings. JSON mode writes exactly one JSON object to standard output.
- Before any mutating command: writer lock, startup recovery, migration checksum check. In read-only mode (unresolved recovery state) every mutating command exits 7.
- Human output wraps values that may mix directions in Unicode isolates (U+2068 … U+2069) and wraps source text in `<source-text unit="…">…</source-text>`. JSON output contains neither.

## 2. Output envelope (JSON)

```json
{"schema_version": 1, "status": "ok | error | dry_run", "correlation_id": "…", "command": "ingest",
 "workflow_run_id": "WFR-000310", "data": {}, "warnings": [{"code": "W_INDEX_STALE", "message": "…"}],
 "errors": [{"code": "E_INVALID_INPUT", "detail": "unsupported_media_type", "message": "…", "next_step": "…"}]}
```

## 3. Exit codes

| Code | Name | Meaning |
|---|---|---|
| 0 | OK | Success (including `duplicate` and dry-run) |
| 2 | E_INVALID_INPUT | Bad arguments, schema violation, unsupported or rejected input |
| 3 | E_NOT_FOUND | Referenced object or file does not exist |
| 4 | E_CONFLICT | Lock held, base version changed, duplicate key, illegal transition |
| 5 | E_FORBIDDEN | Path or name policy, channel not allowed for tier |
| 6 | E_UNAVAILABLE | Missing dependency, disk full, limit exceeded, SQLite lacks a feature |
| 7 | E_INTEGRITY | Hash mismatch, chain break, constraint failure, read-only mode, doctor failure |
| 8 | E_APPROVAL_REQUIRED | No valid approval for the proposal's tier |
| 9 | E_INTERNAL | Unexpected error (logged with traceback, no content) |

## 4. Commands

Tier column: tier of the operation (AGENTIC-ARCHITECTURE §5). "R" = read-only.

| Command and syntax | Options (defaults) | Validation | Output `data` | Tier | Errors | Acceptance tests | Phase |
|---|---|---|---|---|---|---|---|
| `init [--home PATH]` | — | target empty; same-volume rule; SQLite ≥ 3.45 with FTS5; interactive confirmation | created paths, versions | 2 | 4, 5, 6 | TEST-OPS-013, TEST-OPS-014 | 1 |
| `doctor` | `--deep` (false), `--check ID` | — | per-check status, verdict | R | 7 | TEST-OPS-007, TEST-OPS-008 | 1 |
| `ingest PATH…` | `--title`, `--source-date`, `--authority` (unrated), `--lang`, `--new-version-of SRC`, `--no-extract` | path policy; intake | per file: status, IDs, extraction status | 0 | 2, 3, 5, 6, 7 | TEST-ING-001..009 | 2 |
| `ingest --inbox` | — | as above per file | result table | 0 | 4 | TEST-ING-014 | 2 |
| `extract --source SRC` | `--force`, `--extractor NAME` | source active | extraction ID, counts, warnings | 0 | 3, 6 | TEST-ING-005 | 2 |
| `sources list` | `--state`, `--needs-ocr`, `--limit` (50) | — | rows | R | — | TEST-ING-001 | 2 |
| `sources show SRC` | — | — | metadata, versions, extractions | R | 3 | TEST-ING-004 | 2 |
| `sources withdraw SRC --reason TEXT` | — | active | proposal ID, impact report | 1 | 3, 8 | TEST-ING-015 | 5 |
| `sources purge SRC --reason TEXT` | — | withdrawn | proposal ID, exposure report | 2 | 3, 4, 8 | TEST-MEM-012 | 5 |
| `notes new TYPE --title TEXT` | `--project`, `--lang` | title rules; type creatable | path, ID | 0 | 2, 4 | TEST-KNW-004 | 3 |
| `notes sync` | `--repair`, `--path` | — | added, changed, moved, missing, invalid, drift | 0 | 4 | TEST-KNW-005..007 | 3 |
| `validate` | `--scope PATH`, `--links` | — | findings | R | — (exit 7 if any error-severity finding) | TEST-KNW-001, TEST-KNW-012 | 3 |
| `index status` | — | — | counts, dirty, versions | R | — | TEST-REC-003 | 4 |
| `index rebuild` | — | lock | counts, duration | 0 | 4, 7 | TEST-OPS-001 | 4 |
| `search QUERY` | `--limit` (10), `--kind`, `--project`, `--source`, `--lang`, `--state`, `--authority`, `--from`, `--to`, `--as-of`, `--allow-stale`, `--explain`, `--include-archived` | RETRIEVAL-ARCHITECTURE §5 | RETRIEVAL-ARCHITECTURE §4 | R | 2, 6, 7 | TEST-RET-001..003, TEST-RET-007..009 | 4 |
| `evidence show PSG` | — | — | passage, locator, source, original path, hash check | R | 3, 7 | TEST-RET-003 | 4 |
| `eval run BENCH` | `--split` (dev), `--latency-only` | benchmark schema | metrics report | R | 2 | TEST-RET-012 | 4 |
| `memory propose --file PROPOSAL.json` | `--stdin` | PRP-MEM-1 | proposal ID, memory IDs, conflicts | 0 (creation) | 2 | TEST-MEM-005 | 5 |
| `memory attest --statement TEXT --kind K` | `--type` (preference) | terminal or in-session prompt | memory ID | 1 | 2, 5 | TEST-MEM-015 | 5 |
| `memory show MEM` | `--explain` | — | record, revisions, evidence, approvals | R | 3 | TEST-MEM-010 | 5 |
| `memory list` | `--state`, `--kind`, `--subject`, `--project`, `--limit` | — | rows | R | — | TEST-MEM-001 | 5 |
| `memory history` | `--subject` or `--memory`, `--as-of`, `--recorded-by` | dates | versions | R | 2, 3 | TEST-MEM-009, TEST-MEM-011 | 5 |
| `memory review-queue` | — | — | rows with reason | R | — | TEST-MEM-013 | 5 |
| `memory transition MEM --to STATE` | `--reason`, `--evidence`, `--supersedes`, `--successor` | WF-2 | proposal ID (applied at once if tier 0) | 0–1 | 2, 4, 8 | TEST-MEM-001, TEST-MEM-006 | 5 |
| `memory purge MEM --reason TEXT` | — | archived | proposal ID, exposure report | 2 | 4, 8 | TEST-MEM-012 | 5 |
| `entities add\|show\|list\|resolve\|alias\|merge\|unmerge` | per subcommand | vocabulary; alias rules | entity data or proposal ID | 0; merge/unmerge 1 | 2, 3, 4, 8 | TEST-KNW-010, TEST-KNW-011 | 6 |
| `relations propose\|show\|list\|transition` | `--explain` | vocabulary; endpoints exist | relationship data or proposal ID | 0; verify/retract 1 | 2, 3, 4, 8 | TEST-KNW-008 | 6 |
| `projects new\|show\|list\|status\|item\|state` | `--as-of`, `--json` | slug; cycles | project data or proposal ID | 0; state 1 | 2, 3, 4, 8 | TEST-PRJ-001..004, TEST-PRJ-007 | 6 |
| `decisions new\|show\|list\|accept\|reject\|supersede\|reverse` | `--project`, `--decided-on`, `--evidence` | date; cycles | decision data or proposal ID | 0; state changes 1 | 2, 3, 4, 8 | TEST-PRJ-005, TEST-PRJ-006 | 6 |
| `dashboards build` | — | — | files written | 0 | 4 | TEST-OBS-004 | 6 |
| `proposals list\|show` | `--state`, `--tier` | — | rows; diff, evidence, approval command | R | 3 | TEST-AGT-002 | 5 |
| `proposals approve PRP --hash PREFIX` | `--apply` (true) | tier/channel; prefix ≥ 8 hex; unexpired | approval ID; applied result | 1 (2 only in a terminal with typed confirmation) | 4, 5, 8 | TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-AGT-008 | 7 |
| `proposals reject PRP --reason TEXT` | — | awaiting approval | state | 1 | 3, 4 | TEST-AGT-006 | 7 |
| `proposals apply PRP` | — | approved, unexpired, base unchanged | applied result | as proposal | 4, 8 | TEST-AGT-006 | 7 |
| `review` | `--tier` | terminal only | interactive walk through the queue | 1–2 | 5 | TEST-ACC-008 | 7 |
| `runs` / `audit tail` / `audit verify` | `--limit`, `--correlation-id` | — | rows; chain report | R | 7 | TEST-AGT-010, TEST-SEC-012 | 7 |
| `workspace verify` / `workspace install` | `--force` (terminal only) | — | hash comparison | R / 2 | 4, 7 | TEST-AGT-011 | 7 |
| `backup create\|list\|verify\|restore-test\|expire` | `--destination LABEL` | destination policy | backup data, reports | 0; expire 2 | 3, 5, 6, 7 | TEST-OPS-003..006 | 2 |
| `restore BKP` | — | restore-tested; terminal | restored home, set-aside path | 2 | 4, 8 | TEST-OPS-015 | 9 |
| `export DEST` | — | empty destination | bundle manifest | 0 | 4, 7 | TEST-KNW-013 | 9 |
| `schedule install\|status\|remove` | — | allowlist | plist paths, last run status | 2; status R | 2, 6 | TEST-OPS-011, TEST-AGT-012 | 9 |
| `recovery status` / `recovery resolve RUN --action accept-file\|restore-staged\|abandon` | — | terminal only for `resolve` | pending operations; result | R / 2 | 3, 5, 7 | TEST-REC-005 | 2 |
| `migrate` | `--to N` | checksums; pre-backup | applied versions | 2 | 4, 7 | TEST-OPS-009 | 1 |
| `import plan\|commit\|rollback` | — | — | plan or batch | R; 2; 2 | — | TEST-IMP-001..003 | 10 (not authorised) |

## 5. Error catalogue (detail values)

Each error object has a stable `code` (table in §3) and a `detail` from this list, with fixed cause and next-step text in English and Arabic (TEST-NFR-013): `source_missing`, `not_regular_file`, `path_outside_roots`, `symlink_rejected`, `forbidden_name`, `unsupported_media_type`, `type_mismatch`, `oversize`, `empty_file`, `archive_rejected`, `encrypted_document`, `extractor_missing`, `extraction_limit`, `disk_full`, `sqlite_feature_missing`, `lock_timeout`, `run_in_progress`, `base_changed`, `illegal_transition`, `cycle`, `duplicate_id`, `filename_exists`, `hash_mismatch`, `chain_broken`, `read_only_mode`, `migration_checksum`, `index_absent`, `index_stale`, `approval_missing`, `approval_expired`, `approval_consumed`, `approval_hash_mismatch`, `channel_not_allowed`, `schema_violation`, `unknown_reference`, `bidi_override`, `secret_in_config`, `destination_inside_home`, `backup_not_tested`.

## 6. Examples

```
$ second-brain ingest ~/SecondBrain/vault/01-Inbox/تقرير.pdf --json
{"schema_version":1,"status":"ok","command":"ingest","workflow_run_id":"WFR-000310",
 "data":{"results":[{"path":"…/تقرير.pdf","status":"registered","source_id":"SRC-000027","source_version_id":"SVR-000031",
   "sha256":"…","media_type":"application/pdf","extraction":{"id":"EXT-000040","status":"partial","passages":212,
   "warnings":["pages 14-15: low text yield"]}}]},"warnings":[],"errors":[]}

$ second-brain search "موعد تسليم مشروع ألفا" --project alpha --json     # see RETRIEVAL-ARCHITECTURE §4

$ second-brain proposals approve PRP-000118 --hash 9f2c1a7e
Approved PRP-000118 (tier 1, channel in_session). Applied: MEM-000131 verified; MEM-000101 superseded.
```

## 7. Use by Claude Code

Claude calls the CLI with `--json`, by absolute path. Read-only and proposing commands are pre-allowed; approval commands prompt the owner; restricted commands are denied to the session (CLAUDE-CODE-CONTRACTS §5). Commands never ask interactive questions when standard input is not a terminal; they fail with the next step in the error object.
