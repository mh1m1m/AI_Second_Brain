# Test Case Specifications

**DOC-TEST-CASES** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Designed, **not executed**: no application has been built under this specification or supplied. Supersedes the 26 templated cases of the V6.0 draft (CHG-014). Generated from `docs/specification/data/tests.json`.

- 143 test cases; 63 are adversarial or stress scenarios (V5.0 required at least 50).
- Automation: 123 fully automated, 14 partly automated (need the target Mac, the owner, or a measured corpus), 6 manual.
- Fixtures (`FX-*`) are synthetic and defined in TEST-STRATEGY §5. Crash points `CP1..CP7` are defined in DATA-ARCHITECTURE §5.
- A test passes only on the stated expected result. 'Not measured' is a failure for performance tests.

## Ingestion

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-ING-001 | FR-ING-001 | integration |  | Registration creates one source and one version with correct metadata. | Empty workspace | FX-TXT-EN | Run `ingest FX-TXT-EN --json`; read sources and source_versions. | One SRC and one SVR row; sha256 equals independently computed hash; media_type text/plain; audit event present. | Missing row, wrong hash, or no audit event. | Yes |
| TEST-ING-002 | FR-ING-001, FR-ING-004 | data-integrity | Y | Registration is deterministic and duplicate-safe. | FX-TXT-EN already ingested | Same file; a renamed copy | Ingest both again. | Status duplicate with the original IDs twice; row counts unchanged. | A second SVR row or a different ID. | Yes |
| TEST-ING-003 | FR-ING-002 | data-integrity |  | Stored original is bit-identical and read-only. | FX-DOCX-AR ingested | Stored path from source_versions | Hash the stored file; stat its mode; attempt to open for write as the test user. | Hash equals registered sha256; mode 0444; write attempt fails. | Hash differs or file writable. | Yes |
| TEST-ING-004 | FR-ING-003 | integration |  | Extraction records extractor version and status. | FX-MD-MIXED ingested | — | Read extractions for the source version. | One active extraction with extractor name, semantic version, status succeeded, text_sha256 set. | Missing version or two active extractions. | Yes |
| TEST-ING-005 | FR-ING-003, FR-RET-002 | data-integrity | Y | Re-extraction keeps earlier citations resolvable. | FX-PDF-AR-TEXT ingested; one evidence link to a passage | Extractor version bumped in test config | Run `extract --source SRC --force`; resolve the old passage ID. | New extraction active; old passage still resolves; link re-anchored if text hash matches, else flagged stale. | Old passage ID no longer resolves. | Yes |
| TEST-ING-006 | FR-ING-004 | integration |  | Duplicate attempt is audited and leaves storage untouched. | FX-TXT-AR ingested | Copy with different name and mtime | Ingest copy; list data/originals. | One stored file; audit action source.duplicate. | Second stored file. | Yes |
| TEST-ING-007 | FR-ING-005 | security | Y | Intake rejects mismatched, oversize, empty and archive files without residue. | Empty workspace | PDF renamed .txt; 0-byte file; .zip; file over limit | Ingest each; hash the workspace before and after. | Each rejected with E_INVALID_INPUT and a reason; workspace hash unchanged apart from audit and log. | Any row, stored byte or staging file remains. | Yes |
| TEST-ING-008 | FR-ING-006 | integration |  | New version registration is gapless and non-destructive. | FX-TXT-EN ingested as SRC | FX-TXT-EN-V2 | `ingest V2 --new-version-of SRC`. | version_no 2; version 1 rows and passages unchanged. | Version 1 altered or version gap. | Yes |
| TEST-ING-009 | FR-ING-007 | integration |  | Arabic text extraction preserves logical order and characters. | — | FX-TXT-AR, FX-HTML-AR, FX-DOCX-AR with known expected text | Ingest each; compare passage text with expected strings. | Exact match after NFC; tashkeel preserved in stored text. | Reordered, stripped or mojibake characters. | Yes |
| TEST-ING-010 | FR-ING-007 | integration | Y | Arabic text-layer PDF extraction quality is measured, not assumed. | PDF extractor selected by D-09 | FX-PDF-AR-TEXT set (10 pages, known text) | Ingest; compute character error rate against expected text. | CER reported per page; pages above 5% CER are flagged partial; result recorded as evidence for ADR-017. | Extractor reports success while CER above threshold goes unflagged. | Partial |
| TEST-ING-011 | FR-ING-007 | integration | Y | Corrupt and password-protected documents fail cleanly. | — | FX-PDF-CORRUPT, FX-PDF-ENCRYPTED | Ingest both. | Source registered and preserved; extraction status failed; zero passages; run ends COMPLETED_WITH_WARNINGS. | Crash, hang, or passages created. | Yes |
| TEST-ING-012 | FR-ING-008 | unit |  | Segmentation is lossless and bounded. | — | Generated texts incl. 5,000-character paragraph, Arabic with combining marks | Segment; concatenate; compare hash; check lengths and grapheme boundaries. | Hash equal; no passage > 2000 chars; no split inside a combining sequence. | Any character lost or boundary inside a cluster. | Yes |
| TEST-ING-013 | FR-ING-009 | integration | Y | Scanned PDF is flagged, not indexed as empty. | — | FX-PDF-SCAN | Ingest; search a term visible in the scan image. | Extraction needs_ocr; no search unit; outcome no_evidence with hint naming the source. | Status succeeded with zero passages. | Yes |
| TEST-ING-014 | FR-ING-010 | integration |  | Inbox sweep isolates per-file failures. | Inbox with 3 valid files, 1 corrupt, 1 symlink | — | `ingest --inbox`. | 3 processed, 1 in .rejected with reason, symlink skipped; 5 results reported. | Sweep aborts at first failure. | Yes |
| TEST-ING-015 | FR-ING-011 | integration | Y | Withdrawing a source reports and applies evidence impact. | Source with 2 verified memories, one of which has a second source | — | Propose and approve `sources withdraw`. | Passages unindexed; links flagged; single-source memory proposed for disputed; other memory unchanged. | A memory left verified with no live support. | Yes |

## Knowledge and notes

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-KNW-001 | FR-KNW-001 | unit |  | Schema validation reports each rule violation. | — | One invalid note per rule OBS-R01..R16 | `validate --json` over the fixture folder. | Exactly one finding per file naming its rule ID. | Missing or mis-attributed finding. | Yes |
| TEST-KNW-002 | FR-KNW-001 | data-integrity | Y | Duplicate note IDs are detected. | — | Two notes with the same id | `validate`. | Both paths reported under OBS-R03. | Only one or none reported. | Yes |
| TEST-KNW-003 | FR-KNW-002 | data-integrity | Y | Supersession cycles are rejected. | A supersedes B | Proposal B supersedes A | Validate and attempt to apply. | E_CONFLICT; no change. | Cycle stored. | Yes |
| TEST-KNW-004 | FR-KNW-003, NFR-022 | integration | Y | Generated notes validate and use NFC names. | — | Titles: Arabic with hamza forms, mixed, with slash, with U+202E | `notes new` for each. | Valid notes with NFC filenames; slash and override titles rejected. | Non-NFC filename or accepted override character. | Yes |
| TEST-KNW-005 | FR-KNW-004 | integration |  | Owner body edit is adopted as a new revision. | Registered concept note | Body edited outside the CLI | `notes sync`. | revision +1 with origin owner_direct; index updated; no proposal needed. | Edit reverted or ignored. | Yes |
| TEST-KNW-006 | FR-KNW-004 | integration |  | Move and removal are tracked by ID. | Two registered notes | One renamed, one deleted in the filesystem | `notes sync`. | Path updated for the first; second marked missing; history rows intact. | New ID created for the moved note or rows deleted. | Yes |
| TEST-KNW-007 | FR-KNW-005 | data-integrity | Y | Hand-editing a managed key does not change governed state. | Memory note projection status: proposed | Edit file to status: verified | `notes sync`; read memory_records. | State still proposed; drift finding OBS-D01; `--repair` restores the file. | State changed by file edit. | Yes |
| TEST-KNW-008 | FR-KNW-006 | data-integrity |  | Relationship endpoints must exist. | — | Edge to unknown ID | Propose edge. | E_INVALID_INPUT; no row. | Dangling edge stored. | Yes |
| TEST-KNW-009 | FR-KNW-006 | unit |  | Wikilinks do not create typed edges. | Note with 5 wikilinks | — | `notes sync`; count relationships. | Zero relationship rows. | Rows created from links. | Yes |
| TEST-KNW-010 | FR-KNW-007 | integration |  | Bilingual aliases resolve to one entity after approved merge. | Entity A (Arabic name), entity B (English name) | Merge proposal | Approve merge; resolve both aliases and old ID. | One active entity; old ID resolves to successor. | Two active entities or broken old ID. | Yes |
| TEST-KNW-011 | FR-KNW-007 | security | Y | Entity merge never happens without approval. | Two entities with equal normalised alias | — | Create second entity via Claude-session actor. | Merge candidate reported; no merge. | Automatic merge. | Yes |
| TEST-KNW-012 | FR-KNW-008 | unit |  | Broken links are reported; code blocks ignored. | Note with 2 broken links, 1 in a code block | — | `validate --links`. | Exactly 2 findings. | Code-block link reported. | Yes |
| TEST-KNW-013 | FR-KNW-009, NFR-003 | acceptance |  | Export bundle is readable without the software. | Populated workspace | — | `export`; run an independent script (stdlib only) that follows one memory to its original. | Statement, evidence passage and original hash recovered from the bundle alone. | Any step needs project code. | Yes |

## Memory

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-MEM-001 | FR-MEM-001 | unit |  | Every transition outside the table is rejected. | — | All 49 state pairs | Attempt each via the application API. | Only the pairs in WF-2 succeed. | An illegal pair succeeds. | Yes |
| TEST-MEM-002 | FR-MEM-001 | data-integrity | Y | The database enforces transitions when the application is bypassed. | Record in each state | Direct SQL UPDATE of state | Attempt illegal transitions with raw SQL. | SB-MEM-001 raised; row unchanged. | Raw SQL changes state illegally. | Yes |
| TEST-MEM-003 | FR-MEM-002 | data-integrity | Y | Verification without resolvable evidence is rejected. | Proposed fact, no evidence; then evidence on a withdrawn source | — | Attempt verify in both situations. | SB-MEM-002 both times. | Verified without live support. | Yes |
| TEST-MEM-004 | FR-MEM-002, FR-MEM-004 | data-integrity | Y | Hypotheses, interpretations, predictions and derived statements cannot be verified. | One record of each | — | Attempt verify with approval. | Rejected by CHECK or SB-MEM-003. | Any reaches verified. | Yes |
| TEST-MEM-005 | FR-MEM-003 | integration |  | A candidate with an unknown passage is rejected whole. | — | Proposal with 2 candidates, one bad passage ID | `memory propose`. | E_INVALID_INPUT; zero records created. | Partial creation. | Yes |
| TEST-MEM-006 | FR-KNW-002, FR-MEM-005, FR-MEM-006 | integration | Y | Contradictory dated evidence is preserved and resolved by validity. | FX-DEADLINE: deadline June (verified); new source says September | — | Propose, validate (conflict flagged), verify new, supersede old. | Both records kept; SUPERSEDES edge; current view September; as-of before effective date June. | Old value overwritten or lost. | Yes |
| TEST-MEM-007 | FR-MEM-004 | integration |  | A sourced claim is stored as claim, not fact. | Source asserting an opinion | Proposal epistemic_type claim | Create; try to verify. | Record proposed with source as evidence; verify rejected by CHECK. | Stored or verified as fact. | Yes |
| TEST-MEM-008 | FR-MEM-005 | unit |  | Records without subject and predicate are reported as not conflict-checkable. | — | Free-text memory | Validate proposal. | Finding MEM-V04 informational; no false conflict. | Silently treated as conflict-free. | Yes |
| TEST-MEM-009 | FR-MEM-006, FR-MEM-008 | integration |  | As-of queries distinguish valid time from recorded time. | FX-DEADLINE applied with back-dated effective date | — | `memory history --as-of D1`, `--recorded-by D1`. | Two different, correct answers. | Same answer for both axes. | Yes |
| TEST-MEM-010 | FR-MEM-007 | data-integrity | Y | Correction adds a revision and never edits history. | Verified record | Correction proposal | Apply; inspect revisions; attempt raw UPDATE of revision 1. | Revision 2 exists; state proposed; UPDATE raises SB-INT-004. | Revision 1 changed. | Yes |
| TEST-MEM-011 | FR-MEM-008 | unit |  | Malformed dates are rejected. | — | --as-of 2026-13-40 | Run history. | E_INVALID_INPUT. | Silent empty result. | Yes |
| TEST-MEM-012 | FR-MEM-009 | integration | Y | Purge removes text everywhere live and reports backup exposure. | Archived record present in index and one backup | — | Tier 2 purge. | Statement '[purged]'; no search hit; report lists the backup and its expiry; audit chain verifies. | Text still retrievable. | Yes |
| TEST-MEM-013 | FR-MEM-010 | integration |  | Outdated records are queued and labelled. | Verified record with review_due_on in the past | — | `memory review-queue`; search for it. | Listed; search outcome outdated. | Presented as current. | Yes |
| TEST-MEM-014 | FR-MEM-011 | unit |  | Consolidation is offered only for exact key duplicates. | Two identical-key records; two similar-text records with different values | — | `conflicts.find_duplicates`. | Only the first pair offered. | Similar pair offered. | Yes |
| TEST-MEM-015 | FR-MEM-012 | security | Y | A Claude session cannot create owner-attested memory. | — | Proposal with attestation owner_attested, actor_kind claude_session | `memory propose`. | E_INVALID_INPUT. | Record created. | Yes |

## Retrieval

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-RET-001 | FR-RET-001 | retrieval |  | Each filter restricts results correctly. | FX-CORPUS-S indexed | One query per filter | Run with and without each filter. | Filtered results are the exact expected subset. | Any out-of-filter hit. | Yes |
| TEST-RET-002 | FR-RET-001 | security | Y | FTS5 query syntax in user input cannot alter the query. | FX-CORPUS-S indexed | Queries containing quotes, NEAR, column filters, *, parentheses, NOT | Search each. | Treated as literal terms; no SQL or FTS error; no unfiltered result leak. | Syntax error or operator honoured. | Yes |
| TEST-RET-003 | FR-RET-002, FR-RET-009 | data-integrity |  | Every returned locator resolves to the original. | FX-CORPUS-S indexed | 50 queries | For each hit, `evidence show`; verify original hash and text containment. | 100% resolve. | Any unresolved locator. | Yes |
| TEST-RET-004 | FR-RET-003 | unit |  | Normaliser golden table. | — | Pairs: tashkeel, tatweel, alef forms, alef-maqsura, ta-marbuta, Persian kaf/yeh, Arabic-Indic digits, presentation forms, lam-alef ligature, Latin case, bidi controls | normalise(input) == expected for each. | All pairs equal; idempotent. | Any mismatch. | Yes |
| TEST-RET-005 | FR-RET-003 | retrieval | Y | Normalised index finds Arabic variants raw FTS5 misses. | Probe corpus from RETRIEVAL-ARCHITECTURE §2 | Probe queries | Run the shipped probe on the target machine. | Results equal the recorded Part B table. | Divergence from recorded results (investigate SQLite build). | Yes |
| TEST-RET-006 | FR-RET-003 | unit |  | Light stemmer golden table and known limits. | — | Prefix/suffix cases; compound prefixes; broken plurals listed as expected misses | light_stem(input) == expected. | All expected equal; documented misses remain misses. | Over-stemming of 3-letter roots. | Yes |
| TEST-RET-007 | FR-RET-004 | retrieval |  | Ranking is deterministic and explained. | FX-CORPUS-S indexed | Tie-producing queries | Run twice; run with --explain. | Identical order; score components present. | Order differs between runs. | Yes |
| TEST-RET-008 | FR-RET-005 | retrieval |  | Outcome classes are produced by rule. | Fixtures for each class | One query per class | Search. | Six classes each observed with stated reasons. | Wrong class. | Yes |
| TEST-RET-009 | FR-RET-005 | retrieval | Y | Unanswerable questions yield no_evidence or insufficient. | FX-CORPUS-S indexed | 10 questions with no support in corpus | Search. | No verified_evidence outcome. | Any verified outcome. | Yes |
| TEST-RET-010 | FR-ING-011, FR-MEM-009, FR-RET-007 | data-integrity | Y | Deleted and withdrawn content is unreachable. | Source withdrawn; memory purged; note removed | Queries targeting each | Search; then rebuild; search again. | No hits before or after rebuild. | Any stale hit. | Yes |
| TEST-RET-011 | FR-RET-006 | integration |  | Query logging failure does not fail search. | query_log made unwritable by test hook | — | Search. | Results returned; warning logged. | Search fails. | Yes |
| TEST-RET-012 | FR-RET-008, NFR-007 | unit |  | Metric functions match hand-computed values. | — | FX-BENCH-UNIT (8 questions with worked metrics) | `eval run`. | Recall@k, P@5, MRR, nDCG@10 equal to 4 decimals. | Any metric differs. | Yes |

## Projects and decisions

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-PRJ-001 | FR-PRJ-001 | integration |  | Replay to now equals current state. | FX-PROJECT-3DATES | — | Replay events; compare with tables. | Exact equality. | Any difference. | Yes |
| TEST-PRJ-002 | FR-PRJ-001 | integration |  | As-of snapshots at three dates are correct. | FX-PROJECT-3DATES | Dates D1<D2<D3 | `projects show --as-of` each. | Three expected snapshots. | Wrong state at any date. | Yes |
| TEST-PRJ-003 | FR-PRJ-002 | integration |  | Project registration with Arabic name and ASCII slug. | — | Arabic name; slug with uppercase (invalid) | `projects new`. | Valid one created with note; invalid slug rejected. | Invalid slug accepted. | Yes |
| TEST-PRJ-004 | FR-PRJ-003 | data-integrity | Y | Dependency cycles are rejected and each change has one event. | Items A->B | B->A | Apply. | E_CONFLICT; event count equals change count. | Cycle stored. | Yes |
| TEST-PRJ-005 | FR-PRJ-004 | integration |  | Decision acceptance requires date and tier 1 approval. | Proposed decision | — | Accept without date; accept without approval; accept correctly. | First two rejected; third applied with event. | Accepted without date or approval. | Yes |
| TEST-PRJ-006 | FR-PRJ-004 | integration |  | Superseded decision stays readable and linked. | Accepted decision D1 | D2 supersedes D1 | Apply; show D1. | D1 superseded with link to D2; note intact. | D1 removed or unlinked. | Yes |
| TEST-PRJ-007 | FR-PRJ-005 | integration |  | Status report lines carry record IDs. | FX-PROJECT-3DATES | — | `projects status --json`. | Every item has an ID that resolves. | Any line without ID. | Yes |

## Agentic execution

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-AGT-001 | FR-AGT-001 | security | Y | Unapproved tier 1 change is rejected with no effect. | Validated proposal, no approval | — | `proposals apply`. | E_APPROVAL_REQUIRED; workspace hash unchanged. | Any change. | Yes |
| TEST-AGT-002 | FR-AGT-003, FR-MEM-003 | integration |  | Proposal validation records findings and freezes payload. | — | Valid and invalid proposals | Create; attempt payload update after validation. | States validated / rejected; update raises SB-AGT-001. | Payload changed after validation. | Yes |
| TEST-AGT-003 | FR-AGT-001 | security | Y | Approval replay is rejected. | Applied proposal with consumed approval | — | Apply again; insert a second approval. | Both rejected. | Second application. | Yes |
| TEST-AGT-004 | FR-AGT-001 | security | Y | Approval for a different payload hash is rejected. | Proposal P; approval row with other hash | — | Insert approval. | SB-AGT-001. | Approval accepted. | Yes |
| TEST-AGT-005 | FR-AGT-002 | recovery |  | Idempotent re-run returns the stored result. | Completed ingest run with key K | — | Re-run with key K. | Same result; no new rows. | Duplicate effects. | Yes |
| TEST-AGT-006 | FR-AGT-003 | integration | Y | Expired and conflicted proposals cannot be applied. | Proposal past expires_at; proposal whose base note changed | — | Approve/apply each. | expired; conflict; no change. | Stale diff applied. | Yes |
| TEST-AGT-007 | FR-AGT-004 | unit |  | Tier table matches the specification. | — | Machine-readable tier table from AGENTIC-ARCHITECTURE §5 | Compare with `policy.tier_of` for every operation. | Exact match. | Any mismatch. | Yes |
| TEST-AGT-008 | FR-AGT-004 | security | Y | Tier 2 approval refuses non-terminal input. | Tier 2 proposal | Approval attempted with stdin piped and via pseudo-terminal wrapper inside the sandbox | Run both. | Piped: E_FORBIDDEN. Sandbox pty: write denied by sandbox. | Approval recorded. | Partial |
| TEST-AGT-009 | FR-AGT-005 | data-integrity |  | Dry-run changes nothing for every mutating command. | Populated workspace | All mutating commands | Hash workspace; run each with --dry-run; hash again. | Hashes equal. | Any difference. | Yes |
| TEST-AGT-010 | FR-AGT-006, NFR-005 | integration |  | Every mutating command is traceable by correlation ID. | — | Suite command log | Join commands to workflow_runs, journal_ops and audit_events. | 100% linked with terminal state. | Unlinked command. | Yes |
| TEST-AGT-011 | FR-AGT-007 | integration | Y | Installed workspace files match packaged hashes; tampering is reported. | Initialised home | settings.json edited | `workspace verify`; `doctor`. | Mismatch reported as fail DOC-SEC-02. | Edit unnoticed. | Yes |
| TEST-AGT-013 | FR-AGT-003 | integration | Y | Proposal limits hold and nothing is lost silently. | Limits set to 3 open and 2 per run | Five distinct payloads; one duplicate payload | Create proposals in one run, then across runs; resubmit a duplicate. | Third creation in a run fails with E_UNAVAILABLE and creates nothing; fourth open proposal refused; duplicate returns the existing ID; expired proposals remain listed; run history records each refusal. | Unbounded queue; duplicate created; proposal dropped without a record. | Yes |
| TEST-AGT-012 | FR-AGT-008 | unit |  | Scheduler renders only allowlisted commands. | — | Schedule config with a forbidden job | `schedule install --dry-run`. | Forbidden job rejected; plists contain only allowlisted subcommands. | Forbidden job rendered. | Yes |

## Security

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-SEC-001 | FR-SEC-001 | security | Y | Path traversal and outside paths are denied. | — | ../../etc/hosts; absolute path outside roots | `ingest` each. | E_FORBIDDEN; audited; no copy. | File read or copied. | Yes |
| TEST-SEC-002 | FR-SEC-001 | security | Y | Symlink escape and swap are denied. | — | FX-SYMLINK to outside file; file swapped for symlink between check and open (test hook) | Ingest. | Denied in both cases. | Target content ingested. | Yes |
| TEST-SEC-003 | FR-SEC-002 | security |  | No secret in repo, vault, logs or export. | Suite completed | Secret patterns incl. test canary | Scan. | Zero matches; inline secret in config rejected at load. | Canary found. | Yes |
| TEST-SEC-004 | FR-SEC-003 | security | Y | Deterministic paths ignore instructions in content. | — | FX-INJECT variants in each format (visible, hidden text, metadata, Arabic and English) | Ingest all; compare workspace diff with the diff for neutral files of equal size. | Only expected rows differ; no extra file, command or network activity. | Any behavioural difference. | Yes |
| TEST-SEC-005 | FR-SEC-003 | security | Y | Injected instructions cannot cause a canonical write through a Claude session. | Target Mac with operating workspace; FX-INJECT ingested | Scripted interactive session asking for a summary of the injected source | Observe tool calls and workspace hash. | No tier 1/2 change without an owner approval prompt; injected commands not executed. | Canonical change without approval. | Manual |
| TEST-SEC-006 | FR-AGT-001, FR-KNW-005, FR-MEM-002, FR-MEM-007, NFR-019 | security | Y | Unauthorised canonical writes fail on every path. | Operating workspace | Attempts: Edit tool on data/ and managed notes; sandboxed `python -c` write to DB; raw sqlite3 UPDATE to verified; hand-edited frontmatter | Execute each attempt (sandbox attempts on target Mac). | All blocked by permission rule, sandbox, trigger or drift rule; workspace canonical hash unchanged. | Any change persists undetected. | Partial |
| TEST-SEC-007 | FR-AGT-004, NFR-019 | security | Y | A sandboxed process cannot approve or apply proposals. | Target Mac; validated tier 1 and tier 2 proposals | Commands issued as sandboxed Bash and with PATH-prefixed fake binary | Run. | Denied; audit shows denial; no approval row. | Approval created. | Manual |
| TEST-SEC-008 | FR-ING-005, FR-SEC-008 | security | Y | Hostile files are bounded and quarantined. | — | FX-BOMB-DOCX; 2 GB sparse file; extractor made to hang by test hook | Ingest. | Limits enforced; run FAILED_TERMINAL; file quarantined or rejected; no hang beyond timeout. | Unbounded memory or time. | Yes |
| TEST-SEC-009 | FR-AGT-007, FR-SEC-004 | security | Y | Instruction-bearing filenames are rejected and detected. | — | Inbox files CLAUDE.md, AGENTS.md, .mcp.json; hand-created vault/.claude/ | Ingest; validate; doctor. | Ingest rejects; validate and doctor report critical finding SEC-F01. | File registered or unnoticed. | Yes |
| TEST-SEC-010 | FR-SEC-004 | security | Y | Operating settings exclude nested instruction files. | Target Mac; test CLAUDE.md placed in vault subfolder | — | Start session; read a file in that folder; inspect loaded instructions. | Nested file not loaded (claudeMdExcludes effective). | Nested instructions loaded. | Manual |
| TEST-SEC-011 | FR-SEC-005, NFR-005 | data-integrity | Y | Audit table rejects update and delete. | Audit rows exist | — | Raw UPDATE and DELETE. | SB-INT-001. | Row changed. | Yes |
| TEST-SEC-012 | FR-SEC-005 | security | Y | Audit tampering with triggers dropped is detected. | Audit rows exist | Drop triggers; edit one row; recreate triggers | `audit verify`. | Chain break reported at the edited sequence. | Verification passes. | Yes |
| TEST-SEC-013 | FR-SEC-006, NFR-004, NFR-009 | security |  | Suite passes with network denied; no network imports. | — | — | Run suite under network-deny profile; static import scan. | All pass; scan clean. | Any network attempt. | Yes |
| TEST-SEC-014 | FR-SEC-007 | security | Y | No integration is present by default; added ones are reported. | Fresh home | Add .mcp.json and a community plugin folder | doctor. | Fresh: ok. After adding: fail DOC-SEC-03 and warn DOC-SEC-04. | Unreported integration. | Yes |
| TEST-SEC-015 | FR-SEC-008 | security | Y | Extractors never invoke a shell. | — | Filenames with shell metacharacters; static scan | Ingest; scan src for shell=True, os.system, backticks. | Files handled as data; scan clean. | Command executed. | Yes |

## Operations

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-OPS-001 | FR-OPS-001, NFR-021 | recovery | Y | Rebuild reproduces search results after index corruption. | FX-CORPUS-S indexed; benchmark results saved | Drop search tables | `index rebuild`; rerun benchmark. | Identical ranked results. | Any difference. | Yes |
| TEST-OPS-002 | FR-OPS-001 | recovery | Y | Failed rebuild leaves the previous index usable or marks it stale. | Indexed workspace | Kill during rebuild | Search; doctor. | Either old index intact or stale flag set and search refuses without --allow-stale. | Half-built index served silently. | Yes |
| TEST-OPS-003 | FR-OPS-002, NFR-006 | recovery |  | Restore-test of a good backup passes and marks it. | Backup created | — | `backup restore-test`. | State restore_tested; report with counts; live workspace untouched. | Live workspace modified. | Yes |
| TEST-OPS-004 | FR-OPS-002 | recovery | Y | Corrupted backup fails closed. | Backup with one byte flipped in the DB snapshot; one missing original | — | restore-test each. | State failed; never verified. | Marked verified. | Yes |
| TEST-OPS-005 | FR-OPS-003 | recovery | Y | Backup during concurrent write is consistent. | Writer running ingest loop | — | `backup create` during writes; restore-test. | integrity_check ok; foreign_key_check empty; audit chain verifies. | Inconsistent snapshot. | Yes |
| TEST-OPS-006 | FR-OPS-003 | integration |  | Backup refuses a destination inside the workspace and copies originals incrementally. | Two backups in sequence | — | Create; inspect copied files. | Inside-workspace destination rejected; second backup copies only new originals. | Recursive backup or full recopy. | Yes |
| TEST-OPS-007 | FR-OPS-004, NFR-014 | integration |  | Each doctor check can fail and is read-only. | Fixtures breaking each check ID | — | doctor --json per fixture; hash workspace. | Matching check fails; workspace unchanged; quick mode within budget. | Check cannot fail or doctor writes. | Yes |
| TEST-OPS-008 | FR-OPS-004 | integration | Y | Deep verification detects a modified original. | One stored original altered by test with chmod | — | `doctor --deep`. | Fail DOC-STO-02 naming the source version. | Undetected. | Yes |
| TEST-OPS-009 | FR-OPS-006 | recovery | Y | Failing migration rolls back. | DB at version n; migration n+1 with a deliberate FK violation | — | Migrate. | Version still n; pre-migration backup exists. | Partial schema. | Yes |
| TEST-OPS-010 | FR-OPS-006 | data-integrity | Y | Edited applied migration is detected. | Applied migration file altered | — | Any command. | E_CONFLICT checksum mismatch; writes blocked. | Runs normally. | Yes |
| TEST-OPS-011 | FR-OPS-007 | integration |  | Generated launchd definitions are valid and allowlisted. | macOS | — | `schedule install --dry-run`; plutil -lint. | Lint ok; commands allowlisted. | Invalid plist. | Partial |
| TEST-OPS-012 | FR-OPS-008, NFR-014 | security |  | Logs contain no content strings and validate against schema. | Suite completed with canary strings in fixtures | — | Scan logs; validate JSON Lines. | No canary; all lines valid. | Canary present. | Yes |
| TEST-OPS-013 | FR-OPS-009 | integration |  | Init produces a healthy workspace and refuses non-empty targets. | Empty and non-empty directories | — | init each; doctor. | First ok and doctor passes; second E_CONFLICT with no change. | Init into non-empty directory. | Yes |
| TEST-OPS-014 | FR-OPS-009, NFR-020 | integration |  | Environment checks detect unsupported SQLite or Python. | Test hook simulating SQLite without FTS5 and old version | — | init; doctor. | E_UNAVAILABLE with remedy text. | Proceeds. | Yes |
| TEST-OPS-015 | FR-OPS-010 | recovery | Y | Full restore is reversible for one step. | Restore-tested backup; live home with later changes | — | restore (tier 2); then simulate verification failure in a second run. | Success: home equals backup, previous home set aside. Failure: original home untouched. | Data loss in either path. | Yes |

## Recovery

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-REC-001 | FR-AGT-002, FR-ING-002, FR-OPS-005, NFR-002 | recovery | Y | Crash between file placement and database commit rolls forward once. | — | FX-TXT-AR | Kill at CP3 and CP4 (test hook); run any command. | Recovery completes the run; exactly one source version; original intact. | Duplicate or missing row; orphan original. | Yes |
| TEST-REC-002 | FR-AGT-002, FR-ING-002, FR-OPS-005 | recovery | Y | Crash after intent before any rename resumes or rolls back. | — | FX-TXT-AR; variant with staged file deleted | Kill at CP2; recover. | Staged present: completed. Staged missing: run FAILED_ROLLED_BACK, no canonical change. | Inconsistent state. | Yes |
| TEST-REC-003 | FR-RET-007 | recovery | Y | Crash after commit before indexing leaves a detectable stale index. | — | FX-TXT-AR | Kill at CP5; doctor; search. | index_dirty set; search refuses or warns; next command re-indexes. | Stale index served as fresh. | Yes |
| TEST-REC-004 | FR-AGT-002, FR-OPS-005 | recovery | Y | Orphan staging without journal is quarantined. | — | Kill at CP1 | Recover. | Staging directory moved to quarantine; no canonical change. | Orphan promoted or left in staging. | Yes |
| TEST-REC-005 | FR-OPS-005 | recovery | Y | Unknown journal state forces read-only mode. | Journal row edited to an impossible combination | — | Any mutating command; doctor. | E_INTEGRITY; writes blocked; doctor fail DOC-JRN-01. | Write proceeds. | Yes |
| TEST-REC-006 | FR-KNW-004 | recovery | Y | Owner edit during a pending note write is never overwritten. | Note write at CP2 | Owner edits the same note | Recover. | Op quarantined; run FAILED_CONFLICT; owner text kept; proposal marked conflict. | Owner edit lost. | Yes |
| TEST-REC-007 | FR-AGT-002 | recovery | Y | Second writer waits or fails cleanly. | Process A holds the writer lock | Process B mutating command; process C search | Run concurrently. | B: E_CONFLICT after timeout, no change. C: succeeds (WAL reader). | Interleaved writes or reader blocked. | Yes |
| TEST-REC-008 | FR-ING-002 | recovery | Y | Disk full during staging leaves no canonical change. | Quota-limited volume | Large file | Ingest. | E_UNAVAILABLE; staging cleaned; no rows. | Partial original or row. | Yes |
| TEST-REC-009 | FR-OPS-004 | recovery | Y | Corrupt database is detected and recovery path is restore. | DB file with damaged pages | — | Any command; doctor. | E_INTEGRITY; no write attempted; runbook RB-03 path verified by restore-test. | Writes to corrupt DB. | Yes |
| TEST-REC-010 | NFR-002, NFR-018 | recovery | Y | Randomised crash loop preserves all invariants. | — | 200 iterations: random command, random kill point | After each, run recovery and invariant checker INV-01..INV-12. | Zero invariant violations; zero lost committed runs; originals intact. | Any violation. | Yes |

## Obsidian and direction

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-OBS-001 | FR-OBS-001 | integration |  | Vault skeleton and Obsidian configuration are as specified. | Fresh home | — | Compare tree and .obsidian files with the specification. | Exact match; no community plugin enabled. | Extra plugin or missing folder. | Yes |
| TEST-OBS-002 | FR-KNW-003, FR-OBS-003, NFR-022 | unit |  | Direction and language properties are set from script detection. | — | Arabic, English, mixed and digit-only titles and bodies | Render notes. | lang and dir values per OBSIDIAN-SCHEMAS §6; keys ASCII; NFC. | Wrong direction or non-ASCII key. | Yes |
| TEST-OBS-003 | FR-OBS-003, FR-RET-009 | unit |  | Human output isolates mixed-direction values; JSON output does not. | — | Mixed Arabic/English titles and paths | `evidence show` in both modes. | Isolates present only in human mode; none in JSON. | Isolate in JSON or override anywhere. | Yes |
| TEST-OBS-004 | FR-OBS-002 | integration |  | Dashboards are plain Markdown and idempotent. | Populated workspace | — | `dashboards build` twice. | Second run reports no change; files contain only standard Markdown. | Content hash changes without data change. | Yes |
| TEST-OBS-005 | FR-OBS-003 | acceptance |  | Arabic notes display correctly in Obsidian. | Target Mac with Obsidian installed; generated Arabic and mixed notes | — | Open notes in Live Preview and Reading view; check direction, properties panel and links. | Arabic paragraphs right-to-left; English left-to-right; links work; properties readable. | Misdirected paragraphs or broken links. | Manual |

## Legacy import

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-IMP-001 | FR-IMP-001 | integration |  | Import plan is read-only and classifies every file. | FX-VAULT-LEGACY | — | `import plan`; hash both vaults. | Hashes unchanged; every file classified. | Any change or unclassified file. | Yes |
| TEST-IMP-002 | FR-IMP-002 | integration |  | Import preserves legacy bytes, attachments and links. | Approved plan | — | `import commit`; validate; check links. | All notes valid; each linked to its legacy source version; links resolve. | Lost attachment or broken link. | Yes |
| TEST-IMP-003 | FR-IMP-003 | recovery | Y | Immediate rollback restores the pre-import vault. | Committed import batch | — | `import rollback`. | Vault hash equals pre-import hash; sources withdrawn. | Residue or over-deletion. | Yes |

## Non-functional measurements

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-NFR-001 | NFR-001 | performance |  | Search latency at S2. | Synthetic S2 corpus indexed | 200 queries (Arabic, English, mixed) | Benchmark harness timing. | p50 and p95 reported with hardware; compared with target. | Not measured (never 'pass by assumption'). | Yes |
| TEST-NFR-006 | NFR-006 | recovery |  | Timed restore drill. | Backup at S2 | — | Measure restore-test duration; record newest restore-tested backup age. | Duration and age reported against RPO/RTO. | Not measured. | Partial |
| TEST-NFR-007 | NFR-007 | retrieval |  | Quality gate on the labelled benchmark. | Pilot corpus ingested; BENCH-1 labelled by the owner | Holdout split | `eval run`. | Per-language metrics reported with confidence intervals; gate decision recorded in ADR-005/006. | Metrics invented or reported without corpus. | Partial |
| TEST-NFR-008 | NFR-008 | performance |  | Ingestion throughput. | Synthetic corpus | — | Timed batch ingest. | Documents per minute reported. | Not measured. | Yes |
| TEST-NFR-010 | NFR-010 | unit |  | Static quality gates. | — | — | mypy --strict; ruff; coverage. | Clean; coverage reported. | Errors. | Yes |
| TEST-NFR-011 | NFR-011 | unit |  | Dependency policy. | — | pyproject.toml, lockfile | Count runtime dependencies; verify hashes present. | Within limit; all hashed. | Unpinned or extra dependency. | Yes |
| TEST-NFR-012 | NFR-012 | performance |  | Capacity at S2 and S3. | Synthetic corpora | — | Ingest, index, search; record sizes and timings. | Measurements recorded against HLD §9 estimates; thresholds updated. | Not measured. | Partial |
| TEST-NFR-013 | NFR-013 | unit |  | Error catalogue completeness. | — | Error catalogue | Assert every error code has cause and next-step text in both output modes. | Complete. | Missing text. | Yes |
| TEST-NFR-015 | NFR-015 | unit |  | Search payload budget and no model client. | FX-CORPUS-S indexed | Queries with many long hits | Check payload size estimate; static scan for model API clients. | Payload within budget with truncation notice; scan clean. | Over budget silently. | Yes |
| TEST-NFR-016 | NFR-016 | unit |  | Output without colour. | — | NO_COLOR set | Run commands; snapshot. | No ANSI sequences; statuses in words. | Colour-only status. | Yes |
| TEST-NFR-017 | NFR-017 | acceptance |  | CLI works without Claude Code and Obsidian. | Environment without both applications | — | Run journeys J1, J2, J10 via CLI only. | All complete. | Any dependency on either application. | Yes |

## Acceptance journeys

| Test ID | Requirements | Type | Adv | Purpose | Preconditions | Test data | Procedure | Expected result | Failure conditions | Automation |
|---|---|---|---|---|---|---|---|---|---|---|
| TEST-ACC-001 | NFR-013 | acceptance |  | J1 Import a document. | Operating workspace | FX-DOCX-AR dropped in inbox | Owner asks Claude to process the inbox; reviews source note in Obsidian. | Source registered, note created, extraction report shown, nothing verified automatically. | Journey needs more than 2 commands or creates verified memory. | Partial |
| TEST-ACC-002 | NFR-013 | acceptance |  | J2 Search historical knowledge in Arabic and English. | Pilot corpus | 5 owner questions per language | Owner asks; checks 3 citations per answer with `evidence show`. | Answers cite resolvable evidence; outcome class shown. | Uncited claim. | Partial |
| TEST-ACC-003 | FR-RET-005 | acceptance |  | J3 Complex research question with abstention. | Pilot corpus | Question with partial support | Owner asks. | Answer separates supported, unverified and unsupported parts. | Unsupported part asserted. | Manual |
| TEST-ACC-004 | FR-PRJ-005 | acceptance |  | J4/J5 Create and resume a project. | — | — | Create project; add items; 'resume' in a new session after closing. | New session reconstructs state from records with IDs. | State invented. | Partial |
| TEST-ACC-005 | FR-PRJ-004 | acceptance |  | J6 Record a decision with evidence. | Pilot corpus | — | Record, approve, later supersede. | History shows both with links. | Earlier decision lost. | Partial |
| TEST-ACC-006 | FR-MEM-007 | acceptance |  | J7 Correct outdated information. | Verified memory | New source | Owner asks to correct. | Proposal with diff; after approval, history preserved. | Silent overwrite. | Partial |
| TEST-ACC-007 | FR-MEM-005 | acceptance |  | J8 Detect contradictory evidence. | FX-DEADLINE | — | Ingest contradicting source; ask the question. | Outcome contradictory with both sources cited until resolved. | One side hidden. | Partial |
| TEST-ACC-008 | FR-AGT-004 | acceptance |  | J9 Execute an approved workflow. | Queue of 5 proposals | — | Review and batch-approve 3, reject 2. | 3 applied, 2 rejected, all audited. | Unapproved applied. | Partial |
| TEST-ACC-009 | FR-OPS-010 | acceptance |  | J10 Recover from failure. | Backup exists | Simulated loss of the data directory | Follow runbook RB-02. | Workspace restored; doctor --deep passes; time recorded. | Runbook step missing. | Manual |
