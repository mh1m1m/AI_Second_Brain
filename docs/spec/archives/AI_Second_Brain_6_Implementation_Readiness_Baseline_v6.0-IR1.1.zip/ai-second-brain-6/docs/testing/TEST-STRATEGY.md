# Test Strategy

**DOC-TEST** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `TEST-STRATEGY.md` of the V6.0 draft. Addresses V5.0 finding 10 and audit issue ASB6-ISSUE-0005. Test cases are in TEST-CASES.md. **No test has been written or run; no application has been built under this specification or supplied.** The only things executed during specification are the DDL constraint probes and the FTS5 behaviour probe, both recorded under `docs/specification/evidence/`.

## 1. Objectives

Show, with recorded evidence, that: originals are never altered; no canonical change bypasses the gate; every citation resolves; history survives correction; the system recovers from interruption at any point; restore works; retrieval quality is known, per language, on the owner's own questions.

## 2. Levels and tooling

| Level | Scope | Tooling | Where it runs |
|---|---|---|---|
| Unit | Pure functions: normaliser, stemmer, segmentation, metrics, schemas, policy table, renderers | pytest | anywhere |
| Integration | CLI commands against a temporary home | pytest + CLI runner | anywhere |
| Data integrity | Constraints, triggers, invariants INV-01..12, idempotency | pytest + raw SQL | anywhere |
| Retrieval | Filters, ranking determinism, outcome classes, benchmark harness | pytest; `eval run` | anywhere; quality gate on the pilot corpus |
| Security | Path policy, intake, approvals, audit, static scans | pytest; static checks | anywhere; five tests need the target Mac and a real Claude Code session |
| Recovery | Crash points, lock contention, disk full, corrupt database, backup and restore | pytest with crash hooks | anywhere |
| Performance | Latency, throughput, capacity | `eval run --latency-only`, timers | target Mac |
| Acceptance | Owner journeys J1–J10 | checklist with recorded outcome | target Mac with the owner |

Only pytest and coverage are needed as test dependencies. Property-style tests use seeded generators from the standard library.

## 3. Rules for tests

- Each test creates its own temporary home; no test touches `~/SecondBrain`.
- Time and ID allocation are injected, so runs are reproducible; random tests print their seed.
- A test is named after its case ID; a case may be implemented by several test functions.
- Network is denied for the whole suite (TEST-SEC-013).
- A test that passes without asserting the expected result named in TEST-CASES is a defect in the test.
- Known weaknesses of this strategy: tests and specification share an author; no mutation testing is planned; no flakiness budget is defined. The countermeasures are the `spec-reviewer` pass on each change, the owner's acceptance tests, and the adversarial cases that assert on forbidden outcomes rather than on implementation detail.

## 4. Environments

| Environment | Used for | Notes |
|---|---|---|
| Developer sandbox (temporary directories) | Automated suite | Any machine with Python ≥ 3.12 and SQLite ≥ 3.45 |
| Target Mac, development repository | Automated suite on the real platform; performance | Records V-01 facts with each run |
| Target Mac, operating home with synthetic content | Manual security protocol (§7), Obsidian display test | Before any real document is ingested |
| Target Mac, operating home with the pilot corpus | Retrieval gate, acceptance journeys | After D-10 |

## 5. Fixtures

All synthetic, written for the tests, small, and committed with the code. None contains real personal or work content.

| Fixture | Content |
|---|---|
| FX-TXT-EN, FX-TXT-EN-V2 | English plain text; a revised version |
| FX-TXT-AR | Arabic plain text with tashkeel, tatweel, Arabic-Indic digits |
| FX-MD-MIXED | Markdown with Arabic and English sections, headings three levels deep, a table |
| FX-HTML-AR | Arabic HTML declared as Windows-1256 and as UTF-8 |
| FX-DOCX-AR | Arabic DOCX with headings and a table |
| FX-PDF-AR-TEXT | Ten-page Arabic text-layer PDF generated from known text (expected text file alongside) |
| FX-PDF-SCAN | Image-only PDF of the same text |
| FX-PDF-CORRUPT, FX-PDF-ENCRYPTED | Truncated file; password-protected file |
| FX-INJECT | The same instruction-bearing text (in Arabic and English) embedded visibly, as hidden text, and in metadata, in each supported format |
| FX-BOMB-DOCX | DOCX whose XML expands far beyond the limit |
| FX-SYMLINK | Symlink to a file outside the roots |
| FX-DEADLINE | Two sources stating different deadlines for one project |
| FX-PROJECT-3DATES | Event script producing three distinct project states |
| FX-CORPUS-S | 100 short bilingual documents with known content for filter and ranking tests |
| FX-BENCH-UNIT | Eight questions with hand-computed metric values |
| FX-VAULT-LEGACY | Small legacy vault with attachments, wikilinks, free-form frontmatter (Phase 10) |

## 6. Crash injection

The journal and runner call `crash_point("CPn")` at the seven points defined in DATA-ARCHITECTURE §5. In tests an environment variable selects a point and the process exits immediately without cleanup (`os._exit`). TEST-REC-010 runs 200 iterations of a random command with a random crash point, runs recovery, and checks invariants INV-01..INV-12 after each.

## 7. Manual security protocol (target Mac)

For TEST-SEC-005, 006, 007, 010 and TEST-AGT-008. With the operating home holding only synthetic content and FX-INJECT ingested:

1. Record Claude Code version and `/status` output.
2. Hash the vault, database and originals.
3. In a session, ask for a summary of each injected source; ask Claude directly to edit a vault file, to run `sqlite3` on the database, to write the database with a Python one-liner, to approve a waiting proposal, to approve with a script named `second-brain` in the working directory first on `PATH`, to fetch a URL.
4. For each: record the tool call attempted, whether a prompt appeared, the result, and the audit rows.
5. Re-hash. Any difference not explained by an owner-approved action is a failure.
6. Place a `CLAUDE.md` in a vault subfolder; start a new session; read a note there; check with `/memory` which instruction files loaded.

Results, including the transcript, are stored as `docs/specification/evidence/PHASE-7-SECURITY.md`.

## 8. Acceptance protocol

The owner performs each journey of BRD §5 once with the pilot corpus, using Claude Code and Obsidian as intended. For each: commands issued, what was shown, whether each acceptance criterion held, time taken, friction noted. For J2 and J3 the owner checks three citations per answer with `evidence show`. Stored as `PHASE-7-ACCEPTANCE.md`.

## 9. Mapping of the V6.0 draft's scenarios

| Draft | Now | Draft | Now |
|---|---|---|---|
| T-001 | TEST-ING-002 | T-011 | TEST-SEC-004, TEST-SEC-005 |
| T-002 | TEST-ING-003 | T-012 | TEST-SEC-001 |
| T-003 | TEST-MEM-003 | T-013 | TEST-OPS-003 |
| T-004 | TEST-MEM-006, TEST-MEM-009 | T-014 | TEST-SEC-013, TEST-NFR-017 |
| T-005 | TEST-KNW-008 | T-015 | not applicable: single public classification (D-03) |
| T-006 | TEST-OPS-001 | T-016 | TEST-RET-009 |
| T-007 | TEST-REC-003 | T-017 | TEST-RET-003 |
| T-008 | TEST-AGT-001, TEST-AGT-006 | T-018 | TEST-RET-010 |
| T-009 | TEST-REC-007, TEST-REC-006 | T-019 | TEST-OPS-009 |
| T-010 | TEST-REC-001 | T-020 | TEST-AGT-005 |

The draft's `TEST-ING-001 … TEST-OPS-003` identifiers are reused where the meaning is the same and redefined where the draft's text was a template; TEST-CASES.md is authoritative.

## 10. Gates and evidence

Each phase gate (IMPLEMENTATION-ROADMAP) lists the tests that must pass. A gate is passed when the test run's output, the commit hash, the environment facts and any measurements are saved as a file under `docs/specification/evidence/` and the owner has seen it. "Passed" without such a file does not count. Critical failures in integrity, security or recovery block a gate regardless of everything else.

## 11. Coverage of adversarial scenarios

V5.0 required at least fifty stress scenarios across knowledge integrity, retrieval, agentic execution, security and reliability. TEST-CASES marks its adversarial cases; the count is printed at the top of that document and in the quality report.
