# Security Architecture

**DOC-SEC** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `SECURITY-ARCHITECTURE.md` and `THREAT-CONTROL-MATRIX.md` of the V6.0 draft. Addresses V5.0 finding 8 and audit issues ASB6-ISSUE-0003, 0014 and 0015.

## 1. What is being protected

The owner has classified all content as public information with no secrecy level (decision D-03, 2026-11-10). That changes the priorities, not the need for controls:

| Property | Priority | Why |
|---|---|---|
| Integrity of knowledge | Highest | The system's value is that verified statements are true to their sources. False memory is the main harm |
| Availability and recoverability | High | Loss of the corpus, history or evidence chain |
| Integrity of the machine | High | Claude Code runs commands with the owner's privileges; ingested documents are attacker-controlled text |
| Confidentiality of sources | Low by classification | Public content. No classification tiers or segregation follow from D-03 |
| Confidentiality of the owner's own data | Moderate | Queries, preferences, decisions and notes are created by the owner inside the system and are not "public documents". They stay on the Mac and in backups, which is why an encrypted backup volume is recommended (D-06; correction CHG-028) |

Assumptions that would invalidate this design if they changed: A-03 the content stays public (if non-public material is ever added, confidentiality controls must be designed first); the Mac's user account is not shared; the owner is the only approver.

## 2. Trust boundaries

| Zone | Trust | Contents | May cause |
|---|---|---|---|
| Z0 Outside | Untrusted | Source documents before ingestion; any web content | Nothing directly |
| Z1 Stored content | Untrusted data | Originals, passages, vault note text (including text Claude wrote) | Nothing: it is only ever read as data by deterministic code |
| Z2 Claude Code session | Semi-trusted: capable, well-intentioned, but steerable by text it reads | Model, tools, session context | Read-only CLI calls; proposals; approval *requests* |
| Z3 CLI and database constraints | Trusted code | Validation, policy, commit protocol, triggers | All authoritative writes |
| Z4 Owner | Trusted | Decisions, approvals, terminal | Tier 1 and tier 2 approvals; configuration |
| Z5 Backups | Trusted storage | Copies | Restore (tier 2) |

Boundary rules: content crosses Z0→Z1 only through intake checks; Z1 text reaches Z2 only inside delimiters or JSON string fields; Z2 reaches authoritative data only through Z3; consequential changes need Z4.

## 3. Egress paths

Complete list of ways data can leave the machine in version 1:

1. Claude Code session context sent to Anthropic for inference: includes any CLI output and any note the session reads. Inherent to using Claude Code; acceptable for public content.
2. Backups written to the destination the owner configures.
3. Exports the owner creates.
4. The vault's Git history, if the owner adds a remote (not configured by the system; D-16).
5. Package index access during an owner-approved dependency installation in the development repository.

The Python package opens no network connection (FR-SEC-006). The operating session has WebFetch and WebSearch denied and an empty sandbox network allowlist.

## 4. Threats and controls

Enforcement column: **OS** = operating-system mechanism (file modes, Seatbelt sandbox); **CC** = Claude Code permission or sandbox configuration; **CODE** = deterministic check in the CLI; **DB** = SQLite constraint or trigger; **DETECT** = found after the fact; **INSTR** = instruction to the model only (not a security boundary).

| # | Threat | Attack surface | Control | Enforcement | Test | Residual risk |
|---|---|---|---|---|---|---|
| S1 | Instructions hidden in a document make Claude change knowledge | Ingested PDF, DOCX, HTML, Markdown | Text delivered as delimited data; tier 1/2 changes need owner approval bound to a proposal hash; proposal note shows statement beside evidence | CODE + DB (gate); INSTR (data rule) | TEST-SEC-004, TEST-SEC-005 | A plausible but wrong proposal that the owner approves |
| S2 | Injected instructions make Claude run harmful shell commands | Same | Sandbox on with no network and write access limited to the working directory minus vault, data, config; protected paths; bypass and auto modes disabled | OS via CC | TEST-SEC-006, V-04 | Reads of files outside the home by sandboxed commands (public content; no secrets expected on this path; `denyRead` can be added) |
| S3 | A file placed in the vault is loaded as Claude Code instructions or configuration | `CLAUDE.md`, `AGENTS.md`, `.claude/`, `.mcp.json` under vault or data | Refused at intake and note creation; `claudeMdExcludes`; doctor critical finding | CODE + CC + DETECT | TEST-SEC-009, TEST-SEC-010, V-07 | Owner copies such a file in by hand between doctor runs |
| S4 | Claude's file tools write the vault or database directly | Edit, Write, NotebookEdit | Deny rules on `/vault/**`, `/data/**`, `/config/**`, `/.claude/**` | CC | TEST-SEC-006, V-03 | Misconfiguration; mitigated by `workspace verify` |
| S5 | A script written by Claude writes the database or vault | Bash tool (`python -c`, `sqlite3`) | Sandbox `denyWrite`; only the installed CLI is excluded from the sandbox | OS via CC | TEST-SEC-006, TEST-SEC-007, V-04, V-05 | Depends on V-05; fallback documented in CLAUDE-CODE-CONTRACTS §5 |
| S6 | Claude approves its own proposal | `proposals approve` | `ask` rule forces a human prompt; tier 2 needs a terminal and typed confirmation; approval is hash-bound, single-use, expiring | CC + CODE + DB | TEST-AGT-001..008, TEST-SEC-007, V-06 | Owner accepts a prompt without reading (tier 1) |
| S7 | Direct SQL changes state | Database file | Triggers T1–T10; audit hash chain; schema-hash check | DB + DETECT | TEST-MEM-002, TEST-SEC-011, TEST-SEC-012 | **RT-S01:** any process running as the owner outside the sandbox can rewrite the file and the chain together. Not preventable with one OS account; chain head in each backup makes it detectable against yesterday |
| S8 | Hand-edited note frontmatter changes governed state | Vault | Managed keys are projections; drift report | CODE | TEST-KNW-007 | none |
| S9 | Path traversal or symlink escape on intake | CLI path arguments, inbox | Real-path confinement, symlink rejection, descriptor-relative opens | CODE | TEST-SEC-001, TEST-SEC-002 | Narrow race window |
| S10 | Hostile file exhausts memory or time, or exploits a parser | Extractors | Type allowlist by signature, size and time limits, no archives, no shell, pinned parsers, quarantine | CODE | TEST-SEC-008, TEST-SEC-015 | Code-execution bug in a parser library (runs as owner; see S14) |
| S11 | FTS5 query syntax injection | Search input | Terms always emitted as quoted strings; parameters bound | CODE | TEST-RET-002 | none known |
| S12 | Secrets leak into repository, vault, logs, exports | Configuration, logs | No secrets exist in v1; config rejects secret patterns; logs carry identifiers only; pre-commit scan | CODE + DETECT | TEST-SEC-003, TEST-OPS-012 | none in v1 |
| S13 | Malicious or over-privileged MCP server or Obsidian plugin | Integrations | None installed; doctor inventory; tier 2 + ADR to add | DETECT + process | TEST-SEC-014 | Owner installs one outside the process |
| S14 | Compromised dependency | Python packages | Few dependencies, pinned with hashes; installation is an explicit owner step | process | TEST-NFR-011 | No continuous vulnerability monitoring |
| S15 | Backup lost, corrupted or stale | Backup destination | Manifest hashes; verification after write; scheduled restore-test; age checks | CODE + DETECT | TEST-OPS-003..006 | Single destination until the owner adds a second |
| S16 | Browser automation follows hostile pages | — | Not present (4.0's Playwright proposal is not carried forward) | absence | TEST-SEC-014 | — |
| S17 | Bidirectional-text tricks hide content in titles or filenames | Notes, filenames | Override characters rejected in titles, filenames, identifiers | CODE | TEST-KNW-004 | Overrides inside body text are kept and reported |
| S18 | Operating instructions or settings are altered | `CLAUDE.md`, `.claude/` | Edit denied; sandbox-protected paths; hash verification | CC + OS + DETECT | TEST-AGT-011 | Owner's own `settings.local.json` can add allow rules (deny and ask still win); listed by DOC-SEC-05 |
| S20 | A skill from outside the project replaces or supplements a Second Brain skill, grants itself tools, or runs shell commands when loaded | Personal, synced and plugin skills; directories added to a session | Proposed under D-20: unique names; Second Brain skills carry no tool grants, hooks, forks or load-time shell commands; inventory and name-collision check; synced skills off; the vault is never added as a directory. Backend authorisation does not depend on what any skill says | CC + DETECT + CODE | V-15; test to be added on approval | A hostile skill installed by the owner is found only at the next check |
| S19 | Claude answers from invention and cites real IDs | Session output | `evidence show` resolves any citation; acceptance tests sample answers | DETECT (manual) | TEST-ACC-002, TEST-ACC-003 | Cannot be prevented, only checked |

## 5. Layered write enforcement

No single layer is sufficient; each covers what the others cannot.

| Layer | Mechanism | Stops | Does not stop |
|---|---|---|---|
| L1 | Operating-system sandbox for Bash (Seatbelt, configured through Claude Code) | Scripts and tools started by Claude writing vault, data, config or reaching the network | Claude's built-in file tools; excluded commands; anything outside a Claude session |
| L2 | Claude Code permission rules (deny, ask) with bypass and auto modes disabled | Built-in file tools writing protected paths; unprompted approval commands; web tools; subagents | Arbitrary programs (that is L1's job) |
| L3 | CLI policy gate | Changes without a valid, hash-bound, unexpired, unconsumed approval for their tier; tier 2 from a non-terminal | A caller who is the owner |
| L4 | Database constraints and triggers | Illegal states and transitions, unsupported verification, edits to history, even from raw SQL | Someone dropping the triggers |
| L5 | Detection: audit chain, schema hash, workspace hashes, doctor, backups holding earlier chain heads | Silent tampering going unnoticed | The tampering itself |

**Invariant (stated explicitly in IR1.1).** No skill, prompt, instruction file, hook or permission prompt is the sole control for a consequential write. A change to canonical data happens only through the CLI policy gate (L3) against an approval row that is bound to the proposal hash, unexpired and unconsumed, and inside the database constraints (L4). A skill can make an operation easier to start; it cannot make it permitted. Turning off model invocation of a skill limits when that skill loads, not what Claude can attempt with its tools.

**Controls that prompts cannot provide and that therefore are not left to prompts:** who may write which path (L1, L2); whether an approval exists (L3, L4); what state a record may be in (L4); whether history was edited (L4, L5); network access (L1, L2). What is left to instructions, knowingly: treating delimited text as data, citation discipline, search budgets, tone and format.

## 6. Prompt-injection posture

Assume any session that has read source text may be steered. Therefore: such a session can propose anything and apply nothing consequential; it has no network; it cannot change its own instructions, settings or skills; it cannot start other agents; everything it does through the CLI is audited. The data rule in `CLAUDE.md` and `.claude/rules/` lowers the rate of steering; it is not counted as a control.

## 7. Credentials

None in version 1. Claude Code's own authentication is managed by Claude Code and is not read by this system. A future integration stores its secret in the macOS Keychain and references it by name.

## 8. Logging restrictions

Logs and audit events contain identifiers, states, counts, durations and codes. They never contain source text, note bodies, statements, queries' result text or file contents. Query text is stored in `query_log` (database), not in log files.

## 9. Data classification

One class: public (D-03). No per-item sensitivity metadata, access filter or encryption follows. The intake workflow does not check rights to a document; the owner attests by ingesting it that they may use it (assumption A-04, audit issue ASB6-ISSUE-0015). If either assumption changes, stop ingestion and revisit this document before continuing.

## 10. Incident response

| Signal | First action | Then |
|---|---|---|
| `audit verify` reports a broken chain; schema hash mismatch; verified record without evidence | Stop using the session; do not approve anything | Runbook RB-06: export current state, compare with the last restore-tested backup, restore or correct by proposals, record an operational memory |
| A file with a forbidden name in the vault (SEC-F01) | Move it to quarantine | Find how it arrived (audit by time), re-run doctor |
| Unexpected proposals in the queue | Reject them | Inspect the session transcript and the source being processed; withdraw the source if hostile |
| Read-only mode | Do not edit files by hand | Runbook RB-04 |

## 11. Verification items for the target Mac

To be executed in TASK-0101 and recorded with outputs; several decide whether a control in §4 holds.

| ID | What to verify | Decides |
|---|---|---|
| V-01 | macOS version, hardware, Python version, `sqlite3.sqlite_version`, FTS5, STRICT tables, JSON functions, WAL on the home volume | NFR-020, schema |
| V-02 | Claude Code version; `settings.json` accepted without warnings (`claude doctor`, `/status`); deny of WebFetch, WebSearch and `Agent(…)` effective | CLAUDE-CODE-CONTRACTS §5 |
| V-03 | `Edit(/vault/**)`-style rules block Edit, Write and NotebookEdit; `Read(/data/db/**)` blocks reads | S4 |
| V-04 | With the sandbox on: `python3 -c` and `sqlite3` cannot write `./vault`, `./data`, `./config`; no network; session exits if the sandbox is unavailable | S2, S5 |
| V-05 | Only the installed CLI path runs unsandboxed; compound commands, environment prefixes and a same-named script in the working directory do not | S5, S6 |
| V-06 | `proposals approve` always prompts in default mode; bypass and auto modes cannot be entered; "don't ask again" does not suppress the ask rule | S6 |
| V-07 | A `CLAUDE.md` placed under `vault/` is not loaded | S3 |
| V-08 | Auto memory is off in the operating home | AGENTIC-ARCHITECTURE §3 |
| V-09 | `fts5_arabic_probe.py` gives the recorded results on the Mac's SQLite | RETRIEVAL-ARCHITECTURE §2 |
| V-10 | Rename is atomic within the home volume; `F_FULLFSYNC` works; staging on the same volume | DATA-ARCHITECTURE §5 |
| V-11 | Obsidian version; generated Arabic, English and mixed notes display correctly; properties show expected types; no community plugin needed | OBSIDIAN-SCHEMAS |
| V-12 | Candidate PDF libraries on Arabic text-layer fixtures: character error rate and reading order | ADR-017, D-09 |
| V-13 | launchd agents run as scheduled, catch up after sleep, and can write the backup destination | FR-OPS-007 |
| V-15 | Inventory of skills, plugins, hooks and MCP servers active in a session started in the operating workspace (project, personal, synced, plugin); which definition wins for each Second Brain skill name; whether a skill's tool grant can suppress an `ask` rule | S20, D-20 |
| V-14 | Skills load from the operating home; `allowed-tools` behaves as documented; workspace trust dialog lists the allow rules | AGENTIC-ARCHITECTURE §6 |

## 12. Residual risks accepted in this baseline

RT-S01 (single OS account); RT-S05 (skills from outside the project, until D-20 is decided and V-15 run); owner approving without reading; parser vulnerabilities inside limits; model fabricating a citation; no continuous dependency monitoring; one backup destination. Each is listed in IMPLEMENTATION-READINESS §5 for the owner's explicit acceptance.
