# Security Assurance Report

**DOC-SAR** · v6.0-IR1.1 · 2026-11-10 · Status: ASSURANCE REPORT · Owner: Mohammed Alsaleh

Specification-level review. It adds no control; it shows, for each sensitive capability, which layer enforces the control and what is still uncertain. Layers L1 to L5 are those of SECURITY-ARCHITECTURE §5. **Nothing here has been verified on the owner's Mac.** A prompt instruction is never counted as a control.

## 1. Capabilities

| Capability | Threat | Trust boundary | Required control | Layer | Failure behaviour | Audit evidence | Acceptance | Remaining uncertainty |
|---|---|---|---|---|---|---|---|---|
| Configuration discovery | A file inside knowledge content is loaded as instructions | Session folder / vault | Vault outside the session folder (AM-04, awaits D-07); exclusion setting; instruction-bearing and configuration file names refused in data areas (FR-SEC-004) | L2 + tool | File quarantined at intake; `doctor` fails if one appears in the vault | Rejection event | V-07; tests of FR-SEC-004 | Version-dependent; layout awaits D-07 |
| Project and personal settings | A user-level or local setting relaxes the workspace rules | Workspace settings / user settings | Workspace files installed and hash-verified by the tool; bypass and auto modes disabled by setting | L2 + L5 | `doctor` fails on a hash mismatch | Workspace hashes | V-02, V-06 | Precedence between user and project settings on the installed version; managed settings would be stronger and are not used |
| Skills and their provenance | A skill from outside the project grants tools or runs shell commands at load | Project skills / personal, synced, plugin, bundled skills | Invariant: skills grant nothing; policy gate and triggers decide. Rules of D-20 (awaiting owner) | L2 to L4; L5 inventory | Unexpected source: `doctor` fails | Inventory record | V-14, V-15; one test on approval of D-20 | Whether a foreign skill's tool grant can suppress an `ask` rule |
| Skill name collisions | A same-named personal skill replaces the project's | Same | `brain-` prefix; collision check | L5 | `doctor` fails | Inventory record | V-15 | Documented precedence, unverified locally |
| Hooks | A user-level hook runs with full user permissions outside the sandbox | Claude Code process / operating system | No hook in the workspace; inventory of user-level hooks | L5 | `doctor` fails on an unexpected hook | Inventory record | V-15 | A hook added later is found only at the next check |
| MCP servers | A server injects content or acts outside the sandbox | Session / external process | None installed; any addition is tier 2 plus an ADR; inventory | L2 + L5 | `doctor` fails on an unexpected server | Inventory record | V-15; TEST-SEC-014 | User-scope servers unverified |
| External network | Exfiltration; injected content from fetched pages | Workspace / internet | Web tools denied; sandbox network allowlist empty; the package has no network code | L1 + L2 + tool | Bash network call blocked; web tool call denied | Measure of NFR-009 | V-02, V-04; tests of FR-SEC-006 | Built-in tools are outside the sandbox and rely on deny rules |
| Prompt injection | Source text instructs Claude | Untrusted content / instructions | Content handed over as delimited data (an instruction, knowingly); the consequence is bounded because injected text cannot write without an approval | L3 + L4 bound the effect | At most a proposal is created; it needs the owner | Proposal and audit events | Tests of FR-SEC-003 | The owner approving a poisoned proposal without reading it (RT-A02) |
| Filesystem authority | A direct write to the vault or data, bypassing the tool | Claude Code tools / data | Sandbox write denial; deny rules for file tools; path policy in the tool | L1 + L2 + tool | Write blocked | — | V-03, V-04, V-05; tests of FR-SEC-001 | One OS account: a process outside a session can write (RT-S01) |
| Approval replay | An approval is reused or attached to a different change | Proposal / approval | Approval rows bound to the payload hash, single-use, expiring; triggers | L3 + L4 | Refused with the approval-required error; nothing applied | Approval, denial and expiry events | TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-AGT-008 | Designed, not executed |
| Unauthorised canonical writes | Raw SQL or a file edit changes governed state | Owner's account / data | Triggers; audit hash chain; schema hash; drift detection | L4 + L5 | Integrity error; read-only mode on unknown state | Chain break recorded | TEST-MEM-002, TEST-SEC-011, TEST-SEC-012 | Detection only against the file owner |
| Data egress | Content leaves the machine | Machine / outside | No network, no integrations, logs without content (FR-OPS-008) | L1 + L2 + tool | — | — | NFR-009 | Text Claude reads in a session is sent to the model provider; that is inherent in ADR-001 and is the owner's to accept |
| Backup encryption | The backup disk is lost or stolen | Home / backup device | Volume-level encryption (awaits D-06) | Operating system | Without the passphrase the copy is unreadable | Restore drill record | Restore drill including unlock | Owner decision pending |
| Recovery key management | The passphrase is lost | — | Keychain plus an offline recovery copy; unlock step in every drill | Procedure | Backups unusable | Drill record | Restore drill | A procedure, not a technical control |
| Obsidian plugin boundary | A community plugin runs code with access to the vault | Obsidian / data | Core plugins only in the installed configuration; Obsidian holds no approval authority; a plugin's edit is an ordinary file edit handled by sync and drift rules | L4 + L5 | Managed-field edits ignored and reported | Drift report | V-11 | A plugin the owner installs can change the body of human notes; recovery is by history and backup |

## 2. Configuration trust boundaries

| Location | Trust | Written by | Loaded by Claude Code as configuration | Control |
|---|---|---|---|---|
| Development repository (`CLAUDE.md`, `.claude/`) | Trusted | Owner, development sessions | Yes, in development sessions only | Version control |
| Operating workspace (instructions, rules, settings, skills) | Trusted, hash-verified | The tool, tier 2 | Yes | `workspace verify`, `doctor` |
| `~/.claude` (user settings, personal skills, hooks, MCP servers, plugins) | Owner-controlled, outside this baseline | Owner | Yes, in every session | Inventory (V-15), `doctor` |
| Skills synced from claude.ai | Outside this baseline; can change remotely | The account | Yes, unless switched off | Off for this workspace (D-20) |
| Bundled skills | Supplied with Claude Code | — | Yes | Prefix avoids name collisions |
| Vault | **Untrusted as configuration**, authoritative as content | Owner, the tool | Must not be | Outside the session folder (AM-04); exclusions; file-name policy; V-07 |
| Inbox, originals, staging, quarantine | Untrusted | Owner, the tool | No | Path policy; never executed |
| Backup device | Protected copy | The tool | No | Separate device; encryption (D-06) |
| Obsidian configuration | Owner's interface settings | Obsidian | No | Core plugins only |

## 3. Evidence classes

- **Documented** (Claude Code and Obsidian documentation read on 2026-11-10): sandbox scope; rule order deny, ask, allow; settings to disable bypass and auto modes; nested instruction and skill discovery; skill sources and precedence; plugin skill namespacing; bundled skills; `skillOverrides`; behaviour of non-interactive and bare runs.
- **Version-dependent**: every item above. Re-verify after each Claude Code upgrade (DEPLOYMENT-SPECIFICATION).
- **Locally verified**: none.
- **Executed in the specification sandbox**: database constraints and triggers (27 probes); the Arabic tokenizer probe.
- **Unverified assumptions**: precedence of user over project settings for each key used; interaction of a skill's tool grant with an `ask` rule; where the synced-skills switch is honoured. `skillOverrides`, bare mode and safe mode are not relied on.

Minimum Claude Code configuration for the baseline: default permission mode; bypass and auto modes disabled; deny rules for file tools on protected paths, web tools and subagents; `ask` rules on approving commands; sandbox on and required; no hooks, MCP servers or plugins; auto memory off; six skills that grant nothing.

## 4. Skills review (20 points of the directive)

| Points | Covered by |
|---|---|
| Project-local, personal, synced, plugin, added-directory skills; discovery; untrusted locations | CLAUDE-CODE-CONTRACTS §4.1; threat S20; V-15; D-20; vault never added as a directory |
| Name collisions | `brain-` prefix; collision check (AM-05) |
| Permissions, `allowed-tools`, `disallowed-tools` | Second Brain skills carry no tool grants; permissions live in settings |
| Dynamic shell injection, hooks, forked subagents, background execution | Not used by Second Brain skills (AM-05); foreign skills caught by inventory |
| Context compaction | No invariant lives in skill text; controls are L1 to L4 |
| Versioning, provenance | Skills installed and hash-verified by the tool with the workspace |
| Evaluation | Owner acceptance journeys in Phase 7 |
| Synchronisation | Synced skills off for the workspace (D-20) |

No new ADR is needed: ADR-015 and ADR-018 cover skills once amended by AM-05.

## 5. Obsidian

1. Claude Code does not open vault files directly under the recommended layout; it reads note text through the tool.
2. Python reads and writes vault files under the path policy and the commit protocol.
3. Claude Code loads configuration only from the session folder and the user's own configuration, never from the vault.
4. Obsidian displays Markdown and properties and edits human notes.
5. Obsidian plugins execute their own code; none is installed by this design.
6. A native integration between Claude Code and Obsidian is not part of the baseline and would need an ADR.

Obsidian is a presentation and editing interface. It is not an execution or authorisation boundary.

## 6. Material security issues still open at specification level

- D-06 (encryption), D-07 (layout), D-11 (research folder), D-20 (skill rules): proposals awaiting the owner; amendments AM-01, AM-04, AM-05, AM-06 not applied.
- All enforcement on the Mac: UNVERIFIED (V-01 to V-15).
- Accepted limits to confirm: one OS account (RT-S01); approval without reading (RT-A02).
