# 500-Slot Coverage Matrix

**DOC-SLOTS** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

The adversarial assurance directive defines 25 domains of 20 investigation questions. The audit package marked all 500 UNVERIFIED because no implementation was supplied. That remains true for implementation. This matrix adds what can be assessed from the specification alone, and keeps the two questions apart.

**No slot is a confirmed defect of an implementation. The existence of an implementation is not established: none was supplied or verified.** Column 'Implementation' is PENDING for all 500.

Specification-level status:

| Code | Meaning | Count |
|---|---|---:|
| SPECIFIED | The revised specification answers the question with a requirement or contract and, where applicable, a designed test. Whether an implementation honours it is unknown | 366 |
| PARTLY SPECIFIED | Addressed with a stated limitation, a residual risk, an advisory-only control, or a value that awaits measurement | 98 |
| OWNER DECISION PENDING | Cannot be closed in the specification until the owner decides (DECISIONS-FOR-APPROVAL) | 10 |
| OPEN SPECIFICATION FINDING | A genuine weakness of this baseline that the author could not close; listed in ADVERSARIAL-REVIEW | 4 |
| NOT APPLICABLE IN V1 | The thing the question is about is excluded from version 1 by a recorded decision | 22 |

Limits of this assessment: it was made by the author of the revised specification, in one pass, by reading each question against the documents. 'SPECIFIED' means a specific place in the specification answers the question; it is not a claim that the answer is right. The reference column lets a reviewer check each one.

## Summary by domain

| # | Domain | Specified | Partly | Decision | Open finding | N/A v1 |
|---|---|---:|---:|---:|---:|---:|
| 01 | Business objectives and product value | 13 | 6 | 0 | 0 | 0 |
| 02 | Requirements engineering | 14 | 5 | 1 | 0 | 0 |
| 03 | Architecture and component boundaries | 16 | 4 | 0 | 0 | 0 |
| 04 | Canonical data authority | 20 | 0 | 0 | 0 | 0 |
| 05 | Filesystem and transaction integrity | 18 | 2 | 0 | 0 | 0 |
| 06 | Sqlite database engineering | 15 | 5 | 0 | 0 | 0 |
| 07 | Obsidian integration | 16 | 2 | 1 | 0 | 1 |
| 08 | Source ingestion | 15 | 4 | 0 | 0 | 1 |
| 09 | Knowledge representation | 15 | 5 | 0 | 0 | 0 |
| 10 | Memory lifecycle | 18 | 2 | 0 | 0 | 0 |
| 11 | Temporal knowledge | 17 | 0 | 1 | 1 | 1 |
| 12 | Sqlite fts5 and retrieval | 13 | 6 | 0 | 0 | 1 |
| 13 | Agentic rag | 13 | 7 | 0 | 0 | 0 |
| 14 | Claude code orchestration | 8 | 7 | 0 | 0 | 5 |
| 15 | Agentic workflow execution | 19 | 0 | 0 | 0 | 1 |
| 16 | Security and trust boundaries | 12 | 5 | 1 | 0 | 2 |
| 17 | Privacy and data governance | 7 | 6 | 3 | 0 | 4 |
| 18 | Knowledge graph and entity resolution | 17 | 3 | 0 | 0 | 0 |
| 19 | Project and decision intelligence | 16 | 3 | 0 | 0 | 1 |
| 20 | Testing and evaluation | 15 | 4 | 1 | 0 | 0 |
| 21 | Reliability and recovery | 17 | 1 | 2 | 0 | 0 |
| 22 | Performance and scalability | 9 | 8 | 0 | 0 | 3 |
| 23 | Deployment and environment | 16 | 2 | 0 | 0 | 2 |
| 24 | Observability and operations | 16 | 4 | 0 | 0 | 0 |
| 25 | Methodology, governance and system evolution | 11 | 7 | 0 | 3 | 0 |

## Domain 01 — Business objectives and product value

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 1 | Primary user problem is precisely defined | SPECIFIED | BRD §1 |  | PENDING |
| 2 | System solves an actual recurring problem | PARTLY SPECIFIED | BRD §1; TEST-ACC-001..009 | Recurrence is asserted by the owner, not measured; 30-day usage review proposed (RT-M05) | PENDING |
| 3 | Business objectives are measurable | SPECIFIED | BRD §2; TRACEABILITY §1 |  | PENDING |
| 4 | Success metrics are observable | SPECIFIED | BRD §2 measures |  | PENDING |
| 6 | Proposed features introduce unnecessary complexity | PARTLY SPECIFIED | ADVERSARIAL-REVIEW §4 S-01..S-10 | Simplification candidates listed | PENDING |
| 7 | Product assumes unrealistic user behavior | PARTLY SPECIFIED | D-10; TASK-0406 | Labelling 100+ benchmark questions is real owner effort | PENDING |
| 8 | Manual review requirements become operational bottlenecks | PARTLY SPECIFIED | FR-AGT-004; TEST-ACC-008 | Tiering and batch review reduce load; unmeasured | PENDING |
| 9 | User journeys cover exceptional situations | SPECIFIED | BRD §5 journeys J1-J10 (alternative and exception flows) |  | PENDING |
| 10 | System supports interrupted work | SPECIFIED | FR-AGT-002; FR-OPS-005 |  | PENDING |
| 11 | Project continuity is demonstrable | SPECIFIED | FR-PRJ-001; TEST-PRJ-002; TEST-ACC-004 |  | PENDING |
| 12 | Decision history remains understandable | SPECIFIED | FR-PRJ-004; TEST-PRJ-006 |  | PENDING |
| 13 | Users can identify authoritative information | SPECIFIED | FR-RET-005; DATA-ARCHITECTURE §2 |  | PENDING |
| 14 | User corrections propagate appropriately | SPECIFIED | FR-MEM-007; FR-RET-007 |  | PENDING |
| 15 | System creates excessive maintenance work | PARTLY SPECIFIED | FR-OPS-007; FR-MEM-010 | Maintenance load unmeasured | PENDING |
| 16 | Features overlap without justification | SPECIFIED | PRD §2 (feature-to-surface table) |  | PENDING |
| 17 | Critical capabilities lack acceptance criteria | SPECIFIED | TRACEABILITY §4 (0 untested) |  | PENDING |
| 18 | Scope boundaries are sufficiently explicit | SPECIFIED | BRD §7; PRD MoSCoW |  | PENDING |
| 19 | Product can deliver value before advanced features exist | SPECIFIED | ROADMAP phases 2-4 deliver ingest and search first |  | PENDING |
| 20 | Proposed architecture is proportionate to the actual workload | PARTLY SPECIFIED | ADVERSARIAL-REVIEW §4; RT-M01 | 28 tables and 78 requirements for a single user; justified per table, still large | PENDING |

## Domain 02 — Requirements engineering

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 21 | Missing functional requirements | PARTLY SPECIFIED | SRS | 78 FRs; completeness cannot be proven, only reviewed | PENDING |
| 22 | Ambiguous requirement language | PARTLY SPECIFIED | SRS | 'shall' statements reviewed once by the author; independent review pending (RT-M02) | PENDING |
| 23 | Non-atomic requirements | PARTLY SPECIFIED | SRS | Several requirements bundle related clauses (e.g. FR-RET-003, FR-OPS-004); testable but not strictly atomic | PENDING |
| 24 | Contradictory requirements | SPECIFIED | tools/spec_lint.py; ADVERSARIAL-REVIEW §1 | No contradiction found by lint or review | PENDING |
| 25 | Duplicate requirements | SPECIFIED | spec_lint duplicate-ID check |  | PENDING |
| 26 | Requirements without business justification | SPECIFIED | every FR has `rationale` and `traces_to` |  | PENDING |
| 27 | Requirements without owners | PARTLY SPECIFIED | SRS | Single owner; accountable component named; no per-requirement human owner field | PENDING |
| 28 | Requirements without acceptance criteria | SPECIFIED | every FR has `acceptance` |  | PENDING |
| 29 | Requirements without tests | SPECIFIED | TRACEABILITY §4 |  | PENDING |
| 30 | Requirements without implementation tasks | SPECIFIED | TRACEABILITY §4 |  | PENDING |
| 31 | Architecture components without requirements | SPECIFIED | TRACEABILITY §4 (0 orphan components) |  | PENDING |
| 32 | Hidden assumptions presented as requirements | SPECIFIED | READINESS §4 assumptions register |  | PENDING |
| 33 | Unapproved requirements treated as approved | SPECIFIED | all requirements marked PROPOSED |  | PENDING |
| 34 | Missing exception behavior | SPECIFIED | every FR has `exceptions` |  | PENDING |
| 35 | Missing concurrency requirements | SPECIFIED | FR-AGT-002; DATA-ARCHITECTURE §6; TEST-REC-007 |  | PENDING |
| 36 | Missing data retention requirements | OWNER DECISION PENDING | D-06; DATA-ARCHITECTURE §8 | Retention periods proposed, not approved | PENDING |
| 37 | Missing recovery requirements | SPECIFIED | FR-OPS-005; FR-OPS-002; FR-OPS-010 |  | PENDING |
| 38 | Unmeasurable nonfunctional requirements | SPECIFIED | SRS §3 (every NFR has target and measurement) |  | PENDING |
| 39 | Broken traceability relationships | SPECIFIED | spec_lint |  | PENDING |
| 40 | Requirements whose implementation cannot be objectively verified | PARTLY SPECIFIED | TEST-SEC-005; TEST-ACC-003 | Model-behaviour requirements verified by manual protocol only | PENDING |

## Domain 03 — Architecture and component boundaries

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 41 | Unclear subsystem responsibilities | SPECIFIED | HLD §3; LLD |  | PENDING |
| 42 | Circular dependencies | SPECIFIED | LLD §2 dependency rule (layers point downward) | Verify with import-linter at implementation | PENDING |
| 43 | Excessive coupling | SPECIFIED | LLD §2 |  | PENDING |
| 44 | Unnecessary abstraction layers | SPECIFIED | ADR-016; ADVERSARIAL-REVIEW §4 | objects registry is the one deliberate abstraction | PENDING |
| 45 | Premature microservices | SPECIFIED | ADR-008 (modular monolith, no services) |  | PENDING |
| 46 | Components with overlapping ownership | SPECIFIED | DATA-ARCHITECTURE §2 authority map |  | PENDING |
| 47 | Hidden runtime dependencies | PARTLY SPECIFIED | V-01; D-09 | SQLite build and PDF library are environment-dependent | PENDING |
| 48 | Undefined trust boundaries | SPECIFIED | SECURITY-ARCHITECTURE §2 |  | PENDING |
| 49 | Unclear failure isolation | SPECIFIED | HLD §8 failure handling |  | PENDING |
| 50 | Unnecessary network dependencies | SPECIFIED | FR-SEC-006 |  | PENDING |
| 51 | Architectural single points of failure | PARTLY SPECIFIED | HLD §8 | Single machine, single database file by design; mitigated by backup | PENDING |
| 52 | Missing extension contracts | SPECIFIED | LLD §9 extension points (extractors, proposal types, normaliser versions) |  | PENDING |
| 53 | Inconsistent synchronous/asynchronous behavior | SPECIFIED | all operations synchronous CLI calls |  | PENDING |
| 54 | Unbounded resource consumption | PARTLY SPECIFIED | FR-SEC-008; NFR-012 | Per-file limits specified; database growth unbounded until measured | PENDING |
| 55 | Unnecessary background processes | SPECIFIED | FR-AGT-008 (no daemon; launchd jobs only) |  | PENDING |
| 56 | Poor module cohesion | SPECIFIED | LLD §3 module table |  | PENDING |
| 57 | Inconsistent error propagation | SPECIFIED | CLI-SPECIFICATION §5 error catalogue |  | PENDING |
| 58 | Missing lifecycle ownership | SPECIFIED | DATA-ARCHITECTURE §2 (write owner per data class) |  | PENDING |
| 59 | Architecture decisions unsupported by evidence | PARTLY SPECIFIED | ADR-REGISTER | Evidence is documentation and probes; no benchmark yet | PENDING |
| 60 | Simpler architectures that satisfy the same requirements | SPECIFIED | ADR-011 (alternatives A-F) |  | PENDING |

## Domain 04 — Canonical data authority

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 61 | Multiple competing sources of truth | SPECIFIED | DATA-ARCHITECTURE §2 |  | PENDING |
| 62 | Undefined ownership of source metadata | SPECIFIED | DATA-ARCHITECTURE §2 row 2 |  | PENDING |
| 63 | Undefined ownership of knowledge notes | SPECIFIED | DATA-ARCHITECTURE §2 row 4 |  | PENDING |
| 64 | Undefined ownership of memory revisions | SPECIFIED | DATA-ARCHITECTURE §2 row 6 |  | PENDING |
| 65 | Undefined ownership of relationships | SPECIFIED | DATA-ARCHITECTURE §2 row 7 |  | PENDING |
| 66 | Derived data treated as canonical | SPECIFIED | FR-OPS-001; NFR-021 |  | PENDING |
| 67 | Inconsistent stable identifiers | SPECIFIED | ADR-016; DATABASE-SCHEMA objects |  | PENDING |
| 68 | Duplicate canonical records | SPECIFIED | UNIQUE constraints; TEST-ING-002; TEST-KNW-002 |  | PENDING |
| 69 | Missing schema versions | SPECIFIED | schema_migrations; `schema_version` frontmatter; norm_version |  | PENDING |
| 70 | Ambiguous update ownership | SPECIFIED | DATA-ARCHITECTURE §4 sync rules |  | PENDING |
| 71 | Missing conflict-resolution rules | SPECIFIED | DATA-ARCHITECTURE §4; FR-KNW-005 |  | PENDING |
| 72 | Incorrect synchronization assumptions | SPECIFIED | DATA-ARCHITECTURE §4 (no watcher assumed; explicit `notes sync`) |  | PENDING |
| 73 | Stale derived indexes | SPECIFIED | FR-RET-007; TEST-REC-003 |  | PENDING |
| 74 | Untracked manual Markdown edits | SPECIFIED | FR-KNW-004; TEST-KNW-005 |  | PENDING |
| 75 | Database changes not reflected in notes | SPECIFIED | FR-KNW-005 projection |  | PENDING |
| 76 | Notes deleted without reconciliation | SPECIFIED | FR-KNW-004; TEST-KNW-006 |  | PENDING |
| 77 | Metadata divergence | SPECIFIED | FR-KNW-005; TEST-KNW-007 |  | PENDING |
| 78 | Broken referential integrity | SPECIFIED | foreign keys; DDL probe P22 |  | PENDING |
| 79 | Missing reconciliation audit trails | SPECIFIED | note_revisions; audit_events |  | PENDING |
| 80 | Inability to reconstruct authoritative state | SPECIFIED | FR-KNW-009; FR-OPS-001 |  | PENDING |

## Domain 05 — Filesystem and transaction integrity

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 81 | Interrupted writes | SPECIFIED | DATA-ARCHITECTURE §5; TEST-REC-001..004 |  | PENDING |
| 82 | Partial file replacement | SPECIFIED | atomic replace; TEST-REC-001 |  | PENDING |
| 83 | SQLite transaction rollback failure | SPECIFIED | FR-OPS-006; TEST-OPS-009 |  | PENDING |
| 84 | File/database divergence | SPECIFIED | DATA-ARCHITECTURE §5; TEST-REC-010 |  | PENDING |
| 85 | Missing write-ahead recovery protocol | SPECIFIED | journal_ops |  | PENDING |
| 86 | Non-idempotent retries | SPECIFIED | FR-AGT-002; TEST-AGT-005 |  | PENDING |
| 87 | Duplicate transaction execution | SPECIFIED | idempotency_key UNIQUE |  | PENDING |
| 88 | Unsafe temporary files | SPECIFIED | staging inside home, mode 0700; TEST-REC-004 |  | PENDING |
| 89 | Cross-device atomicity assumptions | SPECIFIED | DATA-ARCHITECTURE §5 rule C-2 (same volume enforced at init) | V-10 | PENDING |
| 90 | Directory synchronization assumptions | PARTLY SPECIFIED | DATA-ARCHITECTURE §5 rule C-3 (directory fsync, F_FULLFSYNC) | Behaviour on the target volume unverified (V-10) | PENDING |
| 91 | Concurrent writers | SPECIFIED | writer lock; TEST-REC-007 |  | PENDING |
| 92 | Race conditions | PARTLY SPECIFIED | TEST-SEC-002; TEST-REC-006 | Check-then-open race reduced with descriptor-relative opens; residual TOCTOU for external editors | PENDING |
| 93 | Unsafe file locks | SPECIFIED | DATA-ARCHITECTURE §6 (flock on lock file, released by the OS on process death) |  | PENDING |
| 94 | Interrupted migrations | SPECIFIED | TEST-OPS-009 |  | PENDING |
| 95 | Stale lock recovery | SPECIFIED | DATA-ARCHITECTURE §6 (no stale lock possible with flock) |  | PENDING |
| 96 | Incorrect operation ordering | SPECIFIED | DATA-ARCHITECTURE §5 ordering S0-S7 |  | PENDING |
| 97 | Missing transaction identifiers | SPECIFIED | workflow_runs.id; correlation_id |  | PENDING |
| 98 | Missing recovery checkpoints | SPECIFIED | workflow_runs.step, checkpoint_json |  | PENDING |
| 99 | Unverified crash consistency | SPECIFIED | TEST-REC-010 | Unverified until implemented | PENDING |
| 100 | Reconciliation that can silently destroy valid data | SPECIFIED | recovery never deletes originals or owner edits; TEST-REC-006 |  | PENDING |

## Domain 06 — Sqlite database engineering

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 101 | Missing primary keys | SPECIFIED | DATABASE-SCHEMA |  | PENDING |
| 102 | Missing foreign keys | SPECIFIED | DATABASE-SCHEMA |  | PENDING |
| 103 | Disabled foreign-key enforcement | SPECIFIED | connection pragma; doctor DOC-DB-02 |  | PENDING |
| 104 | Incorrect uniqueness constraints | SPECIFIED | DDL probes P13, P14 |  | PENDING |
| 105 | Invalid CHECK constraints | SPECIFIED | DDL executed; 27 probes |  | PENDING |
| 106 | Inappropriate NULL semantics | SPECIFIED | DATABASE-SCHEMA §3 nullability notes |  | PENDING |
| 107 | Missing indexes | PARTLY SPECIFIED | DATABASE-SCHEMA §4 | Indexes chosen from representative queries; no query-plan measurement yet | PENDING |
| 108 | Excessive indexes | PARTLY SPECIFIED | DATABASE-SCHEMA §4 | 17 indexes; write cost unmeasured | PENDING |
| 109 | Unbounded table growth | PARTLY SPECIFIED | DATA-ARCHITECTURE §8 | audit_events and project_events grow without bound by design; query_log pruned | PENDING |
| 110 | Incorrect transaction isolation assumptions | SPECIFIED | DATA-ARCHITECTURE §6 (single writer, WAL snapshot readers) |  | PENDING |
| 111 | SQLite locking behavior | SPECIFIED | busy_timeout; TEST-REC-007 |  | PENDING |
| 112 | WAL configuration assumptions | PARTLY SPECIFIED | DATABASE-SCHEMA §1 | WAL on APFS assumed; verify V-01 | PENDING |
| 113 | Backup inconsistency | SPECIFIED | FR-OPS-003 (online backup API); TEST-OPS-005 |  | PENDING |
| 114 | Schema migration incompatibility | SPECIFIED | FR-OPS-006; TEST-OPS-010 |  | PENDING |
| 115 | Unsafe rollback assumptions | SPECIFIED | rollback = restore pre-migration backup; TEST-OPS-009 |  | PENDING |
| 116 | Incorrect timestamp storage | SPECIFIED | UTC ISO 8601 text; CHECK-free by design, validated in application | Format not enforced by CHECK (RT-D07) | PENDING |
| 117 | Inconsistent identifier types | SPECIFIED | TEXT ids with GLOB check |  | PENDING |
| 118 | Missing deletion propagation | SPECIFIED | DATA-ARCHITECTURE §8; FR-RET-007 | No ON DELETE CASCADE: rows are never deleted, states change | PENDING |
| 119 | Query-plan degradation | PARTLY SPECIFIED | TASK-0801 | Not analysed | PENDING |
| 120 | Database corruption detection and recovery | SPECIFIED | doctor DOC-DB-01; TEST-REC-009 |  | PENDING |

## Domain 07 — Obsidian integration

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 121 | Vault path discovery | SPECIFIED | config `vault` under home; no discovery |  | PENDING |
| 122 | Vault portability | SPECIFIED | vault is plain Markdown; NFR-003 |  | PENDING |
| 123 | Markdown compatibility | SPECIFIED | OBSIDIAN-SCHEMAS §1 (CommonMark plus wikilinks, block anchors) |  | PENDING |
| 124 | YAML frontmatter validation | SPECIFIED | FR-KNW-001 |  | PENDING |
| 125 | Unsupported metadata properties | SPECIFIED | OBSIDIAN-SCHEMAS §3 (flat properties only; no nested YAML) |  | PENDING |
| 126 | Filename collisions | SPECIFIED | FR-KNW-003 E_CONFLICT; NFC rule |  | PENDING |
| 127 | Wikilink resolution | SPECIFIED | FR-KNW-008 |  | PENDING |
| 128 | Renamed notes | SPECIFIED | FR-KNW-004; TEST-KNW-006 |  | PENDING |
| 129 | Deleted notes | SPECIFIED | FR-KNW-004; TEST-KNW-006 |  | PENDING |
| 130 | Moved attachments | PARTLY SPECIFIED | OBSIDIAN-SCHEMAS §7 attachments | Attachments are unmanaged files backed up with the vault; moves are not tracked | PENDING |
| 131 | Duplicate note identities | SPECIFIED | TEST-KNW-002 |  | PENDING |
| 132 | Manual edits during indexing | SPECIFIED | TEST-REC-006 |  | PENDING |
| 133 | Obsidian closed during operations | SPECIFIED | NFR-017 |  | PENDING |
| 134 | Plugin compatibility assumptions | SPECIFIED | FR-OBS-001 (core plugins only) |  | PENDING |
| 135 | Plugin security exposure | SPECIFIED | FR-SEC-007; doctor DOC-SEC-04 |  | PENDING |
| 136 | Sync conflicts | OWNER DECISION PENDING | D-12 | No sync in v1; conflict-copy filenames reported by validate rule OBS-R16 | PENDING |
| 137 | Broken backlinks | SPECIFIED | FR-KNW-008 |  | PENDING |
| 138 | Incorrect relative paths | SPECIFIED | paths stored relative to vault root, NFC |  | PENDING |
| 139 | Vault migration integrity | NOT APPLICABLE IN V1 | FR-IMP-001..003 | Future capability; fresh vault (D-04) | PENDING |
| 140 | Obsidian interface behavior differing from application assumptions | PARTLY SPECIFIED | TEST-OBS-005; V-11 | Obsidian behaviour verified only by manual test on the target Mac | PENDING |

## Domain 08 — Source ingestion

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 141 | Duplicate documents | SPECIFIED | FR-ING-004 |  | PENDING |
| 142 | Near-duplicate documents | PARTLY SPECIFIED | RETRIEVAL-ARCHITECTURE §5 | Only exact-hash deduplication; near-duplicates collapse at passage level by text hash | PENDING |
| 143 | Corrupted documents | SPECIFIED | TEST-ING-011 |  | PENDING |
| 144 | Unsupported formats | SPECIFIED | FR-ING-005 |  | PENDING |
| 145 | Password-protected files | SPECIFIED | TEST-ING-011 |  | PENDING |
| 146 | Incomplete extraction | SPECIFIED | FR-ING-009 |  | PENDING |
| 147 | Lost tables | PARTLY SPECIFIED | RETRIEVAL-ARCHITECTURE §3 | DOCX tables extracted row-wise; PDF table structure is lost; benchmark has a table stratum | PENDING |
| 148 | Lost headings | SPECIFIED | FR-ING-007; locator heading_path |  | PENDING |
| 149 | Incorrect reading order | PARTLY SPECIFIED | TEST-ING-010 | Arabic PDF reading order is the main extraction risk; measured in spike V-12 | PENDING |
| 150 | Missing attachments | PARTLY SPECIFIED | FR-ING-005 | Only the file itself is ingested; linked resources are not fetched | PENDING |
| 151 | Encoding errors | SPECIFIED | FR-ING-007 (charset detection order stated; undecodable bytes fail extraction) |  | PENDING |
| 152 | OCR inaccuracies | NOT APPLICABLE IN V1 | ADR-017; D-09 | OCR deferred; scanned files flagged needs_ocr | PENDING |
| 153 | Oversized files | SPECIFIED | FR-ING-005 |  | PENDING |
| 154 | Archive extraction risks | SPECIFIED | FR-ING-005 (archives rejected) |  | PENDING |
| 155 | Path traversal | SPECIFIED | FR-SEC-001 |  | PENDING |
| 156 | Malicious document content | SPECIFIED | FR-SEC-003; FR-SEC-008 |  | PENDING |
| 157 | Missing provenance | SPECIFIED | FR-ING-001; FR-ING-003 |  | PENDING |
| 158 | Inconsistent source versions | SPECIFIED | FR-ING-006 |  | PENDING |
| 159 | Partial ingestion recovery | SPECIFIED | FR-AGT-002; TEST-REC-001 |  | PENDING |
| 160 | Incorrect duplicate-content handling | SPECIFIED | TEST-ING-002; TEST-ING-006 |  | PENDING |

## Domain 09 — Knowledge representation

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 161 | Overly broad knowledge records | PARTLY SPECIFIED | skill propose-memory guidance | One statement per record is guidance, not a rule | PENDING |
| 162 | Excessively fragmented notes | PARTLY SPECIFIED | ADR-012 (memory digests by subject) |  | PENDING |
| 163 | Inconsistent entity names | SPECIFIED | FR-KNW-007 |  | PENDING |
| 164 | Ambiguous relationship types | SPECIFIED | KNOWLEDGE-GRAPH §3 predicate definitions |  | PENDING |
| 165 | Unsupported claims | SPECIFIED | FR-MEM-002 |  | PENDING |
| 166 | Incorrect source attribution | PARTLY SPECIFIED | FR-RET-002; TEST-RET-003 | Locator correctness tested; whether the passage supports the statement is a human judgement at approval | PENDING |
| 167 | Missing temporal context | SPECIFIED | memory_revisions validity fields |  | PENDING |
| 168 | Missing uncertainty representation | SPECIFIED | epistemic_type; states; no numeric confidence (MEMORY-ARCHITECTURE §7) |  | PENDING |
| 169 | Conflicting taxonomies | SPECIFIED | controlled vocabularies in CHECK constraints |  | PENDING |
| 170 | Unclear ontology governance | SPECIFIED | vocabulary change = migration + ADR (KNOWLEDGE-GRAPH §3) |  | PENDING |
| 171 | Circular knowledge references | SPECIFIED | supersession cycle rejected; TEST-KNW-003 |  | PENDING |
| 172 | Orphan notes | PARTLY SPECIFIED | dashboards list unlinked notes | Informational only | PENDING |
| 173 | Redundant concept records | SPECIFIED | FR-KNW-007; FR-MEM-011 |  | PENDING |
| 174 | Untraceable interpretations | SPECIFIED | attestation derived + derivation_json |  | PENDING |
| 175 | Facts mixed with predictions | SPECIFIED | FR-MEM-004; TEST-MEM-004 |  | PENDING |
| 176 | Unsupported confidence scores | SPECIFIED | no confidence scores stored |  | PENDING |
| 177 | Incorrect entity merging | SPECIFIED | TEST-KNW-011 |  | PENDING |
| 178 | Missing entity disambiguation | PARTLY SPECIFIED | FR-KNW-007 | Disambiguation is by owner at merge; no automatic resolver | PENDING |
| 179 | Uncontrolled schema evolution | SPECIFIED | schema_version; migrations |  | PENDING |
| 180 | Loss of meaning during normalization | SPECIFIED | stored text never normalised; TEST-RET-004 |  | PENDING |

## Domain 10 — Memory lifecycle

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 181 | False memory creation | SPECIFIED | FR-MEM-002; FR-MEM-003 |  | PENDING |
| 182 | Unsupported factual promotion | SPECIFIED | triggers T3, T4; TEST-MEM-003 |  | PENDING |
| 183 | Silent overwriting | SPECIFIED | FR-MEM-007; TEST-MEM-010 |  | PENDING |
| 184 | Incorrect supersession | SPECIFIED | FR-MEM-006; TEST-MEM-006 |  | PENDING |
| 185 | Missing historical versions | SPECIFIED | memory_revisions immutable |  | PENDING |
| 186 | Temporal contradictions | SPECIFIED | FR-MEM-005 |  | PENDING |
| 187 | Unresolved conflicting evidence | SPECIFIED | state disputed; FR-RET-005 contradictory |  | PENDING |
| 188 | Incorrect preference inference | SPECIFIED | FR-MEM-012; TEST-MEM-015 |  | PENDING |
| 189 | Memory duplication | SPECIFIED | FR-MEM-011 |  | PENDING |
| 190 | Excessive memory retention | PARTLY SPECIFIED | FR-MEM-009; FR-MEM-010 | Archive and review queue exist; no automatic forgetting | PENDING |
| 191 | Missing deletion propagation | SPECIFIED | FR-MEM-009; TEST-RET-010 |  | PENDING |
| 192 | Memory contamination across projects | PARTLY SPECIFIED | project_id filter | Scoping filter, not isolation; content is public (D-03) | PENDING |
| 193 | Stale memory retrieval | SPECIFIED | FR-MEM-010; outcome outdated |  | PENDING |
| 194 | Incorrect verification states | SPECIFIED | FR-MEM-001; TEST-MEM-002 |  | PENDING |
| 195 | Missing approval records | SPECIFIED | approvals table; memory_revisions.proposal_id |  | PENDING |
| 196 | Failed memory reconciliation | SPECIFIED | proposal conflict state; TEST-AGT-006 |  | PENDING |
| 197 | Inconsistent memory identifiers | SPECIFIED | ADR-016 |  | PENDING |
| 198 | Unbounded consolidation | SPECIFIED | FR-MEM-011 (key-equal only) |  | PENDING |
| 199 | Incorrect historical reconstruction | SPECIFIED | FR-MEM-008; TEST-MEM-009 |  | PENDING |
| 200 | Inability to explain why a memory is considered valid | SPECIFIED | `memory show --explain` returns evidence chain and approvals |  | PENDING |

## Domain 11 — Temporal knowledge

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 201 | Event time versus ingestion time confusion | SPECIFIED | event_time vs recorded_at vs source_date |  | PENDING |
| 202 | Missing validity intervals | SPECIFIED | valid_from, valid_to |  | PENDING |
| 203 | Incorrect supersession chronology | SPECIFIED | supersede sets valid_to; TEST-MEM-006 |  | PENDING |
| 204 | Timezone conversion errors | SPECIFIED | UTC storage; local time only in display |  | PENDING |
| 205 | Daylight-saving assumptions | SPECIFIED | no local-time arithmetic |  | PENDING |
| 206 | Ambiguous dates | OPEN SPECIFICATION FINDING | MEMORY-ARCHITECTURE §6; RT-D03 | date_precision and date_text added to the schema; Hijri dates are kept verbatim and not converted. Owner to confirm this is acceptable | PENDING |
| 207 | Future predictions treated as facts | SPECIFIED | FR-MEM-004 |  | PENDING |
| 208 | Historical facts presented as current | SPECIFIED | FR-MEM-010 |  | PENDING |
| 209 | Missing source publication dates | SPECIFIED | source_versions.source_date nullable; shown as unknown |  | PENDING |
| 210 | Incorrect event sequencing | SPECIFIED | project_events ordered by effective_at, seq |  | PENDING |
| 211 | Temporal query failures | SPECIFIED | TEST-MEM-009; TEST-PRJ-002 |  | PENDING |
| 212 | Overlapping validity periods | SPECIFIED | FR-MEM-005 |  | PENDING |
| 213 | Backdated corrections | SPECIFIED | recorded_at separate from validity; TEST-MEM-009 |  | PENDING |
| 214 | Delayed evidence arrival | SPECIFIED | same as 213 |  | PENDING |
| 215 | Out-of-order events | SPECIFIED | project_events effective_at ordering |  | PENDING |
| 216 | Incorrect current-state reconstruction | SPECIFIED | TEST-PRJ-001 |  | PENDING |
| 217 | Missing historical snapshots | SPECIFIED | as-of replay; no stored snapshots needed |  | PENDING |
| 218 | Time-dependent entity relationships | SPECIFIED | relationships.valid_from/valid_to |  | PENDING |
| 219 | Incorrect retention timing | OWNER DECISION PENDING | D-06 |  | PENDING |
| 220 | Temporal metadata lost during migration | NOT APPLICABLE IN V1 | FR-IMP-002 | Future import maps legacy dates to source_date | PENDING |

## Domain 12 — Sqlite fts5 and retrieval

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 221 | Missing indexed content | SPECIFIED | doctor DOC-IDX-02 (unit count reconciliation) |  | PENDING |
| 222 | Stale indexes | SPECIFIED | FR-RET-007 |  | PENDING |
| 223 | Incorrect tokenization | SPECIFIED | FR-RET-003; evidence probe |  | PENDING |
| 224 | Arabic retrieval weaknesses | PARTLY SPECIFIED | RETRIEVAL-ARCHITECTURE §2 | Normaliser and light stemmer specified and probed; broken plurals and clitic chains still missed; quality unmeasured (NFR-007) | PENDING |
| 225 | Mixed-language retrieval | PARTLY SPECIFIED | RETRIEVAL-ARCHITECTURE §7 | Cross-language questions rely on query translation by Claude and entity aliases; benchmark stratum defined | PENDING |
| 226 | Exact phrase failures | SPECIFIED | quoted phrase queries; TEST-RET-001 |  | PENDING |
| 227 | Acronym ambiguity | PARTLY SPECIFIED | FR-KNW-007 aliases | No acronym expansion | PENDING |
| 228 | Incorrect ranking | PARTLY SPECIFIED | FR-RET-004 | Weights provisional | PENDING |
| 229 | Poor passage segmentation | PARTLY SPECIFIED | FR-ING-008 | Sizes provisional | PENDING |
| 230 | Lost document structure | SPECIFIED | locator heading_path, page |  | PENDING |
| 231 | Missing metadata filters | SPECIFIED | FR-RET-001 |  | PENDING |
| 232 | Incorrect access filtering | NOT APPLICABLE IN V1 | D-03 | Single classification (public); no access classes | PENDING |
| 233 | Citation locator failures | SPECIFIED | TEST-RET-003 |  | PENDING |
| 234 | Duplicate search results | SPECIFIED | RETRIEVAL-ARCHITECTURE §5 (collapse identical text hashes) |  | PENDING |
| 235 | Empty-result handling | SPECIFIED | outcome no_evidence |  | PENDING |
| 236 | Unbounded query complexity | SPECIFIED | RETRIEVAL-ARCHITECTURE §5 (max 32 terms, 512 characters) |  | PENDING |
| 237 | Query injection or parser misuse | SPECIFIED | TEST-RET-002 |  | PENDING |
| 238 | Poor incremental indexing | SPECIFIED | FR-RET-007 |  | PENDING |
| 239 | Retrieval latency degradation | PARTLY SPECIFIED | NFR-001 |  | PENDING |
| 240 | Inability to rebuild indexes deterministically | SPECIFIED | NFR-021 |  | PENDING |

## Domain 13 — Agentic rag

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 241 | Incorrect query decomposition | PARTLY SPECIFIED | skill answer-with-evidence | Decomposition is model behaviour; guided, not enforced | PENDING |
| 242 | Unnecessary retrieval loops | SPECIFIED | skill budget: at most 6 searches per question | Advisory | PENDING |
| 243 | Premature answer generation | SPECIFIED | skill step order; outcome class required before answer | Advisory | PENDING |
| 244 | Evidence cherry-picking | PARTLY SPECIFIED | skill rule: report contradicting hits | TEST-ACC-007 | PENDING |
| 245 | Failure to retrieve contradictory evidence | SPECIFIED | FR-RET-005 contradictory (computed in code, not by the model) |  | PENDING |
| 246 | Unsupported synthesis | PARTLY SPECIFIED | TEST-ACC-003 | Manual verification | PENDING |
| 247 | Citation laundering | SPECIFIED | derived statements cannot be verified; citations must be passage IDs |  | PENDING |
| 248 | Tool-output hallucination | PARTLY SPECIFIED | RT-A04 | Cannot be prevented by design; `evidence show` lets the owner check any citation | PENDING |
| 249 | Context-window truncation | SPECIFIED | NFR-015 payload budget with truncation notice |  | PENDING |
| 250 | Incorrect stopping criteria | SPECIFIED | skill stopping rules | Advisory | PENDING |
| 251 | Excessive tool calls | PARTLY SPECIFIED | skill budget | No hard cap on tool calls in an interactive session | PENDING |
| 252 | Missing retrieval budgets | SPECIFIED | NFR-015 |  | PENDING |
| 253 | Failure to abstain | SPECIFIED | TEST-RET-009; TEST-ACC-003 |  | PENDING |
| 254 | Incorrect confidence statements | SPECIFIED | no confidence numbers; outcome classes only |  | PENDING |
| 255 | Confusion between source claims and verified facts | SPECIFIED | epistemic_type claim vs fact |  | PENDING |
| 256 | Inconsistent answers across repeated queries | PARTLY SPECIFIED | RT-A05 | Retrieval is deterministic; synthesis is not | PENDING |
| 257 | Retrieval of outdated information | SPECIFIED | outcome outdated |  | PENDING |
| 258 | Failure to distinguish project contexts | SPECIFIED | project filter |  | PENDING |
| 259 | Missing execution trace | SPECIFIED | query_log; audit |  | PENDING |
| 260 | Inability to reproduce the evidence-selection process | PARTLY SPECIFIED | query_log.top_units_json | Which hits the model used is not recorded | PENDING |

## Domain 14 — Claude code orchestration

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 261 | Incorrect CLAUDE.md instructions | PARTLY SPECIFIED | CLAUDE-CODE-CONTRACTS §2 | Instruction text specified; effectiveness is model behaviour | PENDING |
| 262 | Conflicting nested instructions | SPECIFIED | FR-SEC-004; claudeMdExcludes; V-07 |  | PENDING |
| 263 | Unsupported configuration keys | SPECIFIED | CLAUDE-CODE-CONTRACTS §8 (every key cited to documentation) | Re-verify on installed version V-02 | PENDING |
| 264 | Incorrect permission configuration | PARTLY SPECIFIED | CLAUDE-CODE-CONTRACTS §5; V-03..V-06 | Rules specified from documentation; behaviour on the target version unverified | PENDING |
| 265 | Unnecessary subagents | SPECIFIED | ADR-008 (no custom subagents in the operating workspace) |  | PENDING |
| 266 | Unbounded subagent execution | PARTLY SPECIFIED | CLAUDE-CODE-CONTRACTS §5 (`Agent` denied) | Rule name to be verified V-02 | PENDING |
| 267 | Missing context boundaries | SPECIFIED | untrusted-content rule; output envelope |  | PENDING |
| 268 | Unsafe hooks | NOT APPLICABLE IN V1 | ADR-015 | No hooks in v1; hooks run unsandboxed | PENDING |
| 269 | Hook failures | NOT APPLICABLE IN V1 | ADR-015 |  | PENDING |
| 270 | MCP tool overprivilege | NOT APPLICABLE IN V1 | ADR-018 | No MCP server in v1 | PENDING |
| 271 | Unverified MCP server behavior | NOT APPLICABLE IN V1 | ADR-018 |  | PENDING |
| 272 | Tool-output injection | PARTLY SPECIFIED | FR-SEC-003 | Delimiters and rule; residual semantic manipulation | PENDING |
| 273 | Incorrect session assumptions | SPECIFIED | AGENTIC-ARCHITECTURE §3 (no state in session) |  | PENDING |
| 274 | Missing durable task state | SPECIFIED | workflow_runs |  | PENDING |
| 275 | Context compaction losses | SPECIFIED | state in database; root CLAUDE.md is re-read after compaction per documentation |  | PENDING |
| 276 | Missing execution budgets | PARTLY SPECIFIED | skill budgets | Advisory only | PENDING |
| 277 | Incorrect task delegation | NOT APPLICABLE IN V1 | no delegation in v1 |  | PENDING |
| 278 | Unreliable approval handling | PARTLY SPECIFIED | FR-AGT-004; V-06 | Tier 1 in-session approval depends on Claude Code prompting; verify | PENDING |
| 279 | Inconsistent tool-result interpretation | PARTLY SPECIFIED | JSON envelope with schema_version | Interpretation is model behaviour | PENDING |
| 280 | Uncontrolled modification of project instructions | SPECIFIED | deny Edit on CLAUDE.md and .claude; sandbox protected paths; `workspace verify` |  | PENDING |

## Domain 15 — Agentic workflow execution

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 281 | Undefined workflow states | SPECIFIED | WORKFLOW-CONTRACTS |  | PENDING |
| 282 | Invalid transitions | SPECIFIED | WORKFLOW-CONTRACTS transition tables |  | PENDING |
| 283 | Missing transition guards | SPECIFIED | WORKFLOW-CONTRACTS guards |  | PENDING |
| 284 | Non-idempotent actions | SPECIFIED | FR-AGT-002 |  | PENDING |
| 285 | Duplicate execution | SPECIFIED | idempotency_key |  | PENDING |
| 286 | Missing cancellation behavior | SPECIFIED | WORKFLOW-CONTRACTS §8 cancellation |  | PENDING |
| 287 | Unsafe retries | SPECIFIED | WORKFLOW-CONTRACTS §8 retry classes |  | PENDING |
| 288 | Lost workflow state | SPECIFIED | workflow_runs persisted before side effects |  | PENDING |
| 289 | Missing checkpoints | SPECIFIED | checkpoint_json |  | PENDING |
| 290 | Unbounded execution loops | SPECIFIED | runs are finite step lists; no loops |  | PENDING |
| 291 | Incorrect timeout handling | SPECIFIED | FR-SEC-008 timeouts |  | PENDING |
| 292 | Missing compensation actions | SPECIFIED | WORKFLOW-CONTRACTS §8 compensation = roll forward, roll back, or new proposal |  | PENDING |
| 293 | Approval bypass | SPECIFIED | FR-AGT-001; TEST-AGT-001..004 |  | PENDING |
| 294 | Incorrect authorization inheritance | SPECIFIED | approval bound to one payload hash; no inheritance |  | PENDING |
| 295 | Unclear human intervention points | SPECIFIED | AGENTIC-ARCHITECTURE §5 tier table |  | PENDING |
| 296 | Partial workflow completion | SPECIFIED | FR-OPS-005 |  | PENDING |
| 297 | Inconsistent audit records | SPECIFIED | NFR-005; TEST-AGT-010 |  | PENDING |
| 298 | Unrecoverable interrupted tasks | SPECIFIED | FR-OPS-005; read-only mode |  | PENDING |
| 299 | External side effects without confirmation | NOT APPLICABLE IN V1 | FR-SEC-006 | No external side effects exist in v1 | PENDING |
| 300 | Failure to distinguish proposed actions from completed actions | SPECIFIED | proposal states vs applied; dashboards |  | PENDING |

## Domain 16 — Security and trust boundaries

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 301 | Prompt injection through documents | PARTLY SPECIFIED | FR-SEC-003; TEST-SEC-004; TEST-SEC-005 | Deterministic layer immune; model layer mitigated, not immune | PENDING |
| 302 | Prompt injection through search results | PARTLY SPECIFIED | FR-SEC-003 | Same residual risk | PENDING |
| 303 | Malicious MCP responses | NOT APPLICABLE IN V1 | ADR-018 |  | PENDING |
| 304 | Unauthorized filesystem access | SPECIFIED | FR-SEC-001; sandbox; V-04 |  | PENDING |
| 305 | Credential exposure | SPECIFIED | FR-SEC-002 (no credentials in v1) |  | PENDING |
| 306 | Secret leakage in logs | SPECIFIED | FR-OPS-008; TEST-OPS-012 |  | PENDING |
| 307 | Unsafe shell execution | SPECIFIED | TEST-SEC-015 |  | PENDING |
| 308 | Path traversal | SPECIFIED | TEST-SEC-001 |  | PENDING |
| 309 | Symlink attacks | SPECIFIED | TEST-SEC-002 |  | PENDING |
| 310 | Excessive file permissions | SPECIFIED | DEPLOYMENT-SPECIFICATION §4 modes |  | PENDING |
| 311 | Unauthorized database modification | PARTLY SPECIFIED | TEST-SEC-006 | Same OS user can always edit the database file; made evident by audit chain and triggers, not prevented (RT-S01) | PENDING |
| 312 | Insecure backup storage | OWNER DECISION PENDING | D-06 | Unencrypted backup proposed because content is public | PENDING |
| 313 | Cross-project information leakage | NOT APPLICABLE IN V1 | D-03 |  | PENDING |
| 314 | Unsafe plugin permissions | SPECIFIED | FR-SEC-007 |  | PENDING |
| 315 | Inadequate approval enforcement | PARTLY SPECIFIED | SECURITY-ARCHITECTURE §5 | Layered; depends on V-04..V-06 | PENDING |
| 316 | Untrusted code execution | SPECIFIED | no eval, no plugin loading, no shell |  | PENDING |
| 317 | Dependency compromise | PARTLY SPECIFIED | NFR-011 | Hash-locked; no ongoing vulnerability monitoring specified | PENDING |
| 318 | Sensitive data in temporary files | SPECIFIED | staging under home; cleaned; content public |  | PENDING |
| 319 | Missing security audit events | SPECIFIED | FR-SEC-005 |  | PENDING |
| 320 | Prompt-level controls incorrectly treated as security boundaries | SPECIFIED | SECURITY-ARCHITECTURE §4 (control-enforcement column) |  | PENDING |

## Domain 17 — Privacy and data governance

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 321 | Missing data classification | SPECIFIED | D-03 decided: public |  | PENDING |
| 322 | Undefined retention policies | OWNER DECISION PENDING | D-06 |  | PENDING |
| 323 | Incomplete deletion semantics | SPECIFIED | FR-MEM-009; DATA-ARCHITECTURE §8 |  | PENDING |
| 324 | Personal data in derived indexes | PARTLY SPECIFIED | assumption A-03 | Public documents can still name people; no per-item privacy metadata | PENDING |
| 325 | Sensitive information in embeddings | NOT APPLICABLE IN V1 | ADR-006 | No embeddings | PENDING |
| 326 | Insecure synchronization | OWNER DECISION PENDING | D-12 |  | PENDING |
| 327 | Unclear external processing boundaries | SPECIFIED | SECURITY-ARCHITECTURE §3 egress paths |  | PENDING |
| 328 | Missing consent or authorization | OWNER DECISION PENDING | D-10; assumption A-04 | Owner attests rights to ingest; no per-source rights field | PENDING |
| 329 | Excessive collection | PARTLY SPECIFIED | owner-driven ingestion |  | PENDING |
| 330 | Inadequate data minimization | PARTLY SPECIFIED | NFR-015 |  | PENDING |
| 331 | Sensitive information in test fixtures | SPECIFIED | synthetic fixtures only |  | PENDING |
| 332 | Uncontrolled export | PARTLY SPECIFIED | FR-KNW-009 | Export is an owner action; no control beyond that | PENDING |
| 333 | Incomplete backup deletion | SPECIFIED | purge report lists backup exposure |  | PENDING |
| 334 | Untracked data replication | PARTLY SPECIFIED | backups and vault Git are the only replicas; listed in data map |  | PENDING |
| 335 | Incorrect project isolation | NOT APPLICABLE IN V1 | D-03 |  | PENDING |
| 336 | Unclear audit retention | SPECIFIED | DATA-ARCHITECTURE §8 (audit kept for the life of the system) |  | PENDING |
| 337 | Missing redaction rules | NOT APPLICABLE IN V1 | D-03 |  | PENDING |
| 338 | Accidental public sharing | PARTLY SPECIFIED | D-16 (vault Git has no remote) | Guidance only | PENDING |
| 339 | Inconsistent privacy metadata | NOT APPLICABLE IN V1 | D-03 |  | PENDING |
| 340 | Inability to determine where sensitive data resides | SPECIFIED | DATA-ARCHITECTURE §3 data map |  | PENDING |

## Domain 18 — Knowledge graph and entity resolution

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 341 | Duplicate entities | SPECIFIED | FR-KNW-007 |  | PENDING |
| 342 | Incorrect entity merges | SPECIFIED | merge by approval only |  | PENDING |
| 343 | Incorrect entity splits | SPECIFIED | KNOWLEDGE-GRAPH §4 (edges not rewritten on merge, so unmerge is a state change) |  | PENDING |
| 344 | Ambiguous identifiers | SPECIFIED | ADR-016 |  | PENDING |
| 345 | Unsupported relationships | SPECIFIED | predicate vocabulary |  | PENDING |
| 346 | Missing relationship provenance | SPECIFIED | evidence_links for relationships |  | PENDING |
| 347 | Invalid relationship types | SPECIFIED | CHECK constraint |  | PENDING |
| 348 | Temporal relationship errors | SPECIFIED | validity window CHECK |  | PENDING |
| 349 | Cyclic relationship assumptions | SPECIFIED | SUPERSEDES and DEPENDS_ON cycle checks | PART_OF cycle check not specified (RT-D05) | PENDING |
| 350 | Broken relationship references | SPECIFIED | foreign keys |  | PENDING |
| 351 | Incorrect graph traversal | PARTLY SPECIFIED | KNOWLEDGE-GRAPH §5 (recursive CTE, depth <= 3) | Untested at scale | PENDING |
| 352 | Overly broad ontology | SPECIFIED | 11 predicates, 7 entity types |  | PENDING |
| 353 | Premature graph database adoption | SPECIFIED | ADR-007 |  | PENDING |
| 354 | Graph and Markdown divergence | SPECIFIED | wikilinks are navigation only; TEST-KNW-009 |  | PENDING |
| 355 | Relationship deletion inconsistencies | SPECIFIED | state retracted, never deleted |  | PENDING |
| 356 | Entity renaming failures | SPECIFIED | aliases |  | PENDING |
| 357 | Missing confidence semantics | SPECIFIED | states, no numeric confidence |  | PENDING |
| 358 | Unbounded graph expansion | PARTLY SPECIFIED | NFR-012 |  | PENDING |
| 359 | Poor multi-hop retrieval | PARTLY SPECIFIED | KNOWLEDGE-GRAPH §5 | Not benchmarked; gate RET-G2 | PENDING |
| 360 | Inability to explain relationship evidence | SPECIFIED | evidence_links; `relations show --explain` |  | PENDING |

## Domain 19 — Project and decision intelligence

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 361 | Missing project state | SPECIFIED | projects.state |  | PENDING |
| 362 | Outdated milestones | SPECIFIED | due_on; status report overdue list |  | PENDING |
| 363 | Incorrect task ownership | SPECIFIED | project_items.assignee (added in this pass) |  | PENDING |
| 364 | Broken dependencies | SPECIFIED | TEST-PRJ-004 |  | PENDING |
| 365 | Missing decision rationale | SPECIFIED | decision note required sections (OBS-R11) |  | PENDING |
| 366 | Decisions without evidence | PARTLY SPECIFIED | FR-PRJ-004 | Evidence optional for decisions; absence is shown | PENDING |
| 367 | Superseded decisions presented as current | SPECIFIED | TEST-PRJ-006 |  | PENDING |
| 368 | Unclear approval status | SPECIFIED | decisions.state |  | PENDING |
| 369 | Incorrect project summaries | PARTLY SPECIFIED | FR-PRJ-005; TEST-ACC-004 | Data cited; prose summary is model output | PENDING |
| 370 | Missing unresolved questions | SPECIFIED | item_type question (added in this pass) |  | PENDING |
| 371 | Untracked risks | SPECIFIED | item_type risk |  | PENDING |
| 372 | Conflicting project records | SPECIFIED | single registry; events |  | PENDING |
| 373 | Missing project isolation | NOT APPLICABLE IN V1 | D-03 |  | PENDING |
| 374 | Incorrect historical reconstruction | SPECIFIED | TEST-PRJ-002 |  | PENDING |
| 375 | Unbounded project context | SPECIFIED | status JSON is bounded and paged |  | PENDING |
| 376 | Lost commitments | SPECIFIED | item_type commitment (added in this pass) |  | PENDING |
| 377 | Missing completion evidence | PARTLY SPECIFIED | state done has an event | Evidence link for completion optional | PENDING |
| 378 | Incorrect dependency ordering | SPECIFIED | TEST-PRJ-004 |  | PENDING |
| 379 | Failure to resume interrupted projects | SPECIFIED | TEST-ACC-004 |  | PENDING |
| 380 | Confusion between recommendations and approved decisions | SPECIFIED | decision state proposed vs accepted; tier 1 |  | PENDING |

## Domain 20 — Testing and evaluation

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 381 | Missing unit tests | SPECIFIED | TEST-CASES | Designed, not written or run | PENDING |
| 382 | Missing integration tests | SPECIFIED | TEST-CASES |  | PENDING |
| 383 | Missing end-to-end tests | SPECIFIED | TEST-ACC-* |  | PENDING |
| 384 | Missing property-based tests | SPECIFIED | TEST-REC-010; TEST-ING-012 |  | PENDING |
| 385 | Missing fault-injection tests | SPECIFIED | TEST-REC-001..010 |  | PENDING |
| 386 | Missing security tests | SPECIFIED | TEST-SEC-001..015 |  | PENDING |
| 387 | Missing concurrency tests | SPECIFIED | TEST-REC-007 |  | PENDING |
| 388 | Missing migration tests | SPECIFIED | TEST-OPS-009; TEST-OPS-010 |  | PENDING |
| 389 | Missing restoration tests | SPECIFIED | TEST-OPS-003; TEST-OPS-004; TEST-OPS-015 |  | PENDING |
| 390 | Missing retrieval benchmarks | OWNER DECISION PENDING | D-10; TASK-0406 | Benchmark protocol specified; corpus and labels do not exist | PENDING |
| 391 | Weak evaluation datasets | PARTLY SPECIFIED | BENCHMARK protocol | Owner-labelled; single annotator | PENDING |
| 392 | Test-data leakage | SPECIFIED | development and holdout splits |  | PENDING |
| 393 | Non-reproducible tests | SPECIFIED | temp homes; fixed clock and ID seeds |  | PENDING |
| 394 | Flaky tests | PARTLY SPECIFIED | TEST-STRATEGY §3 | No flakiness budget defined | PENDING |
| 395 | False-positive test results | PARTLY SPECIFIED | TEST-STRATEGY §3 | Mutation testing not planned | PENDING |
| 396 | Unmeasured coverage | SPECIFIED | NFR-010 |  | PENDING |
| 397 | Tests that merely mirror implementation assumptions | PARTLY SPECIFIED | RT-M02 | Tests are derived from the specification before code exists; same author wrote both | PENDING |
| 398 | Missing negative tests | SPECIFIED | 62 adversarial cases |  | PENDING |
| 399 | Unverified acceptance criteria | SPECIFIED | every acceptance criterion maps to a test |  | PENDING |
| 400 | Release gates that can pass despite critical failures | SPECIFIED | READINESS mandatory blockers |  | PENDING |

## Domain 21 — Reliability and recovery

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 401 | Incomplete backups | SPECIFIED | FR-OPS-003 manifest contents |  | PENDING |
| 402 | Inconsistent database backups | SPECIFIED | TEST-OPS-005 |  | PENDING |
| 403 | Missing source artifacts in backups | SPECIFIED | manifest lists every original by hash |  | PENDING |
| 404 | Missing backup integrity verification | SPECIFIED | FR-OPS-002 |  | PENDING |
| 405 | Untested restoration | SPECIFIED | TEST-OPS-003; drill RB-02 |  | PENDING |
| 406 | Recovery-point objective mismatch | OWNER DECISION PENDING | D-06 |  | PENDING |
| 407 | Recovery-time objective mismatch | OWNER DECISION PENDING | D-06 |  | PENDING |
| 408 | Corrupted restore archives | SPECIFIED | TEST-OPS-004 |  | PENDING |
| 409 | Missing disaster-recovery documentation | SPECIFIED | DEPLOYMENT-SPECIFICATION §9 runbooks |  | PENDING |
| 410 | Unsafe restore overwrites | SPECIFIED | FR-OPS-010; TEST-OPS-015 |  | PENDING |
| 411 | Missing index reconstruction | SPECIFIED | FR-OPS-001 |  | PENDING |
| 412 | Unrecoverable workflow state | SPECIFIED | workflow_runs in the database snapshot |  | PENDING |
| 413 | Missing audit continuity | SPECIFIED | audit chain head in manifest |  | PENDING |
| 414 | Partial restore failures | SPECIFIED | TEST-OPS-015 |  | PENDING |
| 415 | Missing recovery checkpoints | SPECIFIED | restore is verify-then-swap |  | PENDING |
| 416 | Unclear incident ownership | SPECIFIED | owner is the only operator |  | PENDING |
| 417 | Unbounded recovery duration | PARTLY SPECIFIED | NFR-006 | Unmeasured | PENDING |
| 418 | Missing rollback procedures | SPECIFIED | runbooks RB-03, RB-05 |  | PENDING |
| 419 | Inconsistent restored references | SPECIFIED | foreign_key_check and locator sample in restore-test |  | PENDING |
| 420 | Recovery procedures that depend on unavailable services | SPECIFIED | restore needs only Python and the backup |  | PENDING |

## Domain 22 — Performance and scalability

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 421 | Excessive indexing latency | PARTLY SPECIFIED | NFR-008 |  | PENDING |
| 422 | Slow retrieval | PARTLY SPECIFIED | NFR-001 |  | PENDING |
| 423 | Unbounded memory consumption | PARTLY SPECIFIED | FR-SEC-008 | Streaming extraction specified; peak memory unmeasured | PENDING |
| 424 | Large-document processing failures | SPECIFIED | size and time limits |  | PENDING |
| 425 | Excessive token usage | SPECIFIED | NFR-015 |  | PENDING |
| 426 | Inefficient context assembly | SPECIFIED | payload budget |  | PENDING |
| 427 | Excessive disk usage | PARTLY SPECIFIED | HLD §9 estimates | Unmeasured | PENDING |
| 428 | Poor database query plans | PARTLY SPECIFIED | TASK-0801 |  | PENDING |
| 429 | Lock contention | SPECIFIED | single writer; readers unblocked |  | PENDING |
| 430 | Unbounded background queues | NOT APPLICABLE IN V1 | no queues |  | PENDING |
| 431 | Slow vault startup | PARTLY SPECIFIED | V-11 | Obsidian startup with many notes unmeasured | PENDING |
| 432 | Excessive Markdown file counts | SPECIFIED | ADR-012 memory digests bound the number of managed files |  | PENDING |
| 433 | Expensive reindexing | PARTLY SPECIFIED | FR-OPS-001 | Rebuild time unmeasured | PENDING |
| 434 | Poor incremental processing | SPECIFIED | FR-RET-007 |  | PENDING |
| 435 | Unnecessary model calls | SPECIFIED | no model call from Python |  | PENDING |
| 436 | Inefficient caching | NOT APPLICABLE IN V1 | no cache layer |  | PENDING |
| 437 | Cache invalidation errors | NOT APPLICABLE IN V1 | no cache layer |  | PENDING |
| 438 | Missing capacity limits | SPECIFIED | HLD §9 capacity profiles |  | PENDING |
| 439 | Unmeasured scaling thresholds | PARTLY SPECIFIED | NFR-012 | Thresholds are estimates | PENDING |
| 440 | Premature infrastructure complexity | SPECIFIED | ADR-006; ADR-007 |  | PENDING |

## Domain 23 — Deployment and environment

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 441 | Unsupported operating systems | SPECIFIED | macOS only (D-01) |  | PENDING |
| 442 | Python version incompatibility | SPECIFIED | NFR-020; V-01 |  | PENDING |
| 443 | Dependency conflicts | SPECIFIED | NFR-011 |  | PENDING |
| 444 | Missing lockfiles | SPECIFIED | lockfile with hashes |  | PENDING |
| 445 | Unreproducible installation | SPECIFIED | DEPLOYMENT-SPECIFICATION §3 | Unexecuted | PENDING |
| 446 | Incorrect environment variables | SPECIFIED | DEPLOYMENT-SPECIFICATION §5 |  | PENDING |
| 447 | Missing configuration validation | SPECIFIED | config validation at load |  | PENDING |
| 448 | Unsafe default paths | SPECIFIED | init refuses non-empty and system paths |  | PENDING |
| 449 | Incorrect directory permissions | SPECIFIED | DEPLOYMENT-SPECIFICATION §4 |  | PENDING |
| 450 | Missing health checks | SPECIFIED | FR-OPS-004 |  | PENDING |
| 451 | Missing startup diagnostics | SPECIFIED | doctor environment checks |  | PENDING |
| 452 | Missing upgrade procedures | SPECIFIED | DEPLOYMENT-SPECIFICATION §8 |  | PENDING |
| 453 | Unsafe schema upgrades | SPECIFIED | FR-OPS-006 |  | PENDING |
| 454 | Missing downgrade strategy | SPECIFIED | downgrade = restore pre-upgrade backup |  | PENDING |
| 455 | Platform-specific path errors | SPECIFIED | NFC paths; case-insensitive APFS noted |  | PENDING |
| 456 | Incorrect scheduling assumptions | PARTLY SPECIFIED | FR-OPS-007; V-13 | launchd behaviour during sleep to be verified | PENDING |
| 457 | Missing process supervision | NOT APPLICABLE IN V1 | no long-running process |  | PENDING |
| 458 | Inconsistent local and cloud environments | NOT APPLICABLE IN V1 | local only |  | PENDING |
| 459 | Undocumented runtime dependencies | PARTLY SPECIFIED | V-01 |  | PENDING |
| 460 | Installation procedures that cannot be reproduced | SPECIFIED | DEPLOYMENT-SPECIFICATION §3 | Unexecuted | PENDING |

## Domain 24 — Observability and operations

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 461 | Missing structured logs | SPECIFIED | FR-OPS-008 |  | PENDING |
| 462 | Missing correlation identifiers | SPECIFIED | correlation_id everywhere |  | PENDING |
| 463 | Sensitive information in logs | SPECIFIED | TEST-OPS-012 |  | PENDING |
| 464 | Missing operational metrics | PARTLY SPECIFIED | doctor and status files | No metrics system | PENDING |
| 465 | Missing indexing status | SPECIFIED | `index status` |  | PENDING |
| 466 | Missing workflow status | SPECIFIED | `runs` |  | PENDING |
| 467 | Missing database health reporting | SPECIFIED | doctor DOC-DB-* |  | PENDING |
| 468 | Missing backup health reporting | SPECIFIED | doctor DOC-BKP-* |  | PENDING |
| 469 | Missing alerting criteria | PARTLY SPECIFIED | DEPLOYMENT-SPECIFICATION §7 | Dashboard and status file; no push alert | PENDING |
| 470 | Excessive logging | SPECIFIED | log levels; no content |  | PENDING |
| 471 | Unbounded log retention | SPECIFIED | rotation: 10 files of 10 MB |  | PENDING |
| 472 | Missing troubleshooting procedures | SPECIFIED | runbooks |  | PENDING |
| 473 | Missing incident classification | PARTLY SPECIFIED | runbook severity table |  | PENDING |
| 474 | Missing root-cause records | PARTLY SPECIFIED | incident note template |  | PENDING |
| 475 | Inconsistent error messages | SPECIFIED | error catalogue |  | PENDING |
| 476 | Missing user-visible failure states | SPECIFIED | outcome classes and exit codes |  | PENDING |
| 477 | Unclear operational ownership | SPECIFIED | owner |  | PENDING |
| 478 | Missing maintenance procedures | SPECIFIED | DEPLOYMENT-SPECIFICATION §7 maintenance calendar |  | PENDING |
| 479 | Missing audit-event integrity checks | SPECIFIED | `audit verify` |  | PENDING |
| 480 | Inability to distinguish system failure from insufficient evidence | SPECIFIED | E_* errors vs outcome classes are separate channels |  | PENDING |

## Domain 25 — Methodology, governance and system evolution

| Slot | Question | Specification status | Reference | Note | Implementation |
|---:|---|---|---|---|---|
| 5 | DEEP INVESTIGATION PROTOCOL | PARTLY SPECIFIED | PRD §3; FR-AGT-004 | Approval friction untested with real use | PENDING |
| 481 | Specification-driven development becoming documentation theater | OPEN SPECIFICATION FINDING | RT-M01 | Three specification passes and no running code. The next step should be Phase 1, not another document | PENDING |
| 482 | Requirements added without user value | PARTLY SPECIFIED | PRD MoSCoW |  | PENDING |
| 483 | Architecture decisions made without alternatives | SPECIFIED | ADR alternatives |  | PENDING |
| 484 | Technology choices based on popularity | SPECIFIED | ADR evidence fields |  | PENDING |
| 485 | Excessive abstraction | PARTLY SPECIFIED | ADVERSARIAL-REVIEW §4 |  | PENDING |
| 486 | Premature optimization | SPECIFIED | gates before optimisation |  | PENDING |
| 487 | Unnecessary AI agents | SPECIFIED | ADR-008 |  | PENDING |
| 488 | Overreliance on AI-generated specifications | OPEN SPECIFICATION FINDING | RT-M02 | This baseline was written by one model in one session | PENDING |
| 489 | Circular validation by the same model | OPEN SPECIFICATION FINDING | RT-M02 | The adversarial review in this package is by the same author; independent review means the owner and executed tests | PENDING |
| 490 | Insufficient independent review | PARTLY SPECIFIED | RT-M02 |  | PENDING |
| 491 | Uncontrolled scope expansion | PARTLY SPECIFIED | CHANGE-REGISTER | Scope grew from 21 to 100 requirements in this pass; each traced | PENDING |
| 492 | Unclear approval authority | SPECIFIED | owner approves; tiers |  | PENDING |
| 493 | Missing change-impact analysis | SPECIFIED | CHANGE-REGISTER affected-documents column |  | PENDING |
| 494 | Untracked architectural regressions | SPECIFIED | V5-COMPLIANCE-MATRIX |  | PENDING |
| 495 | Missing decision-reversal criteria | SPECIFIED | ADR reversal conditions |  | PENDING |
| 496 | Benchmarks designed to confirm assumptions | PARTLY SPECIFIED | BENCHMARK protocol | Holdout split and unanswerable stratum guard against this; single annotator remains | PENDING |
| 497 | Failure to measure actual user value | PARTLY SPECIFIED | RT-M05 |  | PENDING |
| 498 | Continuous improvement without regression controls | SPECIFIED | benchmark as regression suite |  | PENDING |
| 499 | Declaring readiness without operational evidence | SPECIFIED | READINESS verdict rules |  | PENDING |
| 500 | Inability to explain why the architecture is simpler, safer, and more effective than altern | SPECIFIED | ADR-011 |  | PENDING |
