# Change Register

**DOC-CHG** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Every change from the V6.0 draft (snapshot in `docs/_baseline/`) to this baseline. Approval status of every row: **PENDING** owner approval of the baseline (decision D-18). Valid decisions of the draft are kept: the stack, the authority split, FTS5 first, deferred vector and graph stores, single orchestrator, approval-gated promotion, independent backup, the ten ADR subjects, the phase sequence, the CLI exit codes, and all original requirement IDs.

| ID | Original | Revision | Reason | Affected documents |
|---|---|---|---|---|
| CHG-001 | BRD with 9 requirements | 14 business requirements, 8 measurable objectives, capability model, 10 journeys, 14 enforceable rules | Directive §4; owner decisions on language and classification | BRD, TRACEABILITY-MATRIX |
| CHG-002 | PRD with 10 features | 19 features with problem, behaviour, interaction, failure states; surface table | Directive §5 | PRD |
| CHG-003 | SRS (21) and ATOMIC-REQUIREMENTS (16) | One SRS: 78 functional and 22 non-functional requirements in structured form | Directive §6; duplication | SRS, TRACEABILITY-MATRIX, TEST-CASES |
| CHG-004 | DATA-ARCHITECTURE with `claims` model | Authority map of 15 data classes; layout; sync rules; retention | V5.0 F1; baseline conflict X-1 | DATA-ARCHITECTURE, DATABASE-SCHEMA, OBSIDIAN-SCHEMAS |
| CHG-005 | TRANSACTION-PROTOCOL as a separate file | Merged; change plan stored at intent time; recovery table by crash point; conflict rule; read-only mode | Audit 0008 | DATA-ARCHITECTURE §5, WORKFLOW-CONTRACTS |
| CHG-006 | Draft DDL (15 tables) | Schema v1: 28 tables plus FTS5, 15 triggers, executed and probed | Conflicts X-1..X-4; audit 0014 | DATABASE-SCHEMA |
| CHG-007 | `tokenize='unicode61'`; benchmark blueprint | Application normaliser and stem column; gates RET-G1, RET-G2; nine strata | Probe evidence; owner language decision | RETRIEVAL-ARCHITECTURE, ADR-005 |
| CHG-008 | "Human approval required" | Three approval tiers, two channels, hash-bound single-use approvals | Audit 0014; usability | AGENTIC-ARCHITECTURE, CLI-SPECIFICATION, SECURITY-ARCHITECTURE, ADR-009 |
| CHG-009 | Repository containing `vault/` and `data/` | Separate operating home; CLI installed outside both | Security separation | DATA-ARCHITECTURE §3, DEPLOYMENT-SPECIFICATION, ADR-014 |
| CHG-010 | Security: threat list and "OS sandbox" | Enforcement type per control; five layers; exact Claude Code settings; 14 verification items | V5.0 F8; audit 0003, 0007 | SECURITY-ARCHITECTURE, CLAUDE-CODE-CONTRACTS, ADR-015 |
| CHG-011 | FR-AGT-002 SHOULD | MUST | Crash-safe ingestion depends on it | SRS |
| CHG-012 | TASK-001..016 (two meanings) | Four-digit task IDs TASK-0001..1001; old IDs retired | Conflict X-5 | IMPLEMENTATION-BACKLOG, TRACEABILITY-MATRIX, FILE-BUILD-PLAN |
| CHG-013 | Two roadmaps and PRODUCTION-READINESS | One roadmap with scope, interfaces, controls and gate per phase; readiness criteria in §4 | Duplication | IMPLEMENTATION-ROADMAP |
| CHG-014 | 26 templated test cases; T-001..020 | 142 cases; mapping of T-numbers in TEST-STRATEGY §9 | Audit 0005 | TEST-CASES, TEST-STRATEGY |
| CHG-015 | ADR table of ten lines (two copies) | 20 ADRs with context, alternatives, consequences, evidence, reversal; ADR-005, 009, 010 revised | Directive §23 | ADR-REGISTER |
| CHG-016 | Encrypted backup by default | Encryption optional | Owner: public content | DEPLOYMENT-SPECIFICATION, ADR-010 |
| CHG-017 | Deployment for unknown OS | macOS only | Owner decision | DEPLOYMENT-SPECIFICATION |
| CHG-018 | `tasks` table | `project_items` with six item types and assignee; `project_events` | History and continuity | DATABASE-SCHEMA, SRS FR-PRJ-003 |
| CHG-019 | One note per memory | Memory digests by subject, project or month | File-count growth; readability | OBSIDIAN-SCHEMAS, MEMORY-ARCHITECTURE §12, ADR-012 |
| CHG-020 | Subagents and hooks "optional" | No subagent or hook in the operating workspace; one read-only reviewer in development | V5.0 F4; hooks run unsandboxed | AGENTIC-ARCHITECTURE §7–8 |
| CHG-021 | Legacy vault "new isolated vault" assumption | Fresh vault decided; import specified as future capability FR-IMP-001..003 | Owner decision D-04 | SRS, ADR-019 |
| CHG-022 | Retrieval target Recall@10 ≥ 0.85 (draft) | ≥ 0.90 overall (V5.0) and ≥ 0.85 per language, provisional | No evidence for lowering V5.0's target | SRS NFR-007, BRD §8 |
| CHG-023 | Readiness verdict "NOT READY" with eight blockers | Re-assessed against the directive's mandatory blockers | Decisions received; specification completed | IMPLEMENTATION-READINESS |
| CHG-024 | Audit's 15 findings, all "blocking" except one | Individual dispositions; one blocks specification approval | Owner instruction | GAP-REGISTER §3 |
| CHG-025 | 500 slots all UNVERIFIED | Specification-level status per slot; implementation status still pending for all | Owner instruction | 500-SLOT-COVERAGE |
| CHG-026 | (IR1.1) Status wording "executable application does not exist", "no implementation exists" | "Existence not established; none supplied or verified" | External review: the evidence supports only that none was supplied | IMPLEMENTATION-READINESS, README, GAP-REGISTER, BASELINE-INVENTORY, 500-SLOT-COVERAGE, TEST-CASES, TEST-STRATEGY |
| CHG-027 | (IR1.1) Backup destination "external disk or second internal volume" | Separate physical device required | External review: a volume on the same disk fails with it | DEPLOYMENT-SPECIFICATION §6, DECISIONS-FOR-APPROVAL D-06 |
| CHG-028 | (IR1.1) Confidentiality "low by classification" for all stored data; encryption off | Sources public; owner's own data treated as personal; encrypted backup volume recommended, pending D-06 | External review | SECURITY-ARCHITECTURE §1, DEPLOYMENT-SPECIFICATION §6 |
| CHG-029 | (IR1.1) Skills: project skills assumed to be the only ones in play | Skill supply-chain behaviour documented; threat S20; verification item V-15; decision D-20; amendments proposed, not applied | External review; skills documentation | CLAUDE-CODE-CONTRACTS §4.1, SECURITY-ARCHITECTURE, GAP-REGISTER, ADVERSARIAL-REVIEW |
| CHG-030 | (IR1.1) Amendments mixed with corrections | Amendments that depend on an owner decision listed separately and held (DECISIONS-FOR-APPROVAL section I) | Nothing the owner has not decided is applied | Governance |
| CHG-031 | (IR1.1) One-page decision table | Decision package 2.0: sections A to L, twelve fields per decision, ADR approval matrix, classes OWNER, ENG, COND, DEF, simplification challenge, reconciliation with external reviews | Decision-engineering directive; correction C-26 | DECISIONS-FOR-APPROVAL |
| CHG-032 | (IR1.1) ADR records without dependency or acceptance fields; some without context, consequences or alternatives | All 20 records carry eight fields; no decision changed; dependency cycles avoided | Correction C-09 | ADR-REGISTER |
| CHG-033 | (IR1.1) Proposal queue unbounded; backup first built in Phase 9 | FR-AGT-003 limits and TEST-AGT-013; TASK-0212 in Phase 2 and in the Phase 2 gate; FR-OPS-002 and FR-OPS-003 in Phase 2; separate-device check | GAP-033, GAP-034, GAP-037; corrections C-22 to C-24 | SRS, TEST-CASES, IMPLEMENTATION-BACKLOG, IMPLEMENTATION-ROADMAP, FILE-BUILD-PLAN, CLI-SPECIFICATION, DEPLOYMENT-SPECIFICATION, GAP-REGISTER |
| CHG-034 | (IR1.1) No register of the targeted corrections; no requirement-to-ADR trace; no change manifest with hashes | Six assurance reports and one data file, generated from the package | Targeted-correction directive | TARGETED-CORRECTIONS-REGISTER, ADR-COMPLETENESS-REPORT, REQUIREMENTS-TRACEABILITY-REPORT, SECURITY-ASSURANCE-REPORT, SPECIFICATION-CHANGE-MANIFEST, PRE-IMPLEMENTATION-READINESS-CERTIFICATE |
| CHG-035 | (IR1.1) Mixed version labels; checker without approval, ADR-field, coverage or snapshot checks | One label, v6.0-IR1.1, on every current document; nine checks added to `tools/spec_lint.py`; readiness assessment updated | Correction C-05 | All current documents, spec_lint, IMPLEMENTATION-READINESS |

IR1.1 applied corrections and the two findings the owner's correction directive ordered resolved (GAP-033, GAP-034). The amendments in DECISIONS-FOR-APPROVAL section I are **not** applied; they wait for the owner's answers and will be made in one pass.

Not changed, deliberately: `CLAUDE.md` mode (specification-only). No implementation, installation, migration or deployment was performed.
