# Specification Change Manifest

**DOC-SCM** · v6.0-IR1.1 · 2026-11-10 · Status: ASSURANCE REPORT · Owner: Mohammed Alsaleh

Every file that differs between the delivered v6.0-IR1 archive and v6.0-IR1.1, computed by `gen_assurance.py`. Reasons refer to CHANGE-REGISTER.md. This file and `QUALITY-REPORT.json` (rewritten on every checker run) are excluded from their own listing.

Changed: 41. Added: 17. Removed: 0. Unchanged: 79.

| File | Change | SHA-256 in IR1 | SHA-256 in IR1.1 | Reason |
|---|---|---|---|---|
| `CLAUDE.md` | changed | `0e43c2e67c382339d0ec24a86c4f8c59cd51fbd72c4226b9d6af53b5234c3905` | `f7f1b2a3216e04fbfc4c4ace310ba225ed724dad6f8893228150e916b91af93a` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `README.md` | changed | `b9b48fd7103bd4c04d6bc9c030b5d1fb94c830dbc0def443411aadc0999a6e1d` | `f60a42795905227fa901ce2cc8c011622d4e7d618cfe95641b9101081c1138bf` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/_baseline/external-reviews-2026-11-10/01-review-of-readiness-and-decision-sheet.txt` | added | `—` | `b9634bae5ab00036a818b80b11fca2a35402d4e612bd6738c8ead1cacfc00286` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/external-reviews-2026-11-10/02-review-claude-code-skills.txt` | added | `—` | `990d431429781856cc5fdecd875794217bfffba010fa9e682a0fc5d003b46dfd` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/external-reviews-2026-11-10/03-directive-decision-engineering-v2.0.txt` | added | `—` | `a4a18115fa26a1c50ae6868d7a50536114fc8a9ffe13f7ec6d816e30d7e818b8` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/external-reviews-2026-11-10/04-evidence-limited-proposed-decision-sheet.md` | added | `—` | `5f22e25b2b247fd7a42c90b5bbe3dad324102475729f0f14197fd9241c57b819` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/external-reviews-2026-11-10/05-directive-targeted-corrections-C01-C32.txt` | added | `—` | `7936936a219772c37f3933d72378b5ec4452ed4bddf5ea35e8161c0cd2078f08` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/v6.0-IR1-decision-register/ADR-REGISTER.md` | added | `—` | `248f9ec0ef6e9d201de21539b46cb95c9ba4e1b5d50b63d53f0e0f5da4a85458` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/v6.0-IR1-decision-register/DECISIONS-FOR-APPROVAL.md` | added | `—` | `db578097d729e132e7f18f5e33e298aa0b595fe877767e626e14cfe3c9815d18` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/v6.0-IR1-decision-register/GAP-REGISTER.md` | added | `—` | `8c6e449ce07c798bee7a8a527e9ba551293b4ef1140cddd860b8d1f384ef9f94` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/v6.0-IR1-decision-register/IMPLEMENTATION-READINESS.md` | added | `—` | `3a6c0e2d703a52a85de8307877171f5aa953cdfcd010f4ebf9ee67d28f3af0ca` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/v6.0-IR1-decision-register/MANIFEST.md` | added | `—` | `7b48285418fbc5747563af31f817bd4da8668df88ef8cc02b3c48d016b2aa550` | Snapshot or external input preserved (C-04) |
| `docs/_baseline/v6.0-IR1-decision-register/TRACEABILITY-MATRIX.md` | added | `—` | `71e757d6447f7324fae5abd9c9b15481c012108da633754b81829264c0a249f3` | Snapshot or external input preserved (C-04) |
| `docs/architecture/AGENTIC-ARCHITECTURE.md` | changed | `a6e7b2efcf2dd2a410f1c56a7fcb304d0e1434e91a88ecfa8ccb99f913dc8233` | `669253fafed11231aa62758d6fbc876a94235abb1487b66d8b3d8fd1783b466e` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/DATA-ARCHITECTURE.md` | changed | `a512f0000ba11139bdfb557a8ae920e049af973c526063291bb86d4940c48051` | `5cd075cb5957514c04654e29d8a201b46d82a38531dfbd466bdaf0692f62bb3a` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/DATABASE-SCHEMA.md` | changed | `5b2171e406d8d41c1ab5ce5c7b652a8985336c8ff14c0801bffe712d95560341` | `ef5c3c2b1805737e8363bc8d4c38d1746a25c15fecf351c86b0b053c74c06b1b` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/HLD.md` | changed | `57c3b152e99b7d689e1235e45e5bfc72b00f8b276abc4a6c5e0dd0766a22a17c` | `7f7a9ebff6b8bfc978a2b51a924380d1701a6b8a2905058becf16e7209d012ff` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/KNOWLEDGE-GRAPH.md` | changed | `b94349dbe0071eed2758652ba02a59bb985247a760552ee900db01bdf7fae9c6` | `83c53bf3ed2ba9b419e2aebed23fe654744b9c89d9b8585697ac6b70775d85ba` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/LLD.md` | changed | `5c7d7e6c753a3832d73c7be99c8119b8531ac8d1d4f5f5467e0e0a8f56cc368b` | `3f643975e52ecbc0c943188785eb09ed2e0f3ed52eeeae989839d860021e5453` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/MEMORY-ARCHITECTURE.md` | changed | `3ec22babc04377a873daba449619468dcb0ab4d75198191db04048d9813cc3af` | `5cbab3b7c5f2aa7bddbaf6d26df4ce21922d88085e17dc70a001dbb070a2ed95` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/OBSIDIAN-SCHEMAS.md` | changed | `b4579a6c22a4ab2fe9347461acfe245467fb2c47aa428198a0ea4a0a247ad2a6` | `7326126751bafd1c0c77336b399d3a7d75deb0f44d6ee0e5c876bf468c7257b5` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/RETRIEVAL-ARCHITECTURE.md` | changed | `341e1e3fba0212baafc515d8ee4e18f7758ee04accf002d52fc35041da09a5f2` | `7e1f29421ca1d2e7a917cabc832d75c21ee0ec0a9605cb31da56bc3d6da99a93` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/architecture/WORKFLOW-CONTRACTS.md` | changed | `9ae4f7fefe7ba5751027f5d43bc5b56f7ab7cce1aca0a2b58bbe6276aa71ab29` | `03d428df6cb1be7321d1eef9b2ef81ad0975bec947ccc7a61282fec6c33b5a50` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/decisions/ADR-COMPLETENESS-REPORT.md` | added | `—` | `5ef52263404503032807b94cc804013a239b35513743a7e79d77bdc3d40d4693` | CHG-034: assurance report |
| `docs/decisions/ADR-REGISTER.md` | changed | `248f9ec0ef6e9d201de21539b46cb95c9ba4e1b5d50b63d53f0e0f5da4a85458` | `f57f5d74487d0dbf892aa86aa73ee7f3bed56c8b84e09fafeccd02b3d97e1117` | CHG-032: ADR fields completed |
| `docs/engineering/CLAUDE-CODE-CONTRACTS.md` | changed | `3afd6217adb89924834a0d1af59e786b687510b7768604882610fd7dbd40f58b` | `2080415e5a6b2c55c12ff6458ec1f40ff9f8414b52fc67ee09e1ad13b044540a` | CHG-029: skill supply chain |
| `docs/engineering/CLI-SPECIFICATION.md` | changed | `3eb0af04daeeecb8906b9fef7beec0245c9bf3a4fb1b697ff275f572752efc2d` | `0fbd67343916ce056c64fdd9fe64c8e5e8b63f11319f5a62eb62970c0aac33dd` | CHG-033: backup phase |
| `docs/governance/ADVERSARIAL-REVIEW.md` | changed | `ac71de4696dfee659a95087cb951f4808b685f65c48533069cd88f0b4c499207` | `005abe4f7512e517c730a5a9e062b974978e05a7730a04ac60f19b84c4e2f83d` | CHG-029: three findings from external review |
| `docs/governance/DECISIONS-FOR-APPROVAL.md` | changed | `db578097d729e132e7f18f5e33e298aa0b595fe877767e626e14cfe3c9815d18` | `eb493ca8100b6872b27c0c43c5a63fd2550903f1b13811afb35663bcb18d8fd7` | CHG-031: decision package 2.0 |
| `docs/governance/ENGINEERING-HANDOFF.md` | changed | `e870ccfe62b509df736427cd83a8a13a5195ab18a8063fea31f1aacff484bfd5` | `767ba2c679753a2a7a0fd0209813195e704b445bb33d2b632d67ea5da523a9d4` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/governance/IMPLEMENTATION-READINESS.md` | changed | `3a6c0e2d703a52a85de8307877171f5aa953cdfcd010f4ebf9ee67d28f3af0ca` | `aee9fc121555244e5809b06de06ae345133b4e710833d267b2d121e1507a0473` | CHG-026, CHG-035 |
| `docs/governance/PHASE-1-AUTHORIZATION-PROMPT.md` | changed | `5bb37a6d0b31da9b27c44a35abc4dbc8f796b49c83573b1c9aad7ec1704a3e93` | `52ecc1e249a9fc05c32d0c21c65c7408caf726788b65bdc664bb4ec9a2fde749` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/governance/PRE-IMPLEMENTATION-READINESS-CERTIFICATE.md` | added | `—` | `2f945e43d5a3100377fa6b7a9d841889c2754559e6fc2e49b4a42af0ca3c0817` | CHG-034: assurance report |
| `docs/governance/TARGETED-CORRECTIONS-REGISTER.md` | added | `—` | `694982a5f613ee10737899f575751627c9a84b41c7e89e2127e6b1e1067f08c4` | CHG-034: assurance report |
| `docs/operations/DEPLOYMENT-SPECIFICATION.md` | changed | `ee40e6b39ed2d495d961daf2465e675a7a1e41edff82b0442fda630a25804a2a` | `aa55d1bf7b82123e2600aa1fa86c00cf049959073a42abd3555d8e296532a13a` | CHG-027, CHG-028, CHG-033: backup device, sequence, limits |
| `docs/planning/FILE-BUILD-PLAN.md` | changed | `6decd0d51dbdba9dbf18a408d42c809bbfd14a48956f2777399464e5c3e05575` | `6a8d90eb66c671c21ec0f4547fa425beb9910bc804948ca6974b260c0a0aa136` | CHG-033: regenerated |
| `docs/planning/IMPLEMENTATION-BACKLOG.md` | changed | `d1eb97405414afe2ccc5f1046bd059cec49d54fccb885f754c497b2b090d8251` | `6c261504804288e15a257e3fe56c3c645b75a7014731f356b20bf7d93c5e8795` | CHG-033: TASK-0212 |
| `docs/planning/IMPLEMENTATION-ROADMAP.md` | changed | `523725ee052b3be61a40f936681eb0bd2931cd887bfb0fda9061730ba1a408f5` | `9a45045720b44e35b14d46813ced54311c6a0f9697e02afd89c03377ac089911` | CHG-033: Phase 2 gate |
| `docs/requirements/BRD.md` | changed | `dcaf03a95572879172e562e043affb1f6dcb8d35b4394608b4fcdfce8f2086c8` | `e8abec7a91ad517a5b50b391244f86803c8b3d61f9d317f195037b798b59223a` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/requirements/PRD.md` | changed | `85ba374c53f89bd434b58f4e059c6da7e2ee71257e1f5c037551eb69f2900eb8` | `a30c9bf72f088a6b07c063691e1448b06a4fbcff2247ee60f72446dfb208b577` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/requirements/REQUIREMENTS-TRACEABILITY-REPORT.md` | added | `—` | `bdaac9eb0fca0f7cbd5d75156b2da384e3ea209d9b3d783b3cab8b0446f31da2` | CHG-034: assurance report |
| `docs/requirements/SRS.md` | changed | `afa1980ff4cb0ff5bbc76e88f551a58a9f36a523e25b0f283d75cd558f238664` | `e70049162f281198cc634142e3dc3831cf6e9c61641ef4c20a3ff4c072cb23f1` | CHG-033: FR-AGT-003, FR-OPS-002, FR-OPS-003 |
| `docs/requirements/TRACEABILITY-MATRIX.md` | changed | `71e757d6447f7324fae5abd9c9b15481c012108da633754b81829264c0a249f3` | `d5aa1ca7e2147db56b4ee30d799c2a8995e02ed849388f11a8565e20e7cb856a` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/security/SECURITY-ARCHITECTURE.md` | changed | `e4a737dc5035824970ef13ae9676cf066c080d8265e713cab860480c25ec4511` | `14bab9fe0ef46679c979d9955ec4c5049ab596f215e752d075db98df3cb2a2a6` | CHG-028, CHG-029: classification, skills, invariant |
| `docs/security/SECURITY-ASSURANCE-REPORT.md` | added | `—` | `319937216db3157fb0fd5756a72d4556dbf23c47945b73f3ef2a29f445109d43` | CHG-034: assurance report |
| `docs/specification/500-SLOT-COVERAGE.md` | changed | `3b35fa11543e756462d9aa78538ff0d695cd5f5f88f5049efba81e26953a9661` | `9ad0ee89f3d4d2b421770c9c491cb199e1102e7e686a6f4a462d6d1a797dacea` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/specification/BASELINE-INVENTORY.md` | changed | `7d26c5fb40c2acb063b48854c87ea3d5193f877e5c632ce4b72c3e42bb81bb6d` | `6b45138013720e49638e1922cbaf0814f699540e63b6fa52710d2cbbb7549cd8` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/specification/CHANGE-REGISTER.md` | changed | `0e058344f5bb355fa0ba85df691f88688f705c302dfcc38ff3e16138746cf83d` | `9aa73a7884c22fb0b9efd35904d4546db955a0c6f6ed1bc693c17d3226ce8864` | CHG-026 to CHG-035 recorded |
| `docs/specification/GAP-REGISTER.md` | changed | `8c6e449ce07c798bee7a8a527e9ba551293b4ef1140cddd860b8d1f384ef9f94` | `874113c80ed988084365531d845b9b42a3f03594ad8a090ef360e3d28197bd43` | CHG-026 to CHG-033 |
| `docs/specification/V5-COMPLIANCE-MATRIX.md` | changed | `5e06d528a4990f21988323788ceffd556c9b085497c30e21edc03b3ce0774b76` | `8f345c73d9b0ba34ce68ac51e791f13fc02ca157ef135109315ae113d1d693bb` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/specification/data/requirement-decisions.json` | added | `—` | `45ba3468ded7e33ea01d3c4038ba93689bb964e784313d63ccf32ca10eb1da38` | CHG-034: requirement to ADR map |
| `docs/specification/data/requirements.json` | changed | `5b5be7e04f8dc33d0c46bac8871eaf1e13d504420df77f21b8f9cbb6b352c81b` | `2345c7ace22afbd5502b4b889cae7b292a3668a3c01d5ebbd9cdc42402f73e0e` | CHG-033: regenerated data |
| `docs/specification/data/tasks.json` | changed | `3312bdef211be23c6434e43a7d04bbb88ec486c12ddebe4f05efc0eb0182f309` | `5df98045ef60175331e111d1bd1e9a6630be5b16f0a58f3e6e245928f7c3c0bc` | CHG-033: regenerated data |
| `docs/specification/data/tests.json` | changed | `cb9d40bd83bdcb4caea6542ad4b3cc166ef17b3b0eeb9a3171d20dfe8d429d8d` | `2c67dee68d6b75658a8cec09e96aeb671777af91792507c186a4e50167f4d5cd` | CHG-033: regenerated data |
| `docs/specification/evidence/README.md` | changed | `d37fd51bfab7e6d67654ed29ed351eda11042ef84d043b1ee922977c932c71c8` | `f9cefd12fdee01329636a4d878616f64a078a1c3b34fe44ef86b8f7c69ed212b` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `docs/testing/TEST-CASES.md` | changed | `1cbb4d407eed433cd43a1de862649b7dfb60ee631a146c91741efa45bcf9ad43` | `11516b384627f92b88729ac30b14c5d1ef8a52763889bd753e10fbec1e5fd844` | CHG-033: TEST-AGT-013; phases |
| `docs/testing/TEST-STRATEGY.md` | changed | `ab2f0728fac3db3b2c8bd74c05e9c6064f0ec11dd04e7de8ee29552bcfdbb70c` | `ddd38b3262cb53962207c6e22c8051250230968db87e1a7f3ee654fe207485f6` | CHG-035: version label v6.0-IR1.1 and wording (CHG-026) |
| `tools/spec_lint.py` | changed | `dc24351543e58db8602d9cf10cc98b87504d22d272c90e1f56b56a1d3259d474` | `54186a18c9a0045a21e9d5cdfd5e58def3f1ce7339c5204863463e9ec322ec76` | CHG-035: checks added |
