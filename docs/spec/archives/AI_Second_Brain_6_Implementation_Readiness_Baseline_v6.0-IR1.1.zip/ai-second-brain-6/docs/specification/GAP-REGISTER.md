# Gap Register

**DOC-GAP** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

The pre-revision gap register is preserved unchanged at `docs/_baseline/v6.0-expanded-draft/docs/specification/GAP-REGISTER.md`. GAP-001..012 keep their IDs.

Status vocabulary: **RESOLVED-SPEC** closed in the specification, awaiting implementation and test; **VERIFY** specified, depends on a named verification item or measurement; **DECIDE** waits on a named owner decision; **OPEN** not closed. No gap is "verified": nothing has been implemented. Owners are roles of the single owner or, where marked, the implementing Claude Code session.

## 1. Gaps carried from the V6.0 draft

| GAP_ID | Domain | Finding | Severity | Affected requirements | Resolution | Owner | Verification | Status |
|---|---|---|---|---|---|---|---|---|
| GAP-001 | Data | File and database atomicity and crash recovery unspecified | Critical | FR-ING-002, FR-AGT-002, FR-OPS-005 | Commit protocol S0–S7 and recovery table (DATA-ARCHITECTURE §5) | Data architect | TEST-REC-001..010; V-10 | RESOLVED-SPEC |
| GAP-002 | Security | No enforced sandbox configuration selected | Critical | FR-SEC-001, FR-AGT-007 | Operating settings with sandbox and permission rules; five-layer model | Security architect | V-03..V-07; TEST-SEC-006, 007 | VERIFY |
| GAP-003 | Requirements | Environment, corpus and data classification unknown | Critical | NFR-020, NFR-007 | Owner decided macOS, bilingual Arabic-first, public content; corpus still to be supplied | Owner | V-01; D-10 | DECIDE (corpus) |
| GAP-004 | Retrieval | No representative labelled relevance set | High | FR-RET-008, NFR-007 | Benchmark schema, strata and protocol (RETRIEVAL-ARCHITECTURE §9) | Owner, retrieval engineer | TEST-NFR-007 | DECIDE D-10 |
| GAP-005 | Operations | Backup destination, RPO and RTO not approved | High | FR-OPS-002, FR-OPS-003, NFR-006 | Backup design and proposed objectives | Owner | TEST-OPS-003..006; drill | DECIDE D-06 |
| GAP-006 | Data | No concrete DDL or migration contract | High | FR-OPS-006 | Schema v1 executed and probed; migration rules | Database architect | DDL probes; TEST-OPS-009, 010 | RESOLVED-SPEC |
| GAP-007 | Agentic | No durable approval-token semantics | High | FR-AGT-001, FR-AGT-003, FR-AGT-004 | `proposals` and `approvals` tables; hash binding, expiry, single use, channel; triggers T8–T10 | Agentic architect | TEST-AGT-001..008; probes P17–P21 | RESOLVED-SPEC |
| GAP-008 | Obsidian | Direct edits may bypass the registry | High | FR-KNW-004, FR-KNW-005 | Authority map; sync and drift rules; compare-and-swap | Knowledge engineer | TEST-KNW-005..007; TEST-REC-006 | RESOLVED-SPEC |
| GAP-009 | Privacy | Backup erasure and retention conflict | High | FR-MEM-009 | Purge reports backups still holding the text and their expiry; early expiry is tier 2. Retention periods proposed | Data steward | TEST-MEM-012 | RESOLVED-SPEC (design); DECIDE D-06 (periods) |
| GAP-010 | Integrations | Claude Code feature versions unverified | Medium | FR-AGT-007 | Keys and behaviours checked against current documentation; installed version pending | Claude Code engineer | V-02..V-08, V-14 | VERIFY |
| GAP-011 | Languages | Arabic tokenisation unbenchmarked | Medium → **Critical** | FR-RET-003, NFR-007 | See GAP-013 | Retrieval engineer | — | Superseded by GAP-013 |
| GAP-012 | Licensing | Document import authorisation unconfirmed | High → Medium | FR-ING-001 | Content is public (D-03); the owner attests rights by ingesting (assumption A-04); no per-source rights field | Owner | — | DECIDE D-10 |

## 2. Gaps found in this pass

| GAP_ID | Domain | Finding | Severity | Affected requirements | Resolution | Owner | Verification | Status |
|---|---|---|---|---|---|---|---|---|
| GAP-013 | Retrieval | The specified tokenizer indexes vocalised Arabic as single letters and does not match letter variants, tatweel, Arabic-Indic digits or attached articles (measured) | Critical | FR-RET-003 | Application normaliser `ar-en-1`, light-stem column, gate RET-G1 | Retrieval engineer | Probe; TEST-RET-004..006; V-09; NFR-007 | RESOLVED-SPEC; quality VERIFY |
| GAP-014 | Data | Two incompatible knowledge models in one package | High | FR-MEM-001..012 | One model (ADR-020) | Data architect | DDL probes | RESOLVED-SPEC |
| GAP-015 | Data | As-of project reconstruction required but no history stored; sources could not have versions; edges could not reach non-entities | High | FR-PRJ-001, FR-ING-006, FR-KNW-006 | `project_events`; hash on versions only; `objects` registry | Database architect | DDL probes; TEST-PRJ-001, 002 | RESOLVED-SPEC |
| GAP-016 | Security | Claude Code loads `CLAUDE.md` from subdirectories on demand; a file of that name inside the vault would become instructions | High | FR-SEC-004 | Refuse, exclude, detect | Security architect | TEST-SEC-009, 010; V-07 | VERIFY |
| GAP-017 | Agentic | Claude Code's auto memory is a second memory store outside every evidence rule | High | FR-AGT-007 | Disabled in the operating workspace | Claude Code engineer | V-08 | VERIFY |
| GAP-018 | Security | The Bash sandbox does not cover built-in file tools, hooks or MCP servers; the draft treated "sandbox" as one boundary | High | FR-AGT-007, FR-SEC-007 | Layered enforcement L1–L5; no hooks or MCP in v1 | Security architect | V-03..V-05 | VERIFY |
| GAP-019 | Ingestion | Arabic PDF extraction quality and scanned documents were not considered | High | FR-ING-007, FR-ING-009 | `needs_ocr` and `partial` statuses; measured spike before choosing a library; OCR deferred | Document engineer | TEST-ING-010, 013; V-12 | VERIFY; DECIDE D-09 |
| GAP-020 | Retrieval | Questions in one language about evidence in the other | Medium | FR-RET-001 | Bounded reformulation by Claude; entity aliases; benchmark stratum | Retrieval engineer | Benchmark | VERIFY |
| GAP-021 | Agentic | "Human approval" was not distinguishable from agent action | High | FR-AGT-004 | Three tiers and two channels | Agentic architect | TEST-AGT-007, 008; V-06 | VERIFY; DECIDE D-08 |
| GAP-022 | Requirements | Traceability used undefined objectives and covered 16 of 21 requirements | High | all | Generated matrix over 100 requirements with computed consistency findings | Requirements engineer | `tools/spec_lint.py` | RESOLVED-SPEC |
| GAP-023 | Planning | Phase and task contradictions between backlog, roadmap and file plan | Medium | — | One generated plan | Program director | spec_lint | RESOLVED-SPEC |
| GAP-024 | Obsidian | Right-to-left and mixed-direction handling unspecified | Medium | FR-OBS-003, NFR-022 | Direction rules; bidi-override rejection; isolates in terminal output only | Obsidian engineer | TEST-OBS-002, 003, 005; V-11 | VERIFY |
| GAP-025 | Temporal | Hijri and partial dates | Medium | FR-MEM-008 | `date_precision`, `date_text`; no calendar conversion | Knowledge engineer | — | DECIDE D-17 |
| GAP-026 | Projects | No assignee, commitments or open questions | Low | FR-PRJ-003 | Added to `project_items` | Database architect | TEST-PRJ-004 | RESOLVED-SPEC |
| GAP-027 | Operations | Knowledge data inside the code repository | Medium | FR-OPS-009 | Separate operating home (ADR-014) | Reliability engineer | TEST-OPS-013 | DECIDE D-07 |
| GAP-028 | Testing | Test cases generated from a template | High | all | 143 specific cases, 63 adversarial | QA architect | TEST-CASES | RESOLVED-SPEC |
| GAP-029 | Economics | No bound on context returned to the model; no cost view | Medium | NFR-015 | Payload budget; no model calls from Python | Product manager | TEST-NFR-015 | RESOLVED-SPEC; DECIDE D-13 |
| GAP-030 | Scalability | No capacity profiles or migration thresholds | Medium | NFR-012 | HLD §9 estimates; measurement task | Reliability engineer | TEST-NFR-012 | VERIFY |
| GAP-031 | Method | Specification, tests and review by one author; three specification passes without code | High | — | Stated; owner review; recommendation to proceed to Phase 1 | Owner | — | OPEN |
| GAP-032 | Dependencies | Python packages and tools named but never installed or tested | Medium | NFR-011, NFR-020 | Verification in Phase 1–2 | DevOps | V-01, V-12 | VERIFY; DECIDE D-15 |
| GAP-033 | Agentic | Unlimited tier 0 proposals from a session | Medium | FR-AGT-003 | Corrected in IR1.1: configurable limits on open proposals (default 200) and per run (default 50); creation refused at the limit with nothing discarded; duplicates return the existing proposal; doctor warns at 80% | Agentic architect | TEST-AGT-013 | RESOLVED-SPEC |
| GAP-034 | Operations | Automated backup scheduled late (Phase 9) | Medium | FR-OPS-003 | Corrected in IR1.1: backup create, verify and restore-test moved to Phase 2 (TASK-0212) and into the Phase 2 gate; owner documents refused until a restore-tested backup exists; full restore stays in Phase 9 because it needs tier 2 approvals | Reliability engineer | TEST-OPS-003, TEST-OPS-004, TEST-OPS-005, TEST-OPS-006 | RESOLVED-SPEC |
| GAP-036 | Agentic | Skills load from personal, synced, plugin and added-directory locations as well as the project; a same-named personal skill overrides the project skill; skills can grant tools and run shell commands at load (external review, IR1.1) | High | FR-AGT-007 | Proposed: decision D-20 and amendment AM-05 (unique names, no tool grants, inventory and collision check, synced skills off, local sessions only) | Claude Code engineer | V-15; test to add on approval | DECIDE D-20 |
| GAP-037 | Operations | D-06 offered a second internal volume as a backup destination (external review, IR1.1) | High | FR-OPS-003 | Corrected: separate physical device required | Reliability engineer | Doctor check on device identity, to add with AM-01 | RESOLVED-SPEC |
| GAP-038 | Privacy | "Public information" describes the sources; the owner's own queries, preferences, decisions and notes were treated as public too (external review, IR1.1) | Medium | NFR-009, FR-OPS-003 | Security text corrected; encrypted backup volume recommended | Security architect | — | DECIDE D-06 |
| GAP-035 | Inputs | No implementation repository has been supplied or verified | — | — | Open input; see §3 ASB6-ISSUE-0001 | Owner | — | OPEN INPUT |

## 3. Disposition of the fifteen audit findings

Source: `docs/_baseline/asb6-adversarial-audit/04-CONFIRMED-DEFECTS.md`. Each is a specification-level finding against the V6.0 draft. "Blocks approval" answers: does this stop the owner from approving the revised specification?

| Issue | Finding (audit) | Governing requirement | Supporting evidence | Correction in this baseline | Acceptance criteria | Blocks specification approval? | Disposition |
|---|---|---|---|---|---|---|---|
| ASB6-ISSUE-0001 | Existing codebase unavailable for audit | — | No repository, commit or runtime was supplied to this pass or to the audit; owner clarification of 2026-11-10 | None possible. Recorded as open input GAP-035. Authoritative status: no implementation established | If a codebase exists it is supplied as a snapshot and assessed against this baseline as a separate, unverified artifact | No. It blocks any implementation audit | OPEN INPUT |
| ASB6-ISSUE-0002 | Root `CLAUDE.md` prohibits implementation | Directive: implementation not authorised | `CLAUDE.md` of the draft; owner clarification | Not a defect: the instruction file and the authorisation state agree. The revised `CLAUDE.md` keeps SPECIFICATION-ONLY. The way to change it is defined (PHASE-1-AUTHORIZATION-PROMPT) | The file names an authorised phase only after the owner issues that prompt | No | CLOSED — WORKING AS INTENDED |
| ASB6-ISSUE-0003 | Readiness gate fails for security | FR-SEC-001..008, FR-AGT-001, FR-AGT-004, FR-AGT-007 | Draft readiness report; Claude Code documentation read 2026-11-10 | Classification decided (public, D-03). Boundary specified with an enforcement type per control (SECURITY-ARCHITECTURE §4–5). Settings specified (CLAUDE-CODE-CONTRACTS §5). Tests designed | V-03..V-07 pass on the installed version; TEST-SEC-001..015 pass; manual protocol recorded | No for approval of the design. Yes for operating on real content before Phase 7 verification | RESOLVED-SPEC; VERIFY |
| ASB6-ISSUE-0004 | Deployment environment unresolved | NFR-020, FR-OPS-009, NFR-006 | Owner decision macOS (D-01); versions unknown | Deployment specification for macOS; prerequisites; V-01; backup design with proposed objectives | V-01 recorded and meets prerequisites; D-06 decided; install procedure executed once | No. D-06 must be decided before Phase 9; V-01 is the first task of Phase 1 | PARTLY RESOLVED; DECIDE D-06; VERIFY V-01 |
| ASB6-ISSUE-0005 | No executable tests | TEST-STRATEGY; all requirements | Specification-only mode; no application has been supplied or verified | 143 test cases specified with data, procedure, expected result and automation; fixtures defined; DDL probes and tokenizer probe executed and recorded | Tests are written and pass phase by phase with evidence files | No. Executable tests cannot precede implementation | RESOLVED-SPEC (as far as specification can go) |
| ASB6-ISSUE-0006 | Representative retrieval benchmark not available | FR-RET-008, NFR-007 | No corpus supplied | Benchmark schema, nine strata, 100-question minimum, labelling protocol, metrics, gates RET-G1 and RET-G2 | Owner supplies pilot corpus and validates questions; holdout results recorded | No. It blocks the Phase 4 gate | DECIDE D-10 |
| ASB6-ISSUE-0007 | Claude Code compatibility unverified | FR-AGT-007 | Documentation pages listed in CLAUDE-CODE-CONTRACTS §8 | Every key used is taken from current documentation; behaviours relied on are stated with a verification item each | V-02..V-08 and V-14 recorded for the installed version | No. First tasks of Phase 1 | PARTLY RESOLVED; VERIFY |
| ASB6-ISSUE-0008 | Cross-resource atomicity not guaranteed | FR-AGT-002, FR-OPS-005, NFR-002, NFR-018 | SQLite and a filesystem share no transaction | Protocol with intents, commit point, recovery table, read-only mode; seven crash points; invariants | TEST-REC-001..010 pass, including the randomised loop with zero invariant violations | No | RESOLVED-SPEC |
| ASB6-ISSUE-0009 | Critical user approvals open | Governance | Five decisions recorded on 2026-11-10; fifteen open | DECISIONS-FOR-APPROVAL.md lists every open decision and ADR with recommendation, alternatives and consequence | Owner approves or amends each; ADR statuses updated | **Yes.** This is the approval | DECIDE |
| ASB6-ISSUE-0010 | Only priority requirements traced | TRACEABILITY-MATRIX | Draft matrices | 100 requirements traced to objective, feature, component, contract, task, test and acceptance; consistency computed | `spec_lint` reports no untested requirement, orphan test, MUST without task or orphan component | No | RESOLVED-SPEC |
| ASB6-ISSUE-0011 | No validated Arabic retrieval behaviour | FR-RET-003, NFR-007 | Tokenizer probe (measured) | Normaliser, stemmer, index design, Arabic strata in the benchmark. The audit rated this non-blocking; the probe shows the draft design would not have worked for Arabic, so it is rated Critical here | TEST-RET-004..006 pass; V-09 matches; NFR-007 met per language or the gap is recorded with a decision | No. It blocks the Phase 4 gate | RESOLVED-SPEC; quality VERIFY |
| ASB6-ISSUE-0012 | Obsidian manual edits require reconciliation | FR-KNW-004, FR-KNW-005 | — | Authority map; nine sync rules; managed keys as projections; compare-and-swap; parsed-value drift comparison | TEST-KNW-005..007 and TEST-REC-006 pass | No | RESOLVED-SPEC |
| ASB6-ISSUE-0013 | Backup deletion policy unresolved | FR-MEM-009, FR-OPS-003 | — | Deletion table (DATA-ARCHITECTURE §8); purge exposure report; proposed retention | TEST-MEM-012 passes; D-06 decided | No. Retention numbers are part of D-06 | RESOLVED-SPEC; DECIDE D-06 |
| ASB6-ISSUE-0014 | No durable approval semantics | FR-AGT-001, FR-AGT-003, FR-AGT-004 | DDL probes P17–P21 executed | Actor and actor kind, tier, channel, payload hash, expiry, single use, replay rejection, frozen payload; enforced by triggers | TEST-AGT-001..008 pass | No | RESOLVED-SPEC; V-06 for the in-session channel |
| ASB6-ISSUE-0015 | Document ingestion authorisation unresolved | FR-ING-001; SECURITY-ARCHITECTURE §9 | Owner: public information only (D-03) | Provider transmission: session context goes to Anthropic, acceptable for public content. Rights: owner attests by ingesting (A-04); no per-source consent field is specified | Owner confirms A-03 and A-04 in the decision sheet | No, once confirmed in D-10 | DECIDE D-10 |

Summary: 1 closed as working as intended; 8 resolved in specification (three of them with a verification item or decision still attached); 2 partly resolved pending verification on the Mac; 3 waiting on owner decisions; 1 open input. **Only ASB6-ISSUE-0009 blocks specification approval, and it is the approval itself.**

## 4. The fifteen maturity gaps of the version-evolution review

| # | Gap | Where it stands |
|---|---|---|
| 1 | End-to-end implementation proof | Not available in a specification. Phase gates define the proof |
| 2 | Real retrieval benchmarks | D-10; Phase 4 gate |
| 3 | Memory correctness evaluation | TEST-MEM-001..015 designed |
| 4 | Crash-consistency validation | TEST-REC-001..010 designed |
| 5 | Security enforcement tests | TEST-SEC-*, manual protocol designed |
| 6 | Backup restoration evidence | TEST-OPS-003..006, drill designed |
| 7 | Representative evaluation corpus | D-10 |
| 8 | Knowledge freshness policy | FR-MEM-010; review intervals proposed |
| 9 | Entity identity resolution | FR-KNW-007; exact normalised alias match plus owner-approved merge |
| 10 | Multi-project isolation | Not applicable as isolation: one public classification. Project filter provided |
| 11 | Workflow reliability metrics | Run history; no metrics dashboard beyond counts |
| 12 | Human correction feedback | FR-MEM-007; corrections are revisions; no learning loop beyond that |
| 13 | Resource and token budgets | NFR-015; D-13 |
| 14 | Incremental migration and compatibility | Schema and note schema versions; FR-IMP for legacy vaults |
| 15 | Continuous regression evaluation | Benchmark as regression suite at every upgrade (DEPLOYMENT-SPECIFICATION §8) |

No V7.0 scope is adopted. The next milestone remains an approved and then implemented V6.0.

## 5. Totals

38 gaps: 12 carried (1 superseded), 26 new, of which 3 came from external review in IR1.1. By status: RESOLVED-SPEC 16; VERIFY 11; DECIDE 8; OPEN 1; OPEN INPUT 1; superseded 1. Several rows carry a second status after a semicolon; the count uses the first.
