"""Executes schema_v1.sql in a throwaway in-memory SQLite DB and probes constraints. Specification evidence only."""
import sqlite3, sys, json, hashlib
sql = open(sys.argv[1], encoding="utf-8").read()
c = sqlite3.connect(":memory:"); c.execute("PRAGMA foreign_keys=ON")
c.executescript(sql)
res = {"sqlite": sqlite3.sqlite_version, "python": sys.version.split()[0]}
res["tables"] = [r[0] for r in c.execute("select name from sqlite_master where type='table' and name not like 'search_fts_%' and name not like 'sqlite_%' order by 1")]
res["triggers"] = c.execute("select count(*) from sqlite_master where type='trigger'").fetchone()[0]
res["indexes"] = c.execute("select count(*) from sqlite_master where type='index' and name not like 'sqlite_%'").fetchone()[0]
res["fk_check"] = c.execute("PRAGMA foreign_key_check").fetchall()
res["integrity"] = c.execute("PRAGMA integrity_check").fetchone()[0]
T = "2026-11-10T00:00:00Z"; H = "a"*64
def obj(i, t): c.execute("insert into objects values(?,?,?)", (i, t, T))
probes = []
def expect_fail(name, fn, needle):
    try:
        fn(); probes.append((name, "FAIL: statement was accepted"))
    except sqlite3.Error as e:
        probes.append((name, "ok" if needle in str(e) else "FAIL: wrong error: " + str(e)))
def expect_ok(name, fn):
    try: fn(); probes.append((name, "ok"))
    except sqlite3.Error as e: probes.append((name, "FAIL: " + str(e)))
# fixtures
obj("WFR-000001","workflow_run"); c.execute("insert into workflow_runs(id,workflow_type,idempotency_key,state,correlation_id,started_at,updated_at) values('WFR-000001','ingest','k1','COMPLETED','c1',?,?)",(T,T))
obj("SRC-000001","source"); c.execute("insert into sources(id,title,origin_kind,registered_at) values('SRC-000001','t','file',?)",(T,))
obj("SVR-000001","source_version"); c.execute("insert into source_versions(id,source_id,version_no,sha256,byte_size,media_type,original_filename,storage_relpath,captured_at) values('SVR-000001','SRC-000001',1,?,10,'text/plain','a.txt','aa/'||?,?)",(H,H,T))
obj("EXT-000001","extraction"); c.execute("insert into extractions(id,source_version_id,extractor,extractor_version,status,is_active,created_at) values('EXT-000001','SVR-000001','text','1','succeeded',1,?)",(T,))
obj("PSG-000001","passage"); c.execute("insert into passages(id,extraction_id,ordinal,locator_json,text,text_sha256) values('PSG-000001','EXT-000001',0,'{}','نص',?)",(H,))
obj("MEM-000001","memory")
expect_fail("P01 memory cannot be inserted as verified", lambda: c.execute("insert into memory_records(id,kind,epistemic_type,state,created_at,updated_at) values('MEM-000001','semantic','fact','verified',?,?)",(T,T)), "SB-MEM-001")
expect_ok("P02 memory inserted as proposed", lambda: c.execute("insert into memory_records(id,kind,epistemic_type,state,created_at,updated_at) values('MEM-000001','semantic','fact','proposed',?,?)",(T,T)))
c.execute("insert into memory_revisions(memory_id,revision,statement,attestation,change_reason,actor,recorded_at) values('MEM-000001',1,'s','source_evidence','init','owner',?)",(T,))
expect_fail("P03 verify without evidence rejected", lambda: c.execute("update memory_records set state='verified' where id='MEM-000001'"), "SB-MEM-002")
c.execute("insert into evidence_links(subject_id,subject_revision,passage_id,role,created_at) values('MEM-000001',1,'PSG-000001','supports',?)",(T,))
expect_ok("P04 verify with evidence accepted", lambda: c.execute("update memory_records set state='verified' where id='MEM-000001'"))
expect_fail("P05 verified -> captured rejected", lambda: c.execute("update memory_records set state='captured' where id='MEM-000001'"), "SB-MEM-001")
expect_fail("P06 memory revision update rejected", lambda: c.execute("update memory_revisions set statement='x' where memory_id='MEM-000001'"), "SB-INT-004")
expect_fail("P07 memory revision delete rejected", lambda: c.execute("delete from memory_revisions"), "SB-INT-004")
expect_fail("P08 superseded without successor rejected", lambda: c.execute("update memory_records set state='superseded' where id='MEM-000001'"), "CHECK")
obj("MEM-000002","memory"); c.execute("insert into memory_records(id,kind,epistemic_type,state,created_at,updated_at) values('MEM-000002','semantic','hypothesis','proposed',?,?)",(T,T))
c.execute("insert into memory_revisions(memory_id,revision,statement,attestation,change_reason,actor,recorded_at) values('MEM-000002',1,'h','derived','init','claude',?)",(T,))
expect_fail("P09 hypothesis cannot be verified", lambda: c.execute("update memory_records set state='verified' where id='MEM-000002'"), "")
obj("MEM-000003","memory"); c.execute("insert into memory_records(id,kind,epistemic_type,state,created_at,updated_at) values('MEM-000003','semantic','fact','proposed',?,?)",(T,T))
c.execute("insert into memory_revisions(memory_id,revision,statement,attestation,change_reason,actor,recorded_at) values('MEM-000003',1,'d','derived','init','claude',?)",(T,))
expect_fail("P10 derived fact cannot be verified", lambda: c.execute("update memory_records set state='verified' where id='MEM-000003'"), "SB-MEM-003")
expect_ok("P11 supersede with successor accepted", lambda: c.execute("update memory_records set state='superseded', superseded_by='MEM-000003' where id='MEM-000001'"))
expect_fail("P12 source version hash rewrite rejected", lambda: c.execute("update source_versions set sha256=? where id='SVR-000001'",("b"*64,)), "SB-ING-002")
expect_fail("P13 duplicate sha256 rejected", lambda: (obj("SVR-000002","source_version"), c.execute("insert into source_versions(id,source_id,version_no,sha256,byte_size,media_type,original_filename,storage_relpath,captured_at) values('SVR-000002','SRC-000001',2,?,10,'text/plain','b.txt','x',?)",(H,T))), "UNIQUE")
expect_fail("P14 second active extraction rejected", lambda: (obj("EXT-000002","extraction"), c.execute("insert into extractions(id,source_version_id,extractor,extractor_version,status,is_active,created_at) values('EXT-000002','SVR-000001','text','2','succeeded',1,?)",(T,))), "UNIQUE")
c.execute("insert into audit_events(occurred_at,actor,actor_kind,correlation_id,action,outcome,prev_hash,event_hash) values(?,?,?,?,?,?,?,?)",(T,'owner','owner','c1','x','ok','0'*64,H))
expect_fail("P15 audit update rejected", lambda: c.execute("update audit_events set action='y'"), "SB-INT-001")
expect_fail("P16 audit delete rejected", lambda: c.execute("delete from audit_events"), "SB-INT-001")
obj("PRP-000001","proposal"); c.execute("insert into proposals(id,proposal_type,tier,payload_json,payload_sha256,state,created_by,actor_kind,created_at,expires_at) values('PRP-000001','memory_transition',1,'{}',?, 'awaiting_approval','s','claude_session',?,?)",(H,T,T))
expect_fail("P17 approval with wrong hash rejected", lambda: (obj("APR-000001","approval"), c.execute("insert into approvals(id,proposal_id,payload_sha256,approver,channel,approved_at,expires_at) values('APR-000001','PRP-000001',?, 'owner','terminal',?,?)",("c"*64,T,T))), "SB-AGT-001")
expect_ok("P18 approval with matching hash accepted", lambda: c.execute("insert into approvals(id,proposal_id,payload_sha256,approver,channel,approved_at,expires_at) values('APR-000001','PRP-000001',?, 'owner','terminal',?,?)",(H,T,T)))
expect_ok("P19 approval consumed once", lambda: c.execute("update approvals set consumed_at=? where id='APR-000001'",(T,)))
expect_fail("P20 approval second consumption rejected", lambda: c.execute("update approvals set consumed_at=? where id='APR-000001'",("2027-01-01T00:00:00Z",)), "SB-AGT-001")
expect_fail("P21 proposal payload change after validation rejected", lambda: c.execute("update proposals set payload_json='{\"a\":1}' where id='PRP-000001'"), "SB-AGT-001")
expect_fail("P22 FK: passage with unknown extraction rejected", lambda: (obj("PSG-000002","passage"), c.execute("insert into passages(id,extraction_id,ordinal,locator_json,text,text_sha256) values('PSG-000002','EXT-999999',0,'{}','x',?)",(H,))), "FOREIGN KEY")
expect_fail("P23 malformed id rejected", lambda: c.execute("insert into objects values('src-1','source',?)",(T,)), "CHECK")
expect_fail("P24 self-relationship rejected", lambda: (obj("REL-000001","relationship"), c.execute("insert into relationships(id,subject_id,predicate,object_id,created_at,updated_at) values('REL-000001','MEM-000001','SUPPORTS','MEM-000001',?,?)",(T,T))), "CHECK")
expect_fail("P25 project_events delete rejected", lambda: (obj("PRJ-000001","project"), c.execute("insert into projects(id,slug,name,state,created_at,updated_at) values('PRJ-000001','alpha','Alpha','active',?,?)",(T,T)), c.execute("insert into project_events(project_id,subject_id,event_type,payload_json,effective_at,recorded_at,actor) values('PRJ-000001','PRJ-000001','created','{}',?,?,'owner')",(T,T)), c.execute("delete from project_events")), "SB-INT-002")
expect_fail("P26 decision accepted without date rejected", lambda: (obj("DEC-000001","decision"), c.execute("insert into decisions(id,title,state,created_at,updated_at) values('DEC-000001','d','accepted',?,?)",(T,T))), "CHECK")
# FTS smoke
c.execute("insert into search_units(rowid,unit_kind,unit_id,parent_id,text_sha256,norm_version,indexed_at) values(1,'passage','PSG-000001','PSG-000001',?, 'ar-en-1',?)",(H,T))
c.execute("insert into search_fts(rowid,title_norm,text_norm,text_stem) values(1,'','قرا محمد الكتاب','قرا محمد كتاب')")
hit = c.execute("select u.unit_id, bm25(search_fts, 2.0, 1.0, 0.5) from search_fts join search_units u on u.rowid=search_fts.rowid where search_fts match ? ", ('text_norm:"كتاب" OR text_stem:"كتاب"',)).fetchall()
probes.append(("P27 FTS join returns unit", "ok" if hit and hit[0][0]=="PSG-000001" else "FAIL"))
res["probes"] = probes
res["probe_pass"] = sum(1 for _,r in probes if r=="ok"); res["probe_total"] = len(probes)
print(json.dumps(res, ensure_ascii=False, indent=1))
