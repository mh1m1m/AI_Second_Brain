"""FTS5 Arabic/English behaviour probe for AI Second Brain 6.0 (specification evidence).
Stdlib only. Run: python3 -I fts5_arabic_probe.py
Part A shows raw tokenizer behaviour; Part B shows the proposed normaliser 'ar-en-1' + light stem column."""
import sqlite3, sys, unicodedata, re, json

DOCS = {
 1: "قرأ مُحَمَّدٌ الكِتابَ في المَكتبة",
 2: "قرأ محمد الكتاب في المكتبة",
 3: "أحمد وإبراهيم وآمنة في الإدارة",
 4: "احمد وابراهيم وامنة في الادارة",
 5: "المـــكتبة الوطنية",
 6: "زرت مدرسة قديمة قرب مستشفى المدينة",
 7: "زرت مدرسه قديمه قرب مستشفي المدينه",
 8: "صدر القرار رقم ٢٠٢٤",
 9: "صدر القرار رقم 2024",
 10: "ﻟﻤﻜﺘﺒﺔ ﻻ",          # presentation forms + lam-alef ligature
 11: "The Library opened in Riyadh. Libraries are useful.",
 12: "وللمكتبات والكتب أهمية في المدارس",
}
QUERIES = ["محمد","الكتاب","كتاب","احمد","أحمد","المكتبة","مكتبة","مكتبات","مدرسة","مدرسه","مستشفى","2024","٢٠٢٤","library","LIBRARY","libraries","لا"]

TASHKEEL = re.compile("[ً-ٰٟۖ-ۭ]")
CONTROLS = re.compile("[ـ​-‏‪-‮⁦-⁩﻿؜]")
FOLD = str.maketrans({"أ":"ا","إ":"ا","آ":"ا","ٱ":"ا","ى":"ي","ة":"ه","ک":"ك","ی":"ي"})
DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

def normalise(text: str) -> str:
    """Normaliser ar-en-1: NFKC, strip tashkeel/tatweel/bidi controls, fold letter variants, map digits, casefold."""
    t = unicodedata.normalize("NFKC", text)
    t = TASHKEEL.sub("", t)
    t = CONTROLS.sub("", t)
    t = t.translate(FOLD).translate(DIGITS)
    return t.casefold()

PREFIXES = ["ولل","فلل","وال","بال","كال","فال","لل","ال","و"]
SUFFIXES = ["ها","ان","ات","ون","ين","يه","يه","ه","ي"]   # after folding, ta marbuta is already 'ه'
AR = re.compile("^[ء-ي]+$")
def light_stem(tok: str) -> str:
    """Light stemmer ar-light-1 (light10-style) applied to normalised Arabic tokens only."""
    if not AR.match(tok): return tok
    for p in PREFIXES:
        if tok.startswith(p) and len(tok) - len(p) >= 3:
            tok = tok[len(p):]; break
    changed = True
    while changed:
        changed = False
        for s in SUFFIXES:
            if tok.endswith(s) and len(tok) - len(s) >= 3:
                tok = tok[:-len(s)]; changed = True; break
    return tok
def stem_text(norm: str) -> str:
    return " ".join(light_stem(w) for w in re.findall(r"\w+", norm))

def run(c, table, q_exact, q_stem=None):
    expr = '"%s"' % q_exact if q_stem is None else '(text_norm:"%s" OR text_stem:"%s")' % (q_exact, q_stem)
    try: return [r[0] for r in c.execute(f"select rowid from {table} where {table} match ? order by rowid", (expr,))]
    except Exception as e: return "ERR " + str(e)

def main():
    c = sqlite3.connect(":memory:")
    out = {"python": sys.version.split()[0], "sqlite": sqlite3.sqlite_version, "partA": {}, "partB": {}}
    for tok in ["unicode61 remove_diacritics 2", "trigram"]:
        c.execute("drop table if exists a"); c.execute(f"create virtual table a using fts5(body, tokenize=\"{tok}\")")
        c.executemany("insert into a(rowid,body) values(?,?)", DOCS.items())
        out["partA"][tok] = {q: run(c, "a", q) for q in QUERIES}
    c.execute("create virtual table b using fts5(text_norm, text_stem, tokenize=\"porter unicode61 remove_diacritics 2\")")
    for i, d in DOCS.items():
        n = normalise(d); c.execute("insert into b(rowid,text_norm,text_stem) values(?,?,?)", (i, n, stem_text(n)))
    for q in QUERIES:
        n = normalise(q)
        out["partB"][q] = {"norm": n, "stem": light_stem(n), "norm_only": run(c, "b", n) if True else None,
                           "norm_or_stem": run(c, "b", n, light_stem(n))}
    # norm_only should restrict to text_norm column:
    for q in QUERIES:
        n = normalise(q)
        out["partB"][q]["norm_only"] = [r[0] for r in c.execute('select rowid from b where b match ? order by rowid', ('text_norm:"%s"' % n,))]
    c.execute("create virtual table v using fts5vocab(b, instance)")
    out["doc1_norm_tokens"] = [r[0] for r in c.execute("select term from v where doc=1 and col='text_norm' order by offset")]
    out["doc12_stem_tokens"] = [r[0] for r in c.execute("select term from v where doc=12 and col='text_stem' order by offset")]
    out["doc10_norm"] = normalise(DOCS[10])
    print(json.dumps(out, ensure_ascii=False, indent=1))
main()
