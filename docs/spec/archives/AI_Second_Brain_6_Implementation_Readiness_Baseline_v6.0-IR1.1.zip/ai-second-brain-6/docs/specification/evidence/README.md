# Evidence produced during specification

**DOC-EVID** · v6.0-IR1.1 · 2026-11-10 · Owner: Mohammed Alsaleh

Everything that was actually executed or looked up for this baseline. Nothing here is an application test.

## 1. Executed

| Artifact | What it is | Environment | Result |
|---|---|---|---|
| `fts5_arabic_probe.py`, `fts5_arabic_probe.output.json` | Twelve hand-written Arabic, English and mixed sentences indexed three ways: raw `unicode61`, raw `trigram`, and the proposed normaliser with a light-stem column. Seventeen queries each | Specification sandbox (Linux), Python 3.13.18, SQLite 3.53.1 | Summarised in RETRIEVAL-ARCHITECTURE §2 |
| `schema_v1.sql`, `ddl_check.py`, `ddl_check.output.json` | Schema v1 executed in an in-memory database; 27 constraint and trigger probes | Same | 29 tables (28 plus the FTS5 virtual table), 17 indexes, 15 triggers; `integrity_check` ok; 27 of 27 probes as specified |
| `tools/spec_lint.py`, `docs/governance/QUALITY-REPORT.json` | Cross-document identifier and coverage checks | Same | In the report |
| Draft DDL check | The V6.0 draft's DDL executed as written | Same | Executes; design conflicts listed in BASELINE-INVENTORY |

To repeat on the Mac (standard library only; nothing is installed; nothing is written outside the current directory's output file):

```
python3 -I docs/specification/evidence/fts5_arabic_probe.py > probe.json
python3 -I docs/specification/evidence/ddl_check.py docs/specification/evidence/schema_v1.sql > ddl.json
python3 -I tools/spec_lint.py .
```

Differences from the recorded outputs are findings (verification items V-01 and V-09).

## 2. Looked up (official documentation, 2026-11-10)

| Subject | Pages | Used in |
|---|---|---|
| Claude Code instruction files, rules, auto memory | code.claude.com/docs/en/memory | CLAUDE-CODE-CONTRACTS §2; FR-SEC-004; GAP-016, GAP-017 |
| Claude Code skills | code.claude.com/docs/en/skills | CLAUDE-CODE-CONTRACTS §4 |
| Claude Code subagents | code.claude.com/docs/en/sub-agents | AGENTIC-ARCHITECTURE §7 |
| Claude Code hooks | code.claude.com/docs/en/hooks | AGENTIC-ARCHITECTURE §8 |
| Claude Code settings and precedence | code.claude.com/docs/en/settings | CLAUDE-CODE-CONTRACTS §5 |
| Claude Code permissions | code.claude.com/docs/en/permissions | CLAUDE-CODE-CONTRACTS §5; SECURITY-ARCHITECTURE §5 |
| Claude Code sandboxing | code.claude.com/docs/en/sandboxing | CLAUDE-CODE-CONTRACTS §5; ADR-015 |
| Claude Code MCP | code.claude.com/docs/en/mcp | AGENTIC-ARCHITECTURE §9 |
| Claude Code non-interactive mode | code.claude.com/docs/en/headless | ADR-008; FR-AGT-008 |
| Obsidian properties | help.obsidian.md/properties | OBSIDIAN-SCHEMAS |
| Obsidian right-to-left support | docs.obsidian.md (Right-to-left), changelog 1.6 | OBSIDIAN-SCHEMAS §6 |
| Obsidian Bases | obsidian.md/help (Introduction to Bases), changelog 1.9 | ADR-003 (noted, not used) |

These are documentation readings, not observations of the owner's installation. Each fact relied on has a verification item in SECURITY-ARCHITECTURE §11.

## 3. Not done

No dependency installed. No application code written. No real document ingested. No Claude Code configuration applied. No PDF, DOCX or OCR library tried. No benchmark run. No test from TEST-CASES executed. No measurement of latency, throughput or capacity.

## 4. Files expected here later

`ENVIRONMENT-VERIFICATION.md` (V-01..V-15), `PDF-ARABIC-SPIKE.md`, `PHASE-2-GATE.md`, `BENCHMARK-PROTOCOL.md`, `PHASE-4-GATE.md`, `PHASE-7-SECURITY.md`, `PHASE-7-ACCEPTANCE.md`, `CAPACITY.md`, `RESTORE-DRILL.md`.
