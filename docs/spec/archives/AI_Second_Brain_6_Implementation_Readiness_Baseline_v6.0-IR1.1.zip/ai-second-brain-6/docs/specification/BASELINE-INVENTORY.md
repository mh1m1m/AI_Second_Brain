# Baseline Inventory

**DOC-INV** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Inventory of every artifact supplied for this pass, taken before any revision. Evidence source for each row is the file itself in `docs/_baseline/` (byte-for-byte snapshot with `SNAPSHOT-MANIFEST.md`). Status vocabulary: COMPLETE, PARTIALLY COMPLETE, INCOMPLETE, CONTRADICTORY, UNVERIFIED, OBSOLETE. A document is not complete because it has headings.

## 1. Inputs received

| # | Input | What it is | Use in this pass |
|---|---|---|---|
| I-1 | `AI SECOND BRAIN 4.0` (text) | Technology proposal with Qdrant, Neo4j, Docling, Playwright, nine agents | Historical reference |
| I-2 | `AI SECOND BRAIN 6.0` master directive (text) | Requirements-engineering mandate, specification-first | Governing: scope and stop-before-implementation rule |
| I-3 | `AI_Second_Brain_6_Specification_Package.zip` | 22 files, 347 lines, 30 KB | Contained unchanged in I-5 |
| I-4 | Implementation-ready specification engineering directive (text, in the owner's answer) | Mandate for this pass: structure of 29 documents, quality rules | Governing: deliverables and method |
| I-5 | `AI_Second_Brain_6_Implementation_Ready_Specification_Draft.zip` | 46 files (45 Markdown, 1 JSON), 909 lines, 81 KB | **Baseline inventoried below** |
| I-6 | V5.0 adversarial review description (text) | Ten findings, method, limits of what V5.0 established | Mandatory cross-validation: `V5-COMPLIANCE-MATRIX.md` |
| I-7 | V5.0 versus V6.0 comparison (text) | Assessment of where each is stronger | Review input |
| I-8 | V1.0–V7.0 evolution and roadmap (text) | Fifteen maturity gaps; V7 direction | Gap register §4; no V7 scope adopted |
| I-9 | Claude Code with Obsidian and agentic RAG guide (text) | Integration options and an activation prompt | AGENTIC-ARCHITECTURE §2, §4; PHASE-1-AUTHORIZATION-PROMPT |
| I-10 | 500-issue adversarial assurance directive (text) | 25 domains × 20 investigation questions | Coverage framework: `500-SLOT-COVERAGE.md` |
| I-11 | `ASB6_500_Adversarial_Audit_Evidence_Limited.zip` | 25 files: 15 specification findings; 500 slots all UNVERIFIED | Dispositioned in `GAP-REGISTER.md` §3 |
| I-12 | Owner clarification of 2026-11-10 | Authoritative implementation status; specification-only | Governing |

Not received: any implementation repository, code, test log, or running system. Owner decisions received during the pass: macOS; Arabic-first bilingual with RTL and LTR; public information only; fresh vault; V5.0 review mandatory.

## 2. Baseline package I-5

Totals: 46 files. Status counts are at the end of the table.

| Doc ID | File | Version | Lines | Bytes | SHA-256 (12) | Purpose | Status | Completeness, consistency, missing or conflicting content | Disposition |
|---|---|---|---:|---:|---|---|---|---|---|
| B-01 | `CLAUDE.md` | draft, unnumbered | 10 | 1197 | `918bca1fdaa4` | Claude Code project instructions — DRAFT | PARTIALLY COMPLETE | Declares SPECIFICATION-ONLY, which matches the authorisation state; lacks repository conventions, commands, gates | Replaced by `CLAUDE.md` (still specification-only) |
| B-02 | `README.md` | draft, unnumbered | 19 | 1519 | `384ece041c94` | AI Second Brain 6.0 — Specification Baseline (Draft) | PARTIALLY COMPLETE | Accurate about its own draft status and gates G0–G3; no package guide | Replaced by `README.md` |
| B-03 | `docs/architecture/AGENT-RESPONSIBILITY-MATRIX.md` | draft, unnumbered | 15 | 1148 | `0291c36bdc22` | Agent/service allocation | PARTIALLY COMPLETE | Consistent with V5.0 | Merged into `AGENTIC-ARCHITECTURE.md` §1 |
| B-04 | `docs/architecture/AGENTIC-ARCHITECTURE.md` | draft, unnumbered | 9 | 1065 | `bc67503f933e` | Agentic Architecture — Draft | PARTIALLY COMPLETE | Allocation sound; 'human approval' not defined technically | Replaced |
| B-05 | `docs/architecture/CLAUDE-CODE-DEVELOPMENT.md` | draft, unnumbered | 13 | 1188 | `0371f48fea78` | Claude Code Development Instructions — Draft | UNVERIFIED | Defers all Claude Code facts to a later check | Merged into `CLAUDE-CODE-CONTRACTS.md` |
| B-06 | `docs/architecture/DATA-ARCHITECTURE.md` | draft, unnumbered | 27 | 1746 | `1b9b069607b8` | Data Architecture — Draft | CONTRADICTORY | Models knowledge as `claims`/`claim_evidence`; the DDL in the same package uses `knowledge_records` and `memory_records` instead | Replaced (ADR-020) |
| B-07 | `docs/architecture/DATABASE-SCHEMA.md` | draft, unnumbered | 90 | 5787 | `7fc77e7ea77f` | SQLite database contract — proposed v1 | CONTRADICTORY | DDL executes without error on SQLite 3.53.1, but: `sources.sha256` is UNIQUE while `source_versions` also carries a hash, so a source cannot have a second version; `relationships` reference only `entities` while KNOWLEDGE-GRAPH requires edges between claims, sources and decisions; `projects` has no history although as-of reconstruction is required; tokenizer is raw `unicode61` | Replaced; DDL rewritten and probed |
| B-08 | `docs/architecture/HLD.md` | draft, unnumbered | 30 | 1703 | `5f8a1780e5b0` | High-Level Design — Draft | PARTIALLY COMPLETE | One diagram; no context, runtime or sequence views | Replaced |
| B-09 | `docs/architecture/KNOWLEDGE-GRAPH.md` | draft, unnumbered | 9 | 768 | `07e78605a105` | Knowledge Graph — Draft | CONTRADICTORY | Node list includes Source, Passage, Claim, Decision; DDL allows entity-to-entity edges only | Replaced |
| B-10 | `docs/architecture/LLD.md` | draft, unnumbered | 17 | 1714 | `43ee122ac7c7` | Low-Level Design — Draft | INCOMPLETE | Nine one-line module contracts | Replaced |
| B-11 | `docs/architecture/MEMORY-ARCHITECTURE.md` | draft, unnumbered | 13 | 1391 | `0cc188f48883` | Memory Architecture — Draft | PARTIALLY COMPLETE | State machine and evidence policy sound in outline; no schema, conflict algorithm or temporal rules | Replaced |
| B-12 | `docs/architecture/OBSIDIAN-SCHEMAS.md` | draft, unnumbered | 30 | 1684 | `e8bce6d0a17b` | Obsidian/Markdown schema v1 | PARTIALLY COMPLETE | One property set for all types; 'reconciled by hash' undefined | Replaced |
| B-13 | `docs/architecture/RETRIEVAL-ARCHITECTURE.md` | draft, unnumbered | 11 | 1183 | `e2eb2b7213f7` | Retrieval Architecture — Draft | UNVERIFIED | No tokenizer or normalisation decision; Arabic behaviour assumed | Replaced with probe evidence |
| B-14 | `docs/architecture/RETRIEVAL-BENCHMARK.md` | draft, unnumbered | 7 | 1327 | `f849038fb02c` | Retrieval benchmark specification — no results claimed | PARTIALLY COMPLETE | Reasonable blueprint; correctly claims no results | Merged into `RETRIEVAL-ARCHITECTURE.md` §9–10 |
| B-15 | `docs/architecture/TRANSACTION-PROTOCOL.md` | draft, unnumbered | 26 | 1917 | `929b7cc19c76` | File + SQLite commit and recovery contract | PARTIALLY COMPLETE | Correct in refusing to claim atomicity; recovery after rename 'inserts metadata' without saying where the metadata to insert is kept; no rule for an owner edit in the window | Merged into `DATA-ARCHITECTURE.md` §5 |
| B-16 | `docs/architecture/WORKFLOW-CONTRACTS.md` | draft, unnumbered | 22 | 1594 | `647191dea1cc` | Durable workflow contracts | INCOMPLETE | State names without guards, side effects, failure or recovery transitions; memory line is ambiguous about which states may follow which | Replaced |
| B-17 | `docs/decisions/ADR-PROPOSALS.md` | draft, unnumbered | 16 | 1528 | `1e79aaf27a27` | Architecture decision proposals (not approved) | INCOMPLETE | Second table of the same ten decisions with different wording | Merged into `ADR-REGISTER.md` |
| B-18 | `docs/decisions/ADR-REGISTER.md` | draft, unnumbered | 15 | 1199 | `11895670a8dc` | Architecture Decision Register — Proposed, Not Approved | INCOMPLETE | Table of ten one-line decisions; no context, alternatives, consequences or evidence | Replaced; ADR-001..010 subjects preserved |
| B-19 | `docs/engineering/CLAUDE-CODE-CONTRACTS.md` | draft, unnumbered | 9 | 1450 | `db2706983c9c` | Claude Code integration contract — verification required | UNVERIFIED | States that nothing was verified | Replaced; documentation verified 2026-11-10, target machine pending |
| B-20 | `docs/engineering/CLI-SPECIFICATION.md` | draft, unnumbered | 21 | 1771 | `41637df06b6a` | CLI interface contract (proposed, not implemented) | PARTIALLY COMPLETE | 13 commands; exit codes kept; no per-command validation, errors or tests | Replaced; exit codes preserved |
| B-21 | `docs/governance/ENGINEERING-HANDOFF.md` | draft, unnumbered | 24 | 1703 | `2a8fd4a19725` | Engineering handoff — proposed baseline, 2026-11-10 | PARTIALLY COMPLETE | Accurate summary of an incomplete package | Replaced |
| B-22 | `docs/governance/IMPLEMENTATION-READINESS.md` | draft, unnumbered | 28 | 1813 | `fa3c493b4dc5` | Implementation readiness assessment — 2026-11-10 | PARTIALLY COMPLETE | Verdict NOT READY is correct; blockers 1 and 2 since answered | Replaced |
| B-23 | `docs/governance/QUALITY-REPORT.json` | draft, unnumbered | 17 | 373 | `1fad84599684` | Quality counts | PARTIALLY COMPLETE | Counts only; no checks | Replaced; generated by `tools/spec_lint.py` |
| B-24 | `docs/governance/RED-TEAM-REVIEW.md` | draft, unnumbered | 21 | 2741 | `8b62b2c27822` | Independent adversarial specification review (desk review) | PARTIALLY COMPLETE | Exactly 20, 15, 15, 10 and 10 one-phrase items with no severity; says mitigations were added without saying where | Replaced by `ADVERSARIAL-REVIEW.md` |
| B-25 | `docs/operations/DEPLOYMENT-SPECIFICATION.md` | draft, unnumbered | 11 | 1786 | `e83beb339410` | Deployment specification — conditional | OBSOLETE | Written for an unknown operating system; the owner has since chosen macOS | Replaced |
| B-26 | `docs/operations/OPERATIONS.md` | draft, unnumbered | 11 | 1151 | `76eb37547a17` | Operations and Reliability — Draft | PARTIALLY COMPLETE | Sound outline; nothing executable | Merged into `DEPLOYMENT-SPECIFICATION.md` |
| B-27 | `docs/planning/ASSUMPTIONS.md` | draft, unnumbered | 15 | 1231 | `42312789c4e7` | Assumptions and Decisions Requiring Approval | OBSOLETE | Q-01, Q-02, Q-04, Q-11 answered by the owner on 2026-11-10; others still open | Replaced by `DECISIONS-FOR-APPROVAL.md` and readiness §4 |
| B-28 | `docs/planning/ENGINEERING-BACKLOG.md` | draft, unnumbered | 15 | 1169 | `082fb7100d39` | Engineering Backlog — Draft | CONTRADICTORY | TASK-001..010 mean different things from TASK-001..016 in the detailed backlog | Replaced; IDs retired |
| B-29 | `docs/planning/FILE-BUILD-PLAN.md` | draft, unnumbered | 22 | 1776 | `e2ba9c71f887` | Proposed file-by-file implementation plan — no code created | CONTRADICTORY | 16 rows; places the database schema in Phase 4 although the Phase 2 registry and journal need it | Replaced |
| B-30 | `docs/planning/IMPLEMENTATION-BACKLOG-DETAILED.md` | draft, unnumbered | 20 | 2316 | `b812c6d7b19b` | Implementation backlog — proposed, no implementation authori | CONTRADICTORY | One task per requirement generated mechanically; TASK-010 (project history) placed in Phase 3 while the roadmap has it in Phase 6; no files or verification commands | Replaced |
| B-31 | `docs/planning/IMPLEMENTATION-ROADMAP-DETAILED.md` | draft, unnumbered | 17 | 1379 | `d5f47fbec053` | Implementation phases and gates | PARTIALLY COMPLETE | Phases consistent with the directive; no scope, interfaces or controls per phase | Replaced |
| B-32 | `docs/planning/IMPLEMENTATION-ROADMAP.md` | draft, unnumbered | 16 | 857 | `87530cc68e03` | Implementation Roadmap — Draft | OBSOLETE | Duplicated by the detailed roadmap | Replaced |
| B-33 | `docs/planning/PRODUCTION-READINESS.md` | draft, unnumbered | 11 | 668 | `877c7c87444e` | Production Readiness Criteria — Draft | PARTIALLY COMPLETE | Reasonable criteria | Merged into `IMPLEMENTATION-ROADMAP.md` §4 |
| B-34 | `docs/requirements/ATOMIC-REQUIREMENTS.md` | draft, unnumbered | 37 | 3454 | `084223edaffb` | Atomic requirements catalogue — proposed baseline | PARTIALLY COMPLETE | Second requirements catalogue beside the SRS (16 of its 21 IDs, different priority vocabulary); adds NFR-006 | Merged into `SRS.md` |
| B-35 | `docs/requirements/BRD.md` | draft, unnumbered | 27 | 2732 | `3d1d71e195ea` | Business Requirements Document (BRD) — Draft v0.1 | PARTIALLY COMPLETE | 9 requirements; no measurable objectives, capability model, journeys or enforceable rules | Replaced; IDs BRD-001..009 preserved |
| B-36 | `docs/requirements/PRD.md` | draft, unnumbered | 18 | 1661 | `694b5751e04c` | Product Requirements Document — Draft v0.1 | PARTIALLY COMPLETE | 10 features without user problem, dependencies or failure states; three personas for one user | Replaced; IDs PRD-001..010 preserved |
| B-37 | `docs/requirements/SRS.md` | draft, unnumbered | 27 | 2700 | `9974d4e0e95c` | Software Requirements Specification — Draft v0.1 | INCOMPLETE | 21 requirements with no rationale, dependencies, inputs, outputs or exceptions; 5 NFRs; FR-MEM-001 omits states `captured` and `deleted` that the memory document defines | Replaced; all 21 IDs preserved |
| B-38 | `docs/requirements/TRACEABILITY-IMPLEMENTATION.md` | draft, unnumbered | 20 | 1673 | `2e47eec1fb48` | Implementation traceability — proposed | CONTRADICTORY | Objectives `OBJ-01..06` are defined nowhere and are assigned in rotation; task IDs collide with `ENGINEERING-BACKLOG.md`; 'contract' column names one of two files for every row | Replaced by `TRACEABILITY-MATRIX.md` |
| B-39 | `docs/requirements/TRACEABILITY-MATRIX.md` | draft, unnumbered | 13 | 861 | `adbb30a93913` | Requirements Traceability — Draft | INCOMPLETE | 8 rows covering 12 of 21 requirements; BRD-008 and BRD-009 untraced | Replaced |
| B-40 | `docs/security/SECURITY-ARCHITECTURE.md` | draft, unnumbered | 14 | 1293 | `f7977f034956` | Security Architecture — Draft | INCOMPLETE | Threat list without enforcement mechanism per control | Replaced |
| B-41 | `docs/security/THREAT-CONTROL-MATRIX.md` | draft, unnumbered | 14 | 1420 | `888e54a728f5` | Security threat/control matrix | PARTIALLY COMPLETE | Column 'enforced control' lists instruction-level measures (treat content as data) beside real enforcement | Merged into `SECURITY-ARCHITECTURE.md` §4 with an enforcement column |
| B-42 | `docs/specification/BASELINE-INVENTORY.md` | draft, unnumbered | 28 | 4084 | `70bed346a29b` | Baseline inventory — 2026-11-10 | INCOMPLETE | Same finding text on all 22 rows; 21 of its 22 recorded sizes do not match the files in its own package (they look like character counts, not bytes); its hash prefixes match (0 mismatches) | Replaced by this document |
| B-43 | `docs/specification/CHANGE-REGISTER.md` | draft, unnumbered | 10 | 566 | `aa376c0e7e37` | Change register | INCOMPLETE | 4 rows | Replaced |
| B-44 | `docs/specification/GAP-REGISTER.md` | draft, unnumbered | 18 | 2427 | `c584c42fde6d` | Gap register | PARTIALLY COMPLETE | 12 real gaps; identical owner-and-verification boilerplate | Replaced; GAP-001..012 preserved and dispositioned |
| B-45 | `docs/testing/TEST-CASES.md` | draft, unnumbered | 39 | 5288 | `80196a0e5d6f` | Test case contracts — designed, NOT executed | INCOMPLETE | 16 cases produced from one sentence template ('Exercise X; inject Y condition'); identical expected-result wording; not executable as written | Replaced by 142 specific cases |
| B-46 | `docs/testing/TEST-STRATEGY.md` | draft, unnumbered | 7 | 1359 | `cbbb92cea7ad` | Test Strategy — Draft | PARTIALLY COMPLETE | 20 scenario labels T-001..T-020; no fixtures or method | Replaced; mapping kept in §9 |

Status counts: CONTRADICTORY 7; INCOMPLETE 10; OBSOLETE 3; PARTIALLY COMPLETE 23; UNVERIFIED 3. None is COMPLETE.

## 3. Cross-document conflicts found in the baseline

| # | Conflict | Files | Resolution |
|---|---|---|---|
| X-1 | Two knowledge models: `claims` versus `knowledge_records` + `memory_records` | DATA-ARCHITECTURE, DATABASE-SCHEMA | One model (ADR-020) |
| X-2 | Graph nodes of many types versus entity-only edges | KNOWLEDGE-GRAPH, DATABASE-SCHEMA | `objects` registry; edges between any objects (ADR-016) |
| X-3 | A source may have versions, but its hash is unique at source level | DATABASE-SCHEMA | Hash only on `source_versions` |
| X-4 | As-of project reconstruction required; no history table | SRS, DATABASE-SCHEMA | `project_events` |
| X-5 | Two backlogs reuse TASK-001..016 with different meanings | ENGINEERING-BACKLOG, IMPLEMENTATION-BACKLOG-DETAILED, TRACEABILITY-* | New four-digit task IDs; old ones retired |
| X-6 | Project history task in Phase 3 versus Phase 6; schema file in Phase 4 though needed in Phase 2 | backlog, roadmap, file plan | Single generated plan |
| X-7 | Traceability uses objectives OBJ-01..06 that no document defines | TRACEABILITY-IMPLEMENTATION | BO-01..08 defined in the BRD |
| X-8 | Memory states: seven in the memory document and DDL, five in the SRS | SRS, MEMORY-ARCHITECTURE | Seven everywhere |
| X-9 | Two requirement catalogues, two ADR tables, two roadmaps, two traceability matrices | several | One of each |
| X-10 | Root `CLAUDE.md` says specification-only while later audit material assumed implementation was under way | CLAUDE.md, audit package | Owner clarification: no implementation has been supplied or verified, and none is authorised; `CLAUDE.md` stays specification-only |
| X-11 | The draft's own inventory records sizes that do not match its files (hashes do match) | BASELINE-INVENTORY | Recomputed here |

## 4. Audit package I-11

25 files. `04-CONFIRMED-DEFECTS.md` lists 15 specification gaps, each a restatement of something the draft itself admits; `16-IMPLEMENTATION-CORRECTION-CONTRACTS.md` repeats one verification sentence for all 15; nine files are three-line stubs; `machine-readable/investigation-matrix.json` holds 500 identical UNVERIFIED entries; `traceability.json` is 75 bytes. Status of the package as an audit of an implementation: UNVERIFIED by its own statement. Its 15 findings are valid as specification findings and are dispositioned individually.
