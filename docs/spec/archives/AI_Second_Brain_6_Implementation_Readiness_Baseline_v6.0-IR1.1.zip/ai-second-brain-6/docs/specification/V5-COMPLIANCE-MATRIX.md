# V5.0 → V6.0 Compliance Matrix

**DOC-V5** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

The V5.0 adversarial review is a mandatory reference for this baseline (owner decision D-05). This matrix maps each V5.0 finding to the requirement, component, decision and tests that answer it, and says what is still unproven. "Specified" is not "validated": V5.0 itself was a design review, and nothing here has run except two probes.

## 1. The ten findings

| # | V5.0 finding | Required V6.0 response | Requirements | Components | Contract | ADR | Tests | Specification status | Validation status |
|---|---|---|---|---|---|---|---|---|---|
| F1 | Canonical data authority undefined | Data ownership matrix | FR-KNW-005, FR-KNW-004, FR-OPS-001, NFR-021 | CMP-NOT, CMP-RET | DATA-ARCHITECTURE §2, §4 | ADR-012, ADR-020 | TEST-KNW-005..007, TEST-OPS-001 | Addressed: 15 data classes, one authority and one writer each; projection and drift rules | Not validated; needs implementation |
| F2 | Memory updates not transactionally safe | Transaction and reconciliation protocol | FR-AGT-002, FR-OPS-005, FR-MEM-006, FR-MEM-007, NFR-002, NFR-018 | CMP-JRN, CMP-WFL, CMP-MEM | DATA-ARCHITECTURE §5–6; WORKFLOW-CONTRACTS | ADR-013 | TEST-REC-001..010, TEST-MEM-010 | Addressed: commit protocol S0–S7, recovery table, single writer, immutable revisions | Schema triggers probed (27/27); protocol not validated until the crash suite runs; V-10 |
| F3 | False-memory contamination | Provenance and verification rules | FR-MEM-002, FR-MEM-003, FR-MEM-004, FR-MEM-012, FR-RET-002 | CMP-MEM, CMP-RET | MEMORY-ARCHITECTURE §3, §10 | ADR-020 | TEST-MEM-003, 004, 007, 015; TEST-RET-003 | Addressed: seven epistemic types; evidence trigger; derived statements unverifiable; owner-only attestation | Triggers T3–T5 probed; residual: owner approves a statement its passage does not support |
| F4 | Too many agents | Responsibility allocation model | FR-AGT-008, FR-AGT-007 | CMP-CCW, CMP-OPS | AGENTIC-ARCHITECTURE §1, §7 | ADR-008 | TEST-AGT-012, TEST-AGT-011 | Addressed: one orchestrator, no operating subagents, one read-only reviewer in development | Design decision; nothing to validate beyond configuration (V-02) |
| F5 | Qdrant premature | Retrieval benchmark gate | FR-RET-008, NFR-007 | CMP-EVL | RETRIEVAL-ARCHITECTURE §9–10 | ADR-005, ADR-006 | TEST-RET-012, TEST-NFR-007 | Addressed: gates RET-G1, RET-G2 with numeric criteria | No benchmark exists (D-10) |
| F6 | Neo4j and GraphRAG premature | Typed relationship schema | FR-KNW-006, FR-KNW-007 | CMP-GRF | KNOWLEDGE-GRAPH §3–6 | ADR-007 | TEST-KNW-008..011 | Addressed: 11 predicates with definitions, evidence and validity; gate for a graph database | Not validated |
| F7 | Durable workflow execution missing | Workflow state machines | FR-AGT-002, FR-AGT-003, FR-AGT-006 | CMP-WFL, CMP-PRP | WORKFLOW-CONTRACTS WF-1..WF-6, §8 | ADR-008, ADR-013 | TEST-AGT-005, 006, 010; TEST-REC-* | Addressed: six state machines with guards, side effects, failure and recovery transitions; no state in sessions | Not validated |
| F8 | Security boundaries underdeveloped | Enforceable permission model | FR-SEC-001..008, FR-AGT-001, FR-AGT-004, NFR-019 | CMP-SEC, CMP-PRP, CMP-CCW, CMP-AUD | SECURITY-ARCHITECTURE §4–5; CLAUDE-CODE-CONTRACTS §5 | ADR-015, ADR-009, ADR-018 | TEST-SEC-001..015, TEST-AGT-001..008 | Addressed on paper: five layers with an enforcement type per control; settings checked against current documentation | **Open:** V-03 to V-07 on the installed Claude Code version decide whether layers L1–L2 hold |
| F9 | Git overextended | Independent backup and restoration | FR-OPS-002, FR-OPS-003, FR-OPS-010, NFR-006 | CMP-OPS | DEPLOYMENT-SPECIFICATION §6 | ADR-010 | TEST-OPS-003..006, 015; TEST-ACC-009 | Addressed: manifest, verification, scheduled restore test, reversible restore | Destination and objectives undecided (D-06); nothing run |
| F10 | Evaluation not formalised | Test harness and acceptance criteria | FR-RET-008, all `acceptance` fields, NFR-001..022 | CMP-EVL | TEST-STRATEGY; TEST-CASES; IMPLEMENTATION-ROADMAP gates | ADR-011 | 142 cases, 62 adversarial | Addressed: every requirement has a test; gates need recorded evidence | Nothing executed except DDL and tokenizer probes |

## 2. Other V5.0 obligations

| V5.0 item | Status in this baseline |
|---|---|
| Six-architecture comparison (Method C) | Summarised in ADR-011 and HLD §11 as reasoning. V5.0's ten evaluation dimensions were not scored quantitatively; no data exists to score them |
| Failure mode and effects analysis (Method D) | HLD §8 lists failure, cause, effect, detection, response, residual risk for 14 failures. Likelihood and severity scores are not assigned (no operating data) |
| Dependency and coupling analysis (Method E) | LLD §2 dependency rule; NFR-011; HLD §10 list of what is not used |
| Empirical evaluation design (Method F) | RETRIEVAL-ARCHITECTURE §9; TEST-STRATEGY |
| Architecture decision records (Method G) | ADR-REGISTER: 20 records with context, alternatives, consequences, evidence, reversal |
| At least 50 stress scenarios | 63 adversarial cases designed across the five V5.0 categories; none executed |
| Scalability profiles S1–S5 | HLD §9, estimates only; NFR-012; measured in TASK-0801 |
| Economic sustainability | NFR-015 payload budget; no model call from Python; dependency limit. Model subscription or usage cost is not modelled (D-13) |
| Fourteen conceptual memory categories | MEMORY-ARCHITECTURE §2 maps them onto seven stored kinds plus existing tables |
| 100 critical architectural questions; 24-perspective committee | Not reproduced. The 500-slot framework of the later audit directive covers the same ground (500-SLOT-COVERAGE) |
| Provisional success criteria | Adopted in BRD §8: provenance 100%; Recall@10 ≥ 0.90 overall; unauthorised writes 0; correction propagation 100%; unsupported claims ≤ 2%. Two are stated more strictly: citation validity 1.00 (V5.0: ≥ 0.95) because locator resolution is deterministic; recovery and reconstruction 100% of defined tests (V5.0: ≥ 95%) because no evaluation set exists to take a percentage of |

## 3. Regressions and changes relative to V5.0

No V5.0 recommendation is reversed. Changes that go beyond V5.0, each with new evidence:

| Change | New evidence |
|---|---|
| FTS5 kept, but raw `unicode61` rejected in favour of application normalisation | Tokenizer probe (RETRIEVAL-ARCHITECTURE §2) |
| Backup encryption optional rather than assumed | Owner's public-information decision (D-03) |
| "Markdown links first" for relationships replaced by typed SQLite rows from the start, with wikilinks as navigation only | V5.0 itself recommended typed SQLite relationships as the starting point (its §9); the V6.0 draft's DDL could not hold them |
| Knowledge and code separated into two directories | Claude Code documentation on working-directory scope of settings and sandbox |
| Docling and Playwright from 4.0 not carried forward | Dependency minimalism; no requirement needs browser automation |

Unresolved relative to V5.0: every item in the "Validation status" column. V5.0's own caveat applies unchanged to this document: it is a design baseline, not proof.
