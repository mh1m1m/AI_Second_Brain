# Deployment and Operations Specification

**DOC-OPS** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `DEPLOYMENT-SPECIFICATION.md` and `OPERATIONS.md` of the V6.0 draft. Addresses V5.0 finding 9 and audit issues ASB6-ISSUE-0004 and 0013. **Nothing in this document has been executed.**

## 1. Supported platform

macOS, one user account (decision D-01). The macOS version, processor architecture and available disk are not yet recorded; they are captured by V-01 and become the supported baseline. Linux and Windows are not supported or tested in version 1; the code avoids gratuitous platform dependence but nothing is claimed.

## 2. Prerequisites

| Item | Requirement | How it is checked |
|---|---|---|
| Python | ≥ 3.12 (decision D-15) | `doctor` DOC-ENV-01 |
| SQLite as used by that Python | ≥ 3.45, FTS5 available, STRICT tables | DOC-ENV-02; the system Python on macOS may link an older SQLite — if so use a Python build that bundles a current one |
| Python tool manager | `uv` (proposed, D-15) for the virtual environment and hash-locked dependencies | `make check` |
| Runtime packages | PyYAML; python-docx; one PDF text library chosen by spike V-12 (ADR-017) | lockfile |
| Development packages | pytest, coverage, mypy, ruff | lockfile |
| Git | any current version | — |
| Claude Code | version recorded at V-02 | `claude --version`, `claude doctor` |
| Obsidian | optional; version recorded at V-11 | — |
| Disk | Home volume with free space ≥ 3 × expected corpus; backup destination on a different physical device | DOC-ENV-03, DOC-BKP-03 |

Package names are proposals to be confirmed when they are installed with the owner's approval; no dependency has been installed or tested for this specification.

## 3. Installation procedure (to be executed in Phase 1, step by step with approval)

1. Record V-01 facts. Stop if SQLite or Python does not meet §2.
2. Clone or create the development repository at `~/Developer/ai-second-brain`; create the virtual environment from the lockfile (`uv sync --frozen`); run `make check`.
3. Install the CLI as an isolated tool outside both working directories (`uv tool install .` places the executable under `~/.local/bin`); record its absolute path — it is substituted for `/ABS/` in the operating settings and skills.
4. In a terminal: `second-brain init --home ~/SecondBrain` (tier 2, interactive confirmation). This creates the home, vault skeleton, data directories, configuration, database at schema 1, and the Claude Code workspace files with absolute paths filled in.
5. `second-brain doctor` must pass.
6. Open `~/SecondBrain/vault` in Obsidian (optional); confirm restricted mode is on.
7. Start `claude` in `~/SecondBrain`; accept the workspace trust dialog after reading the listed allow rules; run `/status` and `claude doctor`.
8. Execute verification items V-02 to V-14; record results. Any failed item is resolved or its control's fallback adopted before real content is ingested.
9. Configure the backup destination; `second-brain backup create`; `second-brain backup restore-test`.
10. `second-brain schedule install` (tier 2).

Reproducibility: steps 2–5 and 9 are scripted in the Makefile and exercised by TEST-OPS-013; steps 6–8 are manual with a recorded checklist.

## 4. Directories and modes

| Path | Mode | Notes |
|---|---|---|
| `~/SecondBrain` | 0700 | Owner only |
| `vault/` and its folders | 0755 dirs, 0644 files | Obsidian needs write access |
| `data/originals/**` | 0755 dirs, **0444 files** | Read-only artifacts |
| `data/db/` | 0700; database 0600 | |
| `data/staging/`, `data/quarantine/`, `data/locks/` | 0700 | Same volume as vault and originals |
| `data/logs/` | 0700; files 0600 | |
| `.claude/`, `CLAUDE.md`, `config/` | 0755 dirs, 0644 files | Protected by settings and hash verification, not by mode (the owner must be able to update them) |
| CLI installation | owner-writable, outside every Claude Code working directory | |

File modes do not separate Claude Code from the owner: both run as the same user. They prevent accidents. Separation comes from SECURITY-ARCHITECTURE §5.

## 5. Configuration

Environment variables: `SECOND_BRAIN_HOME` (default `~/SecondBrain`), `NO_COLOR`. No other variable changes behaviour; in particular no secret is read from the environment.

`config/second-brain.toml` (all keys shown with defaults; unknown keys are errors):

```toml
schema = 1
[owner]
name = "Mohammed Alsaleh"           # recorded as actor for terminal operations
[intake]
max_bytes = 209715200               # 200 MB
media_types = ["text/markdown", "text/plain", "text/html",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/pdf"]
extract_timeout_s = 120
extract_max_text_bytes = 52428800
pdf_min_chars_per_page = 50
[segment]
target_min = 200
target_max = 1200
hard_max = 2000
[search]
default_limit = 10
max_terms = 32
payload_token_budget = 6000
log_queries = true
query_log_days = 180
[ranking]
weights = [2.0, 1.0, 0.5]           # title, text, stem
[approvals]
tier1_in_session = true             # decision D-08
proposal_ttl_days = 14
max_open_proposals = 200            # GAP-033; creation refused at the limit, nothing discarded
max_proposals_per_run = 50
approval_ttl_minutes = 30
[freshness]
review_months = { semantic = 24, procedural = 12, project = 3, preference = 12, operational = 12 }
[backup]
destinations = []                   # labels and absolute paths outside the home (D-06)
keep_daily = 14
keep_weekly = 8
encrypt = false                     # application-level encryption; volume-level encryption is the recommended route (D-06)
[locks]
writer_timeout_s = 5
```

## 6. Backup and restore

- **What:** consistent SQLite snapshot taken with the online backup API; the vault (including its `.git`); originals not already at the destination (copied by hash, never rewritten); `config/`; the installed workspace files; a manifest with SHA-256 per file, schema version, package version and audit chain head.
- **Where:** a directory on a **separate physical device** from the home: an external disk, another machine or network storage. A second volume on the same disk is not a backup destination; it fails with the disk (correction CHG-027). Optionally a second destination in a synchronised cloud folder. Decision D-06. Git is not a backup: it does not cover the database or the originals.
- **When:** on demand from Phase 2; daily by launchd once scheduling exists (Phase 9); before every migration and restore.
- **Sequence (GAP-034, corrected in IR1.1):** `backup create`, `verify` and `restore-test` are built in Phase 2 and are part of the Phase 2 gate. No owner document is ingested until one backup at the configured destination is in state `restore_tested` (DOC-BKP-04). Until the tier 2 `restore` command exists (Phase 9), recovery is the manual procedure of runbook RB-02: restore-test into a new directory, check the report, move the result into place.
- **Verification:** after writing, every file is re-read and compared with the manifest → `verified`. Weekly, the newest backup is restored into a temporary directory and checked (`integrity_check`, `foreign_key_check`, audit chain, 100 sampled originals, index rebuild smoke) → `restore_tested`.
- **Retention:** 14 daily, 8 weekly (proposed). Expiry removes snapshots, never originals still referenced by a kept manifest.
- **Encryption:** decision D-06. IR1 proposed "off" because the sources are public; that reasoning overlooked that backups also hold the owner's own queries, preferences, decisions and notes. Current recommendation: encrypt at the volume level (APFS-encrypted external disk or encrypted disk image), with the passphrase in the Keychain and a recovery copy kept offline, and include unlocking in every restore drill. A lost passphrase makes the backups worthless.
- **Objectives (provisional, D-06):** RPO 24 h, RTO 4 h at profile S2. Neither has been measured.
- **Deletion and backups:** a purge reports which kept backups still contain the purged text and when each expires; the owner may expire them early (tier 2).

## 7. Monitoring and maintenance

No monitoring service. Health is `doctor` (one exit code), a status file per scheduled job in `data/logs/status/`, and the dashboard `07-Dashboards/System Health.md`.

Doctor check catalogue:

| ID | Check | Fails when |
|---|---|---|
| DOC-ENV-01/02/03/04/05 | Python version; SQLite version and features; same-volume rule; directory modes; absolute paths in settings, skills and launchd definitions still point at this home and executable | below requirement or mismatch |
| DOC-DB-01/02/03/04 | `integrity_check` and `foreign_key_check`; connection pragmas; schema hash and migration checksums; every `objects` row agrees with its ID prefix and has exactly one row in the table for its type | any mismatch |
| DOC-JRN-01/02 | Journal operations in `intent` or unknown state; orphan staging directories | any (01); older than a day (02, warn) |
| DOC-STO-01/02 | Every source version has its file and every file a row; hashes verify (sample of 200, all with `--deep`) | any mismatch |
| DOC-EXT-01 | Extractions failed or `needs_ocr` | warn with list |
| DOC-NOT-01/02 | Registry versus files (missing, unregistered, drift); validation errors | error-severity findings |
| DOC-IDX-01/02 | Dirty or stale index, version mismatch; unit counts versus expected | any |
| DOC-MEM-01/02 | Verified record without live evidence (query Q5); review queue size | any (01); above threshold (02, warn) |
| DOC-AUD-01 | Audit chain verifies | break |
| DOC-SEC-01..06 | Forbidden files (SEC-F01); workspace file hashes; `.mcp.json` or MCP configuration present; Obsidian community plugins; rules in `settings.local.json`; secret patterns in configuration | any (04, 05 warn) |
| DOC-BKP-01/02/03 | Newest verified backup older than RPO; newest restore-tested backup older than 35 days; destination unreachable | any |
| DOC-BKP-04/05 | Owner documents are registered and no restore-tested backup exists (ingestion of owner documents is refused until one does); destination shares a physical device with the home | any |
| DOC-PRP-01 | Open proposals above 80% of the configured limit | 5 |
| DOC-PRP-01 | Proposals awaiting approval longer than 7 days | warn |

Maintenance calendar: daily (automatic) backup and `doctor`; weekly (automatic) `doctor --deep` and restore-test; weekly (owner, about ten minutes) review the proposal queue, memory review queue and health dashboard; monthly (owner) look at the query log for unanswered questions and add benchmark questions; quarterly (owner) timed restore drill (RB-02) and dependency review.

Alerting: a failed scheduled job writes its status file and the dashboard shows it at next build. There is no push notification in version 1.

## 8. Upgrade and rollback

1. `doctor` passes. 2. `backup create` and `restore-test`. 3. Install the new version of the tool. 4. `second-brain migrate` (tier 2) if the schema changed: pre-migration backup, transactional migration, post-checks. 5. `workspace install` if the workspace template changed (shows a diff; tier 2). 6. `index rebuild` if normaliser, stemmer or segmentation versions changed. 7. `doctor --deep`; run the benchmark and compare with the previous report.

After any Claude Code upgrade: record the new version and re-run verification items V-02 to V-08, V-14 and V-15 before the next session on real content; documented behaviour can change between versions.

Rollback: reinstall the previous tool version and `restore` the pre-upgrade backup. There are no down-migrations.

## 9. Runbooks

| ID | Situation | Procedure (summary; full steps are written in TASK-0903) |
|---|---|---|
| RB-01 | Routine | Weekly review as in §7 |
| RB-02 | Home lost or damaged | Install tool; `restore <newest restore_tested backup>` into a new home (before Phase 9, when `restore` does not yet exist: `backup restore-test` into a new directory, read the report, move that directory into place by hand); `doctor --deep`; `index rebuild`; record time taken |
| RB-03 | Database corrupt, files intact | Stop; copy the damaged file aside; restore the newest backup into a temporary home; `notes sync` against the current vault to adopt later edits; re-ingest sources registered after the backup from `originals` (hash list diff); `doctor --deep` |
| RB-04 | Read-only mode after an unknown recovery state | `runs --open`; inspect the named journal operations and the files; choose per operation: accept the file as owner edit, restore the staged file from quarantine, or abandon the run; `recovery resolve`; never delete from `originals` |
| RB-05 | Failed upgrade or migration | §8 rollback |
| RB-06 | Suspected tampering or injection | SECURITY-ARCHITECTURE §10 |

Severity for the incident note: S1 knowledge or evidence lost or altered; S2 system unusable; S3 degraded (stale index, backup overdue); S4 cosmetic. Each S1/S2 incident gets an operational memory record with cause and fix.

## 10. Scheduling

Three user-level launchd agents generated by `schedule install`: `backup create` daily, `doctor` daily after it, `doctor --deep` and `backup restore-test` weekly. Each runs the installed CLI by absolute path with no network need and writes `data/logs/status/<job>.json`. Jobs missed during sleep run at the next wake if launchd does so on this macOS version (V-13); the backup-age check catches the case where it does not. No scheduled job starts Claude Code.

## 11. Removal

`schedule remove`; delete the tool installation; the home is plain files and may be kept, exported or deleted by the owner. Nothing is installed system-wide.
