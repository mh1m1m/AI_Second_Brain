# Phase 1 Authorisation Prompt

**DOC-AUTH** · v6.0-IR1.1 · 2026-11-10 · Status: TEMPLATE — NOT ISSUED · Owner: Mohammed Alsaleh

This is the text the owner gives to Claude Code, in the development repository, to move from specification-only mode to Phase 1. **Do not use it before** DECISIONS-FOR-APPROVAL.md section G is completed (at least D-07, D-15, D-18). It replaces the "activation prompt" in the earlier guide, which asked for a working ingestion-to-retrieval system in one step; this one authorises one phase.

There are two versions. Use A if you want the Mac checked before anything is installed.

## A. Verification only (no installation, no code)

```
You are working in the AI Second Brain 6.0 development repository. Mode remains SPECIFICATION-ONLY.

I authorise a read-only environment verification, nothing else:
1. Record macOS version, processor, free disk space, python3 versions available, and for each the sqlite3 library version and whether FTS5 and STRICT tables work.
2. Record the Claude Code version (claude --version) and the Obsidian version if installed.
3. Run: python3 -I docs/specification/evidence/fts5_arabic_probe.py and python3 -I docs/specification/evidence/ddl_check.py docs/specification/evidence/schema_v1.sql, and compare with the recorded outputs.
4. List, without changing anything: the skills, plugins, hooks and MCP servers my Claude Code currently loads (personal, synced, plugin), and the key names (not values) set in ~/.claude/settings.json.
5. Write the results to docs/specification/evidence/ENVIRONMENT-VERIFICATION.md (items V-01, V-02 partial, V-09, V-15 partial) and list any difference as a finding.

Do not install anything, create any directory outside this repository, change any setting, or write any application code. Stop and report when done.
```

## B. Phase 1 — Foundation

```
You are working in the AI Second Brain 6.0 development repository.

I have approved the decision sheet docs/governance/DECISIONS-FOR-APPROVAL.md (see its record of approval, section 7) and the requirements and ADR baseline v6.0-IR1.1 with the amendments noted there.

I authorise Phase 1 (Foundation) only: tasks TASK-0101 to TASK-0107 in docs/planning/IMPLEMENTATION-BACKLOG.md.

Rules:
1. First update CLAUDE.md: change the mode line to "PHASE 1 AUTHORISED (tasks TASK-0101..0107)", and record the change in the change register.
2. Do TASK-0101 (environment verification, V-01 to V-15 as far as they can be done in Phase 1) before writing code. If Python, SQLite or Claude Code does not meet the prerequisites, or a V-item fails, stop and report with options.
3. Ask me before each of: installing a tool or dependency; creating the virtual environment; creating any directory outside this repository; creating ~/SecondBrain (init); accepting any Claude Code trust or permission change.
4. Follow docs/planning/FILE-BUILD-PLAN.md and docs/architecture/LLD.md. Create only the files listed for Phase 1. No placeholders for later phases.
5. Write each test before the code it tests; name tests after their test-case IDs; tests use temporary directories only.
6. Do not ingest any real document. Do not start Phase 2.
7. Where the specification is wrong or silent, stop and propose a change to the specification; do not improvise an architectural decision.
8. At the end: run the full Phase 1 test list, save the output with environment facts to docs/specification/evidence/PHASE-1-GATE.md, update the traceability status, and report implemented features, tests run and their results, open issues, risks, and whether the Phase 1 exit gate is met.

Do not claim a test passed unless you ran it. Stop after the report.
```

## What issuing B changes

- `CLAUDE.md` mode line (by Claude Code, as its first action, recorded in the change register).
- Nothing else in the specification. Later phases need their own explicit authorisation.
