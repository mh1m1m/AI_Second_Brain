# Targeted Corrections Register

**DOC-TCR** · v6.0-IR1.1 · 2026-11-10 · Status: ASSURANCE REPORT · Owner: Mohammed Alsaleh

Corrections C-01 to C-32 of the targeted-correction directive of 2026-11-10. Status words: VERIFIED (already satisfied; supported by inspected evidence), CORRECTED (a defect in the documents was amended and the amendment checked), PENDING_OWNER, BLOCKED, UNVERIFIED, NOT_APPLICABLE. No status describes runtime behaviour; nothing has run on the owner's Mac.

**Totals:** CORRECTED 11; UNVERIFIED 1; VERIFIED 20. Four corrected items (C-18, C-19, C-21, C-22) have a part that is PENDING_OWNER, named in their residual-risk line.

**Root-cause pattern.** 9 findings arose only because the review that produced them was given the earlier draft archive instead of the IR1 baseline. 11 were checks that the baseline already satisfied. 11 were real defects or gaps in IR1 and were corrected. One cannot be closed by the author.

**Independent reviewer conclusion, all items.** None exists. Each item was checked by its author and, where mechanical, by `tools/spec_lint.py`. That is recorded as C-32 and gate G8.

| ID | Correction | Status |
|---|---|---|
| C-01 | Identify the authoritative repository | VERIFIED |
| C-02 | Locate and reconcile the decision register | VERIFIED |
| C-03 | Establish the governing specification version | VERIFIED |
| C-04 | Preserve baseline snapshots and hashes | VERIFIED |
| C-05 | Verify cross-document version consistency | CORRECTED |
| C-06 | Inventory ADR-001 to ADR-020 | VERIFIED |
| C-07 | Recover missing ADR records | VERIFIED |
| C-08 | Resolve the 10-versus-20 discrepancy | VERIFIED |
| C-09 | Validate ADR completeness | CORRECTED |
| C-10 | Detect ADR contradictions | VERIFIED |
| C-11 | Verify no proposal was approved | VERIFIED |
| C-12 | Verify the 100-requirement inventory | VERIFIED |
| C-13 | Verify D-06 to D-19 | VERIFIED |
| C-14 | Locate GAP-033 and GAP-034 | VERIFIED |
| C-15 | Reconcile the 15 earlier specification gaps | VERIFIED |
| C-16 | Verify requirement-to-ADR-to-decision traceability | CORRECTED |
| C-17 | Reconcile audit coverage and evidence status | VERIFIED |
| C-18 | Separate skills from application authorisation | CORRECTED |
| C-19 | Resolve trusted configuration and untrusted content boundaries | CORRECTED |
| C-20 | Complete the durable approval protocol | VERIFIED |
| C-21 | Resolve network and external-tool permissions | VERIFIED |
| C-22 | Complete backup and recovery requirements | CORRECTED |
| C-23 | Resolve bounded proposal queues | CORRECTED |
| C-24 | Move restore verification before valuable data ingestion | CORRECTED |
| C-25 | Verify the Obsidian integration trust model | VERIFIED |
| C-26 | Finalise the proposed owner decision package | CORRECTED |
| C-27 | Isolate genuine owner decisions | CORRECTED |
| C-28 | Verify approval records remain unfilled | VERIFIED |
| C-29 | Prepare verification-only authorisation | VERIFIED |
| C-30 | Prepare Phase 1 authorisation | VERIFIED |
| C-31 | Verify amendment traceability | CORRECTED |
| C-32 | Complete independent readiness review | UNVERIFIED |

### C-01 Identify the authoritative repository

- **Original finding.** Identify the authoritative repository (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** This package, v6.0-IR1.1, held in the specification workspace at `/home/claude/out/ai-second-brain-6` and delivered as a ZIP. It is not a Git repository, so there is no commit; identity is by SHA-256 (SPECIFICATION-CHANGE-MANIFEST). No repository on the owner's Mac has been supplied or verified.
- **Affected documents.** README.
- **Required and actual change.** None needed.
- **Acceptance criteria.** One baseline identified with provenance.
- **Verification method and evidence.** Hash manifests; checker.
- **Dependencies.** —.
- **Residual risk.** The owner's working copy does not exist yet; its location is the owner's choice.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-02 Locate and reconcile the decision register

- **Original finding.** Locate and reconcile the decision register (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** IR1 `DECISIONS-FOR-APPROVAL.md` preserved at `docs/_baseline/v6.0-IR1-decision-register/` (SHA-256 `db578097d729e132…`); comparison with the generated sheet in DECISIONS-FOR-APPROVAL section K.
- **Affected documents.** DECISIONS-FOR-APPROVAL.
- **Required and actual change.** Comparison recorded.
- **Acceptance criteria.** File located, version stated, differences listed.
- **Verification method and evidence.** Snapshot hash; section K.
- **Dependencies.** C-01.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-03 Establish the governing specification version

- **Original finding.** Establish the governing specification version (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** Lineage: 22-file V6.0 package → 46-file expanded draft (superseded, snapshot kept) → v6.0-IR1 (2026-11-10) → v6.0-IR1.1 (this revision, authoritative).
- **Affected documents.** README; BASELINE-INVENTORY.
- **Required and actual change.** None needed.
- **Acceptance criteria.** One governing version named.
- **Verification method and evidence.** BASELINE-INVENTORY; snapshot manifests.
- **Dependencies.** C-01.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-04 Preserve baseline snapshots and hashes

- **Original finding.** Preserve baseline snapshots and hashes (directive section 3).
- **Root cause.** Already satisfied for the draft and the audit; the IR1 decision register had no snapshot before this revision.
- **Source evidence.** `docs/_baseline/SNAPSHOT-MANIFEST.md`; `docs/_baseline/v6.0-IR1-decision-register/MANIFEST.md`.
- **Affected documents.** `docs/_baseline/`.
- **Required and actual change.** IR1 decision sheet, ADR register, gap register, traceability matrix and readiness assessment snapshotted before editing; external inputs kept as received.
- **Acceptance criteria.** Every snapshot file matches its recorded hash.
- **Verification method and evidence.** Checker: snapshot hash check.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-05 Verify cross-document version consistency

- **Original finding.** Verify cross-document version consistency (directive section 3).
- **Root cause.** Defect: after the first corrections, headers mixed v6.0-IR1 and v6.0-IR1.1.
- **Source evidence.** Document headers.
- **Affected documents.** All current documents.
- **Required and actual change.** Every header set to v6.0-IR1.1.
- **Acceptance criteria.** One version label in every current document.
- **Verification method and evidence.** Checker: version check.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-06 Inventory ADR-001 to ADR-020

- **Original finding.** Inventory ADR-001 to ADR-020 (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** ADR-COMPLETENESS-REPORT §1 and §3.
- **Affected documents.** ADR-REGISTER.
- **Required and actual change.** None needed.
- **Acceptance criteria.** 20 records listed with location and hash.
- **Verification method and evidence.** Computed inventory.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-07 Recover missing ADR records

- **Original finding.** Recover missing ADR records (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** ADR-011 to ADR-020 are in the IR1 snapshot of the register; nothing was missing.
- **Affected documents.** —.
- **Required and actual change.** None needed.
- **Acceptance criteria.** Exact references and hashes given.
- **Verification method and evidence.** ADR-COMPLETENESS-REPORT §1.
- **Dependencies.** C-06.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-08 Resolve the 10-versus-20 discrepancy

- **Original finding.** Resolve the 10-versus-20 discrepancy (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** Case B: the records exist in a newer baseline. ADR-COMPLETENESS-REPORT §2.
- **Affected documents.** —.
- **Required and actual change.** Explanation recorded.
- **Acceptance criteria.** Discrepancy explained without creating records.
- **Verification method and evidence.** Draft snapshot holds 10 rows; IR1 snapshot holds 20 records.
- **Dependencies.** C-06.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-09 Validate ADR completeness

- **Original finding.** Validate ADR completeness (directive section 3).
- **Root cause.** Defect: IR1 records had no dependency or acceptance field; some lacked context, consequences or alternatives.
- **Source evidence.** ADR-COMPLETENESS-REPORT §3.
- **Affected documents.** ADR-REGISTER.
- **Required and actual change.** Missing fields added to all 20 records; no decision changed.
- **Acceptance criteria.** Eight fields present in every record.
- **Verification method and evidence.** Checker: ADR field check.
- **Dependencies.** —.
- **Residual risk.** Acceptance criteria are untested.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-10 Detect ADR contradictions

- **Original finding.** Detect ADR contradictions (directive section 3).
- **Root cause.** Review task.
- **Source evidence.** ADR-COMPLETENESS-REPORT §4 and §5.
- **Affected documents.** —.
- **Required and actual change.** Dependency cycles in the first draft of the new dependency lines were removed.
- **Acceptance criteria.** No contradiction; no dependency cycle; tensions listed.
- **Verification method and evidence.** Computed cycle check; author reading.
- **Dependencies.** C-09.
- **Residual risk.** A contradiction a second reader would see and the author did not.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-11 Verify no proposal was approved

- **Original finding.** Verify no proposal was approved (directive section 3).
- **Root cause.** Review task.
- **Source evidence.** ADR-REGISTER header; DECISIONS-FOR-APPROVAL section G.
- **Affected documents.** —.
- **Required and actual change.** None needed.
- **Acceptance criteria.** Every ADR and decision PROPOSED; approval record empty.
- **Verification method and evidence.** Checker: approval checks.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-12 Verify the 100-requirement inventory

- **Original finding.** Verify the 100-requirement inventory (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** 78 functional + 22 non-functional in SRS.md and `requirements.json`.
- **Affected documents.** —.
- **Required and actual change.** None needed.
- **Acceptance criteria.** Count and IDs stated.
- **Verification method and evidence.** REQUIREMENTS-TRACEABILITY-REPORT §1.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-13 Verify D-06 to D-19

- **Original finding.** Verify D-06 to D-19 (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** All 14 present in IR1; D-20 added in IR1.1.
- **Affected documents.** DECISIONS-FOR-APPROVAL.
- **Required and actual change.** None needed beyond C-26.
- **Acceptance criteria.** Each decision has a summary row, a detail block and an approval row.
- **Verification method and evidence.** Checker: decision coverage check.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-14 Locate GAP-033 and GAP-034

- **Original finding.** Locate GAP-033 and GAP-034 (directive section 3).
- **Root cause.** Evidence limitation, not a defect: the review worked from the earlier draft archive.
- **Source evidence.** Both are rows of GAP-REGISTER §2 in the IR1 snapshot and in the current register.
- **Affected documents.** —.
- **Required and actual change.** None needed.
- **Acceptance criteria.** Source references given.
- **Verification method and evidence.** Snapshot file.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-15 Reconcile the 15 earlier specification gaps

- **Original finding.** Reconcile the 15 earlier specification gaps (directive section 3).
- **Root cause.** Review task.
- **Source evidence.** GAP-REGISTER §3: ASB6-ISSUE-0001 to 0015, each with requirement, evidence, correction, acceptance and whether it blocks approval.
- **Affected documents.** GAP-REGISTER.
- **Required and actual change.** Counts updated after GAP-033 and GAP-034.
- **Acceptance criteria.** Individual dispositions; closure only where specification-level criteria are met.
- **Verification method and evidence.** Author reading of §3 against the audit snapshot.
- **Dependencies.** —.
- **Residual risk.** ASB6-ISSUE-0009 (owner approvals) and 0001 (no implementation supplied) cannot be closed by documents.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-16 Verify requirement-to-ADR-to-decision traceability

- **Original finding.** Verify requirement-to-ADR-to-decision traceability (directive section 3).
- **Root cause.** Defect: the IR1 matrix traced to objectives, features, components, tasks and tests, not to ADRs or decisions.
- **Source evidence.** REQUIREMENTS-TRACEABILITY-REPORT §2 to §4.
- **Affected documents.** New data file `requirement-decisions.json`; the report.
- **Required and actual change.** Mapping added for all 100 requirements.
- **Acceptance criteria.** Every requirement maps to at least one ADR; every ADR and decision ID resolves.
- **Verification method and evidence.** Checker: mapping check.
- **Dependencies.** —.
- **Residual risk.** The mapping is the author's judgment of which ADR governs each requirement.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-17 Reconcile audit coverage and evidence status

- **Original finding.** Reconcile audit coverage and evidence status (directive section 3).
- **Root cause.** Review task.
- **Source evidence.** 500-SLOT-COVERAGE: specification status NOT APPLICABLE IN V1 22, OPEN SPECIFICATION FINDING 4, OWNER DECISION PENDING 10, PARTLY SPECIFIED 98, SPECIFIED 366; implementation status PENDING 500.
- **Affected documents.** —.
- **Required and actual change.** None needed.
- **Acceptance criteria.** No slot presented as a confirmed implementation defect.
- **Verification method and evidence.** Computed from `slot-coverage.json`.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-18 Separate skills from application authorisation

- **Original finding.** Separate skills from application authorisation (directive section 3).
- **Root cause.** Defect: IR1 did not consider skills from outside the project and gave its own skills tool grants.
- **Source evidence.** SECURITY-ARCHITECTURE §5 invariant, threat S20, V-15; CLAUDE-CODE-CONTRACTS §4.1; SECURITY-ASSURANCE-REPORT §1 and §4.
- **Affected documents.** SECURITY-ARCHITECTURE; CLAUDE-CODE-CONTRACTS; GAP-REGISTER.
- **Required and actual change.** Invariant stated; threat and verification item added; skill rules proposed as D-20.
- **Acceptance criteria.** No skill is the sole control for a consequential write.
- **Verification method and evidence.** Author reading; checker for references.
- **Dependencies.** D-20.
- **Residual risk.** Skill rules (AM-05) are PENDING_OWNER; behaviour unverified on the Mac.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-19 Resolve trusted configuration and untrusted content boundaries

- **Original finding.** Resolve trusted configuration and untrusted content boundaries (directive section 3).
- **Root cause.** Gap: no single matrix; IR1 kept the vault inside the session folder.
- **Source evidence.** SECURITY-ASSURANCE-REPORT §2.
- **Affected documents.** The report.
- **Required and actual change.** Trust-boundary matrix written; layout change proposed as D-07.
- **Acceptance criteria.** Every location classified with its control.
- **Verification method and evidence.** Author reading.
- **Dependencies.** D-07.
- **Residual risk.** Layout (AM-04) is PENDING_OWNER; V-07 unverified.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-20 Complete the durable approval protocol

- **Original finding.** Complete the durable approval protocol (directive section 3).
- **Root cause.** Already satisfied in IR1.
- **Source evidence.** AGENTIC-ARCHITECTURE §5; SECURITY-ARCHITECTURE §5; schema triggers T8 to T10; FR-AGT-001, FR-AGT-003, FR-AGT-004.
- **Affected documents.** —.
- **Required and actual change.** None needed.
- **Acceptance criteria.** Durable record, expiry, replay prevention, hash binding, acceptance tests named.
- **Verification method and evidence.** Schema probes executed; tests designed.
- **Dependencies.** D-08.
- **Residual risk.** Prompt behaviour unverified (V-06).
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-21 Resolve network and external-tool permissions

- **Original finding.** Resolve network and external-tool permissions (directive section 3).
- **Root cause.** Already satisfied in IR1; user-level servers and hooks added to the inventory.
- **Source evidence.** ADR-018; FR-SEC-006, FR-SEC-007; NFR-009; SECURITY-ASSURANCE-REPORT §1.
- **Affected documents.** —.
- **Required and actual change.** None needed beyond V-15.
- **Acceptance criteria.** Permission and egress policy stated per capability.
- **Verification method and evidence.** Author reading.
- **Dependencies.** D-11.
- **Residual risk.** Research folder is PENDING_OWNER.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-22 Complete backup and recovery requirements

- **Original finding.** Complete backup and recovery requirements (directive section 3).
- **Root cause.** Defect: IR1 accepted a second volume on the same disk and reasoned that public sources made encryption unnecessary.
- **Source evidence.** DEPLOYMENT-SPECIFICATION §6; FR-OPS-002, FR-OPS-003, FR-OPS-010; NFR-006.
- **Affected documents.** DEPLOYMENT-SPECIFICATION; SRS; DECISIONS-FOR-APPROVAL.
- **Required and actual change.** Separate physical device required and checked; restore-test criteria stated; encryption, retention and objectives set out for the owner.
- **Acceptance criteria.** Independence and restore verification specified.
- **Verification method and evidence.** Checker; author reading.
- **Dependencies.** D-06.
- **Residual risk.** Encryption, retention and objectives are PENDING_OWNER.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-23 Resolve bounded proposal queues

- **Original finding.** Resolve bounded proposal queues (directive section 3).
- **Root cause.** Defect: no limit in IR1 (GAP-033).
- **Source evidence.** FR-AGT-003; TEST-AGT-013; configuration keys; doctor check.
- **Affected documents.** SRS; TEST-CASES; backlog; DEPLOYMENT-SPECIFICATION; GAP-REGISTER.
- **Required and actual change.** Limits, duplicate rule, failure behaviour and monitoring threshold specified.
- **Acceptance criteria.** Limits enforceable and testable; nothing discarded silently.
- **Verification method and evidence.** Checker: requirement has test and task.
- **Dependencies.** —.
- **Residual risk.** Default values are untried.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-24 Move restore verification before valuable data ingestion

- **Original finding.** Move restore verification before valuable data ingestion (directive section 3).
- **Root cause.** Defect: backup first appeared in Phase 9 (GAP-034).
- **Source evidence.** TASK-0212; Phase 2 gate; DOC-BKP-04.
- **Affected documents.** Backlog; roadmap; SRS; TEST-CASES; CLI-SPECIFICATION; DEPLOYMENT-SPECIFICATION; GAP-REGISTER.
- **Required and actual change.** Backup create, verify and restore-test moved to Phase 2 and into its gate; full restore stays in Phase 9.
- **Acceptance criteria.** A restore-tested backup precedes any owner document.
- **Verification method and evidence.** Checker: no task depends on a later phase; tests scheduled.
- **Dependencies.** —.
- **Residual risk.** Manual recovery procedure until Phase 9.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-25 Verify the Obsidian integration trust model

- **Original finding.** Verify the Obsidian integration trust model (directive section 3).
- **Root cause.** Already satisfied in IR1.
- **Source evidence.** ADR-003; OBSIDIAN-SCHEMAS; SECURITY-ASSURANCE-REPORT §5.
- **Affected documents.** —.
- **Required and actual change.** Six distinctions written out.
- **Acceptance criteria.** Obsidian is an interface, not an authority.
- **Verification method and evidence.** Author reading.
- **Dependencies.** —.
- **Residual risk.** Display unverified (V-11).
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-26 Finalise the proposed owner decision package

- **Original finding.** Finalise the proposed owner decision package (directive section 3).
- **Root cause.** The IR1 sheet was a one-page table without alternatives analysis or ADR matrix.
- **Source evidence.** DECISIONS-FOR-APPROVAL (package version 2.0).
- **Affected documents.** DECISIONS-FOR-APPROVAL.
- **Required and actual change.** Rebuilt with sections A to H and J to L.
- **Acceptance criteria.** 15 decisions with twelve fields each; 20 ADR rows; findings; approval record.
- **Verification method and evidence.** Checker: decision and ADR coverage checks.
- **Dependencies.** C-02.
- **Residual risk.** None.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-27 Isolate genuine owner decisions

- **Original finding.** Isolate genuine owner decisions (directive section 3).
- **Root cause.** Same.
- **Source evidence.** DECISIONS-FOR-APPROVAL sections A and B.1.
- **Affected documents.** DECISIONS-FOR-APPROVAL.
- **Required and actual change.** Each decision classed OWNER, ENG, COND or DEF.
- **Acceptance criteria.** Owner choices listed separately from engineering matters.
- **Verification method and evidence.** Author reading.
- **Dependencies.** C-26.
- **Residual risk.** The classification is a recommendation.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-28 Verify approval records remain unfilled

- **Original finding.** Verify approval records remain unfilled (directive section 3).
- **Root cause.** Review task.
- **Source evidence.** DECISIONS-FOR-APPROVAL section G.
- **Affected documents.** —.
- **Required and actual change.** None needed.
- **Acceptance criteria.** Every answer cell empty.
- **Verification method and evidence.** Checker: empty approval record.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-29 Prepare verification-only authorisation

- **Original finding.** Prepare verification-only authorisation (directive section 3).
- **Root cause.** Already present in IR1; inventory step added.
- **Source evidence.** PHASE-1-AUTHORIZATION-PROMPT prompt A; DECISIONS-FOR-APPROVAL section H.
- **Affected documents.** PHASE-1-AUTHORIZATION-PROMPT.
- **Required and actual change.** Step listing skills, plugins, hooks and MCP servers added.
- **Acceptance criteria.** Instrument A exists and is marked not authorised.
- **Verification method and evidence.** Author reading.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-30 Prepare Phase 1 authorisation

- **Original finding.** Prepare Phase 1 authorisation (directive section 3).
- **Root cause.** Already present in IR1.
- **Source evidence.** PHASE-1-AUTHORIZATION-PROMPT prompt B.
- **Affected documents.** —.
- **Required and actual change.** None needed.
- **Acceptance criteria.** Instrument B exists and is marked not authorised.
- **Verification method and evidence.** Author reading.
- **Dependencies.** D-18.
- **Residual risk.** None.
- **Final status.** VERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-31 Verify amendment traceability

- **Original finding.** Verify amendment traceability (directive section 3).
- **Root cause.** Gap: the change register had reasons but no file hashes.
- **Source evidence.** CHANGE-REGISTER (CHG-026 onward); SPECIFICATION-CHANGE-MANIFEST.
- **Affected documents.** Both.
- **Required and actual change.** Manifest of every changed file with hashes and change IDs.
- **Acceptance criteria.** Every changed file listed with reason and hash.
- **Verification method and evidence.** Computed against the IR1 archive.
- **Dependencies.** —.
- **Residual risk.** None.
- **Final status.** CORRECTED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.

### C-32 Complete independent readiness review

- **Original finding.** Complete independent readiness review (directive section 3).
- **Root cause.** The specification, its corrections and this register have one author.
- **Source evidence.** PRE-IMPLEMENTATION-READINESS-CERTIFICATE gate G8.
- **Affected documents.** —.
- **Required and actual change.** An author's falsification pass and the automated checker were run. No independent party has reviewed IR1.1.
- **Acceptance criteria.** Evidence-based independent verification.
- **Verification method and evidence.** Not performed.
- **Dependencies.** —.
- **Residual risk.** Errors the author cannot see in his own work; three were found by external review of IR1.
- **Final status.** UNVERIFIED.
- **Independent reviewer conclusion.** Author check and checker only; no independent review.
