# Decisions for Owner Approval

**DOC-DEC** · v6.0-IR1.1 · 2026-11-10 · Status: AWAITING OWNER · Owner: Mohammed Alsaleh

Decision package version 2.0. This is the one place where the owner answers. It was rebuilt on 2026-11-10 to the structure of the decision-engineering directive (sections A to H), from the records of this baseline. The IR1 version of this page is preserved unchanged in `docs/_baseline/v6.0-IR1-decision-register/`.

> **Nothing on this page is approved.** Every recommendation is PROPOSED. Reviewer dispositions are recommendations. A blank field in section G means "not decided".
>
> **IMPLEMENTATION NOT AUTHORIZED.**

Status words used here: **VERIFIED** (supported by evidence inspected or executed in the specification sandbox), **PROPOSED**, **APPROVED** (only by the owner, in section G), **CONDITIONAL** (depends on a named prerequisite), **UNVERIFIED**, **REJECTED**. Nothing about the owner's Mac is VERIFIED: it has not been inspected.

## Decided earlier (recorded from the owner on 2026-11-10)

| ID | Decision | Value |
|---|---|---|
| D-01 | Operating system | macOS |
| D-02 | Content languages | Arabic first, bilingual with English; right-to-left for Arabic, left-to-right for English |
| D-03 | Data classification of sources | Public information only; no secrecy classification |
| D-04 | Vault | New, dedicated vault; no existing vault. Legacy import later, as a capability |
| D-05 | V5.0 adversarial review | Mandatory cross-validation reference |

Also recorded as authoritative: no implementation repository has been supplied or verified; the project is in specification-only mode.

## A. Executive decision summary

**Readiness.** The specification is complete enough to decide on. It is not ready for implementation, because nothing is approved and the Mac is unverified. The gate results are in PRE-IMPLEMENTATION-READINESS-CERTIFICATE.md.

**What the evidence base is.** Every record this page refers to exists in this package: 100 requirements (78 functional, 22 non-functional) in SRS.md; ADR-001 to ADR-020 as sections of `docs/decisions/ADR-REGISTER.md`; GAP-001 to GAP-038 in GAP-REGISTER.md; the V5.0 findings in V5-COMPLIANCE-MATRIX.md; the baseline snapshots and hash manifests under `docs/_baseline/`. One external review reported ADR-011 to ADR-020, GAP-033 and GAP-034 as missing. It had been given the earlier V6.0 draft archive (10 ADRs, no decision sheet). The reconciliation is in section K.

**What needs your judgment (ten items).** D-06 backups, D-07 folder layout, D-08 where you approve, D-09 formats, D-10 pilot corpus and benchmark, D-11 web research, D-16 note history, D-18 the baseline itself, D-19 authorisations, D-20 commands and synced skills.

**What engineering has settled and asks you only to confirm (four items).** D-13 context budget, D-14 note naming, D-15 toolchain (conditional on the Mac check), D-17 dates.

**What is deferred (one item).** D-12 mobile and second device.

**Corrected in this revision without waiting, because they change no policy of yours.** Backups on a separate physical device (GAP-037); backup and restore-test moved before any real document is ingested (GAP-034); limits on the proposal queue (GAP-033); every ADR completed with dependencies and acceptance criteria; status wording.

**Recommended for amendment after your answer.** D-06 (encrypted backup volume), D-07 (session folder outside the vault), D-09 (formats enabled in stages), D-11 (optional research workspace), D-20 (skill rules). The amendments are listed in section I and are not applied.

**Remaining evidence gaps.** Nothing has been run on the Mac (V-01 to V-15). No retrieval quality has been measured. No extraction library has been tried. No part of this revision has been reviewed by anyone other than its author.

**Can Phase 1 be authorised?** Not yet. The first thing that can be authorised is the verification-only inspection (Instrument A, section H).

## B. Decisions D-06 to D-20

### B.1 Summary

Class: **OWNER** = OWNER_DECISION_REQUIRED · **ENG** = ENGINEERING_RESOLVED, confirmation asked · **COND** = CONDITIONAL · **DEF** = DEFERRED. All statuses are PROPOSED.

| ID | Question | Recommendation | Class |
|---|---|---|---|
| D-06 | Where do backups go, and are they encrypted? | Dedicated external disk, encrypted volume, daily, 14 daily + 8 weekly | OWNER |
| D-07 | Where do code, the session folder, the vault and data live? | Session folder `~/SecondBrain/workspace`; vault and data beside it, outside the session | OWNER |
| D-08 | Where do you give everyday approvals? | In the Claude Code conversation once V-06 passes on your Mac; terminal-only until then | OWNER, COND |
| D-09 | Which formats must work first? | All five, enabled in stages as each passes its extraction tests; OCR deferred | OWNER |
| D-10 | Will you supply a pilot corpus and validate a benchmark? | 100–200 documents, at least 100 questions, thresholds provisional | OWNER |
| D-11 | Web research? | None in the Second Brain workspace; optional separate research folder | OWNER |
| D-12 | Phone or second computer? | Not in version 1 | DEF |
| D-13 | How much retrieved text per search? | About 6,000 tokens, configurable, measured at the Phase 4 gate | ENG |
| D-14 | How are notes named; how does memory appear? | Title for your notes, ID for managed notes, memory as digests | ENG |
| D-15 | Python toolchain | Python 3.12 or newer, `uv`, hash-locked; three runtime libraries | ENG, COND |
| D-16 | Line-by-line history of your notes? | Local Git for your notes only, no remote; never called a backup | OWNER |
| D-17 | How are dates stored? | Gregorian ISO when reliably known, original text and precision always kept | ENG |
| D-18 | Do you approve the requirements and ADR baseline? | ADR by ADR, using section C | OWNER |
| D-19 | Authorisations | Instrument A first; Instrument B later and separately | OWNER |
| D-20 | Which commands, and may synced skills be off here? | Six `brain-*` skills that grant nothing; synced skills off in this workspace | OWNER |

### B.2 Detail

Acceptance criteria are tagged **[spec]** documents consistent, **[env]** check on the Mac, **[impl]** test after implementation, **[run]** measured in use. Only [spec] can be met before implementation.

#### D-06 Backup and disaster recovery

- **Question.** Where do backups go, are they encrypted, how often, how long are they kept, how quickly must you be able to recover?
- **Recommendation (option A).** An external disk used only for backups, encrypted at the volume level (APFS encrypted volume or encrypted disk image). Daily backup. Keep 14 daily and 8 weekly. Recovery point 24 hours. Recovery time "the same day", replaced by the measured figure after the first drill. Passphrase in the Keychain plus one recovery copy kept offline. Every restore drill starts with unlocking.
- **Alternatives.** B: option A plus an encrypted off-site copy. C: cloud backup only; no provider is approved and it is not recommended as the only copy. Simplest: an unencrypted external disk, as IR1 proposed.
- **Evidence.** V5.0 finding 9; corrections CHG-027 and CHG-028. Nothing has been measured.
- **Rationale.** Sources can be collected again. Your notes, decisions, approvals and benchmark labels cannot. A day's loss is the worst case of a daily backup for a system used in sessions. IR1's four-hour recovery time was carried over from V5.0's illustrative figures; one user has no service obligation, so it is a target to measure, not a commitment. Fourteen daily and eight weekly copies give about two months to notice a mistake.
- **Security.** A disk that stays attached shares the Mac's exposure to theft and to malware; option B answers that. A lost passphrase means lost backups.
- **Data.** Backups hold everything, including your own queries and preferences, which are not public documents.
- **Complexity.** One device and one passphrase procedure. B adds a second procedure.
- **Dependencies.** ADR-010; FR-OPS-002, FR-OPS-003, FR-OPS-010; NFR-006; GAP-034, GAP-037, GAP-038; amendment AM-01.
- **Acceptance.** [spec] AM-01 applied, checker passes. [env] V-13. [impl] TEST-OPS-003 to TEST-OPS-006, TEST-OPS-015. [run] timed restore drill including unlock (TEST-NFR-006).
- **Owner action.** Choose A, B or unencrypted. Confirm or change retention and objectives.
- **Status.** PROPOSED.

#### D-07 Workspace layout

- **Question.** Where do the code, the folder Claude Code runs in, the vault and the data live?
- **Recommendation.** Code in `~/Developer/ai-second-brain` (Git). Claude Code runs in `~/SecondBrain/workspace`, which holds instructions, settings and skills and nothing else. `~/SecondBrain/vault` and `~/SecondBrain/data` (inbox, originals, database, staging, quarantine, logs) sit beside it. Backups on the separate device. The tool is installed outside all of these. The vault is never added to a session as an extra directory.
- **Alternatives.** IR1 layout: the session folder contains the vault and data and relies on deny rules. Reviewer's layout: run Claude Code from the development repository. Higher assurance: a separate macOS account for the data, rejected as disproportionate for a single-user system.
- **Evidence.** Claude Code documentation read on 2026-11-10: instruction files and skill folders in subdirectories below the starting directory load on demand; the sandbox makes the working directory writable by default; added directories contribute skills. UNVERIFIED on the Mac.
- **Rationale.** With the vault outside the session folder, instruction and skill discovery never reach knowledge content by construction, and exclusion rules become the second line. A session that reads knowledge cannot edit the code that guards it.
- **Security.** Separates trusted code, Claude Code configuration, untrusted content, canonical data, temporary processing and backups. No credentials are stored anywhere in the home (FR-SEC-002).
- **Data.** No change of authority. Knowledge never enters the code repository's history.
- **Complexity.** One more folder level. Claude reads note text through the tool, not by opening files.
- **Dependencies.** ADR-014, ADR-015; FR-SEC-001, FR-SEC-004, FR-AGT-007, FR-OPS-009; amendment AM-04.
- **Acceptance.** [spec] AM-04 applied. [env] V-03, V-04, V-07.
- **Owner action.** Choose the layout and confirm the folder names.
- **Status.** PROPOSED.

#### D-08 Approval tiers

- **Question.** For everyday approvals (verify a memory, accept a decision), do you approve in the Claude Code conversation or only in a terminal?
- **Recommendation.** Three tiers as in AGENTIC-ARCHITECTURE §5. Tier 1 in the conversation, CONDITIONAL on V-06 passing on your Mac; terminal-only until then. Tier 2 (purge, restore, configuration, integrations) always in a terminal with typed confirmation.
- **Alternatives.** Terminal-only for everything: simplest and strongest, more friction (simplification S-03). No approval below deletion: rejected.
- **Evidence.** Documentation: an `ask` rule prompts regardless of allow rules, and bypass and auto modes can be disabled by setting. Executed: database triggers T8 to T10 in the schema probes. UNVERIFIED on the installed version.
- **Rationale.** The permission prompt is only the channel. The approval itself is a database row written by the tool: bound to the proposal's payload hash, single-use, expiring (30 minutes by default), and enforced by triggers. There is one operating-system account, so the tool cannot tell you from the agent; the assurance is that the approving command cannot run without the prompt or a terminal.
- **Security.** Residual risks: approving without reading (RT-A02); prompt behaviour depends on the Claude Code version (RT-A01).
- **Data.** Approvals, denials and expiries are audit events. A denial leaves canonical data unchanged. An interrupted apply is resolved by startup recovery before any further write (FR-OPS-005).
- **Complexity.** The in-conversation channel adds dependence on V-05 and V-06.
- **Dependencies.** ADR-009, ADR-015; FR-AGT-001, FR-AGT-003, FR-AGT-004; NFR-019.
- **Acceptance.** [env] V-06. [impl] TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-AGT-007, TEST-AGT-008, TEST-AGT-013.
- **Owner action.** Choose conditional in-conversation approval or terminal-only.
- **Status.** PROPOSED; in-conversation channel CONDITIONAL.

#### D-09 Document formats

- **Question.** Which formats must work in the first usable version?
- **Recommendation (amended after review).** Markdown, text, HTML, DOCX and text-layer PDF all stay in scope and are enabled in stages: Markdown and text first, then HTML, DOCX and PDF, each switched on only when its extraction tests pass on Arabic and English fixtures. The PDF library is chosen by a measured spike (V-12): character error rate and reading order on Arabic fixtures. OCR stays deferred; a scanned file is stored and flagged, not searchable.
- **Alternatives.** All five at once (IR1). Markdown and text only until later (simplification S-06).
- **Evidence.** None measured. No extraction library has been tried.
- **Rationale.** The pipeline is proven first on formats that need no third-party parser. Each parser is a dependency and an attack surface, admitted on evidence.
- **Security.** Parsers handle untrusted files inside the intake limits (FR-SEC-008).
- **Data.** The original is kept byte-for-byte whatever the format; every extraction carries its extractor and version.
- **Complexity.** The same work in a safer order.
- **Dependencies.** ADR-017; FR-ING-003, FR-ING-005, FR-ING-007, FR-ING-009; D-15.
- **Acceptance.** [env] V-12 record. [impl] TEST-ING-009, TEST-ING-010, TEST-ING-011, TEST-ING-013.
- **Owner action.** Say what formats your pilot documents are in. If many are scans, OCR becomes a version 1 need and this decision reopens.
- **Status.** PROPOSED.

#### D-10 Pilot corpus and retrieval benchmark

- **Question.** Will you supply a pilot corpus, validate a benchmark, and confirm you may use the material?
- **Recommendation.** 100 to 200 of your public documents. At least 100 questions drafted by Claude and validated by you, split into development and holdout before any tuning. You attest, by ingesting a document, that you may use it. Provisional thresholds from V5.0 (NFR-007): Recall@10 of at least 0.90 overall and 0.85 for each language, on holdout.
- **Benchmark content.** Arabic, English and mixed-language questions; names and entities; acronyms; spelling variants; diacritics; stemming; broken plurals, reported separately as a tracked risk; temporal questions; contradictory sources; questions with no answer in the corpus, where the right outcome is "not found"; citation validity; withdrawn or superseded sources not returned. RETRIEVAL-ARCHITECTURE §9 defines nine strata and the metrics; amendment AM-08 adds the items it lacks.
- **Alternatives.** Fifty questions with wider uncertainty. A smoke test only, which is no gate.
- **Evidence.** The tokenizer probe shows indexing behaviour, not quality. No retrieval quality has been measured, and no question exists yet.
- **Rationale.** This is how "Arabic first" becomes a number. The light stemmer misses broken plurals; that is measured and reported, and is not a reason to add vector search (ADR-006).
- **Security.** None beyond rights: the attestation is yours.
- **Data.** Benchmark labels are your work and are backed up.
- **Complexity.** Several hours of your time before the Phase 4 gate.
- **Dependencies.** ADR-005, ADR-006; FR-RET-003, FR-RET-005, FR-RET-008; NFR-007.
- **Acceptance.** [spec] AM-08 applied. [run] Phase 4 gate record with results per stratum and language.
- **Owner action.** Commit to the corpus and the validation time. Approve or change the thresholds.
- **Status.** PROPOSED; thresholds provisional.

#### D-11 Network access

- **Question.** Do you want web research, and where?
- **Recommendation.** None in the Second Brain workspace. If you want it: a separate research folder with web tools, whose settings deny the Second Brain tool and keep the sandbox on. Results reach the Second Brain only as files you place in the inbox, then through normal intake as untrusted sources.
- **Alternatives.** Web tools inside the workspace: rejected, because fetched text and proposal writing would share a session. No research folder: simplest.
- **Evidence.** Documentation: deny rules for the web tools; the sandbox's network allowlist covers Bash and its children; MCP servers and hooks run outside the sandbox; user-level servers, hooks and plugins load in every project. UNVERIFIED on the Mac.
- **Rationale.** An injection needs hostile text and a write path in the same session. The separation removes the combination.
- **Security.** Enforced by configuration, not by instruction. Whether it holds on your installed version is an environment check. User-level MCP servers would cross the boundary, which is why V-15 inventories them.
- **Data.** Anything fetched enters with a recorded origin and is treated as data (FR-SEC-003).
- **Complexity.** None unless you want the research folder (amendment AM-06).
- **Dependencies.** ADR-018; FR-SEC-003, FR-SEC-006, FR-SEC-007; NFR-009.
- **Acceptance.** [env] V-02, V-04, V-15. [impl] TEST-SEC-014.
- **Owner action.** Say whether you want a research folder.
- **Status.** PROPOSED.

#### D-12 Mobile and multi-device

- **Question.** Do you need a phone or a second computer in version 1?
- **Recommendation.** No. Portability is kept: a Markdown vault and a documented export (NFR-003). A read-only copy can be added later without changing who owns the data. Two devices writing would mean changing ADR-004 and ADR-016. No cloud synchronisation for convenience.
- **Alternatives.** Read-only copy now; synchronisation now.
- **Evidence.** Design reasoning; single-writer design verified only as schema constraints.
- **Rationale, security, data, complexity.** Every synchronisation path is a second writer or a second copy to protect.
- **Dependencies.** ADR-004, ADR-016; NFR-003, NFR-017.
- **Acceptance.** [spec] no requirement assumes a second writer.
- **Owner action.** Confirm the deferral.
- **Status.** PROPOSED; DEFERRED.

#### D-13 Cost and context budget

- **Question.** How much retrieved text does a search hand to Claude?
- **Recommendation.** About 6,000 tokens of evidence per search as a configurable starting value. No model calls from Python. At the Phase 4 gate the benchmark is run at three budget settings and recall, citation validity and tokens per question are recorded; the smallest budget within two points of the best recall is kept (provisional rule). Skill descriptions stay to one line each.
- **Alternatives.** A fixed 6,000; a larger budget; a second model provider, rejected under ADR-001.
- **Evidence.** None. 6,000 is a hypothesis.
- **Rationale, security, data, complexity.** A budget is a tuning value, not a policy. No external transmission is added.
- **Dependencies.** ADR-001, ADR-005; NFR-015; amendment AM-09.
- **Acceptance.** [run] gate record with quality per budget.
- **Owner action.** Confirm. Add a cost ceiling only if you want one.
- **Status.** PROPOSED; engineering-resolved.

#### D-14 Note naming and memory display

- **Question.** How are notes named, and how does memory appear in Obsidian?
- **Recommendation.** Your notes are named by their title, Arabic or English. Managed notes are named by ID. A filename is never an identifier: the `id` property is, so renaming is safe. Memory appears as digest notes per subject, project or month, with an anchor per record. Originals are never touched. Supersession and history live in the database and show in the digests.
- **Alternatives.** One note per memory record; filenames as identifiers.
- **Evidence.** Obsidian documentation (flat properties, block anchors). Display UNVERIFIED on the Mac.
- **Rationale.** Readable for you, stable for the system.
- **Security.** None.
- **Data.** Editing a managed status line by hand has no effect and is reported (rule OBS-D01).
- **Complexity.** Fewer generated files than one note per record.
- **Dependencies.** ADR-002, ADR-012, ADR-016; FR-OBS-001, FR-OBS-003; NFR-022.
- **Acceptance.** [env] V-11. [impl] rename, collision and drift rules of OBSIDIAN-SCHEMAS.
- **Owner action.** Confirm.
- **Status.** PROPOSED; engineering-resolved.

#### D-15 Python toolchain

- **Question.** Which Python and which libraries?
- **Recommendation.** Runtime: Python 3.12 or newer with its standard `sqlite3` (FTS5 and STRICT tables required), PyYAML, python-docx, one PDF library chosen by V-12. Development only: `uv` with a hash-locked lockfile, pytest, coverage, mypy, ruff. Optional: none. Deferred: OCR, embeddings, an ICU tokenizer.
- **Alternatives.** pip-tools with venv; unpinned dependencies, rejected.
- **Evidence.** Executed in the specification sandbox only (Python 3.13.18, SQLite 3.53.1). Nothing is verified on your Mac. Which SQLite a Python build links differs between builds, so version and FTS5 must be probed there.
- **Rationale.** Few dependencies, each pinned by hash.
- **Security.** Hash-locked installs; no dependency monitoring service (accepted risk).
- **Data.** None.
- **Complexity.** Low.
- **Dependencies.** ADR-004, ADR-017; NFR-010, NFR-011, NFR-020.
- **Acceptance.** [env] V-01 and V-09 recorded by Instrument A. [impl] lockfile with hashes.
- **Owner action.** Confirm. The PDF library is an engineering choice after the spike.
- **Status.** PROPOSED; CONDITIONAL on V-01.

#### D-16 Git in the vault

- **Question.** Do you want line-by-line history of your own notes?
- **Recommendation.** Yes, in reduced scope: a local Git repository in the vault with no remote, covering your notes only. Managed folders, generated dashboards, digests and Obsidian's workspace state are ignored. The tool commits at the end of a run and in the daily job. It is history. It is not a backup and is never described as one.
- **Alternatives.** Defer it (simplification S-08, and the evidence-limited review's recommendation): you could recover yesterday's version from a backup, but not see what changed. Commit everything automatically: rejected.
- **Evidence.** Reviewers are split. Nothing measured.
- **Rationale.** Cheap and reversible both ways; only the history before the start is lost if you begin later.
- **Security.** The database, originals and anything outside your notes never enter the repository.
- **Data.** A second local copy of note text.
- **Complexity.** One more moving part; no merges, because there is one writer and no remote.
- **Dependencies.** ADR-002; amendment AM-07.
- **Acceptance.** [impl] a backup restores fully without Git; excluded paths never appear in the repository.
- **Owner action.** Choose reduced-scope Git or deferral.
- **Status.** PROPOSED.

#### D-17 Dates

- **Question.** How are dates stored?
- **Recommendation.** A Gregorian ISO date when it is reliably known. The original expression is always kept (`date_text`). Precision is recorded as day, month, year or unknown. Periods use a start and an end, either of which may be open. Timestamps are UTC. No automatic Hijri conversion: no calendar convention or validation method has been defined. A date written in Hijri stays as written; the Gregorian equivalent is supplied at proposal time and shown for your check.
- **Alternatives.** Automatic conversion, which needs a library and a convention; text-only dates, which cannot be ordered.
- **Evidence.** Schema probes (columns and checks). Design reasoning otherwise.
- **Rationale.** No invented precision, and history can still be reconstructed "as of" a date.
- **Security.** None.
- **Data.** Temporal contradictions are recorded as conflicts, not overwritten.
- **Complexity.** Low.
- **Dependencies.** ADR-020; FR-MEM-008; finding RT-D03.
- **Acceptance.** [impl] unknown, partial and Hijri-written dates stored without invented precision; as-of reconstruction tests.
- **Owner action.** Confirm.
- **Status.** PROPOSED; engineering-resolved.

#### D-18 Requirements and ADR baseline

- **Question.** Do you approve the 100 requirements and the 20 ADRs as the reference for implementation?
- **Recommendation.** Answer ADR by ADR in section G, using section C. Fifteen are RECOMMEND_APPROVAL, three of them conditional on a later measurement. Five are RECOMMEND_APPROVAL_WITH_AMENDMENT and are answered through D-06, D-07, D-09, D-11 and D-20. None is recommended for deferral or rejection.
- **Requirements.** 78 functional and 22 non-functional, 71 of them MUST, consistent by the checker. This revision amended FR-AGT-003, FR-OPS-002 and FR-OPS-003; the count is unchanged. REQUIREMENTS-TRACEABILITY-REPORT.md lists which requirements depend on which open decision.
- **Alternatives.** Approve with simplifications (section J). Approve as one bundle: not recommended.
- **Evidence.** Checker results in QUALITY-REPORT.json; ADR-COMPLETENESS-REPORT.md.
- **Rationale.** The baseline is what Phase 1 would be held to.
- **Security, data, complexity.** As per each ADR in section C.
- **Dependencies.** Everything.
- **Acceptance.** [spec] every ADR row in section G answered; ADR statuses updated; readiness re-assessed.
- **Owner action.** Answer in section G.
- **Status.** PROPOSED.

#### D-19 Authorisations

- **Question.** What do you authorise, and when?
- **Recommendation.** Instrument A (verification only) first. Instrument B (Phase 1) later, separately, and only after D-07, D-15, D-18 and the record from Instrument A. Section H describes both. Neither is authorised.
- **Alternatives.** Authorise Phase 1 now: not recommended. No verification: not recommended.
- **Evidence, rationale.** Approving the specification does not authorise implementation. Silence authorises nothing.
- **Security, data, complexity.** Instrument A changes nothing on the Mac. Instrument B is bounded by its own directories, dependency policy and stop conditions.
- **Dependencies.** PHASE-1-AUTHORIZATION-PROMPT.md.
- **Acceptance.** [spec] `CLAUDE.md` mode stays SPECIFICATION-ONLY until you issue an instrument.
- **Owner action.** Issue Instrument A, or not.
- **Status.** NOT AUTHORIZED.

#### D-20 Claude Code skills

- **Question.** Which commands do you want in Claude Code, and may skills synced from your claude.ai account be switched off in this workspace?
- **Recommendation.** Six skills: `brain-search`, `brain-ingest`, `brain-memory`, `brain-project`, `brain-review`, `brain-doctor`. Rules: the `brain-` prefix (Claude Code ships a bundled `/doctor` skill in every session); no tool grants, hooks, forked execution or load-time shell commands; `brain-ingest` and `brain-review` run only on your explicit command; `doctor` lists every skill, plugin, hook and MCP server visible to a session and fails on a name collision or an unexpected source; synced skills off in this workspace; local interactive sessions only. Skills are written in Phase 7 with the operating workspace, not in Phase 1. What is decided now is the names and the rules.
- **Compared with the reviewer's six.** The reviewer lists `brain-audit` and no project skill. Audit-chain verification is already part of `doctor`, so one read-only health skill is enough; project review is a required workflow.
- **Alternatives.** IR1's five skills with tool grants. No skills, the tool only: simplest.
- **Evidence.** Skills documentation read on 2026-11-10: a personal skill takes precedence over a project skill of the same name; plugin skills are namespaced; nested and added-directory discovery; bundled skills. UNVERIFIED on the Mac (V-15).
- **Rationale.** A skill is a convenience. Permission comes from the settings file, the tool's policy gate and the database (SECURITY-ARCHITECTURE §5).
- **Security.** Closes finding GAP-036 once amendment AM-05 is applied and V-15 passes.
- **Data.** None.
- **Complexity.** One inventory check, one test.
- **Dependencies.** ADR-015, ADR-018; FR-AGT-007; GAP-036.
- **Acceptance.** [spec] AM-05 applied. [env] V-14, V-15. [impl] inventory and collision test.
- **Owner action.** Choose the command set; accept or refuse switching synced skills off here.
- **Status.** PROPOSED.

## C. ADR approval matrix (ADR-001 to ADR-020)

All 20 records are in `docs/decisions/ADR-REGISTER.md`, each with context, decision, alternatives, consequences, evidence, reversal, dependencies and acceptance. All are PROPOSED. Recommendation classes: **RA** = RECOMMEND_APPROVAL · **RA-C** = RECOMMEND_APPROVAL, conditional on a named measurement · **RAA** = RECOMMEND_APPROVAL_WITH_AMENDMENT. No ADR is classed RECOMMEND_DEFERRAL, RECOMMEND_REJECTION or REQUIRES_OWNER_CHOICE; where a choice is yours it is carried by the decision named in the last column of C.2.

### C.1 Decision, rationale, alternatives, recommendation

| ADR | Proposed decision | Why (business / technical) | Alternatives rejected | Rec. |
|---|---|---|---|---|
| ADR-001 | Claude Code is the only AI platform; Python calls no model | Your standing constraint / one place where model behaviour is governed | Other assistants; API calls from Python | RA |
| ADR-002 | Notes are Markdown files with YAML properties | Portable, yours without the tool / Obsidian-compatible | Notes in the database | RA |
| ADR-003 | Obsidian is optional; core features only | The system works without any one application / no plugin code to trust | Plugin dashboards; plugin approvals | RA |
| ADR-004 | SQLite is the transactional registry | One file, one machine, no service to run / constraints and triggers executed in probes | PostgreSQL; files only | RA |
| ADR-005 | FTS5 with Arabic normalisation and a stem column in the application | Arabic-first search / raw tokenizer failed every variant probe | Raw `unicode61`; trigram; ICU; external engine | RA-C (gate RET-G1) |
| ADR-006 | No vector search until gate RET-G2 | No infrastructure before a measured need / would add a second model | Qdrant; hybrid from the start | RA |
| ADR-007 | No graph database; typed relationships in SQLite | Same / no required query needs it | Neo4j; GraphRAG | RA |
| ADR-008 | One orchestrator; scheduled jobs deterministic; no unattended model runs | You are present for every judgment / reproducibility | Nine agents; scheduled model jobs | RA |
| ADR-009 | Three approval tiers; hash-bound, single-use, expiring approvals | Your approval is real and recorded / replay and substitution refused | Terminal for everything; nothing below deletion | RA-C (V-06) |
| ADR-010 | Independent backup with restore tests; encryption optional | Recovery is tested, not assumed / manifest and verification | Git only; Time Machine only | RAA (AM-01) |
| ADR-011 | Architecture "C+" among V5.0's six | Enough governance, no more / each part maps to a MUST requirement | A, B, D, E, F | RA |
| ADR-012 | Governed fields in SQLite; notes show projections; memory as digests | One authority per fact / hand edits cannot corrupt state | Markdown authoritative; one note per memory | RA |
| ADR-013 | Journal for file-plus-database commits | No half-finished changes / roll-forward recovery | Database first; originals as BLOBs | RA-C (crash suite, V-10) |
| ADR-014 | Knowledge kept apart from code | Knowledge never in code history / a reading session cannot edit its guard | One repository | RAA (AM-04) |
| ADR-015 | Five enforcement layers; no hooks | No single control to defeat / each layer covers another's gap | Prompts only; hook gatekeeper; separate OS account | RAA (AM-05) |
| ADR-016 | Readable sequential IDs; one registry of objects | Citations a person can read / real foreign keys | UUIDs | RA |
| ADR-017 | Small versioned extractors; OCR deferred | Few dependencies / every extraction reproducible | Model-based pipeline; OCR now | RAA (AM-11) |
| ADR-018 | No MCP server, plugin, web access or browser automation; auto memory off | Nothing reaches the workspace unapproved / fewer injection paths | Obsidian MCP; browser automation | RAA (AM-05, AM-06) |
| ADR-019 | Legacy import deferred; schema ready | Nothing to import today / no later redesign | Build now | RA |
| ADR-020 | One memory model: records, revisions, evidence | History is never overwritten / removes the draft's contradiction | Claims in notes; table per kind | RA |

### C.2 Implications, dependencies, reversibility, risk, owner approval

| ADR | Security and data implications | Depends on | Reversibility | Outstanding risk | Answered by |
|---|---|---|---|---|---|
| ADR-001 | No model credential in the package; no batch semantic work | — | Easy to relax, by your decision | None | Its own row |
| ADR-002 | An uncoordinated editor writes authoritative files | ADR-012 | Hard | Sync and conflict rules untested | Its own row |
| ADR-003 | No plugin code runs with your data | ADR-002 | Easy | Display on the Mac (V-11) | Its own row |
| ADR-004 | Single writer; file owner can alter anything, mitigated by ADR-015 | V-01 | Hard | SQLite build on the Mac | Its own row |
| ADR-005 | Index text differs from stored text; excerpts come from originals | D-10 | Moderate (index rebuild) | Quality unmeasured; broken plurals missed | Its own row |
| ADR-006 | No external embedding service | ADR-001, ADR-005 | Easy to add later | Cross-language recall | Its own row |
| ADR-007 | None | ADR-004 | Easy to add later | None known | Its own row |
| ADR-008 | No session without you present | ADR-001 | Moderate | Semantic backlog grows | Its own row |
| ADR-009 | Approval authority; audit evidence for every decision | ADR-015, V-06 | Moderate | Approving without reading | Its own row and D-08 |
| ADR-010 | Copies of everything on another device; encryption pending | D-06 | Easy | Text still says "encryption off" until D-06 | Its own row and D-06 |
| ADR-011 | Sum of the others | ADR-001 to ADR-010 | Hard | Size of the plan for one person | Its own row |
| ADR-012 | Hand edits to managed fields ignored and reported | ADR-002, ADR-004 | Hard | None known | Its own row and D-14 |
| ADR-013 | Integrity under interruption; read-only mode on unknown state | ADR-004 | Hard | Unproven until the crash suite runs | Its own row |
| ADR-014 | Filesystem authority; where instructions are discovered | D-07 | Moderate before data exists | V-03, V-04, V-07 | Its own row and D-07 |
| ADR-015 | Every write path; skills and hooks are not controls | D-20 | Moderate | V-03 to V-06, V-15; one OS account (RT-S01) | Its own row and D-20 |
| ADR-016 | Stable identity independent of filenames | ADR-004 | Hard | Not suitable for two writers | Its own row |
| ADR-017 | Parsers read hostile files; originals preserved | D-09, D-15 | Easy | No library tested | Its own row and D-09 |
| ADR-018 | Network, MCP, plugins, browser, auto memory | D-11, D-20 | Easy to relax, each by ADR | V-02, V-08, V-15 | Its own row and D-11 |
| ADR-019 | None until an import exists | D-04 | Easy | None | Its own row |
| ADR-020 | Provenance and supersession for every memory | ADR-004, ADR-009 | Hard | One shape must fit seven kinds | Its own row |

**Conflicts between ADRs.** None found. Three tensions and two texts awaiting amendment are recorded in ADR-COMPLETENESS-REPORT.md: ADR-001 makes any embedding model an exception needing its own approval; ADR-008 means "automation" here is assisted, not autonomous; ADR-014 and ADR-015 rest on documented Claude Code behaviour that the Mac check must confirm; ADR-010 still reads "encryption off by default" and ADR-015 still says "public content", both held until D-06 and D-20 are answered.

## D. Outstanding findings

| Finding | Where recorded | Disposition | Limits and behaviour | Acceptance | Status |
|---|---|---|---|---|---|
| GAP-033 Proposal queue unbounded | GAP-REGISTER §2; present since IR1 | **Corrected in IR1.1** (FR-AGT-003). Configurable limits: 200 open proposals, 50 per run. Duplicate detection is a hard rule: an identical open payload returns the existing proposal. Monitoring threshold: `doctor` warns at 80% | At a limit the command fails, creates nothing and reports the limit and count; the run records the refusal. Nothing is discarded. Expired proposals stay as records. Retries are idempotent (FR-AGT-002). Your review workload is bounded by the open limit | TEST-AGT-013 | RESOLVED at specification level. Defaults are yours to change |
| GAP-034 Backup late | GAP-REGISTER §2; present since IR1 | **Corrected in IR1.1.** Backup create, verify and restore-test moved to Phase 2 (TASK-0212) and into the Phase 2 gate | Minimum gate: a backup of the test home is created, verified against its manifest and restore-tested into a new directory, where database integrity, foreign keys, the audit chain, sampled originals and an index rebuild are checked. No owner document is ingested until a restore-tested backup exists at your destination (DOC-BKP-04). Full restore over the home stays in Phase 9 because it needs tier 2 approvals; until then recovery is the manual procedure of runbook RB-02 | TEST-OPS-003 to TEST-OPS-006 | RESOLVED at specification level |
| GAP-036 Skills from outside the project | GAP-REGISTER §2; new in IR1.1 | Proposed under D-20 | See D-20 | V-15; one new test on approval | PROPOSED; awaits D-20 |

## E. Security-sensitive decisions

The full analysis (threat, trust boundary, control, enforcement layer, failure behaviour, audit evidence, acceptance test, remaining uncertainty) is in SECURITY-ASSURANCE-REPORT.md. No item below relies on an instruction to Claude as its control.

| Area | Decided through | Enforced by | Evidence status |
|---|---|---|---|
| Network access | D-11, ADR-018 | Deny rules; sandbox network allowlist; package uses no network | Documented; UNVERIFIED on the Mac (V-02, V-04) |
| External services | ADR-001, ADR-018 | None exist in the design; any addition is tier 2 plus an ADR | Specified |
| Filesystem permissions | D-07, ADR-014, ADR-015 | Sandbox for Bash; deny rules for file tools; path policy in the tool | Documented; UNVERIFIED (V-03, V-04, V-05) |
| MCP servers | ADR-018 | None installed; inventory check | UNVERIFIED (V-15) |
| Skills | D-20, ADR-015 | Skills grant nothing; settings, policy gate and triggers decide | Documented; UNVERIFIED (V-14, V-15) |
| Hooks | ADR-015 | None used; inventory check for user-level hooks | UNVERIFIED (V-15) |
| Data deletion | ADR-009 (tier 2) | Terminal with typed confirmation; purge reports affected backups | Specified; tests designed |
| Backups | D-06, ADR-010 | Separate physical device; manifest; restore-test | Specified; nothing run |
| Encryption | D-06 | Volume-level encryption of the backup device, if approved | PROPOSED |
| Approval authority | D-08, ADR-009 | Approval rows bound to payload hash, single-use, expiring; triggers | Schema probes executed; prompt behaviour UNVERIFIED (V-06) |

## F. Environment verification (none performed)

| Activity | Items | Type | Needs |
|---|---|---|---|
| Record macOS, hardware, Python, SQLite, Claude Code and Obsidian versions | V-01, V-02 (version), V-11 (version) | Read-only inspection | Instrument A |
| List skills, plugins, hooks and MCP servers Claude Code loads; names of settings keys, not values | V-15 (inventory) | Read-only inspection | Instrument A |
| FTS5, STRICT tables, JSON functions; the Arabic tokenizer probe; the DDL check | V-01 (capabilities), V-09 | Executable probe, standard library, temporary directory only | Instrument A |
| Settings accepted; deny, ask and sandbox rules behave as documented; instruction file in a data folder not loaded; auto memory off; skill collision behaviour | V-02 to V-08, V-14, V-15 | Executable test in a throwaway folder with synthetic files and a stub command | A separate, scoped authorisation, or Phase 1 task TASK-0101 |
| Atomic rename and full flush on the home volume | V-10 | Executable probe on the home volume | Same |
| Generated Arabic, English and mixed notes display correctly | V-11 | Manual check in Obsidian with sample notes | Same |
| PDF libraries on Arabic fixtures | V-12 | Executable test; **installs candidate libraries** | D-15 and Instrument B |
| Scheduled job can write the backup device after sleep | V-13 | Executable test | D-06 device and Instrument B |

No test uses real documents.

## G. Owner approval record

Write one of **APPROVE**, **APPROVE_WITH_AMENDMENT**, **REJECT**, **DEFER** in the second column. Empty means not decided. To answer several rows identically you may write one dated statement naming the rows.

| Item | Answer | Amendment or note | Date |
|---|---|---|---|
| D-06 backups (A / B / unencrypted) | | | |
| D-07 workspace layout | | | |
| D-08 approval channel | | | |
| D-09 formats | | | |
| D-10 pilot corpus, benchmark, rights attestation | | | |
| D-11 web research | | | |
| D-12 mobile and multi-device (deferral) | | | |
| D-13 context budget | | | |
| D-14 note naming and memory display | | | |
| D-15 toolchain | | | |
| D-16 vault history | | | |
| D-17 dates | | | |
| D-20 skills | | | |
| ADR-001 decision | | | |
| ADR-002 decision | | | |
| ADR-003 decision | | | |
| ADR-004 decision | | | |
| ADR-005 decision | | | |
| ADR-006 decision | | | |
| ADR-007 decision | | | |
| ADR-008 decision | | | |
| ADR-009 decision | | | |
| ADR-010 decision | | | |
| ADR-011 decision | | | |
| ADR-012 decision | | | |
| ADR-013 decision | | | |
| ADR-014 decision | | | |
| ADR-015 decision | | | |
| ADR-016 decision | | | |
| ADR-017 decision | | | |
| ADR-018 decision | | | |
| ADR-019 decision | | | |
| ADR-020 decision | | | |
| D-18 requirements baseline (100 requirements) | | | |
| GAP-033 limits (defaults 200 and 50) | | | |
| GAP-034 early backup gate | | | |
| GAP-036 (through D-20) | | | |
| D-19 Instrument A: verification only | | | |
| D-19 Instrument B: Phase 1 | | | |
| Is there an existing codebase to review separately? (yes / no) | | | |

## H. Implementation authorisation

**NOT AUTHORIZED.**

**Instrument A, verification only (draft, not granted).** Text: prompt A in PHASE-1-AUTHORIZATION-PROMPT.md. Permits recording versions, listing what Claude Code loads, and running the two standard-library probes in a temporary directory. Prohibits installing anything, creating directories outside the repository, changing any setting or permission, touching a vault, and writing application code.

**Instrument B, Phase 1 (draft, not granted, not to be issued yet).** Text: prompt B in the same file. It names the approved baseline and ADRs, the permitted directories, the allowed operations, the dependency policy, the tests required, the security controls, the rollback rule and the stop conditions. Preconditions: section G answered for D-07, D-15, D-18 and the ADRs; Instrument A's record reviewed; the amendments of section I applied and checked.

Approving this page does not issue either instrument.

## I. Amendments held for your answers

Applied in one pass after section G, recorded in the change register, then checked. None is applied now.

| ID | Amendment | Waits for | Documents touched |
|---|---|---|---|
| AM-01 | Encrypted backup volume, key recovery procedure, unlock step in the restore drill; ADR-010 text | D-06 | DEPLOYMENT §5–6, ADR-010, SECURITY, FR-OPS-003 |
| AM-04 | Session folder `~/SecondBrain/workspace`; vault and data outside it | D-07 | DATA-ARCHITECTURE §3, CLAUDE-CODE-CONTRACTS §1 and §5, AGENTIC §2–3, HLD, DEPLOYMENT §3–4, ADR-014 |
| AM-05 | Six `brain-*` skills that grant nothing; inventory and collision check as a requirement, test and doctor check; ADR-015 wording | D-20 | CLAUDE-CODE-CONTRACTS §4, AGENTIC §6, SRS, TEST-CASES, SECURITY, ADR-015 |
| AM-06 | Optional research folder connected only through the inbox | D-11 | AGENTIC, SECURITY, ADR-018 |
| AM-07 | Vault Git limited to your notes | D-16 | OBSIDIAN-SCHEMAS §8 |
| AM-08 | Benchmark: acronyms, more mixed-language questions, broken plurals tagged and reported separately, withdrawn sources not returned | D-10 | RETRIEVAL-ARCHITECTURE §9 |
| AM-09 | Quality-per-budget measurement at the Phase 4 gate | D-13 | NFR-015 |
| AM-11 | Formats enabled in stages, each on passing its extraction tests | D-09 | ADR-017, roadmap, FR-ING-007 |

Already applied in IR1.1 and recorded in the change register: AM-02 (GAP-034), AM-03 (GAP-033), AM-10 (wording and backup device).

## J. Simplification challenge

The ten simplifications of ADVERSARIAL-REVIEW §5, assessed against what must not be weakened: canonical authority, stable identifiers, provenance, transactional integrity, retrieval accuracy, human approval, historical reconstruction, recovery.

| ID | Simplification | Removes | Loses | Reversible later? | Recommendation |
|---|---|---|---|---|---|
| S-01 | Defer entities and relationships | 3 tables, 2 requirements | Arabic and English names resolving to one entity | Adding later is harder than keeping | Keep. Already scheduled after memory |
| S-02 | Merge `captured` into `proposed` | One state | A holding area that does not count as a proposal | Splitting later is harder than merging | Keep |
| S-03 | Terminal-only approval at first | Dependence on V-05, V-06 | Convenience | Yes | Your choice in D-08; it is the fallback in any case |
| S-04 | Normalised column only | Stemmer, one column | The comparison gate RET-G1 needs | Yes | Keep both until RET-G1; drop the stem column if it shows no gain |
| S-05 | Defer dashboards | One requirement, one module | Visibility in Obsidian | Yes | Keep, as the last item of its phase; first to slip |
| S-06 | Fewer formats first | Two extractors at the start | Nothing permanent | Yes | Adopted in staged form (D-09) |
| S-07 | Decisions as a memory kind only | One table | Decision queries and history | Hard | Keep. Historical reconstruction depends on it |
| S-08 | No Git in the vault | D-16 | Line-level note history | Yes | Your choice in D-16 |
| S-09 | Merge phases 5 and 6; drop Phase 8 as a phase | Two gates | Smaller increments | Yes | Keep the gates |
| S-10 | Drop item types `commitment` and `question` | Two vocabulary values | Coverage of two audit questions | Yes | Keep. They cost nothing |

Net: one adopted in staged form, two left to you, seven not recommended. If you want a visibly smaller version 1, S-05 is the only one that removes work without weakening a protected property.

## K. Reconciliation with the external reviews

Five external inputs were received on 2026-11-10 and are kept as received in `docs/_baseline/external-reviews-2026-11-10/`.

| Input | Based on | Result |
|---|---|---|
| Review of the readiness assessment and decision sheet | IR1 | Accepted: backup device, encryption reasoning, status wording, ADR-by-ADR approval, verification first |
| Review of Claude Code skills | IR1 and the skills documentation | Accepted: GAP-036, V-15, D-20. Not accepted: running Claude Code from the development repository (D-07 gives the reason and a counter-proposal) |
| Decision-engineering directive, version 2.0 | — | This page follows its sections A to H |
| Evidence-limited proposed decision sheet | The earlier V6.0 draft archive (10 ADRs, no decision sheet, no GAP-033 or GAP-034) | Its 14 recommendations were compared with this page: 11 agree; D-09 (stage the formats) is adopted; D-16 (defer Git) is shown as your alternative; D-07 keeps IR1 paths, which D-07 here amends. Its ADR-001 to ADR-010 titles match this baseline. Its "not present" findings for ADR-011 to ADR-020, GAP-033 and GAP-034 are an effect of the archive it was given: the records exist in IR1 and are hashed in the snapshot manifest |
| Targeted-correction directive (C-01 to C-32, gates G0 to G8) | The evidence-limited sheet | Executed: TARGETED-CORRECTIONS-REGISTER.md and PRE-IMPLEMENTATION-READINESS-CERTIFICATE.md |

## L. Self-challenge

Answered by the author, with the checker where it can decide. This is not an independent review; see the certificate, gate G8.

| # | Question | Answer |
|---|---|---|
| 1 | Does any recommendation contradict an approved requirement? | No requirement is approved yet. None contradicts D-01 to D-05 |
| 2 | Did a proposal become an approval? | No. Section G is empty; the checker fails if an answer is filled in or an ADR is not PROPOSED |
| 3 | Unnecessary technology recommended? | None added. No vector store, graph database, MCP server, plugin or daemon |
| 4 | Security risks understated? | Two were, in IR1: same-disk backups and foreign skills. Both corrected or raised. One OS account remains an accepted limit (RT-S01) |
| 5 | Skills confused with authorisation? | No. Invariant in SECURITY-ARCHITECTURE §5 |
| 6 | Obsidian files confused with Claude Code instructions? | No. The vault is data; D-07 moves it out of the session folder |
| 7 | Local compatibility assumed? | No. Everything about the Mac is UNVERIFIED |
| 8 | Excessive complexity? | The plan is large for one person (RT-M01). Section J states what could go |
| 9 | An ADR omitted? | No. 20 rows in C.1, C.2 and G; checked |
| 10 | A decision omitted? | No. D-06 to D-20 in B.1, B.2 and G; checked |
| 11 | A dependency overlooked? | User-level MCP servers and hooks were, in IR1; V-15 now covers them |
| 12 | Benchmark results invented? | No. No retrieval result exists |
| 13 | Git treated as backup? | No. D-16 and DEPLOYMENT §6 say so |
| 14 | External data transmission approved? | No |
| 15 | Implementation authorised by accident? | No. `CLAUDE.md` mode is SPECIFICATION-ONLY; the checker fails if implementation directories exist |
| 16 | Arabic-first preserved? | Yes. ADR-005, D-10, NFR-007 per language |
| 17 | Provenance preserved? | Yes. Originals immutable; extraction versions; evidence links |
| 18 | Historical reconstruction preserved? | Yes. Immutable revisions; S-07 not recommended |
| 19 | Canonical authority preserved? | Yes. Authority map unchanged |
| 20 | Can you decide without reading the whole specification? | Sections A, B.1 and G are meant to be enough; B.2 and C when you want the reasons |
