# Independent Adversarial Specification Review

**DOC-REVIEW** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `RED-TEAM-REVIEW.md` of the V6.0 draft.

**How independent this is.** Mostly it is not. Two external reviews received after IR1 found three weaknesses the author had missed (RT-S05, RT-S06, RT-O03), which is the practical case for independent review. The review was written by the same author, in the same working session, as the specification it reviews. It was done after the documents were complete, by reading them against the engineering directive, the V5.0 findings, the audit's 25 domains and each other, and by running the consistency checker. Treat it as a structured self-critique. Independent review is still owed, and can only come from the owner, from a separate reviewer, and from executed tests (findings RT-M02).

**Counts.** The directive asked for at least 20 defects, 15 hidden assumptions, 15 integration risks, 10 simplifications and 10 missing scenarios, and also said not to manufacture findings. The numbers below are what was found: 33 defects and weaknesses (30 by the author, 3 added in IR1.1 from external review), 16 assumptions, 13 integration risks, 10 simplifications, 10 missing scenarios. Integration risks fall short of 15; no filler was added.

Severity: **Critical** blocks implementation of the affected part; **High** must be resolved or explicitly accepted before the phase that depends on it; **Medium** should be resolved during implementation; **Low** noted. Disposition: RESOLVED (changed in this baseline), VERIFY (specified; depends on a V-item or measurement), DECIDE (owner), ACCEPT (residual risk for explicit acceptance), OPEN.

## 1. Consistency checks performed

Automated (`tools/spec_lint.py`, results in `QUALITY-REPORT.json`): every requirement, test, task, component, feature, business requirement, objective, ADR, decision and gap ID referenced in any document exists; no duplicate IDs; every requirement has a test, every test a requirement, every MUST requirement a task, every component a requirement, every file a task; every mandated document exists; the DDL executes and its probes pass. Manual: authority map against DDL tables; state machines against CHECK constraints and trigger T6; tier table against CLI command table and settings rules; decision IDs across documents; phase numbers across backlog, roadmap, file plan and requirements. No contradiction remained after correction; three were found and fixed during the review (decision numbers on two NFRs; a retrieval target lower than V5.0's without new evidence; drift comparison on text rather than parsed values).

## 2. Defects and weaknesses

| ID | Sev | Area | Finding | Disposition |
|---|---|---|---|---|
| RT-S01 | High | Security | One operating-system account: any unsandboxed process running as the owner can rewrite the database and its audit chain together. Triggers and hashes make tampering evident against earlier backups; they do not prevent it | ACCEPT (stated in SECURITY-ARCHITECTURE §12) |
| RT-S02 | High | Security | The whole write-enforcement design leans on how `excludedCommands` matches commands, which the documentation does not specify for compound commands or environment prefixes | VERIFY V-05; fallback defined |
| RT-S03 | Medium | Security | A "don't ask again" answer writes an allow rule to `settings.local.json`; documentation says ask rules still win, but this is the exact path an approval-fatigued owner would take | VERIFY V-06; doctor lists such rules |
| RT-S04 | Medium | Security | Sandboxed commands can read most of the machine by default | RESOLVED: `blockReadsOutsideWorkingDirectories` added |
| RT-S05 | High | Security | Skills from outside the project (personal, synced, plugin) load in the operating workspace, and a same-named personal skill takes precedence over the project's. IR1 also gave its own skills tool grants that the settings file made redundant. Found by external review | DECIDE D-20; VERIFY V-15 |
| RT-S06 | Medium | Privacy | The public classification was applied to everything stored. The owner's own queries, preferences, decisions and notes are not public documents. Found by external review | RESOLVED in security text; DECIDE D-06 for encryption |
| RT-A01 | High | Agentic | Tier 1 in-session approval is only as strong as Claude Code's prompt behaviour on the installed version | VERIFY V-06; DECIDE D-08 (terminal-only is available) |
| RT-A02 | Medium | Agentic | Batch approval lowers scrutiny; nothing measures whether the owner reads proposals | ACCEPT; 30-day review |
| RT-A03 | Medium | Agentic | A session can create unlimited tier 0 proposals and proposed records, flooding the queue and the `evidence_unverified` results | OPEN: add a cap on open proposals and on proposed records per run to FR-AGT-003 before Phase 5 |
| RT-A04 | Medium | Agentic | Nothing prevents a session from attaching a real unit ID to a sentence the unit does not support | ACCEPT; checked by sampling |
| RT-A05 | Low | Agentic | Answers to the same question may differ between sessions | ACCEPT |
| RT-D01 | Medium | Data | "Successor must be verified" on supersession is an application rule; the database only checks that a successor exists | ACCEPT; TEST-MEM-006 |
| RT-D02 | Medium | Data | Note-section search units are numbered by position; inserting a section shifts later IDs, so note sections are unstable as citations | ACCEPT by rule: facts cite passages or memory, never note sections |
| RT-D03 | Medium | Temporal | Hijri, month-only and year-only dates. Fields `date_precision` and `date_text` were added; the system does not convert calendars | DECIDE D-17 |
| RT-D04 | Medium | Data | `objects.object_type` could disagree with the table a row lives in | RESOLVED: doctor check DOC-DB-04 |
| RT-D05 | Low | Graph | `PART_OF` cycles are not rejected | OPEN (low) |
| RT-D06 | Medium | Data | Obsidian's property editor may rewrite frontmatter formatting, which a text comparison would report as drift | RESOLVED: comparison on parsed values |
| RT-D07 | Low | Data | Timestamp format is validated in the application, not by CHECK | ACCEPT |
| RT-D08 | Medium | Data | A run is limited to one original and one note group; compound proposals (verify + supersede + digest) touch several notes | VERIFY in Phase 5 design: digests are regenerated after the commit point as derived output, not inside the journal; state this in the implementation task |
| RT-R01 | High | Retrieval | Retrieval quality is unknown. The probe shows tokenizer behaviour on twelve sentences and nothing more | VERIFY at the Phase 4 gate |
| RT-R02 | Medium | Retrieval | The same text is indexed in two columns; bm25 weights are guesses | VERIFY RET-G1 |
| RT-R03 | Medium | Retrieval | Light stemming misses broken plurals and may conflate unrelated short words | VERIFY RET-G1; documented limitation |
| RT-R04 | Medium | Retrieval | Arabic PDF extraction (reading order, ligatures, tables) is the likeliest practical failure and no library has been tried | VERIFY V-12 before the Phase 2 gate |
| RT-R05 | Medium | Retrieval | Cross-language questions depend on the model translating query terms; unmeasured | VERIFY (benchmark stratum) |
| RT-O01 | Medium | Operations | Automated backup arrives in Phase 9 while real content may enter after Phase 2; the roadmap covers the gap with a manual copy | OPEN: recommend moving `backup create` and `restore-test` to Phase 2 (owner to confirm) |
| RT-O03 | High | Operations | IR1 accepted a second internal volume as a backup destination; a volume on the same disk fails with the disk. Found by external review | RESOLVED |
| RT-O02 | Low | Operations | launchd behaviour after sleep and access to an external disk under macOS privacy controls are assumed | VERIFY V-13 |
| RT-I01 | Medium | Dependencies | `uv`, the DOCX library and the PDF library are named but none was installed or tested for this specification | VERIFY Phase 1–2; DECIDE D-15 |
| RT-M01 | High | Method | This is the third specification pass with no running code. 100 requirements, 143 tests and 28 tables are a large plan for one person's tool. More specification now has sharply diminishing value | OPEN: recommend Phase 1 as the next step, and the simplifications in §5 |
| RT-M02 | High | Method | Specification, tests and review share one author and one session | OPEN: owner review; `spec-reviewer` on changes; executed tests |
| RT-M03 | Medium | Method | Task sizes (S, M, L) are estimates with no history behind them | ACCEPT |
| RT-M04 | Medium | Method | Documentation of Claude Code behaviour was read on one day; no version is pinned | VERIFY V-02; re-verify after upgrades |
| RT-M05 | Medium | Value | Nothing yet measures whether the owner benefits | Roadmap §5 usage review |

## 3. Hidden assumptions

1. One device and one user account. 2. Content is and stays public. 3. The owner will label at least 100 benchmark questions. 4. The owner reads proposals before approving. 5. Claude Code's permission and sandbox behaviour is as documented on the installed version. 6. The macOS sandbox is available and stays enabled. 7. A Python with SQLite ≥ 3.45 and FTS5 is obtainable on the Mac. 8. Staging, vault and originals share one APFS volume. 9. The system clock is roughly right and does not jump backwards. 10. Most PDFs have a text layer. 11. Arabic content is mostly Modern Standard Arabic in Arabic script (dialect, Arabizi and other Arabic-script languages are untested). 12. Lexical search is enough to be useful before any semantic technique. 13. Documents are under 200 MB and extract within two minutes. 14. The owner's Claude plan allows the session volume this workflow needs. 15. The backup disk is connected often enough. 16. Obsidian does not need plugins for the owner to be satisfied with reading Arabic notes.

## 4. Integration risks

1. `excludedCommands` semantics (RT-S02). 2. Permission-rule path anchoring across Claude Code versions. 3. Workspace trust: project allow rules apply only after the trust dialog; a skipped dialog changes behaviour silently. 4. `claudeMdExcludes` pattern matching on absolute paths if the home is moved. 5. Obsidian rewriting frontmatter (RT-D06) and creating files the system does not expect (`.obsidian/workspace.json`, untitled notes, attachments). 6. APFS is case-insensitive by default and normalisation-insensitive; two titles differing only in case or in hamza composition collide. 7. Git on macOS and Unicode filename normalisation in the vault's history. 8. SQLite version bundled with the chosen Python differing from the system `sqlite3` tool. 9. FTS5 `porter` wrapper behaviour on mixed Arabic and Latin tokens on the Mac's build. 10. PDF library output order for right-to-left text. 11. launchd and macOS privacy permissions for external volumes. 12. WAL files and the backup tool: copying the database file directly instead of using the backup API would corrupt backups; only the API is allowed. 13. Terminal emulators render bidirectional text differently; isolates may show as visible characters in some.

## 5. Simplification opportunities

Each would reduce scope without violating a MUST business requirement. They are options for the owner, not changes made.

| ID | Simplification | Removes | Cost |
|---|---|---|---|
| S-01 | Defer entities and typed relationships (Phase 6) until memory has proved useful | 3 tables, FR-KNW-006/007, 4 tests | No bilingual alias resolution; supersession edges become a column |
| S-02 | Merge state `captured` into `proposed` | One state, several transitions | No holding area for unclassified candidates |
| S-03 | Terminal-only approval at first | In-session channel; dependence on V-05, V-06 | More friction for the owner |
| S-04 | Start with the normalised column only; add the stem column only if RET-G1 shows a gain | Stemmer, one column | Possibly lower Arabic recall at the start |
| S-05 | Defer dashboards; use CLI lists and `doctor` | FR-OBS-002, one module | Less visibility in Obsidian |
| S-06 | Start with Markdown, text and PDF; add DOCX and HTML later | Two extractors, one dependency | Convert other files manually |
| S-07 | Model decisions as memory of kind `decision` plus a note, without a `decisions` table | One table, part of FR-PRJ-004 | Weaker decision queries |
| S-08 | Drop the vault's local Git history; rely on backups and `note_revisions` hashes | D-16 | No line-level note history |
| S-09 | Merge Phases 5 and 6; treat Phase 8 as a checklist item | Two gates | Larger increments |
| S-10 | Drop item types `commitment` and `question` until needed | Two vocabulary values | — |

Taking S-01, S-03, S-05, S-06 and S-07 together would remove roughly 15 requirements and four tables from version 1.

## 6. Missing acceptance scenarios

Not yet covered by a test case; candidates to add when the affected phase is planned.

1. Obsidian's property editor changes a managed note's frontmatter formatting (RT-D06). 2. A title longer than the filename limit, in Arabic. 3. The same text ingested as DOCX and as PDF (different hashes, identical passages). 4. A source in a third language or script (French, Persian, Urdu). 5. The clock set backwards between two runs. 6. The backup disk disconnected during verification. 7. Undo of a batch of approvals (there is no batch undo; each is superseded or corrected individually). 8. A proposal targeting a note the owner renamed in the meantime. 9. The home directory renamed or moved (absolute paths in settings, skills and launchd definitions). 10. A Claude Code upgrade that changes the meaning of a setting.

## 7. Coverage against the audit's 25 domains

500-SLOT-COVERAGE.md classifies every slot at specification level. Four slots are open findings (206, 481, 488, 489; they correspond to RT-D03, RT-M01, RT-M02). Ninety-eight are partly specified; their notes say what is missing. All 500 remain unverified for implementation.

## 8. Critical defects

None is rated Critical in the revised specification. The Critical items of the baseline (raw tokenizer unusable for Arabic; contradictory data models; no enforceable approval semantics; undefined file-and-database recovery) were resolved in specification and are listed in GAP-REGISTER. The High items that remain are verification, decision or method items; they are the conditions in IMPLEMENTATION-READINESS.
