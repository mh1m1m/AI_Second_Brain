# Engineering Handoff

**DOC-HANDOFF** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

For whoever implements this, human or a Claude Code session with no memory of how it was written. Everything here is proposed; nothing is implemented; implementation is not authorised.

## A. Architecture baseline

One owner, one Mac. Claude Code (interactive) reasons and proposes. A deterministic Python CLI, `second-brain`, owns every write. Originals are immutable content-addressed files. SQLite holds governed state (sources, passages, memory with revisions and evidence, entities and typed relationships, projects and decisions with event history, proposals and approvals, workflow runs and journal, hash-chained audit). An Obsidian vault holds the owner's prose and generated projections. SQLite FTS5 over application-normalised Arabic and English text is the search baseline. Knowledge lives in an operating home separate from the code repository. Read first: HLD, DATA-ARCHITECTURE, AGENTIC-ARCHITECTURE, SECURITY-ARCHITECTURE §5.

## B. Technology stack

| Item | Choice | Verified? |
|---|---|---|
| AI platform | Claude Code, interactive sessions only | Documentation of 2026-11-10 read; installed version unrecorded (V-02) |
| Language | Python ≥ 3.12, standard library first | Not on the target Mac (V-01) |
| Database | SQLite ≥ 3.45, WAL, STRICT tables, FTS5 (`porter unicode61 remove_diacritics 2`) | DDL executed on 3.53.1 in the sandbox; target build unverified (V-01, V-09) |
| Runtime packages | PyYAML, python-docx, one PDF text library to be chosen by spike | **Unverified; none installed** (D-15, V-12) |
| Development tools | uv, pytest, coverage, mypy, ruff | Unverified (D-15) |
| Notes | Markdown, YAML frontmatter, Obsidian core features only | Documentation read; display unverified (V-11) |
| Scheduling | launchd user agents | Unverified (V-13) |
| Isolation | Claude Code permission rules and macOS sandbox as configured in CLAUDE-CODE-CONTRACTS §5 | Documentation read; behaviour unverified (V-03 to V-07) |
| Not used | Other model providers, vector or graph databases, MCP servers, hooks, plugins, browser automation, web frameworks, daemons | Decisions ADR-006, 007, 008, 015, 018 |

No version is pinned beyond the minimums because nothing has been installed.

## C. Requirements baseline

78 functional requirements (FR-ING, KNW, MEM, RET, PRJ, AGT, SEC, OPS, OBS, IMP) and 22 non-functional, all PROPOSED; 71 are MUST. Source of truth: `docs/specification/data/requirements.json`; rendered in SRS.md. Every non-functional target is provisional and unmeasured. FR-IMP-001..003 are specified but not scheduled.

## D. Database specification

DATABASE-SCHEMA.md: 28 tables plus the FTS5 virtual table, 17 indexes, 15 triggers, migration rules. The DDL is also at `docs/specification/evidence/schema_v1.sql` and becomes `src/second_brain/db/migrations/0001_initial.sql` unchanged. The commit and recovery protocol is DATA-ARCHITECTURE §5.

## E. Interface specification

- Command line: CLI-SPECIFICATION.md (envelope, exit codes, every command with validation, tier, errors, tests).
- Python: LLD.md §4 (signatures), FILE-BUILD-PLAN.md (91 files with interfaces and dependencies).
- Data: DATA-ARCHITECTURE §7 (IDs, locators), OBSIDIAN-SCHEMAS (notes, 17 validation rules), MEMORY-ARCHITECTURE §11 (proposal schema), RETRIEVAL-ARCHITECTURE §4 and §9 (result and benchmark schemas), WORKFLOW-CONTRACTS (six state machines).

## F. Claude Code configuration

Two workspaces. Development repository: root `CLAUDE.md` (delivered, specification-only), one read-only reviewer subagent, minimal settings. Operating home: `CLAUDE.md`, one rule file, five skills, `settings.json` exactly as CLAUDE-CODE-CONTRACTS §5, installed and hash-verified by the CLI. Auto memory off; no hooks, MCP servers or subagents there. Fifteen verification items decide whether the configuration enforces what the security design needs.

## G. Implementation backlog

IMPLEMENTATION-BACKLOG.md: 51 tasks in phases 0–10, each with files, output, requirements, tests and a verification command. Critical path through Phase 9:

TASK-0001 → TASK-0002 → TASK-0101 → TASK-0102 → TASK-0103 → TASK-0105 → TASK-0106 → TASK-0107 → TASK-0201 → TASK-0202 → TASK-0203 → TASK-0205 → TASK-0207 → TASK-0208 → TASK-0210 → TASK-0211 → TASK-0301 → TASK-0302 → TASK-0303 → TASK-0402 → TASK-0403 → TASK-0405 → TASK-0406 → TASK-0407 → TASK-0501 → TASK-0502 → TASK-0503 → TASK-0504 → TASK-0601 → TASK-0602 → TASK-0604 → TASK-0701 → TASK-0703 → TASK-0704 → TASK-0705 → TASK-0901 → TASK-0902 → TASK-0903 → TASK-0904

First task after approval: TASK-0101, environment verification, before any code.

## H. Test plan

TEST-STRATEGY.md and TEST-CASES.md: 142 cases (122 automatable, 14 partly, 6 manual), 62 adversarial. Gates per phase in IMPLEMENTATION-ROADMAP.md; a gate passes only with a recorded evidence file. Five security tests and the acceptance journeys need the target Mac and the owner.

## I. Operational requirements

DEPLOYMENT-SPECIFICATION.md: prerequisites, ten-step installation, directory modes, configuration file, backup design (destination outside the home, manifest, verification, weekly restore test), doctor check catalogue, upgrade and rollback, six runbook outlines, three launchd jobs.

## J. Open decisions and inputs

DECISIONS-FOR-APPROVAL.md: five decided (macOS; Arabic-first bilingual; public content; fresh vault; V5.0 mandatory), fifteen open (D-06 to D-20), three findings (GAP-033, GAP-034, GAP-036), amendments waiting on the answers (section I), gate results in PRE-IMPLEMENTATION-READINESS-CERTIFICATE.md, and one open input: whether any existing codebase should be reviewed separately. Gap dispositions including the fifteen audit findings: GAP-REGISTER. V5.0 mapping: V5-COMPLIANCE-MATRIX. 500-slot coverage: 500-SLOT-COVERAGE.

## K. Readiness verdict

**NOT READY FOR IMPLEMENTATION.** Reasons: the decisions and ADRs are unapproved, and the platform and dependencies are unverified. The specification is ready for the owner's review. After approval and an environment check it would be ready with conditions for Phase 1 only. Details and evidence: IMPLEMENTATION-READINESS.md.

## What has actually been run

Schema DDL with 27 constraint probes; the FTS5 Arabic tokenizer probe; the consistency checker (23 of 23 checks pass). Nothing else. See `docs/specification/evidence/README.md`.

## Known weaknesses of this handoff

Written and reviewed by one author in one session. Large for a single-user tool; ADVERSARIAL-REVIEW §5 lists ten simplifications worth considering before approval. Claude Code behaviour was read from documentation on one date. Library choices are untested. Retrieval quality for Arabic is designed for, not measured.
