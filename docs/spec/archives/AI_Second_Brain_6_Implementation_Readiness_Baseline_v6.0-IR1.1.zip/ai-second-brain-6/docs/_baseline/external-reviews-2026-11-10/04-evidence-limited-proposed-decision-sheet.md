# AI Second Brain 6.0 — Decisions for Approval

> **EVIDENCE-LIMITED PROPOSED DECISION PACKAGE — NOT AN OWNER APPROVAL.**
> **IMPLEMENTATION NOT AUTHORIZED.**

## A. Executive decision summary

Prepared from the accessible specification archive `AI_Second_Brain_6_Implementation_Ready_Specification_Draft.zip` (2026-11-10). This archive contains **10 proposed ADRs (001–010)**, not 20, and does **not** contain a pre-existing `DECISIONS-FOR-APPROVAL.md`, individual ADR files, a baseline hash manifest, or the claimed GAP-033/GAP-034 entries. Therefore this is a **new proposed decision register**, not a verified amendment to a later live repository. The operating Mac and its Claude Code settings were not accessed.

**Readiness:** REQUIRES TARGETED CORRECTIONS before owner approval of a complete 20-ADR baseline; NOT READY FOR IMPLEMENTATION. No decisions below have been approved.

### Source evidence inventory

| Artifact | Evidence status |
|---|---|
| `docs/decisions/ADR-PROPOSALS.md` | VERIFIED present |
| `docs/decisions/ADR-REGISTER.md` | VERIFIED present |
| `docs/governance/IMPLEMENTATION-READINESS.md` | VERIFIED present |
| `docs/specification/GAP-REGISTER.md` | VERIFIED present |
| `docs/architecture/AGENTIC-ARCHITECTURE.md` | VERIFIED present |
| `docs/architecture/OBSIDIAN-SCHEMAS.md` | VERIFIED present |
| `docs/security/SECURITY-ARCHITECTURE.md` | VERIFIED present |
| `docs/requirements/TRACEABILITY-MATRIX.md` | VERIFIED present |
| `docs/requirements/ATOMIC-REQUIREMENTS.md` | VERIFIED present |
| `docs/governance/RED-TEAM-REVIEW.md` | VERIFIED present |
| `docs/architecture/CLAUDE-CODE-DEVELOPMENT.md` | VERIFIED present |

## B. D-06 through D-19 — consolidated owner decisions

All statuses **PROPOSED / PENDING OWNER ACTION**. Acceptance criteria are prospective, not passed tests.

| ID | Decision | Preferred recommendation | Alternatives | Acceptance / evidence required | Dependencies | Owner decision |
|---|---|---|---|---|---|---|
| D-06 | Backup and disaster recovery | Encrypted independent external backup; optional offsite copy only after separate approval | Internal volume only; cloud-only | Specify daily backup, tested restore, encryption/key recovery, owner-approved RPO/RTO and retention | GAP-005; GAP-009; ADR-010 | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-07 | Workspace layout | Separate trusted repo, operating data, untrusted intake and external backups; proposed paths ~/Developer/ai-second-brain and ~/SecondBrain | Single root; separate OS user | No trusted configuration loaded from untrusted corpus; paths and ACLs documented | SECURITY-ARCHITECTURE; DATA-ARCHITECTURE | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-08 | Approval tiers | Durable application-level approval record bound to operation digest, identity, expiry and one-time use | Claude prompt alone; all-manual filesystem operations | Reject replay/expired/mismatched approval; crash recovery preserves denial | GAP-007; ADR-009 | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-09 | Document formats | Stage Markdown/plain text first; HTML/DOCX/text PDF behind measured extraction tests | All formats at once; Markdown only indefinitely | Provenance-preserving extraction tests, error handling, original hashes; OCR deferred | FR-ING-001; FR-ING-002 | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-10 | Pilot and retrieval | Rights-attested 100–200 document pilot and >=100 labeled bilingual questions as provisional targets | Small smoke test only; larger unbounded corpus | Gold labels, missing-answer cases, citations, Arabic variants, authorized retrieval; thresholds agreed before scoring | GAP-004; GAP-011; ADR-005 | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-11 | Network access | Offline-first operating environment; separately authorized research path with no canonical write privileges | Always online; completely disconnected research | Permission and OS/network enforcement verified; external transmissions separately approved | GAP-002; SECURITY-ARCHITECTURE | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-12 | Mobile and multi-device | Defer synchronization and mobile; preserve exportability | Implement sync now; no future portability | No multiwriter assumptions; future read-only path feasible | ADR-003; ADR-004 | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-13 | Cost/context budget | Configurable retrieval budget (initial 6k-token hypothesis); benchmark relevance per token | Fixed 6k; external model API | Token measurement, citation retention, no Python direct model calls without new approval | ADR-001; ADR-005 | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-14 | Note naming and memory | Immutable stable IDs; human-readable titles; versioned metadata and source-linked memory | Filename IDs; opaque names | Rename/collision/reconciliation tests; original sources unchanged | ADR-002; OBSIDIAN-SCHEMAS | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-15 | Python toolchain | Python >=3.12 and SQLite FTS5 subject to local verification; pinned minimal runtime; isolated dev tools | Unpinned toolchain; broad dependency set | Version checks, FTS5 probe, lockfile policy, dependency provenance before install | GAP-010; ADR-004 | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-16 | Git in vault | Defer vault Git by default; optionally version text-only managed notes; independent backups mandatory | Auto-commit all; no history | No SQLite/secrets/binaries in Git; reconcile manual edits; backup independent | ADR-002; ADR-010 | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-17 | Date representation | Preserve original expression and uncertainty; normalized ISO Gregorian only when justified | Forced exact conversion; text-only dates | Unknown/partial/range/timezone/Hijri cases represented without invented precision | DATA-ARCHITECTURE | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-18 | Requirements and ADR approval | Individual owner sign-off for requirements baseline and each evidenced ADR; missing ADRs remain unresolved | Bulk approve; defer all | Full 100 requirements and 20 ADRs enumerated with traceability before approval | ADR-REGISTER; TRACEABILITY-MATRIX | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |
| D-19 | Phase 1 authorization | Separate verification-only instrument first; implementation authorization later and explicit | Immediate implementation; no verification | No work beyond specification until signed authorization with scope and stop conditions | IMPLEMENTATION-READINESS | **PENDING** — APPROVE / APPROVE_WITH_AMENDMENT / REJECT / DEFER |

### Decision consequences and risk ownership

- **Security/privacy:** D-07, D-08 and D-11 are hard security boundaries; prompt instructions and skill invocation restrictions are not sufficient enforcement. D-06 requires encryption and independent physical failure domains.
- **Complexity/cost:** Staging formats (D-09), deferring mobile (D-12), deferring vault Git (D-16), and configurable retrieval budgets (D-13) limit early complexity; costs and operating targets require owner acceptance.
- **Reversibility:** D-09, D-12, D-13 and D-16 are comparatively reversible; canonical ID/temporal semantics (D-14, D-17) and authority controls (D-08) are expensive to reverse.
- **Owner choices:** backup destination, retention, RPO/RTO, sensitive data permissions, external network policy, pilot-corpus rights, cost ceiling, final baseline sign-off and explicit Phase 1 authorization.

## C. ADR-001 through ADR-020 — evidence-qualified approval matrix

| ADR | Verified title / proposal | Recommendation | Principal consequence / verification | Owner decision |
|---|---|---|---|---|
| ADR-001 | Claude Code sole AI platform | **RECOMMEND_APPROVAL** (provisional) | user constraint; verify acceptance and security contracts | PENDING |
| ADR-002 | Markdown human-authored knowledge | **RECOMMEND_APPROVAL** (provisional) | portability; verify acceptance and security contracts | PENDING |
| ADR-003 | Obsidian optional UI | **RECOMMEND_APPROVAL_WITH_AMENDMENT** (provisional) | lower complexity; verify acceptance and security contracts | PENDING |
| ADR-004 | SQLite operational state | **RECOMMEND_APPROVAL** (provisional) | local-first simplicity; verify acceptance and security contracts | PENDING |
| ADR-005 | FTS5 lexical baseline | **RECOMMEND_APPROVAL** (provisional) | measurable baseline; verify acceptance and security contracts | PENDING |
| ADR-006 | Defer Qdrant | **RECOMMEND_APPROVAL** (provisional) | avoid early infrastructure; verify acceptance and security contracts | PENDING |
| ADR-007 | Defer Neo4j | **RECOMMEND_APPROVAL** (provisional) | minimal graph need; verify acceptance and security contracts | PENDING |
| ADR-008 | Single orchestrator + deterministic workers | **RECOMMEND_APPROVAL** (provisional) | predictable control; verify acceptance and security contracts | PENDING |
| ADR-009 | Approval-bound memory changes | **RECOMMEND_APPROVAL_WITH_AMENDMENT** (provisional) | contamination prevention; verify acceptance and security contracts | PENDING |
| ADR-010 | Independent encrypted backup | **RECOMMEND_APPROVAL_WITH_AMENDMENT** (provisional) | Git not sufficient backup; verify acceptance and security contracts | PENDING |
| ADR-011 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-012 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-013 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-014 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-015 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-016 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-017 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-018 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-019 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |
| ADR-020 | **NOT PRESENT IN ACCESSIBLE ARCHIVE** | **REQUIRES_OWNER_CHOICE / EVIDENCE FIRST** | Obtain actual ADR before recommending substance; do not fabricate | PENDING |

**ADR evidence limitation:** the accessible archive has only a compact 10-row proposal register. These provisional classifications are not a substitute for full ADR records containing alternatives, impacts, dependencies, acceptance criteria and signatures. No 20-ADR approval can be represented as complete.

## D. Outstanding findings

| Finding | Evidence status | Proposed disposition | Acceptance gate |
|---|---|---|---|
| GAP-033 — bounded proposal queue | Not found in accessible GAP-REGISTER | PROPOSED: configurable per-operation and open-queue caps, duplicate suppression, explicit overflow state, no silent loss | Boundedness, retry and overflow tests designed before implementation |
| GAP-034 — early backup and restore | Not found in accessible GAP-REGISTER | RECOMMEND ACCEPT: move backup-and-restore gate before real corpus ingestion | Isolated restore recovers original bytes, SQLite consistency, provenance, approvals and metadata |

## E. Claude Code Skills and Obsidian security amendments

1. **Skill provenance:** use reviewed project-local skills for eventual project workflows; do not automatically trust personal, synced, plugin or added-directory skills. Record origin, name collision, active permissions and version.
2. **Tool grants:** review `allowed-tools` and dynamic shell injection before invocation; skill frontmatter grants are turn-scoped and do not replace durable application authorization. Managed settings may override them.
3. **Configuration isolation:** keep untrusted vault content separate from trusted `.claude` configuration and `CLAUDE.md` discovery paths. `--add-dir` access is not equivalent to configuration loading.
4. **Synced skills:** behavior depends on authentication mode, settings sources, feature flags and Claude Code version; account-synced content must not be assumed available in cloud, headless or bare sessions.
5. **Forked agents:** `context: fork` is task isolation, not a reliable authorization sandbox; background edits may escape session checkpoint restoration. No autonomous writes without deterministic gates.
6. **Obsidian:** Markdown/YAML are a human interface; stable IDs and SQLite remain authoritative per approved schema. User edits require reconciliation. Right-to-left display must be verified in Obsidian; it does not alter stored IDs or schema.
7. **Future skills:** `brain-search`, `brain-ingest`, `brain-memory`, `brain-review`, `brain-audit`, `brain-doctor` are **design proposals only**. No executable skill was created or activated.

## F. Environment verification — not performed

| Activity | Type | Gate |
|---|---|---|
| Inspect macOS, Claude Code, Python and SQLite versions | Read-only | Explicit verification-only authorization |
| Inspect relevant permission settings, skill inventory, MCP inventory and config discovery | Read-only | Sensitive settings must be redacted |
| Verify FTS5 with isolated in-memory SQLite | Executable probe | Separate permission under Instrument A |
| Verify Arabic tokenizer behavior using synthetic fixtures | Executable probe | Separate permission under Instrument A |
| Test OS boundary, vault isolation and backups | Executable test | Separate later scoped authorization; never use real data initially |

## G. Owner approval record — intentionally blank

| Decision scope | APPROVE | APPROVE_WITH_AMENDMENT | REJECT | DEFER | Amendment / owner evidence |
|---|---|---|---|---|---|
| D-06 through D-19 (each individually) |  |  |  |  |  |
| ADR-001 through ADR-020 (each individually, after full records exist) |  |  |  |  |  |
| GAP-033 and GAP-034 |  |  |  |  |  |
| Verification-only Instrument A |  |  |  |  |  |
| Phase 1 Instrument B |  |  |  |  |  |

No blank field means approval. The owner must provide explicit affirmative decisions with scope and date.

## H. Authorization instruments

### Instrument A — verification only (draft, not granted)

Scope: inspect version/configuration and run only individually authorized, isolated, non-mutating probes. No dependency installation, live vault writes, data ingestion, MCP activation or application development. **Status: NOT AUTHORIZED.**

### Instrument B — Phase 1 implementation (draft, not granted)

Requires approved requirements and ADR baseline, approved paths, dependency policy, data classifications, security and recovery controls, test/rollback plan, explicit stop conditions and separately recorded owner authorization. **Status: NOT AUTHORIZED.**

## I. Targeted correction backlog

1. Obtain the actual current `DECISIONS-FOR-APPROVAL.md` and full ADR-011–ADR-020 from the active repository, if they exist.
2. Confirm the source-of-truth repository commit and compare its contents with this archived specification before merging any edits.
3. Verify the purported 100 requirements, 14 decisions and two later GAP IDs against the active baseline; do not assume these counts were present in the archive.
4. Obtain owner responses for business-policy choices; leave technical library selection to implementation design review.
5. Record a source hash/commit for each decision amendment and preserve previous versions; do not edit historical audit evidence.

## J. Independent challenge / completion accounting

- D-06–D-19: **14/14** have provisional recommendations; **0/14** approved.
- ADR-001–010: **10/10** source-backed titles and provisional recommendations; detailed ADR evidence incomplete.
- ADR-011–020: **0/10** source-backed records; explicitly unverified.
- GAP-033/034: proposed dispositions, **not confirmed as present in accessible source register**.
- No local Mac tests, no application implementation, no permissions granted, no production data processed.

**Final verdict: REQUIRES TARGETED CORRECTIONS. IMPLEMENTATION NOT AUTHORIZED.**
