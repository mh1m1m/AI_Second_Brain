# Baseline snapshot manifest

Taken 2026-11-10 before any document was revised. Byte-for-byte copies; nothing in this folder is edited.

- `v6.0-expanded-draft/` — the 46-file package `AI_Second_Brain_6_Implementation_Ready_Specification_Draft.zip` (it contains the original 22-file V6.0 package unchanged). Holds the pre-revision gap register, traceability matrices and architecture decisions.
- `asb6-adversarial-audit/` — the package `ASB6_500_Adversarial_Audit_Evidence_Limited.zip` with its 15 findings and 500-slot matrix as received.

| File | Bytes | SHA-256 |
|---|---:|---|
| `asb6-adversarial-audit/00-EXECUTIVE-VERDICT.md` | 4085 | `1a8757f22f996ad94dee91485fecfd9eed38b06a1463ba01284a247b079b9a27` |
| `asb6-adversarial-audit/01-IMPLEMENTATION-BASELINE.md` | 275 | `f80ed7e7d38bad71af246cc0f8b9ea6600e472f70c7393d140438fc5ae8e3511` |
| `asb6-adversarial-audit/02-SOURCE-EVIDENCE-INVENTORY.md` | 2410 | `693d58ef0cc905937c808eb4e1a5737e53af6f2a6cedfff89ef22277d5822a72` |
| `asb6-adversarial-audit/03-500-INVESTIGATION-MATRIX.md` | 1554 | `2066ec85c48e2fb3e5f132080261f999492a7246c1a8758fe6b4b145e7f4bf1d` |
| `asb6-adversarial-audit/04-CONFIRMED-DEFECTS.md` | 4783 | `ce3a0aa44d80e9fe6fb078eb9b7652d5edf40abb711b5479f412f3422ac3781e` |
| `asb6-adversarial-audit/05-PLAUSIBLE-RISKS.md` | 169 | `145b0db1eaf7b8f66bccf59819f5539d70aab60358b01412f50bcab4f5bd2100` |
| `asb6-adversarial-audit/06-UNVERIFIED-ASSUMPTIONS.md` | 349 | `563908b0904084c47e97785660eacca12943515618e929d294bdcee1e030ef19` |
| `asb6-adversarial-audit/07-CROSS-DOMAIN-ROOT-CAUSES.md` | 507 | `cf07cd6292ec0664b42428e030789136c15df2f82f58b37fca7452a6f389306e` |
| `asb6-adversarial-audit/08-V5-TO-V6-REGRESSION-REVIEW.md` | 321 | `2f5a51eea1f7aff0d93b446e2e5f3307961171b15dffc4ec3e6a464d32194aeb` |
| `asb6-adversarial-audit/09-SECURITY-RED-TEAM.md` | 193 | `4a6228682fa744aa78d19a983a7ebebdd867336ffd79f8205b930f6b56a11d55` |
| `asb6-adversarial-audit/10-DATA-INTEGRITY-REVIEW.md` | 184 | `64a6b67915584ee38177e3db6cd9f9c0e4022a6910341b79a4fdca6cb4b0ec67` |
| `asb6-adversarial-audit/11-AGENTIC-RAG-REVIEW.md` | 144 | `c284818da332189a1021d5eb971f6f848c573b84aeb283a5e08c18ab55bbcc34` |
| `asb6-adversarial-audit/12-CLAUDE-CODE-OBSIDIAN-INTEGRATION.md` | 178 | `38e59127c7b8da988e95af06cc5a66b7da67ad98a31cb315db77164d82a295d0` |
| `asb6-adversarial-audit/13-TEST-COVERAGE-GAPS.md` | 167 | `6e4a8608d8e8bf9700d39d835db4ed90bc25d5a7bac7ef2cac067d9a153c2710` |
| `asb6-adversarial-audit/14-ARCHITECTURE-SIMPLIFICATION.md` | 189 | `11ee0ac2295283e458174f5351f38e8d32fad37cea0372426001c44f93fba8f8` |
| `asb6-adversarial-audit/15-REMEDIATION-BACKLOG.md` | 1860 | `8b09878f49e7e33de9cd39182b465a70d01ead8cc68178e1a7a6f176d0030e6a` |
| `asb6-adversarial-audit/16-IMPLEMENTATION-CORRECTION-CONTRACTS.md` | 6385 | `704d468c95c5e27e023381fe96ae320aa5170a68d225f98589d66cbf4bcdd898` |
| `asb6-adversarial-audit/17-RELEASE-BLOCKERS.md` | 191 | `94da46a93f3e467dd18cd6887ef5196eb75758a9efa69d3b32d0e8efa2cf7c1a` |
| `asb6-adversarial-audit/18-OPEN-DECISIONS.md` | 158 | `8856b73e63b782b2184fa7c389cbab3c14cdb8bd4d97e8d300d1f2543e39e46b` |
| `asb6-adversarial-audit/19-ENGINEERING-HANDOFF.md` | 285 | `a1ac6dc40bdf7ae26fcf84b11bdd021cdb3b2194018f940d4c95d86a00c48848` |
| `asb6-adversarial-audit/machine-readable/findings.json` | 10211 | `1aebbb1de0ce7d95443bc0e50fa0a04cb8d9c51cc6f7d312e637efbdc9ae6c44` |
| `asb6-adversarial-audit/machine-readable/investigation-matrix.json` | 189134 | `33b1d1d3aaf1f7d713755ef9bc3d4afbbab1ee2486917048c7405325ee1af8dc` |
| `asb6-adversarial-audit/machine-readable/quality-report.json` | 507 | `659dedaf2f1c87ab75b8d57f2d4bf22ee78492a1cd4af41f5ae19f0eedb43f56` |
| `asb6-adversarial-audit/machine-readable/remediation-backlog.json` | 10211 | `1aebbb1de0ce7d95443bc0e50fa0a04cb8d9c51cc6f7d312e637efbdc9ae6c44` |
| `asb6-adversarial-audit/machine-readable/traceability.json` | 75 | `5e613147dc1db850b78634e53df0058deead729353d7397dbd21fc8e37375191` |
| `v6.0-expanded-draft/CLAUDE.md` | 1197 | `918bca1fdaa4ac81e0289031e20cdeebfb616b23a8642cc6fda1cb9ba46bb44d` |
| `v6.0-expanded-draft/README.md` | 1519 | `384ece041c940a5244c50846bf48cd9cdaf2867ec3fad4065eb070918844ca57` |
| `v6.0-expanded-draft/docs/architecture/AGENT-RESPONSIBILITY-MATRIX.md` | 1148 | `0291c36bdc2228d36876f9086390370bd76ffb9edcabfeecef14311349024727` |
| `v6.0-expanded-draft/docs/architecture/AGENTIC-ARCHITECTURE.md` | 1065 | `bc67503f933ebd37a6a424a9e36b0ea99620234e1b7f50ced05fe9fd13ee0ea7` |
| `v6.0-expanded-draft/docs/architecture/CLAUDE-CODE-DEVELOPMENT.md` | 1188 | `0371f48fea78525bf023b925a43166c7c498996ad66dbb02724e75abc25c81fe` |
| `v6.0-expanded-draft/docs/architecture/DATA-ARCHITECTURE.md` | 1746 | `1b9b069607b88a512e01f3a6125a12ada3f5b3e5a3ff1bf413bf4a3afbacff07` |
| `v6.0-expanded-draft/docs/architecture/DATABASE-SCHEMA.md` | 5787 | `7fc77e7ea77f2bbb5ab3e32882971c02417669fc15aa6fa0c63214ba28149f92` |
| `v6.0-expanded-draft/docs/architecture/HLD.md` | 1703 | `5f8a1780e5b0554ebff2cc5770d859cbf7dbf8ef41193840fb27636c43790abf` |
| `v6.0-expanded-draft/docs/architecture/KNOWLEDGE-GRAPH.md` | 768 | `07e78605a1051b34482c7ea187317ee2595008fd557d8063ee0cb3be485ceb94` |
| `v6.0-expanded-draft/docs/architecture/LLD.md` | 1714 | `43ee122ac7c7eab68813226a11242df2700f3adac607bd1196b9689bd93564d6` |
| `v6.0-expanded-draft/docs/architecture/MEMORY-ARCHITECTURE.md` | 1391 | `0cc188f48883c1c43c431fccead2e46c5caa11f1f72492379763b36494417fed` |
| `v6.0-expanded-draft/docs/architecture/OBSIDIAN-SCHEMAS.md` | 1684 | `e8bce6d0a17b5b65503976d79689cbe5fc557b0cf25bf29f4d0e5185475ca64b` |
| `v6.0-expanded-draft/docs/architecture/RETRIEVAL-ARCHITECTURE.md` | 1183 | `e2eb2b7213f7a490cfcf37ea53829972423a8e6cd1f2f24a84fa0bc45c0f5a01` |
| `v6.0-expanded-draft/docs/architecture/RETRIEVAL-BENCHMARK.md` | 1327 | `f849038fb02ca26137f11d8320e70ad8f2af2dfa9f6678d56c7d0730c9a8fad9` |
| `v6.0-expanded-draft/docs/architecture/TRANSACTION-PROTOCOL.md` | 1917 | `929b7cc19c768db151ef8d51d7bce15c1e26a5ff287026e20c537467f1f57756` |
| `v6.0-expanded-draft/docs/architecture/WORKFLOW-CONTRACTS.md` | 1594 | `647191dea1cc5094e67ebbac5262691d5fbdf588ce8df002c0c75606a38a43df` |
| `v6.0-expanded-draft/docs/decisions/ADR-PROPOSALS.md` | 1528 | `1e79aaf27a2781447064915c175e4b4bed15411d870082e70f72f1cea95f9409` |
| `v6.0-expanded-draft/docs/decisions/ADR-REGISTER.md` | 1199 | `11895670a8dcfdc30ca8838491bc43483cecfbed2c7b3213b13b80f25c0b801b` |
| `v6.0-expanded-draft/docs/engineering/CLAUDE-CODE-CONTRACTS.md` | 1450 | `db2706983c9c23fda1c396d11173d26abac47c12e4805e49b511d4b384a519f9` |
| `v6.0-expanded-draft/docs/engineering/CLI-SPECIFICATION.md` | 1771 | `41637df06b6aaca2786c5497701d5738e23d248fcf4864b060f528e86d9b45c5` |
| `v6.0-expanded-draft/docs/governance/ENGINEERING-HANDOFF.md` | 1703 | `2a8fd4a19725209543b1eb47c8ad5391fd9e02e18160c868df49f3a56d4d53be` |
| `v6.0-expanded-draft/docs/governance/IMPLEMENTATION-READINESS.md` | 1813 | `fa3c493b4dc54841c7f92c9c68eac43dcc18b5b3369784bdaed2fd5dbf93f001` |
| `v6.0-expanded-draft/docs/governance/QUALITY-REPORT.json` | 373 | `1fad845996846cf6bdd5b4fa74db285b04bd5bb5a9d2f9fb7aaea251b8aaee76` |
| `v6.0-expanded-draft/docs/governance/RED-TEAM-REVIEW.md` | 2741 | `8b62b2c27822fffa078a3a92bef41b9d664be0d5f53eb6fb3b80795613384b80` |
| `v6.0-expanded-draft/docs/operations/DEPLOYMENT-SPECIFICATION.md` | 1786 | `e83beb3394100a9aec44f455e0eb494bf1aa565bb95fccd2f57486690af55c58` |
| `v6.0-expanded-draft/docs/operations/OPERATIONS.md` | 1151 | `76eb37547a17df45d80208c8885a9156ecb928d0c17a95b1ba143a4eec05eb25` |
| `v6.0-expanded-draft/docs/planning/ASSUMPTIONS.md` | 1231 | `42312789c4e7ca7b5cf344bd1c0e1366cf9808efb6c933c495dfdded4dffede7` |
| `v6.0-expanded-draft/docs/planning/ENGINEERING-BACKLOG.md` | 1169 | `082fb7100d396adc78e8624c82c15e28cf227453603508ee464b0d45361fe85c` |
| `v6.0-expanded-draft/docs/planning/FILE-BUILD-PLAN.md` | 1776 | `e2ba9c71f887f2f98c6c52c37910071ab9d6afbd1fe7bf8af71224edaf9adaca` |
| `v6.0-expanded-draft/docs/planning/IMPLEMENTATION-BACKLOG-DETAILED.md` | 2316 | `b812c6d7b19b1163111e0fd18affc0aa6d4e4c10de02bb755c77cbcc3719383d` |
| `v6.0-expanded-draft/docs/planning/IMPLEMENTATION-ROADMAP-DETAILED.md` | 1379 | `d5f47fbec053dd4a6029c926f223198ca019e075db0d2293c3615e109db52d55` |
| `v6.0-expanded-draft/docs/planning/IMPLEMENTATION-ROADMAP.md` | 857 | `87530cc68e03e8f6cd951f1689c686e927fc8b1714c558b36eabbc65da8c1a79` |
| `v6.0-expanded-draft/docs/planning/PRODUCTION-READINESS.md` | 668 | `877c7c87444e19ef65e074233b6c39fe5adadac92545919e52be2dda5cf2e318` |
| `v6.0-expanded-draft/docs/requirements/ATOMIC-REQUIREMENTS.md` | 3454 | `084223edaffbcc9d3dca70c6c73404e5af9c893261a916486a731077c987c0c7` |
| `v6.0-expanded-draft/docs/requirements/BRD.md` | 2732 | `3d1d71e195eac0cca87ccc2303a1dab333986e881743ddcf24f74e35cecd922e` |
| `v6.0-expanded-draft/docs/requirements/PRD.md` | 1661 | `694b5751e04c4aec5b8733e27b8b681cfe19cc0ff04d5c665b52a06cf9eaf705` |
| `v6.0-expanded-draft/docs/requirements/SRS.md` | 2700 | `9974d4e0e95ca47261f296b4297969b06b3f9f5763883e110b04191b76c12d4c` |
| `v6.0-expanded-draft/docs/requirements/TRACEABILITY-IMPLEMENTATION.md` | 1673 | `2e47eec1fb48dab72c0f171356e59b90b8e11c848a9a3ee3e3b8f4b70ba2411a` |
| `v6.0-expanded-draft/docs/requirements/TRACEABILITY-MATRIX.md` | 861 | `adbb30a9391368fa953ac1558ea2b1862d6578650fcd2225849cf55ecc66fbe5` |
| `v6.0-expanded-draft/docs/security/SECURITY-ARCHITECTURE.md` | 1293 | `f7977f034956cea76590080326bb6dbba98d59c98398299f910ba4caa08ec295` |
| `v6.0-expanded-draft/docs/security/THREAT-CONTROL-MATRIX.md` | 1420 | `888e54a728f5979903259c4078b9e645741a16f7d8b70b37dda0baeb9823955e` |
| `v6.0-expanded-draft/docs/specification/BASELINE-INVENTORY.md` | 4084 | `70bed346a29ba55e596e0aa11843cc0e24e92597e59d19c4663ac19f444fdfb8` |
| `v6.0-expanded-draft/docs/specification/CHANGE-REGISTER.md` | 566 | `aa376c0e7e375691005690646e84e3d0fe425c8a78a6de3ec8602a42ec873f88` |
| `v6.0-expanded-draft/docs/specification/GAP-REGISTER.md` | 2427 | `c584c42fde6d26b4cdf0a9abdde0eaa2f0c734af79a2485edbacfff1c42e43fc` |
| `v6.0-expanded-draft/docs/testing/TEST-CASES.md` | 5288 | `80196a0e5d6f0175a96db8aa544e6049e0ba01cce80037a29df9eba423dcc8cb` |
| `v6.0-expanded-draft/docs/testing/TEST-STRATEGY.md` | 1359 | `cbbb92cea7ad92113a8bdfb6bb607edf566ec3918190eabbf762e90c5596caaf` |
