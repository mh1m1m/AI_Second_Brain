# Architecture Decision Register

**DOC-ADR** · v6.0-IR1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `ADR-REGISTER.md` and `ADR-PROPOSALS.md` of the V6.0 draft, which were summary tables without context, consequences or evidence (snapshot kept in `docs/_baseline/`). ADR-001 to ADR-010 keep their subjects; four are revised; ADR-011 to ADR-020 are new. **Every ADR is PROPOSED.** None is approved until the owner signs DECISIONS-FOR-APPROVAL.md. Previously settled directions (V5.0) are not reopened without new evidence; where this register changes one, the new evidence is stated.

Evidence labels: **[DOC]** official documentation read on 2026-11-10; **[PROBE]** executed in the specification sandbox, files in `docs/specification/evidence/`; **[OWNER]** owner decision recorded on 2026-11-10; **[V5]** V5.0 adversarial review; **[REASON]** design reasoning without measurement.

---

### ADR-001 Claude Code is the only AI platform
- **Context.** Owner constraint since 4.0; principle P01.
- **Decision.** All model reasoning happens in Claude Code sessions. The Python package calls no model API.
- **Alternatives.** Other assistants or orchestration frameworks; direct API calls from Python for extraction.
- **Consequences.** No batch semantic processing without a session; no embeddings from the same provider path, so any dense retrieval would introduce a second model (see ADR-006).
- **Evidence.** [OWNER], [V5].
- **Reversal.** Explicit owner change of the constraint.

### ADR-002 Markdown with YAML frontmatter for narrative notes
- **Context.** Portability (P08) and Obsidian compatibility.
- **Decision.** Human notes are Markdown files; the file is authoritative for body and descriptive properties.
- **Alternatives.** Notes in the database with generated Markdown; a proprietary note format.
- **Consequences.** An uncoordinated editor (Obsidian) writes authoritative files; requires sync and conflict rules (ADR-012).
- **Evidence.** [V5]; [DOC] Obsidian properties are flat YAML.
- **Reversal.** Structured editing needs dominate and notes become forms.

### ADR-003 Obsidian is an optional interface
- **Decision.** No function depends on Obsidian running or on any plugin. Core plugins only in the installed vault configuration.
- **Alternatives.** Dataview or Templater based dashboards; an Obsidian plugin for approvals; a custom application.
- **Consequences.** Dashboards are generated Markdown; approvals happen in Claude Code or a terminal.
- **Evidence.** [DOC] RTL and mixed-direction support is built in since 1.6; Bases exists as a core plugin since 1.9 and is not relied on. [V5].
- **Reversal.** The owner finds generated dashboards insufficient; Bases views would be the first candidate.

### ADR-004 SQLite as the transactional registry
- **Decision.** One SQLite file in WAL mode, STRICT tables, foreign keys on, schema in DATABASE-SCHEMA.
- **Alternatives.** PostgreSQL; JSON or Markdown files as registry; an embedded key-value store.
- **Consequences.** Single writer; file-level backup through the online backup API; the database owner can alter anything (mitigated by ADR-015).
- **Evidence.** [PROBE] DDL executes on SQLite 3.53.1 with 27 of 27 constraint probes behaving as specified. [V5].
- **Reversal.** Multi-user or multi-device writing becomes a requirement; measured contention.

### ADR-005 FTS5 baseline with application-level Arabic normalisation (revised)
- **Context.** The draft specified `tokenize='unicode61'` and listed Arabic tokenisation as a medium-severity gap to benchmark later.
- **Decision.** Keep FTS5 as the baseline, but normalise text in the application (`ar-en-1`), index a light-stemmed column, and wrap `unicode61` in `porter` for English. Variant chosen by gate RET-G1.
- **Alternatives.** Raw `unicode61` (draft); `trigram` tokenizer; SQLite ICU extension; an external search engine.
- **Consequences.** Index text differs from stored text; excerpts come from originals; a normaliser change needs a rebuild; light stemming misses broken plurals.
- **Evidence.** [PROBE] raw `unicode61` indexed `مُحَمَّدٌ` as four single letters and failed all nine variant probes; the normalised and stemmed index answered eight of them (broken plurals remain missed); details in RETRIEVAL-ARCHITECTURE §2. This is tokenizer behaviour, not a quality measurement.
- **Reversal.** NFR-007 not met on holdout after RET-G1.

### ADR-006 Defer vector retrieval
- **Decision.** No embeddings or vector store until gate RET-G2 is met.
- **Alternatives.** Qdrant (4.0); an embedded vector extension; hybrid from the start.
- **Consequences.** No semantic matching; cross-language questions rely on query translation in the session.
- **Evidence.** [V5] finding 5. [REASON] an embedding model would be a second model provider or a local model, against P01 without explicit approval.
- **Reversal.** RET-G2 criteria, with recorded numbers.

### ADR-007 Defer a graph database
- **Decision.** Typed relationships in SQLite with recursive queries.
- **Alternatives.** Neo4j; GraphRAG pipelines.
- **Evidence.** [V5] finding 6. [REASON] no required query exceeds a depth-3 traversal.
- **Reversal.** KNOWLEDGE-GRAPH §6.

### ADR-008 One orchestrator, deterministic services, no unattended model runs
- **Decision.** One interactive Claude Code session orchestrates; Python does everything that must be reproducible; launchd runs only deterministic commands; no custom subagent in the operating workspace.
- **Alternatives.** Nine agents (4.0); scheduled `claude -p` jobs for ingestion and reconciliation.
- **Consequences.** Semantic work happens only when the owner is present. Bulk proposal drafting is manual-paced.
- **Evidence.** [V5] findings 4 and 7. [DOC] non-interactive runs show no trust dialog and no per-server approval prompt, and deny what would prompt.
- **Reversal.** A measured backlog of semantic work the owner wants processed unattended, with a separate security design.

### ADR-009 Approval-gated promotion with three tiers (revised)
- **Context.** The draft required "human approval" for all knowledge writes without saying how a human is distinguished from the agent.
- **Decision.** Tier 0 (none), tier 1 (owner at a Claude Code permission prompt or terminal), tier 2 (terminal with typed confirmation). Approvals are rows bound to the proposal's payload hash, single-use, expiring.
- **Alternatives.** Approve everything at a terminal (safest, most friction); approve nothing below deletion (least friction); an Obsidian-based approval.
- **Consequences.** Tier 1 in-session approval rests on Claude Code's `ask` rule behaviour (V-06). Friction is unmeasured.
- **Evidence.** [DOC] ask rules prompt regardless of allow rules and hooks; bypass and auto modes can be disabled by setting. [PROBE] triggers T8–T10.
- **Reversal.** V-06 fails (→ terminal-only tier 1), or the 30-day review shows the tiers are wrong.

### ADR-010 Independent backup with restore testing; encryption optional (revised)
- **Decision.** Backups to a destination on another device, with manifest, verification after write and scheduled restore tests. Encryption off by default.
- **Alternatives.** Git only; Time Machine only; encrypted by default (draft).
- **Consequences.** Unencrypted copies of public content; one more thing the owner must provide (a destination).
- **Evidence.** [V5] finding 9. [OWNER] content is public (D-03), which removes the confidentiality reason for mandatory encryption.
- **Reversal.** Content classification changes; then encryption and key handling become mandatory before further ingestion.

### ADR-011 Architecture C+ among the V5.0 alternatives
- **Decision.** Alternative C (Claude Code, Obsidian, FTS5) plus provenance registry, memory lifecycle, commit journal, approval gate, backups and evaluation harness.
- **Alternatives.** A, B, D, E, F as defined by V5.0 (HLD §11).
- **Consequences.** More machinery than A–C; much less than D–F.
- **Evidence.** [V5] recommended production architecture. [REASON] each addition maps to a MUST requirement (TRACEABILITY).
- **Reversal.** A gate result showing a retained component is unnecessary or an omitted one is needed.

### ADR-012 Governed fields live in SQLite; Markdown shows projections; memory appears as digests
- **Context.** V5.0 finding 1; audit issue 0012. The draft left "reconciliation" undefined.
- **Decision.** Authority map of DATA-ARCHITECTURE §2. Managed frontmatter keys are projections and never read back. Memory is projected as digest notes per subject, project or month.
- **Alternatives.** Markdown authoritative for everything; database authoritative for everything; one note per memory record.
- **Consequences.** A hand edit of a managed key is ignored and reported; fewer generated files.
- **Evidence.** [REASON]; [DOC] Obsidian block anchors and flat properties.
- **Reversal.** The owner needs to edit governed fields in Obsidian; then an explicit "edit becomes proposal" path would be designed.

### ADR-013 Application journal for file-plus-database commits
- **Decision.** Protocol S0–S7 with intents, atomic rename, a database commit point, roll-forward recovery and a read-only mode for unknown states.
- **Alternatives.** Database first, files second; files only with the database rebuilt from them; storing originals as BLOBs.
- **Consequences.** A recovery step before every mutating command; runs limited to one original and one note group.
- **Evidence.** [REASON]. Unverified until the crash suite runs; `rename` and full-fsync behaviour on the Mac is V-10.
- **Reversal.** The crash suite shows an unrecoverable interleaving.

### ADR-014 Operating home separate from the development repository
- **Context.** The directive's proposed layout put `vault/` and `data/` inside the code repository.
- **Decision.** Code in `~/Developer/ai-second-brain`; knowledge in `~/SecondBrain` with its own instructions and settings; the CLI installed outside both.
- **Alternatives.** One repository for everything.
- **Consequences.** Two Claude Code contexts; knowledge never enters the code repository's Git history; a session that reads knowledge cannot edit the code that guards it.
- **Evidence.** [DOC] the sandbox makes the working directory writable by default and settings are per project; [REASON].
- **Reversal.** Owner preference for a single folder, accepting weaker separation.

### ADR-015 Layered write enforcement; no hooks in version 1
- **Decision.** Five layers (SECURITY-ARCHITECTURE §5). The installed CLI is the only command excluded from the sandbox.
- **Alternatives.** Prompts only; a PreToolUse hook as gatekeeper; a separate macOS user account for the data; a local daemon owning the data.
- **Consequences.** Depends on V-03 to V-06. Fallback if V-05 fails: drop the exclusion and rely on L2–L5. A separate OS account would be stronger and is rejected as disproportionate for public content.
- **Evidence.** [DOC] the sandbox covers Bash and its children but not built-in file tools, hooks or MCP servers; hooks run with full user permissions; Bash permission rules are not a security boundary.
- **Reversal.** V-items fail without a workable fallback; or content classification changes.

### ADR-016 Sequential typed identifiers and an objects registry
- **Decision.** IDs like `MEM-000101`, allocated in-transaction; every object registered in `objects`.
- **Alternatives.** UUID or ULID; per-table integer keys with polymorphic text references.
- **Consequences.** Readable citations; real foreign keys for cross-type links; unsuitable for multi-device writing.
- **Evidence.** [PROBE] constraints P22–P24.
- **Reversal.** Multi-device writing.

### ADR-017 Extraction: small parsers, versioned extractions, OCR deferred
- **Context.** 4.0 proposed Docling.
- **Decision.** Standard-library extractors for text, Markdown and HTML; one small library each for DOCX and PDF; extractor name and version on every extraction; scanned content flagged, not processed. The PDF library is chosen by a measured spike on Arabic fixtures (V-12).
- **Alternatives.** Docling or a similar model-based pipeline; OCR in version 1; reading PDFs through Claude in a session.
- **Consequences.** Tables and layout are extracted poorly; scanned Arabic documents are not searchable until a later decision.
- **Evidence.** [REASON] dependency minimalism (NFR-011). No library has been tested: **unverified**.
- **Reversal.** Spike shows no small library gives acceptable Arabic reading order; or the pilot corpus is mostly scans.

### ADR-018 No MCP server, plugin, web access or browser automation; Claude Code auto memory off
- **Decision.** None of these in the operating workspace in version 1.
- **Alternatives.** Obsidian MCP server; Playwright (4.0); web research in session.
- **Consequences.** No web research inside the Second Brain workspace (decision D-11 may reopen).
- **Evidence.** [DOC] MCP servers and hooks run outside the sandbox; servers that fetch external content expose sessions to injection; auto memory stores project notes outside any governance.
- **Reversal.** Owner approves a specific integration with an ADR.

### ADR-019 Legacy vault import deferred, schema-ready
- **Decision.** Not built in version 1. The schema already carries what import needs: `origin_kind = legacy_vault`, `change_origin = import`, `created_by_run` for batch rollback, entity aliases for reconciliation. Contracts FR-IMP-001..003.
- **Evidence.** [OWNER] fresh vault; no existing vault (D-04).
- **Reversal.** Owner requests import; it becomes a Phase 10 item with its own approval.

### ADR-020 One memory model
- **Context.** The draft contained `claims` in one document and `knowledge_records` plus `memory_records` in another.
- **Decision.** `memory_records` + `memory_revisions` + `evidence_links`; notes are separate.
- **Alternatives.** Claims embedded in notes; separate tables per memory kind.
- **Evidence.** [PROBE] lifecycle and evidence triggers; [V5] findings 2 and 3.
- **Reversal.** A memory kind needs fields the shared shape cannot hold.
