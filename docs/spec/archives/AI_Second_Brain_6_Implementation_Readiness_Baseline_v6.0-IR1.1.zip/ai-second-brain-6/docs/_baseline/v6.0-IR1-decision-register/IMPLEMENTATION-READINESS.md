# Implementation Readiness Assessment

**DOC-READY** · v6.0-IR1 · 2026-11-10 · Status: ASSESSMENT · Owner: Mohammed Alsaleh

Supersedes the readiness report of the V6.0 draft (snapshot in `docs/_baseline/`).

## 1. Verdict

**NOT READY FOR IMPLEMENTATION.**

Two of the directive's mandatory blockers apply today, and neither is a defect in the documents:

1. **Major architecture decisions are unapproved.** All 20 ADRs and 14 decisions are proposals awaiting the owner (DECISIONS-FOR-APPROVAL).
2. **Installation dependencies are unresolved.** The Mac's macOS, Python and SQLite versions are unrecorded, the Claude Code version is unrecorded, and no package has been installed or tried (V-01, V-02, D-15, ADR-017).

What the specification itself is ready for: **owner review and approval.** If the owner approves the decision sheet and the environment verification finds no surprise, the status becomes READY WITH CONDITIONS for Phase 1 only, the conditions being the verification items of SECURITY-ARCHITECTURE §11. No percentage is offered; a blocker is a blocker.

## 2. Authoritative status

| Item | Status |
|---|---|
| V6.0 specification | Revised baseline v6.0-IR1, proposed, under owner review |
| 15 audit findings | Individually dispositioned (GAP-REGISTER §3) |
| 500 investigation slots | Coverage framework; specification-level status assigned; implementation unverified for all |
| Implementation repository | Not provided, not verified |
| Implementation authorisation | Not granted |
| Executable application | Does not exist |
| Runtime tests | None executed |
| Executed during specification | DDL in a throwaway SQLite database with 27 constraint probes; FTS5 tokenizer probe; cross-document consistency checker |
| Production readiness | Not established |

## 3. Criteria

A criterion passes only on evidence that exists now.

| # | Criterion | Result | Evidence | What is missing |
|---|---|---|---|---|
| 1 | Business completeness | CONDITIONAL PASS | BRD: 8 measurable objectives, 14 requirements, 10 journeys, 14 enforceable rules | Owner approval; pilot corpus (D-10) |
| 2 | Functional completeness | CONDITIONAL PASS | SRS: 78 functional requirements in structured form, each with exceptions, tests, acceptance | Owner approval; two open findings to fold in (GAP-033, GAP-034) |
| 3 | Architecture consistency | PASS (internal consistency only) | `QUALITY-REPORT.json`: no dangling reference, duplicate or orphan; manual cross-checks in ADVERSARIAL-REVIEW §1 | Review by someone other than the author |
| 4 | Data-model completeness | CONDITIONAL PASS | Authority map; DDL executed with 27 of 27 probes; migration rules | Run on the target SQLite (V-01); D-17 |
| 5 | Interface completeness | CONDITIONAL PASS | CLI: every command with validation, output, tier, errors, tests; Python contracts; note and proposal schemas | Unexercised |
| 6 | Security completeness | CONDITIONAL PASS (design) / NOT VERIFIED (enforcement) | Threat table with enforcement type per control; settings checked against documentation of 2026-11-10 | V-03 to V-07 on the installed Claude Code |
| 7 | Operational completeness | CONDITIONAL PASS | Deployment, backup, restore, upgrade, runbook outlines, doctor catalogue | D-06; nothing executed |
| 8 | Testing completeness | CONDITIONAL PASS | 142 designed cases, 62 adversarial; fixtures and protocols defined | 0 executed (cannot be otherwise before implementation) |
| 9 | Traceability completeness | PASS | Every requirement traces to objective, feature, component, contract, task, test, acceptance; computed, zero gaps | — |
| 10 | Dependency completeness | NOT VERIFIED | Dependencies named and limited | V-01, V-02, V-12; D-15 |

Mandatory blockers checked: critical requirements contradictory — no; canonical data ownership undefined — no; critical interfaces unspecified — no; database integrity rules missing — no; security boundaries undefined — defined, unverified; critical requirements without tests — none; installation dependencies unresolved — **yes**; recovery procedures absent — no; major architecture decisions unapproved — **yes**.

## 4. Assumptions

| ID | Assumption | If false |
|---|---|---|
| A-01 | One owner, one Mac, one user account | Concurrency, identity and ID design must change |
| A-02 | The owner is the only approver | Approval model must change |
| A-03 | All content is public and stays public | Stop ingestion; design confidentiality controls first |
| A-04 | The owner may lawfully ingest and process what they ingest | Add per-source rights tracking |
| A-05 | The Mac can run Python ≥ 3.12 with SQLite ≥ 3.45 and FTS5 | Choose a different Python build; if impossible, revisit ADR-004 |
| A-06 | Claude Code behaves as its documentation of 2026-11-10 says | Adopt fallbacks in CLAUDE-CODE-CONTRACTS §5 and ADR-015 |
| A-07 | Most documents are text-layer PDFs, DOCX, HTML, Markdown or text | OCR becomes a version 1 requirement |
| A-08 | The owner will provide a pilot corpus and label a benchmark | Retrieval gate cannot be evaluated; quality stays unknown |
| A-09 | Lexical retrieval with normalisation is useful enough to start | RET-G2 path |
| A-10 | The owner will review proposals weekly | Queue grows; proposals expire; memory stays unverified |

## 5. Residual risks for explicit acceptance

RT-S01 single operating-system account; RT-A02 approval without reading; RT-A04 fabricated citations detectable only by sampling; RT-D01, RT-D02 application-level rules; parser vulnerabilities within limits; one backup destination; no continuous dependency monitoring; RT-M02 single-author specification.

## 6. Path to "ready with conditions"

1. Owner reviews this package, starting with README §2.
2. Owner completes DECISIONS-FOR-APPROVAL (D-06 to D-18, GAP-033, GAP-034) and answers the open input about any existing codebase.
3. Optional but recommended before D-19: a verification-only step on the Mac — record versions, run `fts5_arabic_probe.py` and `ddl_check.py` (standard library only, nothing installed, nothing written outside a temporary directory).
4. ADR statuses updated; this assessment re-run (TASK-0002).
5. Owner authorises Phase 1 with PHASE-1-AUTHORIZATION-PROMPT.md, or does not.

The next decision is whether this specification is approved or needs correction. It is not whether to add features.
