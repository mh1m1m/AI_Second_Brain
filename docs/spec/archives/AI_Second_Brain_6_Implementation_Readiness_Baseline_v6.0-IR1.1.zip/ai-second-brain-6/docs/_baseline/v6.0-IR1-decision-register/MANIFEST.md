# Snapshot manifest — IR1 decision register and external review inputs

Taken 2026-11-10 before DECISIONS-FOR-APPROVAL.md was rebuilt as package 2.0. Files here are never edited.

| File | Bytes | SHA-256 |
|---|---|---|
| `docs/_baseline/v6.0-IR1-decision-register/ADR-REGISTER.md` | 14123 | `248f9ec0ef6e9d201de21539b46cb95c9ba4e1b5d50b63d53f0e0f5da4a85458` |
| `docs/_baseline/v6.0-IR1-decision-register/DECISIONS-FOR-APPROVAL.md` | 4975 | `db578097d729e132e7f18f5e33e298aa0b595fe877767e626e14cfe3c9815d18` |
| `docs/_baseline/v6.0-IR1-decision-register/GAP-REGISTER.md` | 17126 | `8c6e449ce07c798bee7a8a527e9ba551293b4ef1140cddd860b8d1f384ef9f94` |
| `docs/_baseline/v6.0-IR1-decision-register/IMPLEMENTATION-READINESS.md` | 6362 | `3a6c0e2d703a52a85de8307877171f5aa953cdfcd010f4ebf9ee67d28f3af0ca` |
| `docs/_baseline/v6.0-IR1-decision-register/TRACEABILITY-MATRIX.md` | 30330 | `71e757d6447f7324fae5abd9c9b15481c012108da633754b81829264c0a249f3` |
| `docs/_baseline/external-reviews-2026-11-10/01-review-of-readiness-and-decision-sheet.txt` | 4924 | `b9634bae5ab00036a818b80b11fca2a35402d4e612bd6738c8ead1cacfc00286` |
| `docs/_baseline/external-reviews-2026-11-10/02-review-claude-code-skills.txt` | 7382 | `990d431429781856cc5fdecd875794217bfffba010fa9e682a0fc5d003b46dfd` |
| `docs/_baseline/external-reviews-2026-11-10/03-directive-decision-engineering-v2.0.txt` | 26288 | `a4a18115fa26a1c50ae6868d7a50536114fc8a9ffe13f7ec6d816e30d7e818b8` |
| `docs/_baseline/external-reviews-2026-11-10/04-evidence-limited-proposed-decision-sheet.md` | 17076 | `5f22e25b2b247fd7a42c90b5bbe3dad324102475729f0f14197fd9241c57b819` |
| `docs/_baseline/external-reviews-2026-11-10/05-directive-targeted-corrections-C01-C32.txt` | 25518 | `7936936a219772c37f3933d72378b5ec4452ed4bddf5ea35e8161c0cd2078f08` |

The first folder holds the decision sheet, ADR register, gap register, traceability matrix and readiness assessment exactly as delivered in v6.0-IR1. The second holds the five external inputs received on 2026-11-10, as received. Item 04 was prepared by its author from the superseded V6.0 draft archive (10 ADRs); it is kept as evidence and is not part of the baseline.
