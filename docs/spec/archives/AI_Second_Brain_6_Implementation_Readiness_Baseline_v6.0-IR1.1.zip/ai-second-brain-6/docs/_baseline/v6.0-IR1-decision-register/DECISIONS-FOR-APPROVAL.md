# Decisions for Owner Approval

**DOC-DEC** · v6.0-IR1 · 2026-11-10 · Status: AWAITING OWNER · Owner: Mohammed Alsaleh

One page to approve, amend or reject. Nothing below the "Decided" block is in force. A recommended default is given for each open decision so that silence is never read as approval: **an unanswered decision stays open**.

## Decided (recorded from the owner on 2026-11-10)

| ID | Decision | Value |
|---|---|---|
| D-01 | Operating system | macOS |
| D-02 | Content languages | Arabic first, bilingual with English; right-to-left for Arabic, left-to-right for English |
| D-03 | Data classification | Public information only; no secrecy classification |
| D-04 | Vault | New, dedicated vault; no existing vault. Legacy import supported later as a capability, not at initial deployment |
| D-05 | V5.0 adversarial review | Mandatory cross-validation reference |

Also recorded as authoritative: no implementation repository exists or has been verified; implementation is not authorised; the project is in specification-only mode.

## Open

| ID | Decision | Recommended default | Main alternative | What it affects | Needed before |
|---|---|---|---|---|---|
| D-06 | Backup destination, schedule, retention, objectives, encryption | External disk (or second internal volume) as destination; daily; keep 14 daily and 8 weekly; RPO 24 h, RTO 4 h; encryption off | Add a cloud-synchronised folder as second destination; encryption on (then key handling must be specified) | FR-OPS-002/003/010, NFR-006, ADR-010 | Phase 9 (earlier if GAP-034 is accepted) |
| D-07 | Workspace layout | Operating home `~/SecondBrain`, development repository `~/Developer/ai-second-brain`, tool installed outside both | One folder for everything | ADR-014, all paths | Phase 1 |
| D-08 | Approval tiers | Tier table of AGENTIC-ARCHITECTURE §5; tier 1 may be approved at the Claude Code permission prompt | Terminal-only approval for tier 1 (simplification S-03) | FR-AGT-004, ADR-009 | Phase 5 |
| D-09 | Formats and extraction | Markdown, text, HTML, DOCX, text-layer PDF; PDF library chosen by measured spike; OCR deferred | Fewer formats first (S-06); OCR in version 1 | FR-ING-007/009, ADR-017 | Phase 2 |
| D-10 | Pilot corpus, benchmark, rights | Owner supplies 100–200 representative public documents; validates at least 100 benchmark questions drafted by Claude; attests by ingesting that the material may be used (A-04); confirms content stays public (A-03) | Smaller first corpus with a 50-question benchmark and wider intervals | FR-RET-008, NFR-007, ASB6-ISSUE-0006, 0015 | Phase 4 |
| D-11 | Web access in the operating workspace | Denied (WebFetch, WebSearch off) | A separate research workspace with web access and no write path to the Second Brain | FR-SEC-006, ADR-018 | Phase 7 |
| D-12 | Mobile and multi-device | None | Read-only vault copy later | NFR-017, ADR-016 | — |
| D-13 | Cost and context budget | Search payload about 6,000 tokens; no model calls from Python; Claude plan as the owner already has | Larger payload; usage tracking | NFR-015 | Phase 4 |
| D-14 | Note naming and memory display | Human notes named by title; managed notes by ID; memory shown as digests | One note per memory record | OBSIDIAN-SCHEMAS §7, ADR-012 | Phase 3 |
| D-15 | Python toolchain | Python ≥ 3.12; `uv` with a hash-locked lockfile; PyYAML, python-docx, one PDF library; pytest, coverage, mypy, ruff for development | pip-tools and venv | NFR-010/011/020 | Phase 1 |
| D-16 | Vault history | Local Git repository in the vault, no remote | No Git in the vault (S-08) | DATA-ARCHITECTURE §3 | Phase 3 |
| D-17 | Dates | Stored as Gregorian ISO dates with precision and the original date text kept; no automatic Hijri conversion | Add Hijri conversion (needs a library and rules) | FR-MEM-008, RT-D03 | Phase 5 |
| D-18 | Baseline approval | Approve the requirements baseline (100 requirements) and ADR-001 to ADR-020 as proposed, with any amendments noted here | Approve with the simplifications of ADVERSARIAL-REVIEW §5 (state which) | Everything | Any implementation |
| D-19 | Authorisation of Phase 1 | Separate from D-18. Recommended only after D-07, D-15 and D-18, and limited to Phase 1 | Authorise first a verification-only step: read-only inspection of the Mac (V-01, V-02, V-09) with no installation | Mode in `CLAUDE.md` | Phase 1 |

Two review findings ask for a yes or no as well: **GAP-033** (cap tier 0 proposals per run and open proposals overall: recommended yes) and **GAP-034** (move backup creation and restore-test from Phase 9 to Phase 2: recommended yes).

## Open input

Is there any existing codebase for AI Second Brain? None was supplied. If one exists, provide it as a snapshot; it will be assessed against this baseline as a separate, unverified artifact, not assumed to conform.

## Record of approval

| Decision | Approved / amended / rejected | Note | Date |
|---|---|---|---|
| D-06 … D-19, GAP-033, GAP-034 | | | |
