# Agent/service allocation

| Capability | Implementation | Reason | Approval |
|---|---|---|---|
| Hashing, deduplication, schema validation | deterministic Python | reproducible and testable | no for read; yes for write |
| SQLite transactions and index rebuild | deterministic Python | transactional integrity | maintenance approval |
| Semantic extraction and synthesis | Claude Code skill | requires language understanding | proposed outputs only |
| Contradiction candidates | Claude-assisted, deterministic evidence checks | semantics plus enforcement | promotion requires policy gate |
| Retrieval ranking | FTS5 deterministic baseline | measurable | no |
| Independent security review | optional Claude subagent | context isolation | no production write |
| Document ingestion | Python CLI + optional Claude extraction | safe pipeline | approved source scope |
| Scheduling and retries | OS scheduler + durable worker | survives session exit | bounded policy |
| External messaging or uploads | approved integration tool | high consequence | explicit human approval |

Do not equate an engineering role with a persistent autonomous agent.
