# Claude Code Development Instructions — Draft
## First session
1. Read `CLAUDE.md`, requirements, assumptions, ADR register.
2. Inspect actual OS, Python, Git and Obsidian vault location **read-only**.
3. Verify current Claude Code instructions/skills/hooks/MCP syntax against official documentation in the actual environment.
4. Report discrepancies and propose spec amendments.
5. Request explicit authorization for Phase 1.
## Each authorized implementation phase
Plan linked tasks → create failing tests → implement smallest change → run tests → run security/schema checks → update traceability and ADRs → show diff → request approval for consequential changes → commit approved change.
## Do not
Assume external account access, download personal content without authorization, create unrestricted MCP tools, bypass approval using prompts, install services without consent, or assert success from unrun tests.
## Potential skills (not yet created)
`requirements-engineering`, `document-ingestion`, `memory-reconciliation`, `retrieval-evaluation`, `security-review`, `release-validation`. Skill files should be added only after verifying current Claude Code format.
