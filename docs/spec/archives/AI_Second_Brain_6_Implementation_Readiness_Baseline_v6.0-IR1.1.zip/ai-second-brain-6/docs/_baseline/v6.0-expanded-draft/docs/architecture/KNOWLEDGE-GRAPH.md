# Knowledge Graph — Draft
## Minimal schema
Nodes: Source, Passage, Claim, Concept, Person, Organization, Project, Decision, Task, Risk. Typed edges: SUPPORTS, CONTRADICTS, SUPERSEDES, DEPENDS_ON, RELATES_TO, APPROVED_BY, AFFECTS.
## Edge contract
`id, subject_id, predicate, object_id, source_passage_id, state, valid_from, valid_to, created_at, reviewed_by`.
## Controls
Edge creation starts proposed. Require evidence for factual edges. Generic Obsidian wikilinks are navigational, not automatically validated semantic edges. Support temporal queries and provenance traversal in SQLite.
## Neo4j gate
Only consider after real query benchmarks show graph traversal/maintenance is materially inadequate in SQLite; document migration cost and query workloads first.
