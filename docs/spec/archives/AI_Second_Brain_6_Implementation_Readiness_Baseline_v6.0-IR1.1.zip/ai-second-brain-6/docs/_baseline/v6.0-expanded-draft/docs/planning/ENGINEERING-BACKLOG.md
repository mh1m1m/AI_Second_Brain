# Engineering Backlog — Draft
| Task | Epic / Feature / Story | Priority | Dependencies | Acceptance |
|---|---|---|---|---|
| TASK-001 | Foundation / repo / owner opens vault | P0 | G0,G1 | Config and schemas validate |
| TASK-002 | Ingestion / registry / preserve imported file | P0 | TASK-001 | T-001/002 |
| TASK-003 | Knowledge / notes / inspect sourced claim | P0 | TASK-002 | T-003/017 |
| TASK-004 | Retrieval / FTS5 / find cited passage | P0 | TASK-002 | T-006/014/016 |
| TASK-005 | Memory / transitions / correct history | P0 | TASK-003 | T-004/018 |
| TASK-006 | Projects / decisions / reconstruct as-of | P1 | TASK-005 | historical fixtures |
| TASK-007 | Workflows / approval / safe change | P0 | TASK-003 | T-008/009/010/012 |
| TASK-008 | Operations / backups / restore | P0 | TASK-002 | T-013/019 |
| TASK-009 | Retrieval research / vector comparison | P2 | TASK-004 + gold corpus | pre-registered benchmark |
| TASK-010 | Graph research / typed edges | P2 | TASK-005 | evidence-backed edge tests |
## Critical path
Approval → foundation → source registry → provenance + FTS → memory/approval → backups + acceptance. No tasks have started.
