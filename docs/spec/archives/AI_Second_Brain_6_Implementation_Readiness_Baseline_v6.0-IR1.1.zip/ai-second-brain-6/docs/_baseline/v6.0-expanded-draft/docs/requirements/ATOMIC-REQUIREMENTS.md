# Atomic requirements catalogue — proposed baseline

No user approval is implied. Every requirement is provisional. Each acceptance test is specified in TEST-CASES.md.

| ID | Requirement | Priority | Input | Output | Failure | Test |
|---|---|---|---|---|---|---|
| FR-ING-001 | Register content-addressed source | MUST | source_path | source_id, sha256, media_type | missing, forbidden, duplicate | TEST-ING-001 |
| FR-ING-002 | Preserve original source bytes | MUST | source bytes | immutable copy | disk-full, interrupted write | TEST-ING-002 |
| FR-ING-003 | Record extraction version and locators | MUST | source_id, parser | passage ids, offsets | parse failure, unsupported | TEST-ING-003 |
| FR-KNW-001 | Validate note schema and unique IDs | MUST | markdown note | validated note | invalid yaml, duplicate id | TEST-KNW-001 |
| FR-KNW-002 | Retain competing claims and supersession | MUST | claims | revision graph | contradiction, cycle | TEST-KNW-002 |
| FR-MEM-001 | Enforce memory state machine | MUST | memory transition | new revision | illegal transition | TEST-MEM-001 |
| FR-MEM-002 | Require evidence before verification | MUST | claim, source passage | verified status | unresolved source | TEST-MEM-002 |
| FR-RET-001 | FTS5 search with filters | MUST | query, filters | ranked hits | invalid filter, index absent | TEST-RET-001 |
| FR-RET-002 | Return resolvable evidence locators | MUST | hit | source id, passage, locator | deleted source | TEST-RET-002 |
| FR-PRJ-001 | Reconstruct project history as of date | SHOULD | project id, timestamp | historical state | missing event | TEST-PRJ-001 |
| FR-AGT-001 | Require approval for consequential write | MUST | proposal, actor | authorized operation | expired approval | TEST-AGT-001 |
| FR-AGT-002 | Idempotent resumable workflows | SHOULD | workflow id, key | stable result | crash, retry | TEST-AGT-002 |
| FR-SEC-001 | Enforce protected path restrictions | MUST | actor, path | allow or deny | traversal, symlink | TEST-SEC-001 |
| FR-SEC-002 | Keep credentials outside repository | MUST | configuration | secret reference | secret in log | TEST-SEC-002 |
| FR-OPS-001 | Rebuild FTS from canonical data | MUST | source and passage store | recreated index | corrupt index | TEST-OPS-001 |
| FR-OPS-002 | Restore verified backup in isolation | MUST | backup manifest | verified restored snapshot | missing backup | TEST-OPS-002 |

## Shared contract
- Preconditions: configured writable workspace; valid authorization for requested operation.
- Postconditions: durable audit event for any state change; derived indexes can be rebuilt.
- Invalid input must return a structured error without partial canonical modification.
- All timestamps are UTC ISO 8601; original source time zone is retained when known.
- P0 acceptance requires the mapped automated test and independent security review.

## Provisional NFRs
- NFR-001: lexical search p95 <= 1000 ms on 10k representative passages, warmed local disk; **hypothetical target, not measured**.
- NFR-002: zero modified original source bytes after injected process interruption; must pass test.
- NFR-003: notes and original sources export without proprietary client.
- NFR-004: lexical search works with network disabled.
- NFR-005: all state-changing operations produce actor, correlation ID, UTC timestamp and result.
- NFR-006: recovery target RPO 24 h / RTO 4 h is **provisional**, subject to hardware and backup approval.
