# Memory Architecture — Draft
## Content classes
Semantic, episodic, procedural, decision, project, preference, operational. Classes are labels, not necessarily separate databases.
## State machine
`captured -> proposed -> verified`; `proposed -> disputed`; `verified -> disputed | superseded | archived`; `disputed -> verified | superseded`; `archived -> deleted` subject to retention and legal constraints. Physical erasure is distinct from a tombstone.
## Evidence policy
Source-backed factual memories require locator and source version. User-stated preferences may be owner-attested, not externally sourced. Inferences remain `proposed` with derivation. Disputed claims preserve both sides. Do not turn a model summary into its own independent source.
## Consolidation
Merge only when same subject/predicate/time semantics and non-conflicting provenance; never merge solely on embedding similarity. Record parent claims, revision reason, actor and timestamp.
## Retrieval
Filter by access class, validity date and status before ranking; prefer primary evidence; surface contradictory records and abstain when evidence insufficient.
## Deletion
Apply retention policy, revoke exposure, remove/tombstone canonical records as authorized, rebuild FTS/embeddings, and track backup expiration; do not promise immediate erasure from immutable backups without a designed retention mechanism.
