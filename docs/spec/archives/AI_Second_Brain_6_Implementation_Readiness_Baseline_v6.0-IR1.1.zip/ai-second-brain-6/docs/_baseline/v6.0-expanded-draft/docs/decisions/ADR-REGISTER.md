# Architecture Decision Register — Proposed, Not Approved
| ADR | Decision | Status | Reversal trigger |
|---|---|---|---|
| ADR-001 | Claude Code sole AI orchestrator | Proposed | Unmet required workflows |
| ADR-002 | Markdown for human-readable notes | Proposed | Loss of required structure/portability |
| ADR-003 | Obsidian optional UI | Proposed | User workflow demands alternate UI |
| ADR-004 | SQLite transactional registry | Proposed | Multiwriter/scale limitations measured |
| ADR-005 | FTS5 baseline retrieval | Proposed | Recall fails benchmark |
| ADR-006 | Defer vector DB | Proposed | Hybrid benchmark gains justify cost |
| ADR-007 | Defer graph DB | Proposed | Typed edge queries exceed SQLite capabilities |
| ADR-008 | One orchestrator, deterministic services | Proposed | Agent decomposition benchmark |
| ADR-009 | Approval-gated knowledge promotion | Proposed | User-approved risk policy change |
| ADR-010 | Independent encrypted backup | Proposed | Alternative meets restore objectives |

For every ADR, record context, options, tradeoffs, evidence, consequence and approval in separate file at design sign-off. This register does not imply decisions have been ratified.
