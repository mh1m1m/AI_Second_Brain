# Data Architecture — Draft
## Authority map
| Data | Canonical | Derived |
|---|---|---|
| Source bytes | Content-addressed originals | Extracted text, thumbnails |
| Narrative notes | Markdown in vault | Search passages |
| Identity, approvals, state, typed edges | SQLite registry | Markdown views, graph visualizations |
| Search | None | FTS5 (rebuildable) |
| Workflow audit | Append-only structured SQLite records plus backup | Dashboards |
## Core entities
`sources(id, sha256, mime, created_at, classification)`; `source_versions(id, source_id, locator, parser_version, extraction_status)`; `passages(id, version_id, locator, text_hash)`; `notes(id, path, revision_hash, status)`; `claims(id, subject, predicate, value_json, state, valid_from, valid_to, recorded_at)`; `claim_evidence(claim_id, passage_id, relation)`; `relationships(id, subject_id, predicate, object_id, evidence_id, state, valid_from, valid_to)`; `proposals(id, patch_hash, status, actor, approved_by)`; `workflow_runs(id, idempotency_key, state, attempt)`; `audit_events(id, correlation_id, action, actor, timestamp, result)`.
## Integrity invariants
Unique stable IDs; foreign keys enabled; factual `verified` claim requires ≥1 resolvable evidence link; supersession never silently deletes historical record; index deletion/tombstones propagate on rebuild; record both valid-time and transaction-time where applicable.
## Example note
```yaml
---
id: NOTE-000001
kind: concept
title: Example concept
status: proposed
created_at: 2026-11-10T00:00:00Z
updated_at: 2026-11-10T00:00:00Z
source_refs: [SRC-000001]
---
```
## Privacy
Sensitive source binaries and local DB are excluded from Git by default; require user-approved classification and retention policies.
