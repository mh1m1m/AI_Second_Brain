# Architecture decision proposals (not approved)

| ADR | Decision | Alternatives | Rationale | Reversal trigger | Status |
|---|---|---|---|---|---|
| ADR-001 | Claude Code sole AI platform | other AI orchestrators | user constraint | explicit user change | PROPOSED |
| ADR-002 | Markdown human-authored knowledge | database-only notes | portability | structured editing dominates | PROPOSED |
| ADR-003 | Obsidian optional UI | custom app | lower complexity | unmet UX needs | PROPOSED |
| ADR-004 | SQLite operational state | PostgreSQL | local-first simplicity | multiuser concurrent writes | PROPOSED |
| ADR-005 | FTS5 lexical baseline | hybrid/vector | measurable baseline | relevance benchmark fails | PROPOSED |
| ADR-006 | Defer Qdrant | embedded vectors | avoid early infrastructure | measured recall benefit | PROPOSED |
| ADR-007 | Defer Neo4j | SQLite relationships | minimal graph need | graph query scale evidence | PROPOSED |
| ADR-008 | Single orchestrator + deterministic workers | multi-agent swarm | predictable control | justified parallel specialization | PROPOSED |
| ADR-009 | Approval-bound memory changes | auto-promotion | contamination prevention | verified safe policy | PROPOSED |
| ADR-010 | Independent encrypted backup | Git only | Git not sufficient backup | validated alternative | PROPOSED |

For each ADR, acceptance requires confirmation of user constraints, technical documentation, risk ownership and reversal conditions. Current evidence is design reasoning, not deployment benchmark.
