# Engineering handoff — proposed baseline, 2026-11-10

**Status: NOT READY FOR IMPLEMENTATION.** This package is a detailed design handoff, not authorization to code.

## Architecture
Claude Code interprets and proposes; deterministic Python CLI owns writes and validates policy; Obsidian displays portable Markdown; SQLite owns operational metadata and workflow state; FTS5 is a derived index; original bytes remain immutable. See HLD, DATABASE-SCHEMA, TRANSACTION-PROTOCOL and WORKFLOW-CONTRACTS.

## Technology
Proposed: Python >=3.11 (unverified environment), SQLite with FTS5, Markdown/YAML, Git for code and nonsensitive docs, Obsidian optional UI, Claude Code sole AI execution platform. Qdrant and Neo4j deferred. Version constraints are not pinned until target OS and official compatibility are verified.

## Contracts
`ATOMIC-REQUIREMENTS.md`, `CLI-SPECIFICATION.md`, `DATABASE-SCHEMA.md`, `OBSIDIAN-SCHEMAS.md`, `WORKFLOW-CONTRACTS.md`, `CLAUDE-CODE-CONTRACTS.md`.

## Build sequence
See `IMPLEMENTATION-ROADMAP-DETAILED.md` and `FILE-BUILD-PLAN.md`. First approved task after gate: isolated foundation and OS-enforced permissions; then source registry and crash journal.

## Validation
Tests in `TEST-CASES.md` are designs only. Retrieval benchmark is a labeling plan, not fabricated data. No automated implementation tests have run.

## Open decisions
See `IMPLEMENTATION-READINESS.md` and original `docs/planning/ASSUMPTIONS.md`. Explicit approval required for implementation and consequential integrations.

## Risks
Cloud AI context transfer, prompt injection through documents, file/DB inconsistency, untested backup restore, Arabic search quality and user-edited Markdown conflicts.
