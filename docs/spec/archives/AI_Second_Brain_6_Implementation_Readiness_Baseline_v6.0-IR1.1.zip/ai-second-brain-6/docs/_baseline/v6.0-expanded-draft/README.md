# AI Second Brain 6.0 — Specification Baseline (Draft)
**Status:** DRAFT / approval required. **Date:** 2026-11-10. **Mode:** specification only; no application implementation.

## Objective
A local-first, Claude Code–operated personal knowledge system with Obsidian as an optional Markdown interface, preserved original evidence, explainable retrieval, temporal memory, and permission-controlled workflows. No ChatGPT/OpenAI dependency.

## Architectural baseline
- Original source bytes: immutable evidence artifacts, content-addressed; never silently rewritten.
- Human-authored Markdown: canonical editable knowledge notes.
- SQLite: canonical transactional registry for source IDs, memory states, relationships, workflow/audit metadata; FTS5 is derived and rebuildable.
- Claude Code: interactive planner and semantic analyst; **not** the sole durable scheduler or security boundary.
- Obsidian: optional UI, not required for indexing or queries.
- Graph DB, vector DB, extra agents: deferred pending benchmarks.

## Approval gates
G0: Confirm environment, data sensitivity, initial corpus, synchronization and retention policy. G1: Approve BRD/PRD/SRS/ADRs. G2: Approve architecture and security. G3: Authorize implementation of Phase 1 only.

## Documentation index
See `docs/requirements`, `docs/architecture`, `docs/security`, `docs/operations`, `docs/testing`, `docs/planning`, `docs/decisions`. This is a *proposed* baseline; it has not been validated against a real user repository or benchmark corpus.
