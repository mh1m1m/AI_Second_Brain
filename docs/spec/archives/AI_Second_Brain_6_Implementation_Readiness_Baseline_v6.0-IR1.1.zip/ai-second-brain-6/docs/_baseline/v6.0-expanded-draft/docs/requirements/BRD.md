# Business Requirements Document (BRD) — Draft v0.1
## Business problem
Personal knowledge becomes fragmented across documents, notes, projects, decisions and time. Conventional search lacks provenance and temporal context; ad-hoc AI summaries risk creating false memory.
## Vision and outcomes
A trustworthy, portable, local-first knowledge operating system for a single primary owner, accessed through Claude Code and optionally Obsidian. Outcomes: faster evidence discovery, accurate project reconstruction, traceable decisions, controlled maintenance.
## Stakeholders
Owner/product approver; knowledge steward (may be same person); local system administrator; Claude Code operator (non-human); external data providers (future, separately authorized).
## Business requirements
| ID | Requirement | Priority | Success measure |
|---|---|---|---|
| BRD-001 | Preserve source artifacts and trace claims to source location | Must | 100% of promoted factual claims linked to source IDs |
| BRD-002 | Search and answer with inspectable evidence | Must | Benchmark recall/citation metrics established |
| BRD-003 | Maintain corrected and superseded knowledge without erasing history | Must | 100% of defined correction tests pass |
| BRD-004 | Organize project state and decision history | Should | Project reconstruction acceptance test |
| BRD-005 | Propose updates and request approval for consequential changes | Must | Zero unauthorized writes in controlled tests |
| BRD-006 | Operate without Obsidian running | Must | Headless retrieval test |
| BRD-007 | Recover from interruption and verified backups | Must | Restoration drill passes |
| BRD-008 | Integrate external apps through separately approved scopes | Could | Connector-specific acceptance tests |
| BRD-009 | Visualize links and dashboards in Obsidian | Should | User acceptance test |
## Core processes
Ingest → preserve → extract → register provenance → propose knowledge → reconcile → approve → commit → index → retrieve → audit. Correction and deletion follow separate controlled workflows.
## Rules
BR-01 Untrusted content cannot issue tool instructions. BR-02 Source versions are immutable. BR-03 Disputes preserve competing claims. BR-04 No unapproved destructive or external action. BR-05 Derived indexes can be rebuilt. BR-06 Confidential domains remain segregated by policy.
## Scope
In: local files, Markdown, source registry, SQLite FTS5, evidence citations, controlled changes. Out initially: cloud hosting, live mail/calendar, unrestricted autonomy, Neo4j/Qdrant, public API, universal multimodal parsing.
## Open decisions
See `docs/planning/ASSUMPTIONS.md`; all targets provisional until a corpus and user workflows are supplied.
