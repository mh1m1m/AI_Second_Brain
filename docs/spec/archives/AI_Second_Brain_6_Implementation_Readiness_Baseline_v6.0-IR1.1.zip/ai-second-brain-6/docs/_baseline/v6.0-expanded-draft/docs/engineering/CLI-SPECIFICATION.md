# CLI interface contract (proposed, not implemented)

Entry point `second-brain`; default output human-readable, `--json` for machine-readable. All commands support `--help`; mutating commands support `--dry-run` when meaningful. Exit codes: 0 success, 2 invalid input, 3 not found, 4 conflict, 5 permission denied, 6 unavailable dependency, 7 integrity error, 8 approval required, 9 internal error.

| Command | Required arguments | Output | Side effects | Authorization |
|---|---|---|---|---|
| `init` | `--workspace PATH` | paths/config manifest | creates isolated workspace | explicit approval |
| `doctor` | none | diagnostics | read-only | read |
| `ingest` | `PATH` | source ID, status | stages/registers | approved write |
| `search` | `QUERY` `--limit N` `--json` | hits + locators | none | read |
| `sources list` | optional filters | source metadata | none | read |
| `memory propose` | `--file PATH` | proposal ID/hash | proposal only | proposal |
| `memory approve` | `PROPOSAL_ID` | approval record | approved action | authorized human |
| `projects show` | `PROJECT_ID` `--as-of ISO` | state | none | read |
| `decisions list` | `--project ID` | decision records | none | read |
| `index rebuild` | `--dry-run` | count, integrity report | derived index | approved maintenance |
| `backup create` | `--destination PATH` | manifest and checksum | snapshot | approved maintenance |
| `backup restore-test` | `BACKUP_ID` | verification report | isolated test directory | approved maintenance |
| `validate` | `--scope PATH` | violations | none | read |

Validate all path arguments against allowed roots and symlink resolution. Never echo secrets. JSON responses include `schema_version`, `correlation_id`, `status`, `data`, `errors` with stable error codes.
