# Assumptions and Decisions Requiring Approval
| ID | Question | Working assumption | Risk |
|---|---|---|---|
| Q-01 | Operating system and hardware? | Unknown | Install/run compatibility |
| Q-02 | Existing Obsidian vault or new? | New isolated vault | Migration cost |
| Q-03 | Initial corpus formats, count, languages? | Unknown; pilot 100 mixed files | Parser/retrieval fit |
| Q-04 | Sensitive/professional documents allowed? | No until explicitly scoped | Privacy/confidentiality |
| Q-05 | Offline-only or approved network use? | Offline-first | Research/connectors limited |
| Q-06 | Cloud sync and mobile access? | Deferred | Conflict/security model |
| Q-07 | Backup destination and retention? | Unspecified | Recovery gap |
| Q-08 | Acceptable model usage budget? | Unspecified | Operating costs |
| Q-09 | Approval for automatic knowledge writes? | Human approval required | Workflow friction |
| Q-10 | Project ownership and source licensing? | User-owned or authorized only | Compliance |
| Q-11 | Primary language and multilingual search? | English/Arabic expected, not confirmed | FTS tokenizer relevance |
| Q-12 | Should system ingest previous chats? | Only user-exported, authorized data | Access limitations |
