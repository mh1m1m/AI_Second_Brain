# Low-Level Design — Draft
## Modules / contracts
- `ingestion.registry`: `register(path, provenance) -> SourceRef`; computes hash, validates size/type, copies to immutable storage.
- `ingestion.extract`: `extract(source_ref, parser_version) -> ExtractionManifest`; offsets, parser warnings, page anchors.
- `knowledge.schemas`: validate Markdown frontmatter (`id`, `kind`, `title`, `created_at`, `updated_at`, `status`, `source_refs`).
- `knowledge.proposals`: `propose_change(patch, evidence, actor) -> Proposal`; does not write canonical state.
- `knowledge.commit`: `apply_approved(proposal_id, approval_token) -> CommitReceipt`; lock, stage, validate, write, journal, reconcile.
- `retrieval.search`: `search(query, filters, limit) -> EvidenceHit[]`; includes passage ID, source locator, snippet, temporal status.
- `memory.transitions`: validate finite-state transitions and evidence requirements.
- `relationships`: typed edge upsert with source proof, validity window and dispute state.
- `operations.doctor`: integrity checks across DB, source hashes, Markdown IDs and FTS freshness.
## Error taxonomy
`UnsupportedFormat`, `ExtractionIncomplete`, `InvalidSchema`, `DuplicateID`, `MissingEvidence`, `UnapprovedWrite`, `ConcurrentModification`, `IndexStale`, `RestoreFailure`.
## Concurrency
Single writer for canonical updates; SQLite foreign keys on, WAL subject to filesystem support; filesystem lock with timeout; no assumptions of atomicity across DB and filesystem—journal plus recovery reconciliation required.
## Coding conventions
Python typed interfaces, structured logs without source contents, explicit migration version, dependency pinning, pytest fixtures, no silent exception swallowing.
