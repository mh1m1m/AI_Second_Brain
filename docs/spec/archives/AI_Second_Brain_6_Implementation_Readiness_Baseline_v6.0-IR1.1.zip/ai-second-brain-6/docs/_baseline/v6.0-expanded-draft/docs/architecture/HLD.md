# High-Level Design — Draft
```mermaid
flowchart LR
 U[Owner] --> CC[Claude Code: planning/semantic reasoning]
 U --> OB[Obsidian: optional UI]
 OB <--> MD[Markdown Vault]
 SRC[Immutable source bytes] --> ING[Deterministic ingest/extract]
 ING --> REG[(SQLite canonical registry)]
 ING --> PROP[Proposed knowledge changes]
 CC --> PROP
 PROP --> GATE[Validation + human approval]
 GATE --> MD
 GATE --> REG
 MD --> IDX[(FTS5 derived index)]
 REG --> IDX
 IDX --> RET[Evidence retrieval service]
 RET --> CC
 REG --> AUD[Audit log]
 MD --> BAK[Independent backup]
 SRC --> BAK
 REG --> BAK
```
## Trust boundaries
Untrusted source zone → parsing sandbox → proposed claims → validation/approval gate → canonical stores. Claude's textual instructions are not permission enforcement. Credentials and backups live outside the vault and Git.
## Deployment
Single-user modular Python application, local SQLite, filesystem Markdown and source artifacts. Scheduler invokes bounded jobs; interactive Claude Code initiates or reviews semantic tasks. Obsidian optional. No network listener by default.
## Failure model
Crash during write: staged file + SQLite transaction + recovery journal/reconciliation. Crash during index update: mark stale and rebuild. Corrupt DB: restore verified backup. Sync conflict: quarantine competing versions; never last-write-wins for verified knowledge.
## Data authority
Original source bytes authoritative for source evidence; Markdown authoritative for owner-edited narrative notes; SQLite authoritative for IDs, workflow state, memory state transitions and typed edges; FTS index derived. Cross-store consistency enforced through write coordinator and reconciliation.
