# Durable workflow contracts

## Ingestion
`PENDING → VALIDATING → STAGING → REGISTERING → EXTRACTING → INDEXING → COMPLETED`.
Any active state may transition to `FAILED_RETRYABLE`, `FAILED_TERMINAL` or `WAITING_APPROVAL` where appropriate. Resume uses durable checkpoint and idempotency key. Invalid file or unsafe path → terminal failure without canonical mutation.

## Memory verification
`CAPTURED → PROPOSED → VERIFIED | DISPUTED → SUPERSEDED | ARCHIVED`; `DELETED` is a controlled tombstone transition. `VERIFIED` requires evidence and approval policy. Never mutate an old revision.

## Knowledge update
`PROPOSED → VALIDATED → WAITING_APPROVAL → STAGED → COMMITTED → INDEXED → COMPLETED`; hash conflict → `CONFLICT_REVIEW`. Approval binds proposal hash, scope, actor, expiration; a changed proposal invalidates approval.

## Project update
`DRAFT → VALIDATED → WAITING_APPROVAL → APPLIED → COMPLETED`, with `REJECTED` and `CONFLICT_REVIEW`. As-of reconstruction uses versioned events, not current Markdown alone.

## Agentic task
`REQUESTED → PLANNED → POLICY_CHECKED → RUNNING → WAITING_APPROVAL → RESUMING → COMPLETED`; retryable failures persist checkpoint. External communications always require explicit approval.

## Backup
`REQUESTED → SNAPSHOTTING → HASHING → STORED → RESTORE_TESTING → VERIFIED`; failed restore must never mark backup verified.

Every transition emits correlation ID, actor, timestamp, old/new state and outcome. Invalid transitions fail closed. Cancellation must leave recoverable journal state.
