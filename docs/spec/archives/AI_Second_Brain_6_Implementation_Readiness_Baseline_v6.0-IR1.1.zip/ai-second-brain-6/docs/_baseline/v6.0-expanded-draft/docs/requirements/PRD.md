# Product Requirements Document — Draft v0.1
## Personas and journeys
Primary owner: drops file into inbox → receives extraction and provenance report → reviews suggested notes → approves → searches source-backed answers. Reviewer: opens a decision → sees supporting and superseded evidence. Administrator: checks index/backup health and restores a test snapshot.
## Feature priorities
| ID | Feature | MoSCoW | Acceptance |
|---|---|---|---|
| PRD-001 | Inbox source import and duplicate warning | Must | Identical content is not registered as a new version accidentally |
| PRD-002 | Evidence-backed search with file/section locator | Must | Every displayed citation resolves |
| PRD-003 | Proposed knowledge change review with diff | Must | Rejection leaves canonical data unchanged |
| PRD-004 | Search by project, date, source, status | Must | Filter tests pass |
| PRD-005 | Project and decision note templates | Should | Notes validate against schema |
| PRD-006 | Obsidian navigation and backlinks | Should | Notes open with working links |
| PRD-007 | Offline lexical search | Must | Runs without internet and without Obsidian |
| PRD-008 | Mobile access | Could | Security and sync strategy approved first |
| PRD-009 | Semantic/vector search | Could | Improvement over baseline measured |
| PRD-010 | Autonomous cross-app actions | Won't initially | Requires separate approval |
## UX
Show evidence status (verified/disputed/insufficient), source date versus validity date, and clear user approval for writes. Do not display model confidence as calibrated probability. Prefer simple CLI and Obsidian notes over custom frontend initially.
