# Baseline inventory — 2026-11-10

Source: supplied V6.0 ZIP, inspected locally. All original files retained byte-for-byte. Baseline documentation is preliminary; length alone is not a completeness test.

| Document ID | File | Bytes | SHA256 prefix | Status | Finding |
|---|---|---:|---|---|---|
| BASE-001 | `README.md` | 1515 | `384ece041c94` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-002 | `CLAUDE.md` | 1195 | `918bca1fdaa4` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-003 | `docs/testing/TEST-STRATEGY.md` | 1347 | `cbbb92cea7ad` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-004 | `docs/decisions/ADR-REGISTER.md` | 1197 | `11895670a8dc` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-005 | `docs/operations/OPERATIONS.md` | 1149 | `76eb37547a17` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-006 | `docs/architecture/HLD.md` | 1693 | `5f8a1780e5b0` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-007 | `docs/architecture/MEMORY-ARCHITECTURE.md` | 1389 | `0cc188f48883` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-008 | `docs/architecture/KNOWLEDGE-GRAPH.md` | 766 | `07e78605a105` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-009 | `docs/architecture/LLD.md` | 1710 | `43ee122ac7c7` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-010 | `docs/architecture/DATA-ARCHITECTURE.md` | 1742 | `1b9b069607b8` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-011 | `docs/architecture/CLAUDE-CODE-DEVELOPMENT.md` | 1170 | `0371f48fea78` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-012 | `docs/architecture/AGENTIC-ARCHITECTURE.md` | 1063 | `bc67503f933e` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-013 | `docs/architecture/RETRIEVAL-ARCHITECTURE.md` | 1171 | `e2eb2b7213f7` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-014 | `docs/requirements/PRD.md` | 1649 | `694b5751e04c` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-015 | `docs/requirements/SRS.md` | 2698 | `9974d4e0e95c` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-016 | `docs/requirements/TRACEABILITY-MATRIX.md` | 859 | `adbb30a93913` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-017 | `docs/requirements/BRD.md` | 2710 | `3d1d71e195ea` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-018 | `docs/security/SECURITY-ARCHITECTURE.md` | 1279 | `f7977f034956` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-019 | `docs/planning/ASSUMPTIONS.md` | 1231 | `42312789c4e7` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-020 | `docs/planning/PRODUCTION-READINESS.md` | 666 | `877c7c87444e` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-021 | `docs/planning/ENGINEERING-BACKLOG.md` | 1157 | `082fb7100d39` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
| BASE-022 | `docs/planning/IMPLEMENTATION-ROADMAP.md` | 853 | `87530cc68e03` | PARTIALLY COMPLETE | Conceptual baseline; requires executable contracts and stakeholder approval |
