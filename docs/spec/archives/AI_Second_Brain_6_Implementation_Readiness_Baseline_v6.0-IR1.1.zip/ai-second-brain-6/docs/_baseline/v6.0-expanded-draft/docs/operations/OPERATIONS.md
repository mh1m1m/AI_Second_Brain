# Operations and Reliability — Draft
## Baseline
Single-user local process; no persistent public endpoint. Scheduler must provide bounded execution, retries with backoff, idempotency and health reporting.
## Backups
Separate encrypted copies of source bytes, Markdown, SQLite consistent snapshot, manifests, schema and configuration (excluding plaintext secrets). Git is supplementary history, not backup. Provisional RPO 24h, RTO 4h pending approval. Monthly isolated restoration drill; verify file hashes and database integrity.
## Observability
Structured events: correlation ID, workflow ID, component, status, duration, bytes, error category; redact content and secrets. Track stale indexes, unapproved proposals, failed ingestion, backup age, restore-test age.
## Recovery
On startup reconcile staged writes, source manifests, SQLite revisions and FTS freshness. On index failure rebuild from canonical data. On sync conflict quarantine variants for owner review.
## Environment
Pin Python dependencies; test OS/platform assumptions; document Obsidian vault path and backup destination; never assume iPhone can run local Claude Code services.
