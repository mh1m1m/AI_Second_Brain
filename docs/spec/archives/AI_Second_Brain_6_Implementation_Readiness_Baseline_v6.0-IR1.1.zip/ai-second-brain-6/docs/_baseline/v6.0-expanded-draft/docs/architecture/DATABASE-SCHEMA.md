# SQLite database contract — proposed v1

**Authority:** SQLite owns operational metadata, revision pointers, workflow state and typed relationships; original source bytes are authoritative in immutable artifact storage; Markdown owns human-authored note content. FTS is derived. SQLite foreign keys MUST be enabled per connection. WAL and busy timeout require explicit initialization.

## DDL (design only; not executed)
```sql
PRAGMA foreign_keys=ON;
CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
CREATE TABLE sources(
 id TEXT PRIMARY KEY, sha256 TEXT NOT NULL UNIQUE CHECK(length(sha256)=64),
 media_type TEXT NOT NULL, byte_size INTEGER NOT NULL CHECK(byte_size>=0),
 original_path TEXT NOT NULL, created_at TEXT NOT NULL, deleted_at TEXT);
CREATE TABLE source_versions(
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES sources(id),
 version_no INTEGER NOT NULL CHECK(version_no>=1), sha256 TEXT NOT NULL,
 captured_at TEXT NOT NULL, UNIQUE(source_id,version_no));
CREATE TABLE extracted_passages(
 id TEXT PRIMARY KEY, source_version_id TEXT NOT NULL REFERENCES source_versions(id),
 parser_version TEXT NOT NULL, ordinal INTEGER NOT NULL CHECK(ordinal>=0),
 locator TEXT NOT NULL, body TEXT NOT NULL, content_sha256 TEXT NOT NULL,
 UNIQUE(source_version_id,parser_version,ordinal));
CREATE TABLE knowledge_records(
 id TEXT PRIMARY KEY, note_path TEXT NOT NULL UNIQUE, note_sha256 TEXT NOT NULL,
 record_type TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN
 ('proposed','verified','disputed','superseded','archived')),
 revision INTEGER NOT NULL DEFAULT 1 CHECK(revision>=1), updated_at TEXT NOT NULL);
CREATE TABLE evidence_links(
 knowledge_id TEXT NOT NULL REFERENCES knowledge_records(id),
 passage_id TEXT NOT NULL REFERENCES extracted_passages(id),
 evidence_role TEXT NOT NULL CHECK(evidence_role IN ('supports','contradicts','context')),
 PRIMARY KEY(knowledge_id,passage_id,evidence_role));
CREATE TABLE entities(id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, canonical_name TEXT NOT NULL);
CREATE TABLE relationships(
 id TEXT PRIMARY KEY, subject_id TEXT NOT NULL REFERENCES entities(id),
 predicate TEXT NOT NULL, object_id TEXT NOT NULL REFERENCES entities(id),
 evidence_passage_id TEXT REFERENCES extracted_passages(id),
 valid_from TEXT, valid_to TEXT, status TEXT NOT NULL DEFAULT 'proposed',
 CHECK(valid_to IS NULL OR valid_from IS NULL OR valid_to>=valid_from));
CREATE TABLE memory_records(
 id TEXT PRIMARY KEY, kind TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN
 ('captured','proposed','verified','disputed','superseded','archived','deleted')),
 current_revision INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE memory_revisions(
 memory_id TEXT NOT NULL REFERENCES memory_records(id), revision INTEGER NOT NULL,
 content TEXT NOT NULL, evidence_passage_id TEXT REFERENCES extracted_passages(id),
 supersedes_revision INTEGER, created_at TEXT NOT NULL, actor TEXT NOT NULL,
 PRIMARY KEY(memory_id,revision));
CREATE TABLE projects(id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE decisions(
 id TEXT PRIMARY KEY, project_id TEXT REFERENCES projects(id), title TEXT NOT NULL,
 rationale TEXT NOT NULL, decided_at TEXT, status TEXT NOT NULL);
CREATE TABLE tasks(
 id TEXT PRIMARY KEY, project_id TEXT REFERENCES projects(id), title TEXT NOT NULL,
 status TEXT NOT NULL, due_at TEXT, updated_at TEXT NOT NULL);
CREATE TABLE workflow_runs(
 id TEXT PRIMARY KEY, idempotency_key TEXT NOT NULL UNIQUE, workflow_type TEXT NOT NULL,
 state TEXT NOT NULL, checkpoint_json TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE approvals(
 id TEXT PRIMARY KEY, workflow_id TEXT NOT NULL REFERENCES workflow_runs(id),
 proposal_hash TEXT NOT NULL, approver TEXT NOT NULL, scope TEXT NOT NULL,
 expires_at TEXT NOT NULL, approved_at TEXT NOT NULL, consumed_at TEXT);
CREATE TABLE audit_events(
 id TEXT PRIMARY KEY, occurred_at TEXT NOT NULL, actor TEXT NOT NULL,
 correlation_id TEXT NOT NULL, action TEXT NOT NULL, object_id TEXT,
 outcome TEXT NOT NULL, detail_json TEXT NOT NULL DEFAULT '{}');
CREATE INDEX idx_passages_source ON extracted_passages(source_version_id);
CREATE INDEX idx_audit_corr ON audit_events(correlation_id,occurred_at);
CREATE INDEX idx_relationship_subject ON relationships(subject_id,predicate);
CREATE INDEX idx_tasks_project ON tasks(project_id,status);
CREATE VIRTUAL TABLE passage_fts USING fts5(body, content='extracted_passages', content_rowid='rowid', tokenize='unicode61');
```

## Index consistency
External-content FTS requires insert/update/delete triggers or a controlled full rebuild; choose a single indexing owner. Rebuild with `INSERT INTO passage_fts(passage_fts) VALUES('rebuild')` after verifying source table consistency. `rowid` stability must be preserved during incremental updates. Filter deleted source versions at query time. No FTS output is canonical.

## Migration rules
Numbered, checksummed forward migrations; pre-migration backup; foreign-key integrity check; rollback by restoring verified snapshot if a migration is not reversible. Migration execution requires explicit approval. Test migrations on copies only during specification phase.

## Representative query
```sql
SELECT p.id,p.locator,s.id AS source_id,s.sha256,bm25(passage_fts) AS rank
FROM passage_fts JOIN extracted_passages p ON p.rowid=passage_fts.rowid
JOIN source_versions sv ON sv.id=p.source_version_id
JOIN sources s ON s.id=sv.source_id
WHERE passage_fts MATCH :query AND s.deleted_at IS NULL
ORDER BY rank LIMIT :limit;
```

**Open design issues:** retention semantics for sensitive evidence, multi-writer support, FTS Arabic recall, schema extensibility and audit tamper evidence.
