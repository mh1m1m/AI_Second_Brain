# Test case contracts — designed, NOT executed

All fixtures must be synthetic or user-authorized. No test result is claimed.

| Test ID | Requirement | Preconditions | Procedure | Expected result | Automation |
|---|---|---|---|---|---|
| TEST-ING-001 | FR-ING-001 | Isolated fixture workspace | Exercise register content-addressed source; inject missing condition | Correct source_id, sha256, media_type; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-ING-002 | FR-ING-002 | Isolated fixture workspace | Exercise preserve original source bytes; inject disk-full condition | Correct immutable copy; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-ING-003 | FR-ING-003 | Isolated fixture workspace | Exercise record extraction version and locators; inject parse failure condition | Correct passage ids, offsets; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-KNW-001 | FR-KNW-001 | Isolated fixture workspace | Exercise validate note schema and unique ids; inject invalid yaml condition | Correct validated note; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-KNW-002 | FR-KNW-002 | Isolated fixture workspace | Exercise retain competing claims and supersession; inject contradiction condition | Correct revision graph; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-MEM-001 | FR-MEM-001 | Isolated fixture workspace | Exercise enforce memory state machine; inject illegal transition condition | Correct new revision; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-MEM-002 | FR-MEM-002 | Isolated fixture workspace | Exercise require evidence before verification; inject unresolved source condition | Correct verified status; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-RET-001 | FR-RET-001 | Isolated fixture workspace | Exercise fts5 search with filters; inject invalid filter condition | Correct ranked hits; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-RET-002 | FR-RET-002 | Isolated fixture workspace | Exercise return resolvable evidence locators; inject deleted source condition | Correct source id, passage, locator; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-PRJ-001 | FR-PRJ-001 | Isolated fixture workspace | Exercise reconstruct project history as of date; inject missing event condition | Correct historical state; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-AGT-001 | FR-AGT-001 | Isolated fixture workspace | Exercise require approval for consequential write; inject expired approval condition | Correct authorized operation; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-AGT-002 | FR-AGT-002 | Isolated fixture workspace | Exercise idempotent resumable workflows; inject crash condition | Correct stable result; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-SEC-001 | FR-SEC-001 | Isolated fixture workspace | Exercise enforce protected path restrictions; inject traversal condition | Correct allow or deny; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-SEC-002 | FR-SEC-002 | Isolated fixture workspace | Exercise keep credentials outside repository; inject secret in log condition | Correct secret reference; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-OPS-001 | FR-OPS-001 | Isolated fixture workspace | Exercise rebuild fts from canonical data; inject corrupt index condition | Correct recreated index; no unauthorized partial mutation; audit emitted when applicable | Yes |
| TEST-OPS-002 | FR-OPS-002 | Isolated fixture workspace | Exercise restore verified backup in isolation; inject missing backup condition | Correct verified restored snapshot; no unauthorized partial mutation; audit emitted when applicable | Yes |

## Additional adversarial scenarios
| Test ID | Trigger | Pass criterion |
|---|---|---|
| TEST-SEC-003 | Inject tool instructions inside PDF text | extracted text treated as untrusted data |
| TEST-SEC-004 | MCP server requests broader scope | permission denied pending approval |
| TEST-SEC-005 | unapproved Obsidian plugin | not loaded by managed setup |
| TEST-SEC-006 | classified source sent to model | blocked unless policy authorizes transfer |
| TEST-REC-001 | kill process between file rename and DB commit | journal reconciliation completes without duplicate |
| TEST-REC-002 | kill process after DB commit before FTS | reindex restores search |
| TEST-REC-003 | two writers change same Markdown note | conflict review; no lost update |
| TEST-RET-003 | deleted source still in FTS | result filtered; rebuild removes stale hit |
| TEST-MEM-003 | contradictory dated evidence | history preserved; current view uses validity |
| TEST-OPS-003 | corrupted backup | restore test fails closed |

## Execution requirements
Use isolated temporary directories and throwaway SQLite files. For each run record test version, fixture hash, OS, Python version, actual output, pass/fail, and evidence log. This package contains **test specifications only**, not executable tests.
