# Implementation Roadmap — Draft
| Phase | Deliverable | Exit gate |
|---|---|---|
| 0 | Requirements, assumptions, ADRs | Owner approval |
| 1 | Repository and Obsidian-compatible vault | Schema checks |
| 2 | Immutable source registry and extraction manifest | T-001/002 |
| 3 | Provenance-backed Markdown/claims | T-003/017 |
| 4 | SQLite FTS5 baseline | T-006/014/016 + gold set |
| 5 | Memory lifecycle and temporal history | T-004/018 |
| 6 | Projects and decisions | As-of reconstruction |
| 7 | Approval-gated Claude workflows | T-008/009/010/012 |
| 8 | Vector/graph experiments | Measured improvement or defer |
| 9 | Security/recovery readiness | T-011/013/015/019 |
| 10 | Future evolution | New ADR and tests |

Security and backup requirements apply throughout, not only Phase 9. Phase 1 implementation cannot start until G0–G3 approvals.
