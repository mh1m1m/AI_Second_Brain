# Security threat/control matrix

| Threat | Surface | Enforced control | Test | Residual risk |
|---|---|---|---|---|
| Prompt injection | PDF/web/Markdown | treat content as data; no direct tool execution; approval gate | TEST-SEC-003 | semantic manipulation |
| Path traversal/symlink | CLI file arguments | resolve realpath; allowlist root; OS sandbox | TEST-SEC-001 | TOCTOU; mitigate with fd-based APIs |
| Credential leakage | logs/vault | external secret store; redaction; repository scanner | TEST-SEC-002 | backups/log copies |
| MCP compromise | external server | allowlist, least privilege, network boundary | TEST-SEC-004 | supply chain |
| Plugin compromise | Obsidian plugins | default deny; review plugin provenance | TEST-SEC-005 | user-installed plugin |
| Sensitive source exfiltration | cloud model/network | classification gate; user consent; network egress policy | TEST-SEC-006 | provider retention unknown |
| Unauthorized write | Claude shell access | OS-level permissions + scoped CLI writer | TEST-AGT-001 | privileged user bypass |
| Backup disclosure | removable/cloud media | encryption at rest and key separation | TEST-OPS-002 | key loss |

Prompts and Claude hooks are not security boundaries. Local-first does not mean model inference is offline: Claude Code may transmit context to its provider. Sensitive content must not be submitted until policy and provider handling are approved.
