# Independent adversarial specification review (desk review)

Findings are reasoned design risks, not measured production defects. Critical unresolved items are retained rather than falsely marked resolved.

## 20 objections
1. User environment unknown. 2. Source corpus unknown. 3. Sensitive data policy unknown. 4. Claude provider data transfer not approved. 5. OS sandbox not specified. 6. Plugin execution boundary unclear. 7. SQLite single-writer contention unmeasured. 8. Filesystem+DB updates not atomic. 9. Direct Obsidian edits can race. 10. FTS Arabic recall untested. 11. Source locators may break after parser upgrades. 12. Audit table can be modified by DB owner. 13. Git is not a secure backup. 14. Backup key management missing. 15. Deletion propagation may conflict with retention. 16. Agent session cannot guarantee durable background operation. 17. Approval may become stale after proposal changes. 18. Workflow retry may duplicate external effects. 19. Source licensing/authorization not validated. 20. Cost and latency budgets unknown.

## 15 assumptions
A1 single user; A2 local filesystem; A3 writable vault; A4 Markdown edits are occasional; A5 trusted OS account; A6 sufficient disk; A7 compatible Python; A8 FTS5 available; A9 source ownership; A10 Claude connectivity; A11 Arabic/English corpus; A12 no simultaneous mobile writes; A13 backups possible; A14 one primary device; A15 explicit user review feasible.

## 15 integration risks
I1 Obsidian file locks; I2 Windows rename semantics; I3 SQLite WAL backup; I4 parser upgrades; I5 invalid YAML; I6 symlink escape; I7 MCP overpermission; I8 cloud sync races; I9 clock skew; I10 tokenizer mismatch; I11 citation offset drift; I12 interrupted migration; I13 stale FTS rows; I14 approval replay; I15 missing encryption keys.

## 10 simplifications
S1 no Neo4j initially; S2 no Qdrant initially; S3 no microservices; S4 no web dashboard; S5 no always-on LLM agent; S6 one CLI; S7 one SQLite DB; S8 Markdown templates not complex ontology; S9 Git only for nonsensitive code/docs; S10 deterministic workers before subagents.

## 10 missing acceptance scenarios
T1 restore after full disk; T2 lost encryption key; T3 changed approval payload; T4 duplicate imports with renamed paths; T5 Arabic diacritics mismatch; T6 malformed source locator; T7 two-device conflict; T8 superseded source citation; T9 malicious symlink during import; T10 network outage mid-Claude reasoning.

## Disposition
Design mitigations added to SQL schema, transaction protocol, security matrix, workflow contracts, and tests. Residual critical blockers: environment, permissions, data policy, backup key management, unverified dependencies. No consensus or implementation approval is implied.
