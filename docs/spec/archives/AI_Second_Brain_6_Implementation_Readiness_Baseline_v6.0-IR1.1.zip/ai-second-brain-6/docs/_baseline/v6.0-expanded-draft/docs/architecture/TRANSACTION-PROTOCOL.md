# File + SQLite commit and recovery contract

SQLite cannot atomically commit changes to the filesystem. Use an **application journal** and idempotent reconciler, not an unsupported distributed transaction claim.

1. Validate path, authorization, free space and source policy.
2. Compute SHA-256 and assign operation UUID and idempotency key.
3. Stage bytes in a restricted temporary directory on the destination filesystem; fsync file.
4. Create `workflow_runs` journal entry with `STAGED` state in SQLite transaction.
5. Atomically rename staged bytes to content-addressed final path; fsync parent directory where supported.
6. Commit source metadata and journal `CANONICAL_COMMITTED` in one SQLite transaction; use unique checksum and idempotency constraints.
7. Generate versioned extraction; stage and validate note content separately.
8. Apply note update using compare-and-swap expected hash and atomic replace. Reject conflicting edits.
9. Update derived FTS; record `INDEXED`, then `COMPLETED`.
10. On startup reconcile incomplete journal entries: verify hashes; either finish idempotently or quarantine orphaned bytes. Never delete canonical originals automatically.

Crash matrix:
| Crash point | Durable state | Recovery |
|---|---|---|
| Before stage fsync | no canonical change | discard temporary file after inspection |
| After stage, before journal | orphan stage | quarantine by age/hash |
| After journal, before rename | STAGED | verify stage and retry rename |
| After rename, before DB commit | file exists without row | journal recovery inserts/links metadata |
| After DB commit, before FTS | canonical committed | reindex |
| During note update | expected hash mismatch | conflict review, never blind overwrite |

Invariants: originals immutable; operation retries do not duplicate records; only verified canonical records enter indexes; audit events exclude source contents and credentials.
