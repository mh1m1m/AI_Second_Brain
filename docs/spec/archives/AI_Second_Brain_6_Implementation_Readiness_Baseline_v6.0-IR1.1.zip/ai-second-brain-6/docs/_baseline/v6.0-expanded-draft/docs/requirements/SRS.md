# Software Requirements Specification — Draft v0.1
Each item is provisional pending stakeholder sign-off. Verification methods: T=test, I=inspection, D=demonstration.
| ID | Requirement | Priority | Verification / acceptance |
|---|---|---|---|
| FR-ING-001 | Register file with SHA-256, size, media type, source ID | P0 | T: deterministic registration and dedupe |
| FR-ING-002 | Preserve original bytes; never mutate artifact in place | P0 | T: checksum unchanged after processing |
| FR-ING-003 | Store extraction version, parser and page/section offsets | P0 | T: locator resolves for fixture |
| FR-KNW-001 | Validate Markdown frontmatter and unique note IDs | P0 | T: invalid/duplicate IDs rejected |
| FR-KNW-002 | Preserve competing claims and supersession edges | P0 | T: history query returns both versions |
| FR-MEM-001 | Support proposed/verified/disputed/superseded/archived states | P0 | T: invalid state transitions rejected |
| FR-MEM-002 | Require source evidence for verified factual claim | P0 | T: unsourced promotion rejected |
| FR-RET-001 | Support FTS5 search with project/time/status filters | P0 | T: gold fixture retrieval |
| FR-RET-002 | Return source ID, locator, and excerpt for citations | P0 | T: all locators resolve |
| FR-PRJ-001 | Record project states, decisions, dependencies and effective dates | P1 | T: as-of reconstruction |
| FR-AGT-001 | Require approved proposal before consequential canonical write | P0 | T: unapproved write rejected |
| FR-AGT-002 | Record idempotency key and resumable workflow status | P1 | T: retry has no duplicate effects |
| FR-SEC-001 | Prevent tool access outside allowlisted paths | P0 | T: forbidden-path attempt blocked by OS/tool boundary |
| FR-SEC-002 | Keep secrets outside vault, logs and version control | P0 | I/T: secret scan and config review |
| FR-OPS-001 | Rebuild derived index from canonical artifacts | P0 | T: rebuilt results match fixtures |
| FR-OPS-002 | Restore tested snapshot and verify hashes | P0 | D: isolated restore succeeds |
| NFR-001 | Search p95 latency target set after baseline measurements | P1 | T: report p50/p95 with corpus size |
| NFR-002 | No source corruption under interrupted ingestion | P0 | T: fault injection |
| NFR-003 | Portable Markdown export and source manifest | P0 | D: inspect without proprietary client |
| NFR-004 | Offline lexical retrieval | P0 | D: network disabled |
| NFR-005 | Structured audit trail for state-changing operations | P0 | T: correlation IDs and actor captured |
## Interfaces
CLI commands proposed: `ingest`, `search`, `propose`, `approve`, `reindex`, `doctor`, `backup`, `restore-test`. Names are design proposals, not implemented commands.
