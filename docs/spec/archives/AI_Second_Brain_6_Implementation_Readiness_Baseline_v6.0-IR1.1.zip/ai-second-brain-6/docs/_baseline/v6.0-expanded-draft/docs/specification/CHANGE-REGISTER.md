# Change register

No baseline files were overwritten. New detailed specification files extend the V6.0 baseline; all decisions remain proposed.

| Change | Original | Proposal | Reason | Approval |
|---|---|---|---|---|
| CHG-001 | V6 SRS | Add atomic contract catalogue | Testability | PENDING |
| CHG-002 | V6 Data Architecture | Add SQL DDL and staged file/DB protocol | Integrity | PENDING |
| CHG-003 | V6 Operations | Add deployment and recovery contracts | Recoverability | PENDING |
| CHG-004 | V6 Retrieval | Add benchmark blueprint | Evidence | PENDING |
