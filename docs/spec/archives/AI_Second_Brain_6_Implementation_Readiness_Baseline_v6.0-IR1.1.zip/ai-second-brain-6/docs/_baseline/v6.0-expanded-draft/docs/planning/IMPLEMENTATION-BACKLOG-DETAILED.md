# Implementation backlog — proposed, no implementation authorized

| Epic | Feature | Task | Dependencies | Phase | Complexity | Acceptance |
|---|---|---|---|---|---|---|
| EPIC-ING | FR-ING-001 | TASK-001: Register content-addressed source | Approved environment | 2 | M | TEST-ING-001 passes |
| EPIC-ING | FR-ING-002 | TASK-002: Preserve original source bytes | Approved environment | 2 | M | TEST-ING-002 passes |
| EPIC-ING | FR-ING-003 | TASK-003: Record extraction version and locators | Workspace + security baseline | 2 | M | TEST-ING-003 passes |
| EPIC-KNW | FR-KNW-001 | TASK-004: Validate note schema and unique IDs | Workspace + security baseline | 3 | M | TEST-KNW-001 passes |
| EPIC-KNW | FR-KNW-002 | TASK-005: Retain competing claims and supersession | Workspace + security baseline | 3 | M | TEST-KNW-002 passes |
| EPIC-MEM | FR-MEM-001 | TASK-006: Enforce memory state machine | Workspace + security baseline | 5 | M | TEST-MEM-001 passes |
| EPIC-MEM | FR-MEM-002 | TASK-007: Require evidence before verification | Workspace + security baseline | 5 | M | TEST-MEM-002 passes |
| EPIC-RET | FR-RET-001 | TASK-008: FTS5 search with filters | Workspace + security baseline | 4 | M | TEST-RET-001 passes |
| EPIC-RET | FR-RET-002 | TASK-009: Return resolvable evidence locators | Workspace + security baseline | 4 | M | TEST-RET-002 passes |
| EPIC-PRJ | FR-PRJ-001 | TASK-010: Reconstruct project history as of date | Workspace + security baseline | 3 | S | TEST-PRJ-001 passes |
| EPIC-AGT | FR-AGT-001 | TASK-011: Require approval for consequential write | Workspace + security baseline | 7 | M | TEST-AGT-001 passes |
| EPIC-AGT | FR-AGT-002 | TASK-012: Idempotent resumable workflows | Workspace + security baseline | 7 | S | TEST-AGT-002 passes |
| EPIC-SEC | FR-SEC-001 | TASK-013: Enforce protected path restrictions | Workspace + security baseline | 9 | M | TEST-SEC-001 passes |
| EPIC-SEC | FR-SEC-002 | TASK-014: Keep credentials outside repository | Workspace + security baseline | 9 | M | TEST-SEC-002 passes |
| EPIC-OPS | FR-OPS-001 | TASK-015: Rebuild FTS from canonical data | Workspace + security baseline | 9 | M | TEST-OPS-001 passes |
| EPIC-OPS | FR-OPS-002 | TASK-016: Restore verified backup in isolation | Workspace + security baseline | 9 | M | TEST-OPS-002 passes |
