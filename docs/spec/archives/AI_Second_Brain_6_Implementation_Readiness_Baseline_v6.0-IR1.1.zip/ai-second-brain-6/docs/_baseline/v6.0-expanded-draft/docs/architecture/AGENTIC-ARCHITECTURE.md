# Agentic Architecture — Draft
## Allocation
Claude Code: semantic extraction proposals, research synthesis, task planning, adversarial review. Deterministic Python: hashing, schemas, transactional writes, indexes, backup validation. Scheduler: recurring bounded jobs. Human: approve external communications, sensitive writes, new integrations, security changes, destructive operations.
## Workflow states
`queued -> running -> awaiting_approval -> committed | rejected | failed | cancelled`; idempotency key and checkpoint per step. A process crash cannot be treated as successful completion.
## Subagents
Optional for independent security review or context isolation; do not instantiate until comparative test shows value. Claude Code session persistence and scheduling capabilities must be verified against current official docs in the target environment.
## MCP policy
Allowlist server origin, tool scopes and data domains; credentials external; log tool invocation metadata; never grant blanket filesystem/network access merely because a prompt requests it.
