# Gap register

All findings are engineering analysis, not measured incidents.

| GAP ID | Domain | Finding | Severity | Affected requirement | Resolution | Owner | Verification |
|---|---|---|---|---|---|---|---|
| GAP-001 | Data | File/DB atomicity and crash recovery unspecified | CRITICAL | FR-ING-002 | Journaled staged write and recovery protocol | Data architect | Design review + future acceptance test |
| GAP-002 | Security | No enforced sandbox configuration selected | CRITICAL | FR-SEC-001 | OS permission boundary and test plan | Security architect | Design review + future acceptance test |
| GAP-003 | Requirements | User environment, corpus and data classification unknown | CRITICAL | NFR-004 | Decision register and pilot assumptions | Product owner | Design review + future acceptance test |
| GAP-004 | Retrieval | No representative labeled relevance set | HIGH | FR-RET-001 | Gold set protocol and 100-question blueprint | Retrieval engineer | Design review + future acceptance test |
| GAP-005 | Operations | Backup destination, RPO/RTO not approved | HIGH | FR-OPS-002 | Provisional recovery design | SRE | Design review + future acceptance test |
| GAP-006 | Data | No concrete DDL or migration contract | HIGH | FR-KNW-001 | SQL schema and migration plan | DB architect | Design review + future acceptance test |
| GAP-007 | Agentic | No durable approval token semantics | HIGH | FR-AGT-001 | Approval record and policy gate | Agent architect | Design review + future acceptance test |
| GAP-008 | Obsidian | Direct edits may bypass SQLite registry | HIGH | FR-KNW-001 | Reconciliation ownership protocol | Knowledge engineer | Design review + future acceptance test |
| GAP-009 | Privacy | Backup erasure/retention conflict unresolved | HIGH | FR-SEC-002 | Deletion and retention policy | Data steward | Design review + future acceptance test |
| GAP-010 | Integrations | Claude Code feature versions unverified | MEDIUM | FR-AGT-001 | Official documentation validation required | Claude engineer | Design review + future acceptance test |
| GAP-011 | Languages | Arabic tokenization behavior unbenchmarked | MEDIUM | FR-RET-001 | Arabic exact/phrase benchmark | Retrieval engineer | Design review + future acceptance test |
| GAP-012 | Licensing | Document import authorization unconfirmed | HIGH | FR-ING-001 | Source policy and approvals | Product owner | Design review + future acceptance test |
