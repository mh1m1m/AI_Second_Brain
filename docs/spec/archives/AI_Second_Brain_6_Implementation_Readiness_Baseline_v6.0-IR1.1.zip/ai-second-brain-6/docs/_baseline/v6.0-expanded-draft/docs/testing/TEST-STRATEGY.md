# Test Strategy — Draft
## Levels
Unit (hashes, validators, state transitions), integration (source→DB→Markdown→FTS), security (malicious input, unauthorized writes), recovery (crash, DB restore, index rebuild), retrieval (gold Q/A and citations), acceptance (owner journeys).
## Mandatory scenarios
T-001 identical source dedupe; T-002 original bytes unchanged; T-003 missing evidence rejects verified state; T-004 temporal supersession preserves past answer; T-005 invalid edge rejected; T-006 FTS rebuild reproduces hits; T-007 stale index detected; T-008 approval rejection changes nothing; T-009 concurrent writes conflict safely; T-010 interrupted commit reconciles; T-011 prompt-injection document cannot trigger tools; T-012 forbidden path denied; T-013 backup restore hash match; T-014 offline retrieval; T-015 sensitive document excluded from unauthorized query; T-016 no-answer abstention; T-017 citation locator resolution; T-018 deleted record removed from rebuilt index; T-019 migration rollback or restore; T-020 workflow retry idempotent.
## Evaluation gates
Targets provisional: source hash integrity 100%; unauthorized writes 0 in test suite; citation correctness ≥95% on labeled corpus; Recall@10 ≥90% only after corpus established. Report actual measured values, confidence intervals where practical, and benchmark provenance.
