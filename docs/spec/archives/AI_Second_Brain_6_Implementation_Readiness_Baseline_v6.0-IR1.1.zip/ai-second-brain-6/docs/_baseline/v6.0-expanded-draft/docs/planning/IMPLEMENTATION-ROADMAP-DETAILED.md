# Implementation phases and gates

| Phase | Deliverable | Dependency | Exit evidence |
|---|---|---|---|
| 0 Specification | approved requirements and ADRs | user decisions | no critical blockers |
| 1 Foundation | isolated repo/config/CI | OS approval | configuration and sandbox tests |
| 2 Source registry | immutable artifacts, journal | phase 1 | hash, dedupe, crash tests |
| 3 Knowledge | Markdown schemas and reconciliation | phase 2 | schema and conflict tests |
| 4 Retrieval | SQLite, FTS5, citation API | phase 3 | holdout retrieval and citation tests |
| 5 Memory | versioned memory lifecycle | phase 4 | false-memory and temporal tests |
| 6 Project intelligence | project/decision history | phase 5 | as-of reconstruction tests |
| 7 Controlled workflows | proposal/approval/replay | phase 6 | policy and recovery tests |
| 8 Advanced retrieval | optional embedding A/B study | phase 4 | measured improvement or rejection |
| 9 Hardening | backup, restore, audit, monitoring | phases 1-7 | independent readiness review |
| 10 Evolution | optional graph/vector extensions | measured need | separate ADR and approval |

No phase is complete merely because files exist. The critical path is environment approval → enforced permissions → immutable source journal → canonical schema → retrieval grounding → controlled memory writes → restore verification.
