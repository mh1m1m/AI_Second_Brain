# Claude Code integration contract — verification required

Claude Code is the only AI reasoning and orchestration platform. This specification does not claim an installed version or current feature compatibility. Before implementation verify exact syntax and behavior in the official documentation: `https://code.claude.com/docs/` and `https://docs.anthropic.com/`.

Root `CLAUDE.md`: concise mission, scope, protected paths, test commands and references to detailed docs. `.claude/skills/<skill>/SKILL.md`: use only if current official syntax is confirmed. `.claude/agents/*.md`: create only for justified independent verification or context isolation. Hooks and MCP settings: treat as optional and version-dependent; never security boundary by themselves.

Contract: Claude proposes semantic changes; Python policy gate checks actor, path, proposal hash, approval, allowed operation, data classification and audit. Deterministic CLI owns all canonical writes. Tools must not be granted broad filesystem or network access by default. Background scheduling is an external OS/service responsibility, not an assumed always-running Claude session.

Verification checklist: exact CLI release, settings keys, skill discovery behavior, hooks event names, subagent permissions, MCP trust model, interactive vs unattended restrictions, model/token budget, OS sandbox behavior. Mark each UNVERIFIED until documentation inspected in deployment environment.
