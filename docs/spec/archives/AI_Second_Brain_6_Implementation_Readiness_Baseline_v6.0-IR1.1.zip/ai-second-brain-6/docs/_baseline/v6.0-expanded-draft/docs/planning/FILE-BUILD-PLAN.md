# Proposed file-by-file implementation plan — no code created

| Phase | Proposed path | Purpose | Requirements | Tests |
|---|---|---|---|---|
| 1 | `pyproject.toml` | package and pinned tooling | NFR-003 | foundation validation |
| 1 | `src/second_brain/config.py` | validated path/config contract | FR-SEC-001 | TEST-SEC-001 |
| 2 | `src/second_brain/ingestion/registry.py` | immutable source registration | FR-ING-001/002 | TEST-ING-001/002 |
| 2 | `src/second_brain/ingestion/extract.py` | versioned passages | FR-ING-003 | TEST-ING-003 |
| 2 | `src/second_brain/storage/journal.py` | crash-safe staged updates | FR-ING-002 | TEST-REC-001/002 |
| 3 | `src/second_brain/knowledge/validate.py` | Markdown schema checks | FR-KNW-001 | TEST-KNW-001 |
| 3 | `src/second_brain/knowledge/revisions.py` | history and conflicts | FR-KNW-002 | TEST-KNW-002 |
| 4 | `src/second_brain/db/schema.sql` | SQLite schema | FR-ING-001 | DB migration tests |
| 4 | `src/second_brain/retrieval/fts.py` | lexical retrieval | FR-RET-001/002 | TEST-RET-001/002 |
| 5 | `src/second_brain/memory/lifecycle.py` | state machine | FR-MEM-001/002 | TEST-MEM-001/002 |
| 6 | `src/second_brain/projects/history.py` | as-of reconstruction | FR-PRJ-001 | TEST-PRJ-001 |
| 7 | `src/second_brain/workflows/approval.py` | authorization and replay | FR-AGT-001/002 | TEST-AGT-001/002 |
| 7 | `src/second_brain/cli.py` | stable CLI | cross-cutting | CLI integration |
| 9 | `src/second_brain/operations/backup.py` | verified snapshot/restore | FR-OPS-002 | TEST-OPS-002 |
| 9 | `src/second_brain/security/policy.py` | path/data policy | FR-SEC-001/002 | TEST-SEC-001/002 |
| all | `tests/` | fixtures and tests corresponding to IDs | all | all |

All paths are proposals; no placeholders created in `src/`.
