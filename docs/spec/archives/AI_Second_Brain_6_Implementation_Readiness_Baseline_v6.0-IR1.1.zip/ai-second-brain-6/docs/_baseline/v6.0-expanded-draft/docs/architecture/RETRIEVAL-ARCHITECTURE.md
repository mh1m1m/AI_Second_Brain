# Retrieval Architecture — Draft
## Baseline
Structure-aware passages (heading/page anchors) → SQLite FTS5 index → query + metadata filters → ranked evidence hits → Claude synthesis with citations. Use normalized IDs and locators; no fabricated page numbers.
## Retrieval contract
`EvidenceHit {source_id, source_version, passage_id, locator, excerpt, score, source_date, valid_time, status, classification}`.
## Evaluation
Build ≥100 representative labeled questions once real authorized corpus exists: exact IDs, paraphrases, temporal questions, contradictions, cross-doc joins, no-answer cases. Measure Recall@5/10, nDCG@10, citation precision, unsupported answer rate, p95 latency and token cost. Use stratified split and record annotator disagreement.
## Upgrade experiment
Compare FTS5 against embeddings and hybrid fusion with identical corpus, query set, access filters and latency budget. Promote vector search only if prespecified gains outweigh operational cost. Reranking and graph retrieval remain experiments.
## Failure behavior
Distinguish no-hit, low coverage, conflicting evidence, stale evidence and access-denied. Do not synthesize unsupported facts.
