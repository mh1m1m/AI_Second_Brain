# Deployment specification — conditional

**OS and hardware unknown.** Support macOS/Linux as candidate environments; Windows requires validated PowerShell/WSL and file-locking behavior. Select supported Python release after compatibility checks (provisional Python >=3.11); use isolated virtual environment, locked dependencies, reproducible package hashes. No dependencies were installed for this specification.

Proposed setup sequence (NOT EXECUTED): create isolated workspace; verify filesystem permissions; create secrets outside vault; initialize SQLite with foreign keys/WAL; validate vault; run read-only `doctor`; run unit/integration fixtures; create first encrypted backup; restore in isolated directory; authorize controlled ingestion pilot.

Environment config: `SECOND_BRAIN_HOME`, `SECOND_BRAIN_VAULT`, `SECOND_BRAIN_DB`, `SECOND_BRAIN_LOG_LEVEL`, `SECOND_BRAIN_BACKUP_DIR`; these are **proposed app keys**, not Claude Code settings. Validate paths and permissions on startup; refuse overlapping source/backup directories.

Operations: OS scheduler invokes deterministic maintenance worker; every job idempotent with durable run ID; JSON structured logs with no source content; integrity and backup checks; alerts via local status report by default. RPO 24h and RTO 4h are provisional. Backups: consistent SQLite snapshot + source manifest + Markdown + extraction metadata, encrypted at rest, hash verified, periodic restore drills. No backup is VERIFIED until isolated restoration succeeds.

Upgrade: snapshot → verify → migrate staging copy → integrity test → approved cutover. Rollback via restored snapshot, not unproven reverse migration. Disaster recovery assumes keys and storage accessible; loss of keys is unrecoverable unless escrow policy approved.
