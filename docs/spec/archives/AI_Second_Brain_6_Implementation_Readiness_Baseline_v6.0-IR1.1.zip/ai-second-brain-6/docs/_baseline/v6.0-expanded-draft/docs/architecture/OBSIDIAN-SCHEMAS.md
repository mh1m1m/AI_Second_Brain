# Obsidian/Markdown schema v1

Obsidian is an interface, not a required daemon. Files remain readable in a standard editor. IDs never depend on filenames. Validate YAML frontmatter against a versioned schema; reject duplicate IDs and invalid dates. External content in notes is untrusted data, never an instruction.

| Type | Required keys | Additional rules |
|---|---|---|
| source | id, type, title, source_ids, created_at, status, tags | source_ids must resolve |
| concept | id, type, title, source_ids, created_at, status, tags | verified requires evidence |
| entity | id, type, title, source_ids, created_at, status, tags | stable entity ID |
| memory | id, type, title, source_ids, created_at, status, tags | lifecycle transitions controlled |
| project | id, type, title, created_at, status, tags | project_id in SQLite |
| decision | id, type, title, source_ids, created_at, status, tags | decision_id and alternatives |
| research | id, type, title, source_ids, created_at, status, tags | distinguish hypotheses |
| workflow | id, type, title, created_at, status, tags | no credentials or raw audit secrets |

```yaml
---
id: KNW-000001
schema_version: 1
type: concept
title: Example Concept
status: proposed
created_at: 2026-11-10T00:00:00Z
updated_at: 2026-11-10T00:00:00Z
source_ids: [SRC-000001]
tags: [knowledge/concept]
---
```

Allowed `status` depends on note type; `verified` requires a resolvable supporting passage. Use wikilinks for navigation only; typed semantic edges are stored separately. Obsidian direct edits are reconciled by hash and schema validation; conflicting edits create a review proposal. Do not enable arbitrary community plugins by default.
