# Security Architecture — Draft
## Assets
Original documents, personal metadata, project decisions, credentials, machine filesystem, connector scopes, audit records.
## Threats and controls
- Prompt injection in PDFs/Markdown/web pages → mark content untrusted, strict tool allowlists, approval gates, no source-to-instruction promotion.
- Malicious plugin/MCP → review publisher and permissions, pin versions, isolated credentials, disable by default.
- Cross-project leakage → classification and access-filtered retrieval, separate vaults or OS identities for high-sensitivity domains.
- Unauthorized write → OS filesystem permission, controlled write service, protected directories, diff and approval token.
- Exfiltration → deny external network by default for sensitive processing; explicit connector scope approval.
- Secret leakage → OS secret store, never log credentials, scan commits.
## Trust boundaries
Source intake untrusted; parser sandbox limited; proposals untrusted; canonical writes trusted only after policy check; backups encrypted and access-controlled.
## Security verification
Adversarial fixtures for malicious source instructions, path traversal, unsafe MIME, unauthorized MCP scope and secrets in logs. No claim that prompting alone enforces security.
