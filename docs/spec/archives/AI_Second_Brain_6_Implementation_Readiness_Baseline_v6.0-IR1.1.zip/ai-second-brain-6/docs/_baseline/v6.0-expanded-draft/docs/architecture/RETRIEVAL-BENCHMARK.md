# Retrieval benchmark specification — no results claimed

Construct 100 **human-validated** questions from licensed/authorized representative fixtures: 20 exact identifiers, 20 Arabic/English lexical variants, 15 tables/footnotes, 15 cross-document, 10 temporal, 10 contradictions, 10 unanswerable. Gold labels must identify passage IDs and source locations; split development vs holdout, prevent duplicates/leakage. This is a blueprint, not 100 fabricated labeled questions.

Metrics: Recall@5 = relevant retrieved / relevant gold capped at 5; Precision@5 = relevant retrieved / 5; MRR = mean reciprocal rank of first relevant hit; nDCG@10 = mean normalized discounted gain; citation validity = resolvable locators / citations; abstention precision on unanswerable questions. Report per-language and per-document-format results, p50/p95 latency, corpus size, hardware, tokenizer, query set version, confidence intervals.

Provisional gate: FTS5 Recall@10 >= 0.85 and citation validity = 1.0 on holdout. Dense/hybrid retrieval is adopted only if paired evaluation demonstrates >= 5 percentage point absolute recall improvement without unacceptable citation or latency regression. Thresholds are proposed, not evidence of actual performance. Arabic tokenization may require normalization or alternate tokenizer after testing.
