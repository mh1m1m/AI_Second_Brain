# 14 ARCHITECTURE SIMPLIFICATION

Retain single Claude Code orchestrator and deterministic Python/SQLite/Markdown baseline; defer extra vector, graph and agent services pending benchmarks.
