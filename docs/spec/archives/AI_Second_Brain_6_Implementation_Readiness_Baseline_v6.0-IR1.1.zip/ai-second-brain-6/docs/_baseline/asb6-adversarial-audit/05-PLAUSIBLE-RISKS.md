# Plausible risks

The 500 investigation candidates are **not** confirmed issues. Consult `machine-readable/investigation-matrix.json` for unresolved evidence requests.
