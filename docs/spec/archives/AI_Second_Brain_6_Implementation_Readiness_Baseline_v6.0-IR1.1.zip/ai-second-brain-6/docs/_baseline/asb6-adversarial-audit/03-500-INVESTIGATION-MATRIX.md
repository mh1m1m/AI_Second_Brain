# 500 investigation slots

**All 500 are UNVERIFIED with respect to runtime behavior.** Domains and slot numbers preserve the 25 × 20 structure in the user mandate.

- 001–020: Business objectives and product value — UNVERIFIED
- 021–040: Requirements engineering — UNVERIFIED
- 041–060: Architecture and component boundaries — UNVERIFIED
- 061–080: Canonical data authority — UNVERIFIED
- 081–100: Filesystem and transaction integrity — UNVERIFIED
- 101–120: SQLite database engineering — UNVERIFIED
- 121–140: Obsidian integration — UNVERIFIED
- 141–160: Source ingestion — UNVERIFIED
- 161–180: Knowledge representation — UNVERIFIED
- 181–200: Memory lifecycle — UNVERIFIED
- 201–220: Temporal knowledge — UNVERIFIED
- 221–240: SQLite FTS5 and retrieval — UNVERIFIED
- 241–260: Agentic RAG — UNVERIFIED
- 261–280: Claude Code orchestration — UNVERIFIED
- 281–300: Agentic workflow execution — UNVERIFIED
- 301–320: Security and trust boundaries — UNVERIFIED
- 321–340: Privacy and data governance — UNVERIFIED
- 341–360: Knowledge graph and entity resolution — UNVERIFIED
- 361–380: Project and decision intelligence — UNVERIFIED
- 381–400: Testing and evaluation — UNVERIFIED
- 401–420: Reliability and recovery — UNVERIFIED
- 421–440: Performance and scalability — UNVERIFIED
- 441–460: Deployment and environment — UNVERIFIED
- 461–480: Observability and operations — UNVERIFIED
- 481–500: Methodology governance and system evolution — UNVERIFIED
