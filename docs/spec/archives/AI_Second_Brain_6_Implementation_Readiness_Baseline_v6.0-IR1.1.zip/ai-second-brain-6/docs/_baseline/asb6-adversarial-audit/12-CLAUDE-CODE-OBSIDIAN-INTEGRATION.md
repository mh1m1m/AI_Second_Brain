# 12 CLAUDE CODE OBSIDIAN INTEGRATION

No installed Claude Code or Obsidian vault provided. Root CLAUDE.md is specification-only. Verify filesystem/CLI bridge and authorization.
