# Unverified assumptions

- Active repository corresponds to this specification ZIP.
- A Claude Code installation exists and has compatible permissions.
- Obsidian vault exists and is writable.
- FTS5 is compiled into target SQLite build.
- Any application tests have run.
- Backup restoration works.
- Approved corpus and privacy boundaries exist.
