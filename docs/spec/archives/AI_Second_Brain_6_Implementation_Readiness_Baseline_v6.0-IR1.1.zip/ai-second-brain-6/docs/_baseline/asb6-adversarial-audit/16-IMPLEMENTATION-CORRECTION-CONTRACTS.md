# Implementation correction contracts

These are proposed changes, not authorization to modify code.

## ASB6-ISSUE-0001 — Existing codebase unavailable for audit
Evidence: `README.md`
Required action: Request read-only repo access or immutable commit snapshot; capture branch, hash, diff and test logs.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0002 — Specification explicitly prohibits implementation
Evidence: `CLAUDE.md`
Required action: Record explicit implementation authorization and amend root instructions through approved change control.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0003 — Readiness gate fails for security
Evidence: `docs/governance/IMPLEMENTATION-READINESS.md`
Required action: Approve data classifications, permission boundary and enforcement tests before protected data use.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0004 — Deployment environment unresolved
Evidence: `docs/governance/IMPLEMENTATION-READINESS.md`
Required action: Capture actual OS/hardware, versions, backup design, RPO/RTO and validate installation.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0005 — No executable tests in supplied specification
Evidence: `docs/testing/TEST-CASES.md`
Required action: Implement isolated tests in code repository; execute and retain evidence before verification claims.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0006 — Representative retrieval benchmark not available
Evidence: `docs/architecture/RETRIEVAL-ARCHITECTURE.md`
Required action: Create approved corpus, gold labels and baseline evaluation; publish measured recall, citations and latency.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0007 — Claude Code compatibility remains unverified
Evidence: `docs/engineering/CLAUDE-CODE-CONTRACTS.md`
Required action: Verify actual installed release and official supported settings, then test least privilege.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0008 — Cross-resource atomicity is not guaranteed
Evidence: `docs/architecture/TRANSACTION-PROTOCOL.md`
Required action: Implement staged journal and crash-point tests; verify orphan recovery and note conflict preservation.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0009 — Critical user approvals remain open
Evidence: `docs/governance/IMPLEMENTATION-READINESS.md`
Required action: Record user decisions in ADRs and re-run readiness gates.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0010 — Only priority requirements have traceability
Evidence: `docs/governance/IMPLEMENTATION-READINESS.md`
Required action: Complete requirement-to-design-to-test-to-code mappings for approved scope.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0011 — No validated Arabic retrieval behavior
Evidence: `docs/specification/GAP-REGISTER.md`
Required action: Build Arabic and mixed-language labeled retrieval set; benchmark FTS5 tokenizer and normalization.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0012 — Obsidian manual edits require reconciliation
Evidence: `docs/specification/GAP-REGISTER.md`
Required action: Define ownership, detect changes, implement CAS reconciliation and collision tests.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0013 — Backup deletion policy unresolved
Evidence: `docs/specification/GAP-REGISTER.md`
Required action: Approve retention and erasure semantics including derived indexes and backup lifecycle.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0014 — No durable approval semantics validated
Evidence: `docs/specification/GAP-REGISTER.md`
Required action: Specify actor, scope, expiry, operation hash and replay resistance; test rejection cases.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.

## ASB6-ISSUE-0015 — Document ingestion authorization unresolved
Evidence: `docs/specification/GAP-REGISTER.md`
Required action: Define per-source consent/rights and provider transmission policy before real ingestion.
Verification: produce isolated reproducible test evidence and review against the corresponding V6 requirement.
Approval: obtain before changes to data, policies, production configuration or vault.
