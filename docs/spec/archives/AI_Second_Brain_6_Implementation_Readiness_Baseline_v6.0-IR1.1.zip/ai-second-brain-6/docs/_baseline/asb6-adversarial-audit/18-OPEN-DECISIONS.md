# 18 OPEN DECISIONS

Confirm OS, vault start/migration, corpus and languages, sensitive-data transmission, network/MCP, backups, RPO/RTO, approval semantics.
