# Remediation backlog

- [BLOCKING] ASB6-ISSUE-0001: Request read-only repo access or immutable commit snapshot; capture branch, hash, diff and test logs.
- [BLOCKING] ASB6-ISSUE-0002: Record explicit implementation authorization and amend root instructions through approved change control.
- [BLOCKING] ASB6-ISSUE-0003: Approve data classifications, permission boundary and enforcement tests before protected data use.
- [BLOCKING] ASB6-ISSUE-0004: Capture actual OS/hardware, versions, backup design, RPO/RTO and validate installation.
- [BLOCKING] ASB6-ISSUE-0005: Implement isolated tests in code repository; execute and retain evidence before verification claims.
- [BLOCKING] ASB6-ISSUE-0006: Create approved corpus, gold labels and baseline evaluation; publish measured recall, citations and latency.
- [BLOCKING] ASB6-ISSUE-0007: Verify actual installed release and official supported settings, then test least privilege.
- [BLOCKING] ASB6-ISSUE-0008: Implement staged journal and crash-point tests; verify orphan recovery and note conflict preservation.
- [BLOCKING] ASB6-ISSUE-0009: Record user decisions in ADRs and re-run readiness gates.
- [BLOCKING] ASB6-ISSUE-0010: Complete requirement-to-design-to-test-to-code mappings for approved scope.
- [NONBLOCKING] ASB6-ISSUE-0011: Build Arabic and mixed-language labeled retrieval set; benchmark FTS5 tokenizer and normalization.
- [BLOCKING] ASB6-ISSUE-0012: Define ownership, detect changes, implement CAS reconciliation and collision tests.
- [BLOCKING] ASB6-ISSUE-0013: Approve retention and erasure semantics including derived indexes and backup lifecycle.
- [BLOCKING] ASB6-ISSUE-0014: Specify actor, scope, expiry, operation hash and replay resistance; test rejection cases.
- [BLOCKING] ASB6-ISSUE-0015: Define per-source consent/rights and provider transmission policy before real ingestion.
