# 17 RELEASE BLOCKERS

Blockers: unresolved implementation authorization, security sandbox, platform/dependencies, privacy, crash recovery, tests, real corpus benchmarks, backups, approvals.
