# Confirmed specification gaps (not confirmed runtime defects)

## ASB6-ISSUE-0001: Existing codebase unavailable for audit

Evidence: `README.md` — No live implementation repository, branch, commits or runtime are included in the supplied ZIP.

Correction: Request read-only repo access or immutable commit snapshot; capture branch, hash, diff and test logs.

## ASB6-ISSUE-0002: Specification explicitly prohibits implementation

Evidence: `CLAUDE.md` — Root instructions declare SPECIFICATION-ONLY; user reports active implementation, creating an unresolved instruction/authorization boundary.

Correction: Record explicit implementation authorization and amend root instructions through approved change control.

## ASB6-ISSUE-0003: Readiness gate fails for security

Evidence: `docs/governance/IMPLEMENTATION-READINESS.md` — Readiness report explicitly records Security FAIL due to unapproved enforceable sandbox and classification policy.

Correction: Approve data classifications, permission boundary and enforcement tests before protected data use.

## ASB6-ISSUE-0004: Deployment environment unresolved

Evidence: `docs/governance/IMPLEMENTATION-READINESS.md` — Readiness report records OS, dependencies, backup destination and recovery objectives unknown.

Correction: Capture actual OS/hardware, versions, backup design, RPO/RTO and validate installation.

## ASB6-ISSUE-0005: No executable tests in supplied specification

Evidence: `docs/testing/TEST-CASES.md` — Test cases explicitly say designed, NOT executed and include no executable test suite.

Correction: Implement isolated tests in code repository; execute and retain evidence before verification claims.

## ASB6-ISSUE-0006: Representative retrieval benchmark not available

Evidence: `docs/architecture/RETRIEVAL-ARCHITECTURE.md` — Retrieval specification requires ≥100 labeled questions once an authorized corpus exists; no measured evaluation is supplied.

Correction: Create approved corpus, gold labels and baseline evaluation; publish measured recall, citations and latency.

## ASB6-ISSUE-0007: Claude Code compatibility remains unverified

Evidence: `docs/engineering/CLAUDE-CODE-CONTRACTS.md` — Claude Code contracts explicitly defer exact CLI/settings/hooks/MCP compatibility checks.

Correction: Verify actual installed release and official supported settings, then test least privilege.

## ASB6-ISSUE-0008: Cross-resource atomicity is not guaranteed

Evidence: `docs/architecture/TRANSACTION-PROTOCOL.md` — Transaction protocol explicitly acknowledges SQLite and filesystem cannot share a native atomic commit; recovery is only a proposed contract.

Correction: Implement staged journal and crash-point tests; verify orphan recovery and note conflict preservation.

## ASB6-ISSUE-0009: Critical user approvals remain open

Evidence: `docs/governance/IMPLEMENTATION-READINESS.md` — Readiness report lists eight blocking user decisions including vault migration, corpus, transmission and approval semantics.

Correction: Record user decisions in ADRs and re-run readiness gates.

## ASB6-ISSUE-0010: Only priority requirements have traceability

Evidence: `docs/governance/IMPLEMENTATION-READINESS.md` — Readiness report states 16 priority functional requirements mapped and full baseline cross-check pending.

Correction: Complete requirement-to-design-to-test-to-code mappings for approved scope.

## ASB6-ISSUE-0011: No validated Arabic retrieval behavior

Evidence: `docs/specification/GAP-REGISTER.md` — Gap register identifies Arabic tokenization as unbenchmarked.

Correction: Build Arabic and mixed-language labeled retrieval set; benchmark FTS5 tokenizer and normalization.

## ASB6-ISSUE-0012: Obsidian manual edits require reconciliation

Evidence: `docs/specification/GAP-REGISTER.md` — Gap register states direct edits may bypass SQLite registry.

Correction: Define ownership, detect changes, implement CAS reconciliation and collision tests.

## ASB6-ISSUE-0013: Backup deletion policy unresolved

Evidence: `docs/specification/GAP-REGISTER.md` — Gap register records backup erasure and retention conflict.

Correction: Approve retention and erasure semantics including derived indexes and backup lifecycle.

## ASB6-ISSUE-0014: No durable approval semantics validated

Evidence: `docs/specification/GAP-REGISTER.md` — Gap register records no durable approval token semantics.

Correction: Specify actor, scope, expiry, operation hash and replay resistance; test rejection cases.

## ASB6-ISSUE-0015: Document ingestion authorization unresolved

Evidence: `docs/specification/GAP-REGISTER.md` — Gap register records import authorization unconfirmed.

Correction: Define per-source consent/rights and provider transmission policy before real ingestion.
