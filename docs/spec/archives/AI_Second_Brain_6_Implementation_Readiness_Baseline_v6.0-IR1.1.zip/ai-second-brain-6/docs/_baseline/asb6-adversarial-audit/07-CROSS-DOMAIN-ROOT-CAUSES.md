# Cross-domain root causes

1. **Authority/consistency:** Markdown↔SQLite↔FTS5 synchronization and manual edits (issues 8,12).
2. **Authorization:** implementation mandate vs root `CLAUDE.md`, privacy classification, approvals (issues 2,3,9,14,15).
3. **Verification deficit:** tests, benchmark, platform compatibility, traceability (issues 5,6,7,10,11).
4. **Recoverability:** file/DB commit journal and backup retention (issues 8,13).

These are proposed groupings, not demonstrated code root causes.
