# Retrieval Architecture

**DOC-RET** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `RETRIEVAL-ARCHITECTURE.md` and `RETRIEVAL-BENCHMARK.md` of the V6.0 draft (CHG-007). Addresses V5.0 findings 5 and 10 and audit issues ASB6-ISSUE-0006 and 0011.

## 1. Pipeline

```
ingest → extract (versioned) → segment into passages ─┐
notes sync → note sections ───────────────────────────┼→ normalise (ar-en-1) → search_units + search_fts (FTS5)
memory revisions (current) ───────────────────────────┘
query → validate → normalise → build MATCH → FTS5 + filters → rank → collapse → budget → classify outcome → EvidenceHit[]
```

Retrieval is deterministic code. Claude Code calls it through `second-brain search --json` and decides what to ask next (§7); it never reads the database or the index directly.

## 2. Normalisation and tokenisation

**Finding (measured in the specification sandbox, SQLite 3.53.1, Python 3.13; script and output in `docs/specification/evidence/`).** SQLite's `unicode61` tokenizer, which the V6.0 draft specified, is not usable for Arabic as it stands. Its diacritic removal applies to Latin script. Arabic vowel marks are treated as separators, so a vocalised word is indexed as fragments.

| Probe | Raw `unicode61` (draft design) | Normalised column | Normalised + stem column |
|---|---|---|---|
| Tokens indexed for `مُحَمَّدٌ` | `م`, `ح`, `م`, `د` (four single letters) | `محمد` | `محمد` |
| Query `محمد` finds the vocalised sentence | no | yes | yes |
| Query `المكتبة` finds the form with tatweel (`المـــكتبة`) | no | yes | yes |
| Query `أحمد` finds `احمد` and the reverse | no | yes | yes |
| Query `مدرسة` finds `مدرسه` and the reverse | no | yes | yes |
| Query `2024` finds `٢٠٢٤` and the reverse | no | yes | yes |
| Presentation-form and ligature text (`ﻻ`) is searchable | no | yes | yes |
| Query `كتاب` finds `الكتاب` (attached article) | no | no | yes |
| Query `مكتبة` finds `وللمكتبات` (prefix chain and plural suffix) | no | no | yes |
| Query `كتاب` finds `الكتب`; `مدرسة` finds `المدارس` (broken plurals) | no | no | **no** |
| `trigram` tokenizer on raw text: `كتاب` finds `الكتاب` | yes (substring) | — | — |
| `trigram` tokenizer on raw text: letter and vowel variants | no | — | — |

These rows show tokenizer behaviour on twelve hand-written sentences. They are not a retrieval-quality measurement; that is NFR-007 on the owner's corpus.

**Design.** Normalisation is done by the application, identically for indexed text and queries. Stored passage and note text is never altered.

Normaliser `ar-en-1` (pure function, versioned, FR-RET-003), in order:

1. Unicode NFKC (folds Arabic presentation forms and ligatures, full-width forms).
2. Remove tashkeel and Quranic marks (U+064B–U+065F, U+0670, U+06D6–U+06ED), tatweel (U+0640), zero-width and bidi control characters (U+200B–U+200F, U+202A–U+202E, U+2066–U+2069, U+FEFF, U+061C).
3. Fold letters: `أ إ آ ٱ → ا`; `ى → ي`; `ة → ه`; Persian `ک → ك`, `ی → ي`. Hamza on waw or yeh (`ؤ`, `ئ`) and bare hamza are kept in version 1; folding them is experiment variant `ar-en-1h`.
4. Map Arabic-Indic and extended Arabic-Indic digits to ASCII digits.
5. Case-fold.

Light stemmer `ar-light-1` (applied to normalised Arabic-script tokens for the stem column only): strip at most one prefix from `ولل فلل وال بال كال فال لل ال و` and repeated suffixes from `ها ان ات ون ين يه ه ي`, never leaving fewer than three letters. English stemming is done by FTS5's `porter` wrapper.

Index table: `search_fts(title_norm, text_norm, text_stem)` with `tokenize = "porter unicode61 remove_diacritics 2"`. A change of normaliser or stemmer version marks the index stale and requires a rebuild.

## 3. Extraction and segmentation

- Supported in version 1: Markdown, plain text, HTML, DOCX, PDF with a text layer (D-09, ADR-017). Each extractor has a name and semantic version recorded per extraction.
- Encoding: UTF-8, then UTF-16 with BOM, then Windows-1256 for text and HTML; undecodable input fails extraction rather than guessing silently.
- Segmentation: boundaries at heading, page and paragraph; target 200–1200 characters; hard maximum 2000; never inside a grapheme cluster; concatenation reproduces the extraction text exactly (FR-ING-008).
- Each passage is tagged `ar`, `en`, `mixed` or `und` by the share of Arabic-script and Latin-script letters (≥ 80% one script, otherwise `mixed`).
- Known losses: DOCX tables are extracted row by row as text; PDF tables lose their structure; images and scanned pages yield no text and are flagged `needs_ocr` (FR-ING-009). Arabic PDF reading order depends on the PDF library and is measured before the library is fixed (V-12, TEST-ING-010).

## 4. Result contract

```json
{
  "schema_version": 1, "status": "ok", "correlation_id": "…",
  "data": {
    "outcome": "verified_evidence | evidence_unverified | insufficient | contradictory | outdated | no_evidence",
    "outcome_reasons": ["…"],
    "query": {"text": "…", "normalised": "…", "norm_version": "ar-en-1", "filters": {}, "method": "fts5-bm25"},
    "truncated": false,
    "hits": [{
      "rank": 1, "unit_kind": "passage | note_section | memory", "unit_id": "PSG-000123",
      "score": -7.31, "score_parts": {"bm25": -7.31, "state_rank": 0, "authority": 1},
      "excerpt": "original text, never normalised", "lang": "ar",
      "source": {"source_id": "SRC-000012", "source_version_id": "SVR-000014", "title": "…", "source_date": "2025-03-01", "authority": "primary", "state": "active"},
      "locator": {"kind": "pdf", "page": 12, "block": 3, "char_start": 1840, "char_end": 2710},
      "memory": null,
      "temporal": {"valid_from": null, "valid_to": null, "recorded_at": "…"},
      "flags": ["outdated", "disputed", "anchor_stale"]
    }],
    "unextracted_sources": ["SRC-000031"]
  }
}
```

For a memory hit, `memory` carries `memory_id`, `state`, `epistemic_type`, `attestation` and the passage IDs of its evidence. Source text inside `excerpt` is data, not instructions (FR-SEC-003).

## 5. Query processing

API: `search(query: str, *, limit: int = 10, filters: SearchFilters | None = None, allow_stale: bool = False, explain: bool = False) -> SearchResult`.

- Validation: non-empty after normalisation; at most 512 characters and 32 terms; `limit` 1–100; unknown filter keys rejected.
- MATCH construction: the query is split on whitespace; each term is emitted as a double-quoted FTS5 string with embedded quotes doubled, so FTS5 operators in user text have no effect (TEST-RET-002). Per term: `(title_norm:"t" OR text_norm:"t" OR text_stem:"s")` where `s` is the stemmed form; terms are joined with AND. A quoted phrase in the input becomes one phrase against `text_norm`. If AND yields nothing, one relaxed pass with OR is run and the result is marked `relaxed`.
- Filters (SQL joins, not FTS): `unit_kind`, `project`, `source_id`, `lang`, `state`, `authority`, `date_from`/`date_to` on source date or validity, `include_unverified` (default true, labelled), `include_archived` (default false).
- Excluded always: units of withdrawn or purged sources, superseded extractions, removed notes, deleted memory.
- Ranking (FR-RET-004): `bm25(search_fts, 2.0, 1.0, 0.5)` ascending; then state rank (verified, proposed, disputed, superseded); then authority; then newer `source_date`; then `unit_id`. Weights are configuration and provisional.
- Collapse: hits with the same `text_sha256` are merged into one hit listing all sources.
- Budget: the payload is cut at the configured size (default about 6,000 tokens, NFR-015) and `truncated` is set.
- Every query is logged (FR-RET-006).

## 6. Outcome classes

Computed in code, in this order:

| Outcome | Rule |
|---|---|
| `no_evidence` | No hit after the relaxed pass |
| `contradictory` | Among returned verified memory hits, two are linked by a live `CONTRADICTS` relationship, or a hit is in state `disputed` |
| `outdated` | The best-ranked verified hit is flagged outdated (past review date, stale or withdrawn anchor, newer source version) and no non-outdated verified hit exists |
| `verified_evidence` | At least one hit is a verified memory with live evidence, or a passage of an active source with authority `primary` or `secondary` |
| `evidence_unverified` | Hits exist but only from unrated or tertiary sources, proposed memory or note sections |
| `insufficient` | Hits exist only through the relaxed pass |

A passage is evidence that a source says something. Only a verified memory record is a statement the system holds true. The outcome tells Claude which of these it has.

## 7. Agentic retrieval and cross-language questions

Lexical search does not cross languages: an English question does not match Arabic text. The operating skill `answer-with-evidence` therefore runs a bounded loop (contract in AGENTIC-ARCHITECTURE §4): search the question as asked; if the corpus is bilingual and the outcome is weak, reformulate with the key terms translated into the other language and with entity aliases from `entities resolve`; stop on `verified_evidence`, on contradiction, or after six searches. Query translation is done by Claude and is therefore not deterministic; the benchmark has a cross-language stratum to measure it separately from index quality.

## 8. Indexing

- Units: one per passage of the active extraction of each present version of each active source; one per heading-delimited section of each registered, active note; one per current revision of each non-deleted memory record.
- `search_units.rowid` equals the FTS rowid; deletions are by rowid.
- Incremental update happens in step S6 of the commit protocol; `index_state` holds `dirty`, `norm_version`, `last_rebuild_at`, `unit_counts`.
- `index rebuild` drops and recreates both tables from authoritative data. `doctor` compares expected and actual unit counts and hashes a sample.

## 9. Evaluation

Benchmark file `BENCH-1` (JSON Lines), one object per question: `id`, `question`, `lang` (`ar`, `en`, `mixed`), `stratum`, `gold_passages` (IDs; empty for unanswerable), `gold_note`, `split` (`dev` or `holdout`), `author`, `validated_by`, `corpus_fingerprint`.

Minimum composition, 100 questions validated by the owner (the count and strata are a design; no question exists yet):

| Stratum | Count | Arabic / English / mixed |
|---|---|---|
| Exact identifiers, names, numbers | 15 | 8 / 5 / 2 |
| Arabic morphological variants (clitics, plurals, vocalised text) | 15 | 15 / 0 / 0 |
| Paraphrase | 15 | 8 / 7 / 0 |
| Cross-language (question in one language, evidence in the other) | 10 | 5 / 5 / 0 |
| Tables and structured content | 10 | 5 / 5 / 0 |
| Cross-document | 10 | 6 / 4 / 0 |
| Temporal | 10 | 6 / 4 / 0 |
| Contradiction | 5 | 3 / 2 / 0 |
| Unanswerable | 10 | 5 / 5 / 0 |

Protocol: Claude drafts candidate questions from the pilot corpus; the owner accepts, edits or rejects each and confirms the gold passages; 30% of each stratum goes to holdout, chosen before any tuning; the development split is used for tuning weights and variants; holdout is run only at gates. Limits to state with every result: one annotator; questions drafted by the same model that will answer them.

Metrics (FR-RET-008), per language and overall, with bootstrap 95% intervals: Recall@5, Recall@10, Precision@5, MRR, nDCG@10, citation validity (resolvable locators / returned locators), abstention precision (unanswerable questions with outcome `no_evidence` or `insufficient` / unanswerable questions), p50 and p95 latency. Reports carry SQLite version, normaliser and stemmer versions, ranking weights, corpus fingerprint and benchmark version.

## 10. Decision gates

**RET-G1 (Phase 4, mandatory): index variant.** Compare on the development split, confirm on holdout: (a) normalised only; (b) normalised + stem (default); (c) variant `ar-en-1h`; (d) b plus a trigram fallback table used only when the outcome is `no_evidence`. Adopt the simplest variant that meets NFR-007. Record the numbers in ADR-005.

**RET-G2 (Phase 8, conditional): anything beyond FTS5.** Dense retrieval, hybrid fusion, reranking or graph retrieval may be proposed only if the chosen FTS5 variant fails NFR-007 on holdout, or a paired experiment shows an absolute Recall@10 gain of at least 0.05 in a language with the interval excluding zero, no loss of citation validity, p95 latency within the NFR-001 target, operation with networking disabled, and at most one added runtime dependency. An embedding model would be a model other than Claude and needs the explicit approval principle P01 requires. Until then ADR-006 and ADR-007 stand.

## 11. Known limitations

Broken plurals and unmarked clitic chains are missed by the light stemmer. Cross-language retrieval depends on query translation. There is no semantic matching. Tables in PDFs lose structure. Scanned documents are not searchable. Ranking weights and passage sizes are unmeasured defaults.
