# Workflow Contracts

**DOC-WF** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Addresses V5.0 finding 7 and audit issue ASB6-ISSUE-0014. Every mutating command is a workflow run recorded in `workflow_runs` before any side effect. States are upper-case strings stored in `workflow_runs.state`. An unlisted transition is an error (E_CONFLICT) and is audited. Transition notation: `FROM → TO [trigger | guard | side effects | audit action]`.

## 1. WF-1 Document ingestion

States: PENDING, VALIDATING, STAGED, COMMITTED, EXTRACTING, INDEXING, COMPLETED, COMPLETED_WITH_WARNINGS, REJECTED, FAILED_RETRYABLE, FAILED_ROLLED_BACK, FAILED_CONFLICT, FAILED_TERMINAL, CANCELLED.

| From | To | Trigger | Guard | Side effects | Audit |
|---|---|---|---|---|---|
| — | PENDING | `ingest PATH` | idempotency key = sha256 of bytes + operation | run row | ingest.requested |
| PENDING | VALIDATING | start | writer lock held | — | — |
| VALIDATING | REJECTED | intake fails | — | none; inbox file moved to `.rejected/` | ingest.rejected |
| VALIDATING | COMPLETED | sha256 already registered | — | none | source.duplicate |
| VALIDATING | STAGED | intake passes | free space, path policy | staged copy; journal intent (S2–S3) | — |
| STAGED | COMMITTED | S4–S5 succeed | target absent or identical | original placed; source, version rows; source note | source.registered |
| COMMITTED | EXTRACTING | automatic | extractor available | — | — |
| EXTRACTING | INDEXING | extraction succeeded or partial | limits respected | extraction and passages (own transaction) | extraction.completed |
| EXTRACTING | COMPLETED_WITH_WARNINGS | failed, needs_ocr, or no extractor | — | extraction row with status; no passages | extraction.failed |
| INDEXING | COMPLETED | index delta applied | — | search units | ingest.completed |
| any active | FAILED_RETRYABLE | lock timeout, disk full, SQLite busy | — | staging cleaned if before S3 | ingest.failed |
| STAGED | FAILED_ROLLED_BACK | recovery finds staged file missing | — | intents `undone` | ingest.rolled_back |
| EXTRACTING | FAILED_TERMINAL | time or size limit, extractor crash | — | file listed for quarantine review; source stays registered | extraction.terminated |
| any before COMMITTED | CANCELLED | SIGINT | — | as recovery CP1/CP2 | ingest.cancelled |

Registration and extraction are separate commits on purpose: a source whose extraction fails is still preserved and visible.

## 2. WF-2 Memory record lifecycle

States of `memory_records.state`. Each transition is carried by a proposal (WF-3).

| From | To | Tier | Guard | Side effects |
|---|---|---|---|---|
| — | captured | 0 | raw note of something to consider; no schema beyond statement | record + revision 1 |
| — | proposed | 0 | PRP-MEM-1 valid | record + revision 1 + evidence links |
| captured | proposed | 0 | classification supplied | revision n+1 |
| captured | archived | 0 | — | — |
| proposed | verified | 1 | type fact, decision or preference; evidence rule T3; not derived (T4); no unresolved conflict, or conflict resolved in the same proposal | index delta; digest regenerated |
| proposed | disputed | 1 | contradicting evidence linked | CONTRADICTS edge |
| proposed | archived | 0 | — | unindexed from default search |
| verified | disputed | 1 | contradicting evidence, or only support withdrawn | flagged in search |
| verified | superseded | 1 | successor verified; no cycle | validity closed; SUPERSEDES edge |
| verified | archived | 1 | — | — |
| verified | proposed | 1 | correction (new revision) | must be re-verified |
| disputed | verified | 1 | T3 holds; dispute resolution recorded | CONTRADICTS edge retracted or other side superseded |
| disputed | superseded | 1 | as above | — |
| disputed | archived | 1 | — | — |
| superseded | archived | 0 | — | — |
| archived | proposed | 1 | — | — |
| archived | deleted | 2 | purge approval | text blanked; tombstone |

Failure state: none on the record; a failed transition leaves the record unchanged and the proposal `failed` or `conflict`.

## 3. WF-3 Knowledge update (proposal lifecycle)

States of `proposals.state`: draft, validated, awaiting_approval, approved, applied, rejected, expired, conflict, failed.

| From | To | Trigger | Guard | Side effects | Audit |
|---|---|---|---|---|---|
| — | draft | `… propose` | actor recorded | row | proposal.created |
| draft | validated | validation passes | schema, references, base versions captured, tier computed | payload frozen; proposal note written | proposal.validated |
| draft | rejected | validation fails | — | findings stored | proposal.invalid |
| validated | applied | tier 0 | base versions unchanged | change applied (WF commit protocol) | proposal.applied |
| validated | awaiting_approval | tier 1 or 2 | — | appears in queue | — |
| awaiting_approval | approved | `proposals approve ID --hash PREFIX` | channel allowed for tier; hash prefix (≥ 8 hex) matches; not expired | approval row | proposal.approved |
| awaiting_approval | rejected | `proposals reject` | — | reason stored | proposal.rejected |
| awaiting_approval, validated | expired | time | `expires_at` passed | — | proposal.expired |
| approved | applied | `proposals apply` or same command | approval unexpired and unconsumed; base versions unchanged | change applied; approval consumed in the same transaction | proposal.applied |
| approved, validated | conflict | apply | a base version changed | nothing applied; approval consumed as void | proposal.conflict |
| approved | failed | apply raises | — | rolled back; approval **not** consumed | proposal.failed |

A proposal is a diff against recorded base versions (note content hash, memory revision number, row `updated_at`). Approval binds to `payload_sha256`. Changing a proposal means creating a new one.

## 4. WF-4 Project update

Project, item and decision changes are proposals of type `project_change` or `decision_change`.

| Operation | Tier | Guard | Side effects |
|---|---|---|---|
| Create project, add or edit item, change item state | 0 | slug unique; no dependency cycle | row change + one `project_events` row each |
| Change project state (active, on hold, completed, cancelled) | 1 | — | event |
| Record decision as proposed | 0 | note created | event |
| Accept, reject, supersede, reverse decision | 1 | decided_on present; no supersession cycle | event; relationships |
| Back-dated change (`effective_at` earlier than now) | 1 | `effective_at` ≥ project creation | event with both times |

States: projects `proposed, active, on_hold, completed, cancelled`; items `open, in_progress, blocked, done, dropped`; decisions `proposed, accepted, rejected, superseded, reversed`.

## 5. WF-5 Agentic task (a request handled in a Claude Code session)

This describes the session-level sequence; nothing here is stored except the runs and proposals it produces.

`REQUESTED → PLANNED → RETRIEVING ⇄ REFINING → (ANSWERED | DRAFTED_PROPOSALS → AWAITING_OWNER → APPLIED | REJECTED) → REPORTED`

| Step | Who | Contract |
|---|---|---|
| REQUESTED | owner | natural-language request |
| PLANNED | Claude | chooses a skill; states the plan in one or two lines |
| RETRIEVING / REFINING | Claude via CLI | read-only commands; at most 6 searches per question (advisory budget) |
| ANSWERED | Claude | answer with passage or memory IDs for every factual statement; outcome class reported; abstains when the outcome requires |
| DRAFTED_PROPOSALS | Claude via CLI | `… propose` only; tier 0 items apply at once and are reported |
| AWAITING_OWNER | owner | reads proposal notes or `proposals show`; approves in session (tier 1) or in a terminal (tier 1 or 2) |
| REPORTED | Claude | lists what was proposed, applied, rejected, failed, with IDs |

If the session ends at any point, nothing is lost: applied changes are committed, pending proposals wait in the queue, and nothing else existed.

## 6. WF-6 Backup and restore

Backup: `REQUESTED → SNAPSHOTTING → COPYING → MANIFESTED → VERIFIED → (RESTORE_TESTED)`; failure → `FAILED` from any state. `VERIFIED` means every file re-read from the destination matches the manifest. `RESTORE_TESTED` is set only by WF restore-test.

Restore-test: `REQUESTED → EXTRACTING_TO_TEMP → CHECKING → PASSED | FAILED`; the backup row becomes `restore_tested` or `failed`.

Restore (tier 2): `REQUESTED → PRECHECK (backup restore_tested) → SET_ASIDE (current home renamed) → RESTORING → VERIFYING → COMPLETED`; on failure in RESTORING or VERIFYING → `ROLLED_BACK` (set-aside home renamed back).

## 7. Audit events

Every transition above emits one event: `occurred_at`, `actor`, `actor_kind`, `correlation_id`, `action`, `object_id`, `outcome`, `detail_json` (old and new state, tier, channel, error code; never content). Denials are events with outcome `denied`.

## 8. Cross-cutting rules

- **Idempotency.** Key = operation name + canonical hash of its inputs (for ingest, the file hash). A completed key returns the stored result. A key in progress returns E_CONFLICT.
- **Retries.** FAILED_RETRYABLE may be re-run by the same command; nothing is retried automatically inside a command except SQLite busy waits. Scheduled jobs retry on their next schedule.
- **Timeouts.** Extraction 120 s and 50 MB of text per file; lock wait 5 s; all configurable.
- **Cancellation.** SIGINT and SIGTERM are caught: before S3 the run cleans up and ends CANCELLED; after S3 it stops and recovery finishes or rolls back on the next command.
- **Compensation.** There are no compensating transactions. Before the commit point the run rolls back or forward by the recovery table; after it, undoing means a new proposal (supersede, correct, withdraw), which leaves history intact.
- **Loops.** A run is a finite list of steps. No workflow waits, polls or loops.
- **Human intervention points.** Exactly the tier 1 and tier 2 approvals, conflict resolution, quarantine review, and read-only mode.
