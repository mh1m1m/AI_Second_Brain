# Memory Architecture

**DOC-MEM** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `MEMORY-ARCHITECTURE.md` of the V6.0 draft. Addresses V5.0 findings 2 and 3. The V6.0 draft held two incompatible models (`claims` in the data architecture, `knowledge_records` plus `memory_records` in the DDL); this document replaces both with one (ADR-020).

## 1. Model

A **memory record** is one statement the system tracks, with a lifecycle. It has a kind, an epistemic type, a state, an optional subject and predicate, and a list of immutable **revisions**. Each revision carries the statement text, an optional structured value, validity dates, an attestation and its own **evidence links** to passages. SQLite is authoritative; the vault shows records in generated digest notes (§12).

Notes are not memory. A concept note is the owner's prose; a memory record is a governed statement. A note may link to memory records, and a memory record may have a subject that is an entity with a note.

## 2. Kinds

| Kind | Holds | Typical capture | May be verified by | Default review interval |
|---|---|---|---|---|
| semantic | Facts and definitions about the world | Extraction from a source | Evidence + tier 1 approval | 24 months |
| episodic | What happened, when | Source or owner | Evidence or owner attestation + tier 1 | none |
| procedural | How something is done | Source or owner | Evidence or owner attestation + tier 1 | 12 months |
| decision | A decision taken (mirrors a `decisions` row when project-related) | Decision workflow | Tier 1 | none; superseded explicitly |
| project | State facts about a project | Project workflow | Tier 1 | 3 months while the project is active |
| preference | What the owner prefers | Owner only | Owner attestation | 12 months |
| operational | Lessons about running this system | Owner or doctor findings | Owner attestation | 12 months |

The fourteen conceptual categories of V5.0 map onto this storage without new tables: relationship → `relationships`; temporal → validity fields on every revision; task and commitment → `project_items`; failure and evaluation → operational memory plus evidence files; provenance → `evidence_links`. Working memory is the Claude Code session context and is not stored.

## 3. Epistemic types

| Type | Meaning | Can reach `verified`? |
|---|---|---|
| fact | Stated as true, supported by a source passage | Yes, with resolvable supporting evidence |
| claim | Something a source asserts; recorded as the source's position | No. Stays `proposed`; the source is its evidence |
| hypothesis | A conjecture to test | No |
| interpretation | A reading or synthesis, including any summary written by Claude | No |
| prediction | A statement about the future | No |
| decision | A decision taken by an identified decider | Yes, by approval |
| preference | An owner preference | Yes, by owner attestation |

Attestation per revision: `source_evidence` (requires supporting passages), `owner_attested` (owner states it; only actor kind `owner` may create it), `derived` (produced by reasoning; must carry `derivation_json` listing the records it was derived from; can never be verified). These rules are enforced by CHECK constraints and triggers T3–T5 (DATABASE-SCHEMA §5), not only by the application.

## 4. States

`captured → proposed → verified`; `proposed → disputed`; `verified → disputed | superseded | archived`; `disputed → verified | superseded | archived`; `superseded → archived`; `archived → deleted | proposed`. Full transition table with guards and tiers: WORKFLOW-CONTRACTS WF-2.

## 5. Conflict handling

Deterministic detection at proposal validation (FR-MEM-005): two non-archived records conflict when they share `subject_id` and `predicate`, their validity windows overlap (open ends treated as unbounded), and their `value_json` differ after canonical JSON serialisation. Records lacking subject or predicate are reported as not checkable. Claude may also flag a suspected conflict in free text; that is stored as a proposal comment and decides nothing.

Worked example. Existing: MEM-000101, verified, subject Project Alpha, predicate `deadline`, value `2026-06-30`, valid from 2026-01-10. New source says the deadline is 30 September.

1. Ingest the source; passages are created. Nothing else changes.
2. Claude drafts a proposal: new record, same subject and predicate, value `2026-09-30`, evidence = the new passage, `valid_from` = the date the change took effect according to the source.
3. Validation finds the conflict with MEM-000101 and attaches it to the proposal. The proposal note shows both statements, both evidence passages and both dates.
4. The owner decides. Usual outcome: approve verification of the new record and supersession of the old one (one tier 1 approval of a compound proposal).
5. In one transaction: new record `verified`; old record `superseded`, `superseded_by` set, `valid_to` = the effective date; `SUPERSEDES` relationship created; revisions untouched.
6. Index delta: both re-indexed. Default search returns the new record; `--as-of 2026-03-01` returns the old one; `memory history` shows both.
7. If the owner cannot decide, both stay and the old record is set `disputed`; search reports `contradictory` with both.

## 6. Time

Every revision can carry three independent times: `event_time` (when the thing happened), `valid_from`/`valid_to` (when the statement holds), and `recorded_at` (when this system stored it). Sources carry `source_date` (publication) and `captured_at` (ingestion). Queries: `--as-of D` filters on validity; `--recorded-by D` filters on `recorded_at`.

Dates are stored as ISO 8601 Gregorian calendar dates in UTC terms, with no local-time arithmetic. Because Arabic sources often give Hijri dates, month-only or year-only dates, each revision also has `date_precision` (`day`, `month`, `year`, `unknown`) and `date_text` (the date exactly as written in the source). The system does not convert calendars: whoever drafts the proposal supplies the Gregorian value, the original string is kept beside it, and the owner sees both at approval. This is open finding RT-D03 for the owner to confirm.

## 7. Confidence

No numeric confidence is stored or displayed. What the system knows about reliability is categorical and inspectable: state, epistemic type, attestation, number and authority of supporting sources, freshness flags. A number would look calibrated and would not be.

## 8. Retrieval of memory

Order of preference in ranking ties: verified before proposed before disputed before superseded; within validity before outside it; primary-source evidence before secondary. Filters by state and validity are applied in SQL before ranking. Proposed records are returned labelled `evidence_unverified`. Superseded and archived records are returned only on request.

## 9. Correction, consolidation, archive, deletion

- Correction (FR-MEM-007): new revision; a verified record returns to `proposed` and must be re-verified with evidence attached to the new revision.
- Consolidation (FR-MEM-011): only for records equal in subject, predicate and value with overlapping validity. Evidence is unioned onto the survivor; the others are archived with a `SUPERSEDES` edge.
- Freshness (FR-MEM-010): the review queue lists verified records past `review_due_on`, with stale or withdrawn evidence, or whose source has a newer version.
- Archive and purge: DATA-ARCHITECTURE §8.

## 10. Controls against false memory

| Risk | Control | Enforced by |
|---|---|---|
| A summary written by Claude becomes a fact | Summaries are `interpretation` / `derived` and cannot be verified | CHECK, trigger T4 |
| A fact is verified with no source | Supporting passage of a live source required | Trigger T3 |
| A source's opinion is stored as fact | `claim` type; cannot be verified | CHECK |
| Verified text is edited silently | Revisions immutable; correction creates a new revision and resets state | Triggers T2, T6 |
| An old value is overwritten by a new one | Supersession keeps both | FR-MEM-006 |
| A hand-edited note changes state | Frontmatter state is a projection | FR-KNW-005 |
| Claude invents an owner preference | `owner_attested` only from actor kind owner | Application check, TEST-MEM-015 |
| Evidence disappears later | Anchor state `stale` / `source_withdrawn`; record queued or disputed | FR-ING-011, FR-MEM-010 |
| A citation points at nothing | Locators resolved and hash-checked on display | FR-RET-002 |

Residual risk that no control removes: the owner approves a statement whose cited passage does not actually support it. The proposal note shows passage and statement side by side to make that check easy.

## 11. Proposal schema PRP-MEM-1

```json
{"schema": "PRP-MEM-1", "candidates": [{
  "statement": "…", "statement_lang": "ar", "kind": "semantic", "epistemic_type": "fact",
  "attestation": "source_evidence", "subject_id": "ENT-000007", "predicate": "deadline",
  "value": {"date": "2026-09-30"}, "valid_from": "2026-04-02", "valid_to": null,
  "date_precision": "day", "date_text": null, "event_time": null,
  "evidence": [{"passage_id": "PSG-000431", "role": "supports", "quote": "…"}],
  "project_id": null, "derivation": null }],
 "requested_transition": "none | verify", "supersedes": [], "note": "free text for the reviewer"}
```

Validation rejects the whole proposal if any passage ID is unknown, any quote is not contained in its passage (after NFC), any vocabulary value is invalid, or attestation and actor kind disagree.

## 12. Projection into the vault

Memory is shown in **digest notes**, not one file per record: `04-Memory/by-subject/<subject>.md`, `04-Memory/by-project/<slug>.md`, and `04-Memory/unfiled/<YYYY-MM>.md`. Each record is a section with a block anchor (`^MEM-000101`), its state, validity, statement and links to its source notes. Digests are managed files regenerated from SQLite. This keeps the number of generated files proportional to subjects rather than statements.
