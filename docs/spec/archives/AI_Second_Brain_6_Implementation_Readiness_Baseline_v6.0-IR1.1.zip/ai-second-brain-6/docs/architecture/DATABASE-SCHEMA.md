# Database Schema

**DOC-DB** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

SQLite schema version 1 (migration `0001_initial.sql`). Supersedes `DATABASE-SCHEMA.md` of the V6.0 draft (CHG-006). Addresses audit issue ASB6-ISSUE-0014 (approval semantics) through tables `proposals` and `approvals` and triggers T8–T10.

**What has been verified.** The DDL in §6 was executed in a throwaway in-memory database in the specification sandbox (SQLite 3.53.1, Python 3.13.18): 29 tables including the FTS5 virtual table, 17 indexes, 15 triggers; `PRAGMA integrity_check` returned `ok`; 27 of 27 constraint probes behaved as specified (§8). It has not been run on the owner's Mac (V-01), and no application code uses it.

## 1. Conventions

- One database file, `data/db/second_brain.sqlite3`. Every connection sets `foreign_keys=ON`, `journal_mode=WAL`, `synchronous=FULL`, `busy_timeout=5000`, `trusted_schema=OFF`. `doctor` checks them (DOC-DB-02).
- All tables are `STRICT`. Minimum SQLite 3.45 (STRICT needs 3.37; JSON functions are built in from 3.38; the margin leaves room for FTS5 fixes). The exact minimum is confirmed against the Mac's build in V-01.
- Timestamps are UTC text `YYYY-MM-DDTHH:MM:SSZ`; dates are `YYYY-MM-DD`. The format is validated by the application, not by CHECK constraints (review finding RT-D07).
- Identifiers are text with a three-letter prefix, allocated from `id_sequences` and registered in `objects` in the same transaction as the row they name.
- Rows that carry history are never deleted; there is no `ON DELETE CASCADE`. Deletion semantics are in DATA-ARCHITECTURE §8.
- JSON columns are checked with `json_valid`. Their shapes are defined where they are used: `locator_json` (DATA-ARCHITECTURE §7), `payload_json` (proposal schemas), `checkpoint_json` (change plan of the commit protocol), `detail_json` (WORKFLOW-CONTRACTS §7).

## 2. Table catalogue

| Table | Purpose | Primary key | References | Unique constraints | Retention |
|---|---|---|---|---|---|
| `schema_migrations` | Applied migrations with checksum | version | — | — | life of system |
| `id_sequences` | Next sequence number per ID prefix | prefix | — | — | life of system |
| `objects` | Registry of every identifiable object; target of polymorphic foreign keys | id | — | — | never deleted |
| `index_state` | Key-value state of the derived index (dirty flag, versions, counts) | key | — | — | rewritten on rebuild |
| `workflow_runs` | One row per mutating command: state, step, checkpoint, idempotency key | id | objects | idempotency_key | kept |
| `proposals` | Requested changes: frozen payload, hash, tier, base versions, state | id | objects, workflow_runs | — | kept |
| `approvals` | Single-use approval bound to a proposal payload hash | id | objects, proposals | proposal_id | kept |
| `journal_ops` | Write-ahead intents for file operations of a run | (workflow_run_id, seq) | workflow_runs | — | kept |
| `sources` | Logical documents | id | objects, workflow_runs | — | never deleted; state withdrawn/purged |
| `source_versions` | Immutable artifacts: one row per distinct file content | id | objects, sources, workflow_runs | sha256; storage_relpath; (source_id, version_no) | never deleted; state purged |
| `extractions` | One row per (source version, extractor, extractor version) | id | objects, source_versions | (source_version_id, extractor, extractor_version); one active per version | kept; superseded extractions stay for citation stability |
| `passages` | Evidence units with locator and text | id | objects, extractions | (extraction_id, ordinal) | kept; text blanked on source purge |
| `notes` | Registry of vault notes: path, type, content hash, revision | id | objects, workflow_runs | path | never deleted; state missing/removed |
| `note_revisions` | Append-only record of note content hashes and origin | (note_id, revision) | notes, proposals | — | append-only |
| `entities` | Named things with canonical name; merge pointer | id | objects, notes, entities | — | never deleted |
| `entity_aliases` | Arabic and English names with normalised form | (entity_id, alias_norm) | entities | — | removable on unmerge |
| `relationships` | Typed edges between any two objects with state and validity | id | objects (x3), proposals | live (subject, predicate, object, valid_from) | never deleted; state retracted |
| `projects` | Projects: current state | id | objects, notes | slug | never deleted |
| `project_items` | Milestones, tasks, risks, dependencies, commitments, open questions: current state | id | objects, projects | — | never deleted; state dropped |
| `decisions` | Decisions: current state and supersession pointer | id | objects, projects, decisions, notes | — | never deleted |
| `project_events` | Append-only history for projects, items and decisions; source of as-of replay | seq | projects, objects, proposals | — | append-only, life of system |
| `memory_records` | Governed statements: kind, epistemic type, state, subject, predicate | id | objects (x2), projects, memory_records | — | never deleted; state deleted = tombstone |
| `memory_revisions` | Immutable statement versions with validity and attestation | (memory_id, revision) | memory_records, proposals | — | immutable; text blanked only by purge |
| `evidence_links` | Links from a memory revision, relationship or decision to supporting or contradicting passages | (subject_id, subject_revision, passage_id, role) | objects, passages | — | kept; anchor_state changes |
| `audit_events` | Append-only hash-chained log of state changes and denials | seq | objects | event_hash | append-only, life of system |
| `query_log` | Search queries with outcome and timing | seq | — | — | pruned after 180 days (D-06) |
| `backups` | Backups known to the system and their verification state | id | objects | — | kept; state expired |
| `search_units` | Derived: one row per indexed unit; rowid shared with search_fts | rowid | objects | unit_id | rebuilt |
| `search_fts` | Derived: FTS5 index over normalised title, text and stemmed text | rowid (implicit) | — | — | rebuilt |

## 3. Nullability and semantics notes

- `memory_records.subject_id` and `predicate` are nullable: free-text statements are allowed but are not conflict-checkable (FR-MEM-005).
- `valid_from`/`valid_to` NULL means unbounded on that side. `source_versions.source_date` NULL means unknown, never 'today'.
- `evidence_links.subject_revision` is 0 for subjects without revisions (relationships, decisions).
- `relationships` uniqueness applies only to live states, so a retracted edge can be proposed again.
- `approvals.proposal_id` is unique: one approval per proposal. A failed apply does not consume it; a conflict voids it.
- `notes.managed = 1` marks projections whose body is generated.
- `created_by_run` on `sources`, `source_versions` and `notes` records the workflow run that created the row; it is what makes a batch (for example a future vault import) reversible as a unit.

## 4. Indexes and representative queries

Indexes exist for: open workflow runs, pending journal operations, proposals by state, passages by text hash (re-anchoring and duplicate collapse), alias lookup, relationships by object, project items by project, events by project and by subject, memory by state and by subject, evidence by passage, audit by correlation and by object, search units by parent. Query plans have not been measured (TASK-0801).

```sql
-- Q1 search (the application builds :match from normalised, quoted terms; see RETRIEVAL-ARCHITECTURE §5)
SELECT u.unit_kind, u.unit_id, u.parent_id, u.locator_json, bm25(search_fts, 2.0, 1.0, 0.5) AS score
  FROM search_fts JOIN search_units u ON u.rowid = search_fts.rowid
 WHERE search_fts MATCH :match ORDER BY score, u.unit_id LIMIT :limit;

-- Q2 evidence chain of a memory record down to the stored original
SELECT m.id, r.revision, r.statement, e.role, p.id AS passage_id, p.locator_json, sv.sha256, sv.storage_relpath, s.title
  FROM memory_records m JOIN memory_revisions r ON r.memory_id = m.id AND r.revision = m.current_revision
  JOIN evidence_links e ON e.subject_id = m.id AND e.subject_revision = r.revision
  JOIN passages p ON p.id = e.passage_id JOIN extractions x ON x.id = p.extraction_id
  JOIN source_versions sv ON sv.id = x.source_version_id JOIN sources s ON s.id = sv.source_id
 WHERE m.id = :memory_id;

-- Q3 what was held true about a subject on a date (valid time)
SELECT m.id, r.statement, r.valid_from, r.valid_to, m.state FROM memory_records m
  JOIN memory_revisions r ON r.memory_id = m.id AND r.revision = m.current_revision
 WHERE m.subject_id = :subject AND m.predicate = :predicate AND m.state IN ('verified','superseded')
   AND (r.valid_from IS NULL OR r.valid_from <= :as_of) AND (r.valid_to IS NULL OR r.valid_to > :as_of);

-- Q4 project state as of a date: replay events
SELECT subject_id, event_type, payload_json FROM project_events
 WHERE project_id = :project AND effective_at <= :as_of ORDER BY effective_at, seq;

-- Q5 verified facts whose every supporting source is withdrawn (should be empty; doctor check DOC-MEM-01)
SELECT m.id FROM memory_records m JOIN memory_revisions r ON r.memory_id = m.id AND r.revision = m.current_revision
 WHERE m.state = 'verified' AND r.attestation = 'source_evidence' AND NOT EXISTS (
   SELECT 1 FROM evidence_links e JOIN passages p ON p.id = e.passage_id JOIN extractions x ON x.id = p.extraction_id
     JOIN source_versions sv ON sv.id = x.source_version_id JOIN sources s ON s.id = sv.source_id
    WHERE e.subject_id = m.id AND e.subject_revision = r.revision AND e.role = 'supports'
      AND sv.state = 'present' AND s.state = 'active');
```

## 5. Integrity triggers

| ID | Trigger(s) | Rule | Error text |
|---|---|---|---|
| T1 | `trg_audit_no_update/delete`, `trg_pevents_no_update/delete`, `trg_noterev_no_update` | Append-only tables | SB-INT-001, SB-INT-002, SB-INT-003 |
| T2 | `trg_memrev_immutable`, `trg_memrev_no_delete` | Memory revisions immutable; only an authorised purge may blank text | SB-INT-004 |
| T3 | `trg_memory_verify_needs_evidence` | A source-evidenced record cannot be verified without a supporting passage of a live source | SB-MEM-002 |
| T4 | `trg_memory_verify_not_derived` | A derived statement cannot be verified | SB-MEM-003 |
| T5 | `trg_memory_insert_state` | New records start captured or proposed | SB-MEM-001 |
| T6 | `trg_memory_transition` | Only the transitions of WF-2 | SB-MEM-001 |
| T7 | `trg_sv_immutable` | Source version identity cannot change | SB-ING-002 |
| T8 | `trg_approval_consume_once` | Approvals are single-use and otherwise immutable | SB-AGT-001 |
| T9 | `trg_approval_hash_match` | Approval hash must equal the proposal payload hash | SB-AGT-001 |
| T10 | `trg_proposal_payload_frozen` | Proposal payload cannot change after draft | SB-AGT-001 |

Triggers are a last line of defence for someone or something writing SQL directly. They do not stop the database owner from dropping them; that is what the audit chain and `doctor` schema-hash check (DOC-DB-03) detect.

## 6. DDL

```sql
-- AI Second Brain 6.0 — SQLite schema v1 (migration 0001_initial)
-- DESIGN ARTEFACT. Executed only against throwaway in-memory databases during specification.
-- Connection pragmas (set by the application on every connection, not stored in the file):
--   PRAGMA foreign_keys = ON;  PRAGMA journal_mode = WAL;  PRAGMA synchronous = FULL;
--   PRAGMA busy_timeout = 5000;  PRAGMA trusted_schema = OFF;
-- All timestamps: UTC ISO 8601 text 'YYYY-MM-DDTHH:MM:SSZ'. Dates: 'YYYY-MM-DD'.
-- All tables are STRICT (SQLite >= 3.37).

---------------------------------------------------------------- infrastructure
CREATE TABLE schema_migrations (
  version     INTEGER PRIMARY KEY,
  name        TEXT NOT NULL,
  checksum    TEXT NOT NULL CHECK (length(checksum) = 64),
  applied_at  TEXT NOT NULL
) STRICT;

CREATE TABLE id_sequences (
  prefix      TEXT PRIMARY KEY CHECK (prefix GLOB '[A-Z][A-Z][A-Z]'),
  next_value  INTEGER NOT NULL CHECK (next_value >= 1)
) STRICT;

-- One row per identifiable object. Gives global ID uniqueness and lets
-- relationships, evidence links, events and audit rows use real foreign keys.
CREATE TABLE objects (
  id           TEXT PRIMARY KEY CHECK (id GLOB '[A-Z][A-Z][A-Z]-[0-9][0-9][0-9][0-9][0-9][0-9]*'),
  object_type  TEXT NOT NULL CHECK (object_type IN
                 ('source','source_version','extraction','passage','note','memory',
                  'entity','relationship','project','project_item','decision',
                  'proposal','approval','workflow_run','backup')),
  created_at   TEXT NOT NULL
) STRICT;

CREATE TABLE index_state (
  key    TEXT PRIMARY KEY,
  value  TEXT NOT NULL
) STRICT;

---------------------------------------------------------------- workflow, proposals, approvals
CREATE TABLE workflow_runs (
  id               TEXT PRIMARY KEY REFERENCES objects(id),
  workflow_type    TEXT NOT NULL CHECK (workflow_type IN
                     ('ingest','extract','note_sync','knowledge_update','memory_transition',
                      'project_update','agentic_task','index_rebuild','backup','restore_test',
                      'restore','migration','purge','vault_import')),
  idempotency_key  TEXT NOT NULL UNIQUE,
  state            TEXT NOT NULL,
  step             INTEGER NOT NULL DEFAULT 0 CHECK (step >= 0),
  attempt          INTEGER NOT NULL DEFAULT 1 CHECK (attempt >= 1),
  checkpoint_json  TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(checkpoint_json)),
  correlation_id   TEXT NOT NULL,
  started_at       TEXT NOT NULL,
  updated_at       TEXT NOT NULL,
  finished_at      TEXT,
  error_code       TEXT,
  error_detail     TEXT
) STRICT;
CREATE INDEX idx_workflow_open ON workflow_runs(state) WHERE finished_at IS NULL;

CREATE TABLE proposals (
  id                  TEXT PRIMARY KEY REFERENCES objects(id),
  proposal_type       TEXT NOT NULL CHECK (proposal_type IN
                        ('memory_create','memory_transition','memory_revise','note_write',
                         'relationship_change','entity_merge','project_change','decision_change',
                         'source_withdraw','purge','restore','migration','config_change','vault_import')),
  tier                INTEGER NOT NULL CHECK (tier IN (0,1,2)),
  payload_json        TEXT NOT NULL CHECK (json_valid(payload_json)),
  payload_sha256      TEXT NOT NULL CHECK (length(payload_sha256) = 64),
  base_versions_json  TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(base_versions_json)),
  validation_json     TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(validation_json)),
  state               TEXT NOT NULL CHECK (state IN
                        ('draft','validated','awaiting_approval','approved','rejected',
                         'expired','applied','failed','conflict')),
  created_by          TEXT NOT NULL,
  actor_kind          TEXT NOT NULL CHECK (actor_kind IN ('owner','claude_session','scheduler','system')),
  created_at          TEXT NOT NULL,
  expires_at          TEXT NOT NULL,
  decided_at          TEXT,
  workflow_run_id     TEXT REFERENCES workflow_runs(id)
) STRICT;
CREATE INDEX idx_proposals_state ON proposals(state, created_at);

CREATE TABLE approvals (
  id              TEXT PRIMARY KEY REFERENCES objects(id),
  proposal_id     TEXT NOT NULL UNIQUE REFERENCES proposals(id),
  payload_sha256  TEXT NOT NULL CHECK (length(payload_sha256) = 64),
  approver        TEXT NOT NULL,
  channel         TEXT NOT NULL CHECK (channel IN ('in_session','terminal')),
  approved_at     TEXT NOT NULL,
  expires_at      TEXT NOT NULL,
  consumed_at     TEXT
) STRICT;

-- Write-ahead intents for filesystem operations (see TRANSACTION PROTOCOL in DATA-ARCHITECTURE.md).
CREATE TABLE journal_ops (
  workflow_run_id       TEXT NOT NULL REFERENCES workflow_runs(id),
  seq                   INTEGER NOT NULL CHECK (seq >= 1),
  op_type               TEXT NOT NULL CHECK (op_type IN
                          ('place_original','write_note','move_note','remove_note','remove_original')),
  target_relpath        TEXT NOT NULL,
  staged_relpath        TEXT,
  expected_prev_sha256  TEXT,
  new_sha256            TEXT,
  state                 TEXT NOT NULL CHECK (state IN ('intent','done','undone','quarantined')),
  recorded_at           TEXT NOT NULL,
  completed_at          TEXT,
  PRIMARY KEY (workflow_run_id, seq)
) STRICT;
CREATE INDEX idx_journal_pending ON journal_ops(state) WHERE state = 'intent';

---------------------------------------------------------------- sources and extraction
CREATE TABLE sources (
  id             TEXT PRIMARY KEY REFERENCES objects(id),
  title          TEXT NOT NULL,
  origin_kind    TEXT NOT NULL CHECK (origin_kind IN ('file','web_capture','owner_authored','legacy_vault')),
  origin_ref     TEXT,
  primary_lang   TEXT NOT NULL DEFAULT 'und' CHECK (primary_lang IN ('ar','en','mixed','und')),
  authority      TEXT NOT NULL DEFAULT 'unrated' CHECK (authority IN ('primary','secondary','tertiary','unrated')),
  state          TEXT NOT NULL DEFAULT 'active' CHECK (state IN ('active','withdrawn','purged')),
  registered_at  TEXT NOT NULL,
  withdrawn_at   TEXT,
  created_by_run TEXT REFERENCES workflow_runs(id)
) STRICT;

CREATE TABLE source_versions (
  id                 TEXT PRIMARY KEY REFERENCES objects(id),
  source_id          TEXT NOT NULL REFERENCES sources(id),
  version_no         INTEGER NOT NULL CHECK (version_no >= 1),
  sha256             TEXT NOT NULL UNIQUE CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
  byte_size          INTEGER NOT NULL CHECK (byte_size >= 0),
  media_type         TEXT NOT NULL,
  original_filename  TEXT NOT NULL,
  storage_relpath    TEXT NOT NULL UNIQUE,
  source_date        TEXT,
  captured_at        TEXT NOT NULL,
  state              TEXT NOT NULL DEFAULT 'present' CHECK (state IN ('present','purged')),
  created_by_run     TEXT REFERENCES workflow_runs(id),
  UNIQUE (source_id, version_no)
) STRICT;

CREATE TABLE extractions (
  id                 TEXT PRIMARY KEY REFERENCES objects(id),
  source_version_id  TEXT NOT NULL REFERENCES source_versions(id),
  extractor          TEXT NOT NULL,
  extractor_version  TEXT NOT NULL,
  status             TEXT NOT NULL CHECK (status IN ('succeeded','partial','failed','needs_ocr')),
  is_active          INTEGER NOT NULL DEFAULT 0 CHECK (is_active IN (0,1)),
  text_sha256        TEXT,
  passage_count      INTEGER NOT NULL DEFAULT 0 CHECK (passage_count >= 0),
  warnings_json      TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(warnings_json)),
  created_at         TEXT NOT NULL,
  UNIQUE (source_version_id, extractor, extractor_version),
  CHECK (is_active = 0 OR status IN ('succeeded','partial'))
) STRICT;
CREATE UNIQUE INDEX uq_extraction_active ON extractions(source_version_id) WHERE is_active = 1;

CREATE TABLE passages (
  id             TEXT PRIMARY KEY REFERENCES objects(id),
  extraction_id  TEXT NOT NULL REFERENCES extractions(id),
  ordinal        INTEGER NOT NULL CHECK (ordinal >= 0),
  locator_json   TEXT NOT NULL CHECK (json_valid(locator_json)),
  text           TEXT NOT NULL CHECK (length(text) > 0),
  text_sha256    TEXT NOT NULL CHECK (length(text_sha256) = 64),
  lang           TEXT NOT NULL DEFAULT 'und' CHECK (lang IN ('ar','en','mixed','und')),
  UNIQUE (extraction_id, ordinal)
) STRICT;
CREATE INDEX idx_passages_hash ON passages(text_sha256);

---------------------------------------------------------------- notes (Markdown registry)
CREATE TABLE notes (
  id              TEXT PRIMARY KEY REFERENCES objects(id),
  note_type       TEXT NOT NULL CHECK (note_type IN
                    ('source','concept','entity','memory','project','decision','research','workflow','dashboard')),
  path            TEXT NOT NULL UNIQUE,
  title           TEXT NOT NULL,
  lang            TEXT NOT NULL DEFAULT 'und' CHECK (lang IN ('ar','en','mixed','und')),
  managed         INTEGER NOT NULL CHECK (managed IN (0,1)),   -- 1 = body generated from SQLite (projection)
  content_sha256  TEXT NOT NULL CHECK (length(content_sha256) = 64),
  revision        INTEGER NOT NULL DEFAULT 1 CHECK (revision >= 1),
  state           TEXT NOT NULL DEFAULT 'active' CHECK (state IN ('active','archived','missing','removed')),
  created_at      TEXT NOT NULL,
  updated_at      TEXT NOT NULL,
  created_by_run  TEXT REFERENCES workflow_runs(id)
) STRICT;

CREATE TABLE note_revisions (
  note_id         TEXT NOT NULL REFERENCES notes(id),
  revision        INTEGER NOT NULL CHECK (revision >= 1),
  content_sha256  TEXT NOT NULL CHECK (length(content_sha256) = 64),
  change_origin   TEXT NOT NULL CHECK (change_origin IN ('system','owner_direct','import')),
  actor           TEXT NOT NULL,
  proposal_id     TEXT REFERENCES proposals(id),
  recorded_at     TEXT NOT NULL,
  PRIMARY KEY (note_id, revision)
) STRICT;

---------------------------------------------------------------- entities and typed relationships
CREATE TABLE entities (
  id              TEXT PRIMARY KEY REFERENCES objects(id),
  entity_type     TEXT NOT NULL CHECK (entity_type IN
                    ('person','organization','place','concept','work','event','other')),
  canonical_name  TEXT NOT NULL,
  canonical_lang  TEXT NOT NULL DEFAULT 'und' CHECK (canonical_lang IN ('ar','en','mixed','und')),
  note_id         TEXT REFERENCES notes(id),
  state           TEXT NOT NULL DEFAULT 'active' CHECK (state IN ('active','merged','retired')),
  merged_into     TEXT REFERENCES entities(id),
  created_at      TEXT NOT NULL,
  CHECK ((state = 'merged') = (merged_into IS NOT NULL)),
  CHECK (merged_into IS NULL OR merged_into <> id)
) STRICT;

CREATE TABLE entity_aliases (
  entity_id   TEXT NOT NULL REFERENCES entities(id),
  alias       TEXT NOT NULL,
  alias_norm  TEXT NOT NULL,
  lang        TEXT NOT NULL DEFAULT 'und' CHECK (lang IN ('ar','en','mixed','und')),
  PRIMARY KEY (entity_id, alias_norm)
) STRICT;
CREATE INDEX idx_alias_norm ON entity_aliases(alias_norm);

CREATE TABLE relationships (
  id           TEXT PRIMARY KEY REFERENCES objects(id),
  subject_id   TEXT NOT NULL REFERENCES objects(id),
  predicate    TEXT NOT NULL CHECK (predicate IN
                 ('SUPPORTS','CONTRADICTS','SUPERSEDES','DEPENDS_ON','RELATES_TO','APPROVED_BY',
                  'AFFECTS','PART_OF','AUTHORED_BY','MENTIONS','DERIVED_FROM')),
  object_id    TEXT NOT NULL REFERENCES objects(id),
  state        TEXT NOT NULL DEFAULT 'proposed' CHECK (state IN
                 ('proposed','verified','disputed','superseded','retracted')),
  valid_from   TEXT,
  valid_to     TEXT,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL,
  proposal_id  TEXT REFERENCES proposals(id),
  CHECK (subject_id <> object_id),
  CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from)
) STRICT;
CREATE UNIQUE INDEX uq_relationship_live ON relationships(subject_id, predicate, object_id, ifnull(valid_from,''))
  WHERE state IN ('proposed','verified','disputed');
CREATE INDEX idx_rel_object ON relationships(object_id, predicate);

---------------------------------------------------------------- projects and decisions
CREATE TABLE projects (
  id          TEXT PRIMARY KEY REFERENCES objects(id),
  slug        TEXT NOT NULL UNIQUE CHECK (slug GLOB '[a-z0-9]*' AND slug NOT GLOB '*[^a-z0-9-]*'),
  name        TEXT NOT NULL,
  state       TEXT NOT NULL CHECK (state IN ('proposed','active','on_hold','completed','cancelled')),
  note_id     TEXT REFERENCES notes(id),
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
) STRICT;

CREATE TABLE project_items (
  id             TEXT PRIMARY KEY REFERENCES objects(id),
  project_id     TEXT NOT NULL REFERENCES projects(id),
  item_type      TEXT NOT NULL CHECK (item_type IN ('milestone','task','risk','dependency','commitment','question')),
  title          TEXT NOT NULL,
  state          TEXT NOT NULL CHECK (state IN ('open','in_progress','blocked','done','dropped')),
  assignee       TEXT,                       -- free-text owner of the item; NULL = the workspace owner
  due_on         TEXT,
  depends_on_id  TEXT REFERENCES objects(id),
  updated_at     TEXT NOT NULL,
  CHECK (depends_on_id IS NULL OR depends_on_id <> id)
) STRICT;
CREATE INDEX idx_items_project ON project_items(project_id, item_type, state);

CREATE TABLE decisions (
  id             TEXT PRIMARY KEY REFERENCES objects(id),
  project_id     TEXT REFERENCES projects(id),
  title          TEXT NOT NULL,
  state          TEXT NOT NULL CHECK (state IN ('proposed','accepted','rejected','superseded','reversed')),
  decided_on     TEXT,
  decided_by     TEXT,
  superseded_by  TEXT REFERENCES decisions(id),
  note_id        TEXT REFERENCES notes(id),
  created_at     TEXT NOT NULL,
  updated_at     TEXT NOT NULL,
  CHECK (state NOT IN ('accepted','rejected') OR decided_on IS NOT NULL),
  CHECK ((state = 'superseded') = (superseded_by IS NOT NULL)),
  CHECK (superseded_by IS NULL OR superseded_by <> id)
) STRICT;

-- Append-only history for projects, items and decisions. As-of reconstruction replays this table.
CREATE TABLE project_events (
  seq           INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id    TEXT REFERENCES projects(id),
  subject_id    TEXT NOT NULL REFERENCES objects(id),
  event_type    TEXT NOT NULL CHECK (event_type IN
                  ('created','state_changed','field_changed','linked','unlinked')),
  payload_json  TEXT NOT NULL CHECK (json_valid(payload_json)),
  effective_at  TEXT NOT NULL,
  recorded_at   TEXT NOT NULL,
  actor         TEXT NOT NULL,
  proposal_id   TEXT REFERENCES proposals(id)
) STRICT;
CREATE INDEX idx_pevents_project ON project_events(project_id, effective_at, seq);
CREATE INDEX idx_pevents_subject ON project_events(subject_id, effective_at, seq);

---------------------------------------------------------------- memory
CREATE TABLE memory_records (
  id                TEXT PRIMARY KEY REFERENCES objects(id),
  kind              TEXT NOT NULL CHECK (kind IN
                      ('semantic','episodic','procedural','decision','project','preference','operational')),
  epistemic_type    TEXT NOT NULL CHECK (epistemic_type IN
                      ('fact','claim','hypothesis','interpretation','preference','decision','prediction')),
  state             TEXT NOT NULL CHECK (state IN
                      ('captured','proposed','verified','disputed','superseded','archived','deleted')),
  subject_id        TEXT REFERENCES objects(id),
  predicate         TEXT,
  project_id        TEXT REFERENCES projects(id),
  current_revision  INTEGER NOT NULL DEFAULT 1 CHECK (current_revision >= 1),
  superseded_by     TEXT REFERENCES memory_records(id),
  review_due_on     TEXT,
  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL,
  CHECK ((state = 'superseded') = (superseded_by IS NOT NULL)),
  CHECK (superseded_by IS NULL OR superseded_by <> id),
  -- only facts and decisions can be 'verified'; other epistemic types stop at 'proposed'/'disputed'
  CHECK (state <> 'verified' OR epistemic_type IN ('fact','decision','preference'))
) STRICT;
CREATE INDEX idx_memory_state ON memory_records(state, kind);
CREATE INDEX idx_memory_subject ON memory_records(subject_id, predicate);

CREATE TABLE memory_revisions (
  memory_id        TEXT NOT NULL REFERENCES memory_records(id),
  revision         INTEGER NOT NULL CHECK (revision >= 1),
  statement        TEXT NOT NULL CHECK (length(statement) > 0),
  statement_lang   TEXT NOT NULL DEFAULT 'und' CHECK (statement_lang IN ('ar','en','mixed','und')),
  value_json       TEXT CHECK (value_json IS NULL OR json_valid(value_json)),
  attestation      TEXT NOT NULL CHECK (attestation IN ('source_evidence','owner_attested','derived')),
  derivation_json  TEXT CHECK (derivation_json IS NULL OR json_valid(derivation_json)),
  event_time       TEXT,
  valid_from       TEXT,
  valid_to         TEXT,
  date_precision   TEXT NOT NULL DEFAULT 'day' CHECK (date_precision IN ('day','month','year','unknown')),
  date_text        TEXT,                     -- date exactly as written in the source (e.g. a Hijri date); never parsed
  change_reason    TEXT NOT NULL,
  actor            TEXT NOT NULL,
  proposal_id      TEXT REFERENCES proposals(id),
  recorded_at      TEXT NOT NULL,
  PRIMARY KEY (memory_id, revision),
  CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from)
) STRICT;

-- Evidence for memory records, relationships and decisions (subject_id -> objects).
CREATE TABLE evidence_links (
  subject_id        TEXT NOT NULL REFERENCES objects(id),
  subject_revision  INTEGER NOT NULL DEFAULT 0 CHECK (subject_revision >= 0),
  passage_id        TEXT NOT NULL REFERENCES passages(id),
  role              TEXT NOT NULL CHECK (role IN ('supports','contradicts','context')),
  quote_sha256      TEXT CHECK (quote_sha256 IS NULL OR length(quote_sha256) = 64),
  anchor_state      TEXT NOT NULL DEFAULT 'current' CHECK (anchor_state IN ('current','stale','source_withdrawn')),
  created_at        TEXT NOT NULL,
  PRIMARY KEY (subject_id, subject_revision, passage_id, role)
) STRICT;
CREATE INDEX idx_evidence_passage ON evidence_links(passage_id);

---------------------------------------------------------------- audit, query log, backups
CREATE TABLE audit_events (
  seq             INTEGER PRIMARY KEY AUTOINCREMENT,
  occurred_at     TEXT NOT NULL,
  actor           TEXT NOT NULL,
  actor_kind      TEXT NOT NULL CHECK (actor_kind IN ('owner','claude_session','scheduler','system')),
  correlation_id  TEXT NOT NULL,
  action          TEXT NOT NULL,
  object_id       TEXT REFERENCES objects(id),
  outcome         TEXT NOT NULL CHECK (outcome IN ('ok','denied','failed')),
  detail_json     TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(detail_json)),
  prev_hash       TEXT NOT NULL CHECK (length(prev_hash) = 64),
  event_hash      TEXT NOT NULL UNIQUE CHECK (length(event_hash) = 64)
) STRICT;
CREATE INDEX idx_audit_corr ON audit_events(correlation_id, seq);
CREATE INDEX idx_audit_object ON audit_events(object_id, seq);

CREATE TABLE query_log (
  seq            INTEGER PRIMARY KEY AUTOINCREMENT,
  occurred_at    TEXT NOT NULL,
  query_text     TEXT NOT NULL,
  query_norm     TEXT NOT NULL,
  filters_json   TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(filters_json)),
  outcome_class  TEXT NOT NULL CHECK (outcome_class IN
                   ('verified_evidence','evidence_unverified','insufficient','contradictory','outdated','no_evidence')),
  result_count   INTEGER NOT NULL CHECK (result_count >= 0),
  top_units_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(top_units_json)),
  latency_ms     INTEGER NOT NULL CHECK (latency_ms >= 0),
  norm_version   TEXT NOT NULL
) STRICT;

CREATE TABLE backups (
  id                TEXT PRIMARY KEY REFERENCES objects(id),
  destination       TEXT NOT NULL,
  manifest_sha256   TEXT NOT NULL CHECK (length(manifest_sha256) = 64),
  total_bytes       INTEGER NOT NULL CHECK (total_bytes >= 0),
  encrypted         INTEGER NOT NULL CHECK (encrypted IN (0,1)),
  state             TEXT NOT NULL CHECK (state IN ('created','verified','restore_tested','failed','expired')),
  created_at        TEXT NOT NULL,
  verified_at       TEXT,
  restore_tested_at TEXT
) STRICT;

---------------------------------------------------------------- derived search index (rebuildable)
CREATE TABLE search_units (
  rowid         INTEGER PRIMARY KEY,
  unit_kind     TEXT NOT NULL CHECK (unit_kind IN ('passage','note_section','memory')),
  unit_id       TEXT NOT NULL UNIQUE,          -- passage id | note id + '#' + ordinal | memory id
  parent_id     TEXT NOT NULL REFERENCES objects(id),
  locator_json  TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(locator_json)),
  lang          TEXT NOT NULL DEFAULT 'und' CHECK (lang IN ('ar','en','mixed','und')),
  text_sha256   TEXT NOT NULL,
  norm_version  TEXT NOT NULL,
  indexed_at    TEXT NOT NULL
) STRICT;
CREATE INDEX idx_units_parent ON search_units(parent_id);

CREATE VIRTUAL TABLE search_fts USING fts5(
  title_norm, text_norm, text_stem,
  tokenize = "porter unicode61 remove_diacritics 2"
);

---------------------------------------------------------------- integrity triggers
-- T1 Append-only tables.
CREATE TRIGGER trg_audit_no_update BEFORE UPDATE ON audit_events
BEGIN SELECT RAISE(ABORT, 'SB-INT-001 audit_events is append-only'); END;
CREATE TRIGGER trg_audit_no_delete BEFORE DELETE ON audit_events
BEGIN SELECT RAISE(ABORT, 'SB-INT-001 audit_events is append-only'); END;
CREATE TRIGGER trg_pevents_no_update BEFORE UPDATE ON project_events
BEGIN SELECT RAISE(ABORT, 'SB-INT-002 project_events is append-only'); END;
CREATE TRIGGER trg_pevents_no_delete BEFORE DELETE ON project_events
BEGIN SELECT RAISE(ABORT, 'SB-INT-002 project_events is append-only'); END;
CREATE TRIGGER trg_noterev_no_update BEFORE UPDATE ON note_revisions
BEGIN SELECT RAISE(ABORT, 'SB-INT-003 note_revisions is append-only'); END;

-- T2 Memory revisions are immutable, except that 'statement' may be blanked by an authorised purge
--    (state 'deleted' on the parent record) so that erasure is possible without breaking history shape.
CREATE TRIGGER trg_memrev_immutable BEFORE UPDATE ON memory_revisions
WHEN NOT (NEW.statement = '[purged]' AND NEW.value_json IS NULL
          AND (SELECT state FROM memory_records WHERE id = OLD.memory_id) = 'deleted'
          AND NEW.memory_id = OLD.memory_id AND NEW.revision = OLD.revision)
BEGIN SELECT RAISE(ABORT, 'SB-INT-004 memory_revisions is immutable'); END;
CREATE TRIGGER trg_memrev_no_delete BEFORE DELETE ON memory_revisions
BEGIN SELECT RAISE(ABORT, 'SB-INT-004 memory_revisions is immutable'); END;

-- T3 Evidence before memory: a source-evidenced fact cannot become verified without a resolvable
--    supporting passage on its current revision.
CREATE TRIGGER trg_memory_verify_needs_evidence BEFORE UPDATE OF state ON memory_records
WHEN NEW.state = 'verified'
 AND (SELECT attestation FROM memory_revisions
       WHERE memory_id = NEW.id AND revision = NEW.current_revision) = 'source_evidence'
 AND NOT EXISTS (
       SELECT 1 FROM evidence_links e
         JOIN passages p         ON p.id = e.passage_id
         JOIN extractions x      ON x.id = p.extraction_id
         JOIN source_versions sv ON sv.id = x.source_version_id
         JOIN sources s          ON s.id = sv.source_id
        WHERE e.subject_id = NEW.id AND e.subject_revision = NEW.current_revision
          AND e.role = 'supports' AND sv.state = 'present' AND s.state = 'active')
BEGIN SELECT RAISE(ABORT, 'SB-MEM-002 verified fact requires resolvable supporting evidence'); END;

-- T4 Derived statements can never be verified (a model summary is not its own source).
CREATE TRIGGER trg_memory_verify_not_derived BEFORE UPDATE OF state ON memory_records
WHEN NEW.state = 'verified'
 AND (SELECT attestation FROM memory_revisions
       WHERE memory_id = NEW.id AND revision = NEW.current_revision) = 'derived'
BEGIN SELECT RAISE(ABORT, 'SB-MEM-003 derived statements cannot be verified'); END;

-- T5 Records may not be inserted directly in a governed end state.
CREATE TRIGGER trg_memory_insert_state BEFORE INSERT ON memory_records
WHEN NEW.state NOT IN ('captured','proposed')
BEGIN SELECT RAISE(ABORT, 'SB-MEM-001 new memory must start as captured or proposed'); END;

-- T6 Legal memory state transitions (the application validates too; this is the last line of defence).
CREATE TRIGGER trg_memory_transition BEFORE UPDATE OF state ON memory_records
WHEN OLD.state <> NEW.state AND NOT (
     (OLD.state = 'captured'   AND NEW.state IN ('proposed','archived'))
  OR (OLD.state = 'proposed'   AND NEW.state IN ('verified','disputed','archived'))
  OR (OLD.state = 'verified'   AND NEW.state IN ('disputed','superseded','archived'))
  OR (OLD.state = 'disputed'   AND NEW.state IN ('verified','superseded','archived'))
  OR (OLD.state = 'superseded' AND NEW.state IN ('archived'))
  OR (OLD.state = 'archived'   AND NEW.state IN ('deleted','proposed')))
BEGIN SELECT RAISE(ABORT, 'SB-MEM-001 illegal memory state transition'); END;

-- T7 A source version row can never have its hash or location rewritten.
CREATE TRIGGER trg_sv_immutable BEFORE UPDATE OF sha256, byte_size, storage_relpath, source_id, version_no ON source_versions
BEGIN SELECT RAISE(ABORT, 'SB-ING-002 source version identity is immutable'); END;

-- T8 An approval can be consumed once and never edited otherwise.
CREATE TRIGGER trg_approval_consume_once BEFORE UPDATE ON approvals
WHEN OLD.consumed_at IS NOT NULL
  OR NEW.payload_sha256 <> OLD.payload_sha256 OR NEW.proposal_id <> OLD.proposal_id
  OR NEW.approver <> OLD.approver OR NEW.expires_at <> OLD.expires_at
BEGIN SELECT RAISE(ABORT, 'SB-AGT-001 approval is single-use and immutable'); END;

-- T9 An approval must match the proposal payload it was issued for.
CREATE TRIGGER trg_approval_hash_match BEFORE INSERT ON approvals
WHEN (SELECT payload_sha256 FROM proposals WHERE id = NEW.proposal_id) <> NEW.payload_sha256
BEGIN SELECT RAISE(ABORT, 'SB-AGT-001 approval hash does not match proposal'); END;

-- T10 Proposal payload is frozen once it leaves draft.
CREATE TRIGGER trg_proposal_payload_frozen BEFORE UPDATE OF payload_json, payload_sha256, tier, proposal_type ON proposals
WHEN OLD.state <> 'draft'
BEGIN SELECT RAISE(ABORT, 'SB-AGT-001 proposal payload is frozen after validation'); END;
```

## 7. Migrations

- Files `src/second_brain/db/migrations/NNNN_name.sql`, numbered from `0001`, applied in order inside one transaction each, recorded with the SHA-256 of the file.
- A recorded checksum that no longer matches its file blocks all writes (TEST-OPS-010).
- Forward-only. Rollback is restoration of the verified backup that `migrate` takes before it starts (FR-OPS-006). Any migration after `0001` is a tier 2 operation.
- A migration that fails its post-checks (`foreign_key_check`, `integrity_check`, row-count expectations it declares) rolls back its transaction.
- Data migrations that rewrite text (for example a normaliser change) do not touch authoritative tables; they mark the index stale.
- The database refuses to open for writing if `schema_migrations` holds a version newer than the software knows.

## 8. Constraint probes executed

| Probe | Result |
|---|---|
| P01 memory cannot be inserted as verified | ok |
| P02 memory inserted as proposed | ok |
| P03 verify without evidence rejected | ok |
| P04 verify with evidence accepted | ok |
| P05 verified -> captured rejected | ok |
| P06 memory revision update rejected | ok |
| P07 memory revision delete rejected | ok |
| P08 superseded without successor rejected | ok |
| P09 hypothesis cannot be verified | ok |
| P10 derived fact cannot be verified | ok |
| P11 supersede with successor accepted | ok |
| P12 source version hash rewrite rejected | ok |
| P13 duplicate sha256 rejected | ok |
| P14 second active extraction rejected | ok |
| P15 audit update rejected | ok |
| P16 audit delete rejected | ok |
| P17 approval with wrong hash rejected | ok |
| P18 approval with matching hash accepted | ok |
| P19 approval consumed once | ok |
| P20 approval second consumption rejected | ok |
| P21 proposal payload change after validation rejected | ok |
| P22 FK: passage with unknown extraction rejected | ok |
| P23 malformed id rejected | ok |
| P24 self-relationship rejected | ok |
| P25 project_events delete rejected | ok |
| P26 decision accepted without date rejected | ok |
| P27 FTS join returns unit | ok |
