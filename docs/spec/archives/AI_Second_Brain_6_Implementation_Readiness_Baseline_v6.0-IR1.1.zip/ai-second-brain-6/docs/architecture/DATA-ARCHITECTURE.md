# Data Architecture

**DOC-DATA** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `DATA-ARCHITECTURE.md` and `TRANSACTION-PROTOCOL.md` of the V6.0 draft (CHG-004, CHG-005). Addresses V5.0 findings 1 and 2 and audit issues ASB6-ISSUE-0008, 0012 and 0013.

## 1. Principles

1. Every data class has exactly one authoritative representation and exactly one component allowed to write it.
2. Anything derived can be deleted and rebuilt from authoritative data with identical results (NFR-021).
3. Nothing authoritative is updated in place when history matters: sources are immutable, revisions are appended, states change, rows are not deleted.
4. Files and SQLite cannot commit atomically together. The design does not claim they do; it makes every intermediate state recoverable (§5).

## 2. Authority map

| # | Data class | Authoritative store | Sole writer | Derived copies | Rebuild path |
|---|---|---|---|---|---|
| 1 | Original source bytes | `data/originals/<aa>/<sha256>` (read-only files) | CMP-STO through the journal | none | none; protected by backup |
| 2 | Source and version metadata | SQLite `sources`, `source_versions` | CMP-ING | source notes (`02-Sources`), frontmatter projections | `notes sync --repair` |
| 3 | Extracted text and passages | SQLite `extractions`, `passages` (retained, versioned) | CMP-EXT | search index | re-extract from originals with the recorded extractor version; older extractions are kept because exact reproduction of an old extractor is not guaranteed |
| 4 | Note body and descriptive frontmatter (title, tags, aliases, free text) of human notes | Markdown files in the vault | the owner in Obsidian, or CMP-NOT applying an approved proposal | `notes` registry row (path, hash, revision), search index | `notes sync` |
| 5 | Governed fields: IDs, states, evidence links, validity, approvals | SQLite | CMP-MEM, CMP-PRJ, CMP-GRF, CMP-PRP | managed frontmatter keys, memory digests, dashboards | projection (§4) |
| 6 | Memory records and revisions | SQLite `memory_records`, `memory_revisions` | CMP-MEM | memory digest notes (`04-Memory`), search index | projection |
| 7 | Entities, aliases, typed relationships | SQLite `entities`, `entity_aliases`, `relationships` | CMP-GRF | entity notes, Obsidian graph view (navigation only) | projection |
| 8 | Projects, items, decisions (current state) and their event history | SQLite `projects`, `project_items`, `decisions`, `project_events` | CMP-PRJ | project and decision note frontmatter, dashboards | replay of `project_events` |
| 9 | Narrative of projects and decisions (context, alternatives, rationale) | Markdown project and decision notes | owner or approved proposal | index | `notes sync` |
| 10 | Workflow runs, journal, proposals, approvals | SQLite | CMP-WFL, CMP-JRN, CMP-PRP | proposal notes (`00-System/Proposals`), dashboards | projection |
| 11 | Audit events | SQLite `audit_events` (append-only, hash-chained) | CMP-AUD | chain head in each backup manifest | none; protected by backup |
| 12 | Search index | none (derived): `search_units`, `search_fts`, `index_state` | CMP-RET | — | `index rebuild` |
| 13 | Query log | SQLite `query_log` (operational, prunable) | CMP-RET | benchmark candidates | not rebuilt |
| 14 | Embeddings | not present in v1 (ADR-006) | — | — | — |
| 15 | Configuration | `config/second-brain.toml`, `.claude/` files in the operating home | owner in a terminal (tier 2) | hashes checked by `workspace verify` | reinstall from package |

Two consequences the earlier drafts left open:

- **A note never holds governed truth.** A frontmatter line `status: verified` is a display of the database value. Editing it changes nothing and is reported as drift (FR-KNW-005).
- **The owner's prose is never overwritten by the system.** The system writes a human note only by applying a proposal whose base content hash still matches the file (compare-and-swap); otherwise the proposal becomes `conflict`.

## 3. Layout and data map

Two directory trees (ADR-014):

```
~/Developer/ai-second-brain/         development repository (Git): code, tests, docs. No knowledge data.
~/SecondBrain/                       operating home (SECOND_BRAIN_HOME). Not the code repository.
├── CLAUDE.md, .claude/              operating instructions, rules, skills, settings (installed, hash-verified)
├── config/second-brain.toml
├── vault/                           Obsidian vault; local Git repository for note history (D-16)
│   ├── 00-System/  Templates/, Proposals/ (managed)
│   ├── 01-Inbox/   drop zone; .processed/, .rejected/
│   ├── 02-Sources/ one managed note per source
│   ├── 03-Knowledge/ Concepts/, Entities/, Research/  (human notes)
│   ├── 04-Memory/  managed digests: by-subject/, by-project/, unfiled/
│   ├── 05-Projects/ <slug>/ project note and free notes
│   ├── 06-Decisions/
│   ├── 07-Dashboards/ (managed)
│   └── _attachments/ (unmanaged)
└── data/
    ├── originals/<aa>/<sha256>      mode 0444, directories 0755
    ├── db/second_brain.sqlite3      (+ -wal, -shm)
    ├── staging/<run-id>/            mode 0700; same volume as vault and originals
    ├── quarantine/                  never read by the system again; owner disposes
    ├── locks/writer.lock
    ├── logs/                        JSON Lines, 10 files x 10 MB
    └── exports/
<backup destination, outside the home>   see DEPLOYMENT-SPECIFICATION §6
```

Where knowledge content resides, completely: the vault, `data/originals`, the SQLite file, the staging and quarantine directories while in use, backups, the vault's Git history, exports the owner creates, and the context of any Claude Code session the owner runs (which is transmitted to Anthropic). Logs and audit events hold identifiers and metadata, never content (FR-OPS-008).

## 4. Synchronisation between Markdown and SQLite

There is no file watcher. Reconciliation happens when a command runs: `notes sync` explicitly, and a lightweight sync at the start of every mutating command for the notes that command touches.

| Situation detected | Rule | Result |
|---|---|---|
| File with valid frontmatter and unknown `id` (or no `id`) in a human-note folder | Adopt | Register note (new ID written into frontmatter through the journal if absent), revision 1, origin `owner_direct` |
| Registered note, content hash changed, managed keys unchanged | Adopt | Revision n+1, origin `owner_direct`, re-index. No approval: the owner made the change |
| Registered note, a managed key's parsed value differs from the database | Drift | Finding OBS-D01; database wins; `--repair` rewrites the projection; body edits in the same file are still adopted |
| Registered note found at a different path (same `id`) | Move | Update `notes.path` |
| Two files with the same `id` | Collision | Finding OBS-R03; neither is adopted until the owner resolves it |
| Registered note file absent | Missing | `notes.state = missing`; history, links and evidence untouched; restored automatically if the file reappears |
| File in a managed folder (`04-Memory`, `07-Dashboards`, `00-System/Proposals`) edited by hand | Managed overwrite | Reported as drift; regenerated on next projection. Managed files carry a first-line comment saying so |
| File fails schema validation | Invalid | Reported; not registered; never modified |
| Proposal to write a human note whose base hash no longer matches | Conflict | Proposal state `conflict`; file untouched; staged content kept in the proposal for re-basing |

Managed frontmatter keys (projection, never authoritative in the file): `id`, `type`, `schema_version`, `status`, `source_ids`, `evidence`, `valid_from`, `valid_to`, `superseded_by`, `project`, `created_at`, `updated_at`, `revision`. Owner keys (authoritative in the file): `title`, `aliases`, `tags`, `lang`, `dir`, and any key not in the schema, which is preserved verbatim.

## 5. Commit and recovery protocol

Applies to every workflow run that changes a file. A run changes at most one original and one note group (a note plus its projection); batch operations are sequences of runs.

Rules: **C-1** one writer at a time (§6). **C-2** staging, vault and originals are on the same volume; `init` and `doctor` verify this (rename across volumes is not atomic). **C-3** durability uses `fsync` on the file and its directory, with `F_FULLFSYNC` on macOS (to be verified, V-10). **C-4** every step is idempotent. **C-5** recovery never deletes an original and never overwrites content it did not write.

| Step | Action | Durable state after the step |
|---|---|---|
| S0 | Acquire writer lock; run recovery if any `journal_ops.state = 'intent'` exists | — |
| S1 | Validate inputs, policy and approvals. No side effect | nothing |
| S2 | Write new file content into `data/staging/<run>/`; compute SHA-256; fsync | staged files, no journal |
| S3 | Transaction A: insert `workflow_runs` (state STAGED, `checkpoint_json` holding the complete database change plan) and one `journal_ops` row per file operation with `expected_prev_sha256` and `new_sha256`, state `intent` | intent is durable |
| S4 | For each operation in order: verify the target currently has `expected_prev_sha256` (or does not exist); `rename` staged file onto target; fsync directory | files in place |
| S5 | Transaction B: apply the database change plan, mark journal rows `done`, set run COMMITTED, set `index_state.dirty = 1`, append audit events | **commit point** |
| S6 | Transaction C: apply the index delta; clear `dirty`; run COMPLETED | index current |
| S7 | Remove the staging directory; release lock | — |

Recovery table (crash points referenced by tests as CP1..CP7):

| Crash point | What recovery finds | Action |
|---|---|---|
| CP1 after S2, before S3 commits | Staging directory with no run row | Move directory to `quarantine/`; no canonical change |
| CP2 after S3, before any rename | Intent rows; all targets still at `expected_prev` | Staged files present and hashes match: continue at S4. Otherwise mark operations `undone`, run FAILED_ROLLED_BACK |
| CP3 during S4 | Some targets at `new_sha256`, others at `expected_prev` | Continue remaining renames, then S5 |
| CP4 after S4, before S5 commits | All targets at `new_sha256`; no domain rows | Apply the stored change plan (S5): roll forward |
| CP5 after S5, before S6 | Run COMMITTED, `dirty = 1` | Re-run the index delta; if it cannot be derived, set stale and require `index rebuild` |
| CP6 during S6 | Same as CP5 (transaction C rolled back by SQLite) | Same as CP5 |
| CP7 after S6, before S7 | Run COMPLETED, staging directory remains | Remove staging directory |
| Any | A target whose hash is neither `expected_prev` nor `new` (the owner edited the note in the window) | Mark the operation `quarantined`, keep the staged file in quarantine, set run FAILED_CONFLICT and the proposal `conflict`. The owner's content stays |
| Any | A combination not in this table | Enter read-only mode: every mutating command fails with E_INTEGRITY until the owner resolves it using runbook RB-04 |

Invariants checked after every recovery and by the randomised crash test (INV-01..INV-12): originals match their hashes; every `source_versions` row has its file and every file under `originals` has a row or is reported; no `intent` rows remain outside read-only mode; every `notes` row matches a file hash or is `missing`; foreign keys hold; no verified source-evidenced memory lacks live evidence; at most one active extraction per version; audit chain verifies; index is current or flagged; no two runs share an idempotency key; staging holds only directories of open runs; ID sequences exceed every allocated ID.

## 6. Concurrency

- Single writer, enforced by an exclusive `flock` on `data/locks/writer.lock`, held for the whole run. The operating system releases it if the process dies, so there is no stale-lock recovery. A second writer waits up to the busy timeout (default 5 s) and then fails with E_CONFLICT.
- Readers (search, show, doctor) take no lock and use SQLite WAL snapshots, so they are not blocked by a writer.
- Obsidian is an uncoordinated writer of human notes. The protocol treats it as such: compare-and-swap on content hash at S4, and the conflict rule above.
- One device. Two machines writing the same home is unsupported in v1 (D-12).

## 7. Identifiers, versions and naming

- IDs: three-letter type prefix, hyphen, zero-padded sequence of at least six digits (`SRC-000042`). Allocated from `id_sequences` inside the creating transaction, never reused, registered in `objects` (ADR-016). Prefixes: SRC, SVR, EXT, PSG, NOT, MEM, ENT, REL, PRJ, ITM, DEC, PRP, APR, WFR, BKP.
- Versions carried by data: `schema_migrations.version` (database), `schema_version` (note frontmatter), `extractor_version` (extractions), `norm_version` (index), `benchmark_version` (evaluation), `policy_version` (tier table).
- Filenames: Unicode NFC; human notes are named by title, managed notes by ID or subject (D-14); no path separators, control characters or bidi overrides (FR-OBS-003).
- Locators (`passages.locator_json`), by media type: `{"kind":"pdf","page":12,"block":3,"char_start":1840,"char_end":2710}`; `{"kind":"docx","para_start":44,"para_end":47}`; `{"kind":"md"|"html","heading_path":["…","…"],"char_start":…,"char_end":…}`; `{"kind":"txt","line_start":…,"line_end":…}`. Offsets refer to the extraction text identified by `extractions.text_sha256`. `page` is present only when the format has pages.

## 8. Retention and deletion

| Operation | Tier | Effect on authoritative data | Derived data | Backups | Audit |
|---|---|---|---|---|---|
| Archive (memory, note) | 1 | State change; content kept | Removed from default search | unchanged | event |
| Withdraw source | 1 | `sources.state = withdrawn`; bytes kept | Passages unindexed; evidence flagged | unchanged | event with impact report |
| Supersede | 1 | State change, pointer, validity closed | Both re-indexed | unchanged | event |
| Remove note file (owner deletes in Obsidian) | 0 | `notes.state = missing`; rows kept | Sections unindexed | unchanged | event |
| Purge memory | 2 | Statement and value blanked to `[purged]`; row, revision numbers and tombstone kept | Unindexed; projection regenerated | Report lists every backup that still contains the text and when it expires; the owner may expire them early | event (no content) |
| Purge source | 2 | Stored file removed through the journal; `source_versions.state = purged`; passages text blanked; evidence links flagged | Unindexed | same report | event |
| Physical row deletion | never in v1 | — | — | — | — |

Retention (proposed, decision D-06): backups 14 daily and 8 weekly; query log 180 days; logs 10 files of 10 MB; quarantine until the owner clears it; audit events and project events for the life of the system; proposals and workflow runs kept indefinitely (small). Provenance outlives deletion: a purged record still shows that something existed, when it was purged and under which approval, without its content.
