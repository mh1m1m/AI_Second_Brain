# Knowledge Graph

**DOC-KG** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Addresses V5.0 finding 6. Supersedes `KNOWLEDGE-GRAPH.md` of the V6.0 draft, whose DDL allowed edges only between entities while its text required edges between claims, sources and decisions (CHG-006).

## 1. Four things that are not the same

| Thing | What it is here | Authoritative? |
|---|---|---|
| Wikilink | Navigation between notes, written by the owner or by templates | In the note; carries no typed meaning |
| Obsidian graph view | A picture of wikilinks | No; never read by the system |
| Typed relationship | A row in `relationships`: subject, predicate, object, state, validity, evidence | Yes (SQLite) |
| Graph database | Not used (ADR-007) | — |

Wikilinks never create relationship rows (TEST-KNW-009). Relationship rows are projected into notes as a generated "Relationships" section.

## 2. Nodes

Any row in `objects` can be a subject or object: source, passage, note, memory record, entity, project, project item, decision. Entities have a type: person, organization, place, concept, work, event, other.

## 3. Predicates

| Predicate | Meaning | Typical subject → object | Evidence needed to verify | Acyclic |
|---|---|---|---|---|
| SUPPORTS | Subject is evidence for object | passage or memory → memory or decision | the passage itself | — |
| CONTRADICTS | Subject and object cannot both hold in the same period (symmetric; stored once, lower ID first) | memory ↔ memory | both records' evidence | — |
| SUPERSEDES | Subject replaces object from a date | memory → memory; decision → decision; source version → source version | approval | yes |
| DEPENDS_ON | Subject cannot complete before object | project item → project item or project | none (owner statement) | yes |
| PART_OF | Subject is a component of object | entity → entity; note → project | optional | should be; not enforced (RT-D05) |
| AFFECTS | Subject changes the state or scope of object | decision → project or item | optional | — |
| APPROVED_BY | Subject was approved by object | decision → person or organization | supporting passage | — |
| AUTHORED_BY | Subject was written by object | source → person or organization | source metadata or passage | — |
| MENTIONS | Subject refers to object | passage or note → entity | none; never verified, stays proposed | — |
| DERIVED_FROM | Subject was produced from object | memory → memory; note → source | derivation record | yes |
| RELATES_TO | Unspecified association; last resort | any → any | none; cannot be verified | — |

The vocabulary is a CHECK constraint. Adding a predicate or entity type is a schema migration with an ADR. States: `proposed → verified | disputed`; `verified → disputed | superseded | retracted`; `disputed → verified | retracted`. Rows are never deleted.

## 4. Entity resolution

- Each entity has one canonical name and any number of aliases in Arabic and English; `alias_norm` is the alias after normaliser `ar-en-1`.
- Matching is exact equality on `alias_norm` and nothing else. No fuzzy matching, no transliteration guessing, no model-decided merging.
- A new entity whose alias equals an existing alias is created and reported as a merge candidate; merging is a tier 1 proposal.
- Merge keeps both rows: the loser becomes `merged` with `merged_into` set, and its aliases are copied to the survivor. Relationship and memory rows are **not rewritten**; readers resolve an entity ID through `merged_into`. Unmerging is therefore a state change back to `active` plus removal of the copied aliases, also tier 1.
- The link between an Arabic and an English name for the same thing is made by the owner approving a merge or adding an alias. Claude may propose it with evidence.

## 5. Queries

Traversal uses recursive common table expressions in SQLite, limited to depth 3 by default.

```sql
-- everything that (transitively) supports a memory record, with the originals behind it
WITH RECURSIVE sup(id, depth) AS (
  SELECT :memory_id, 0
  UNION
  SELECT r.subject_id, sup.depth + 1 FROM relationships r JOIN sup ON r.object_id = sup.id
   WHERE r.predicate IN ('SUPPORTS','DERIVED_FROM') AND r.state = 'verified' AND sup.depth < 3)
SELECT o.id, o.object_type, sup.depth FROM sup JOIN objects o ON o.id = sup.id;
```

Multi-hop retrieval quality is unmeasured. It is evaluated only under gate RET-G2.

## 6. Gate for a graph database

Reconsider ADR-007 only when all hold: a required query cannot be expressed as a CTE of depth ≤ 5; or measured p95 for required traversals exceeds 2 s at the owner's real scale; and the migration and operating cost has been written down. Evidence must be a recorded measurement.

## 7. Projection

Entity notes (`03-Knowledge/Entities/`) are human notes with a managed "Relationships" section and managed `aliases` (Obsidian's own `aliases` property, so both names find the note). The graph view will show wikilinks only; that is expected.
