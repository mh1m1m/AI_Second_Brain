# Markdown and Obsidian Schemas

**DOC-OBS** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Schema version 1. Supersedes `OBSIDIAN-SCHEMAS.md` of the V6.0 draft. Addresses audit issue ASB6-ISSUE-0012 together with DATA-ARCHITECTURE §4.

Obsidian facts relied on (Obsidian Help and changelog, checked 2026-11-10; to be confirmed on the installed version, V-11): properties are YAML frontmatter; property types are text, list, number, checkbox, date, date & time and tags; `tags`, `aliases` and `cssclasses` are built-in list properties; nested properties are not supported by the properties editor; internal links inside properties must be quoted; right-to-left and mixed-direction text has been supported natively since version 1.6. Nothing here depends on a community plugin.

## 1. Markdown dialect

CommonMark with: YAML frontmatter as the first block; wikilinks `[[Note]]`, `[[Note|label]]`, `[[Note#Heading]]`, `[[Note#^block]]`; block anchors `^ID` at the end of a block; tags in frontmatter only (generated notes do not use inline `#tags`). No HTML, no plugin syntax (no Dataview, no Templater), so every note reads correctly in any Markdown viewer.

## 2. Folders

| Folder | Contents | Written by | Managed |
|---|---|---|---|
| `00-System/Templates/` | One template per note type | installer | yes |
| `00-System/Proposals/` | One note per open proposal: what, why, diff, evidence, approval command | CLI | yes |
| `01-Inbox/` | Files to ingest; `.processed/`, `.rejected/` | owner drops; CLI moves | no |
| `02-Sources/` | One note per source: metadata, versions, extraction status, link to original | CLI | yes (owner may add a free "Notes" section below the marker) |
| `03-Knowledge/Concepts/`, `Entities/`, `Research/` | Human notes | owner; CLI by proposal | no |
| `04-Memory/by-subject/`, `by-project/`, `unfiled/` | Memory digests | CLI | yes |
| `05-Projects/<slug>/` | Project note plus any free notes | owner; CLI by proposal | project note: frontmatter managed, body owner |
| `06-Decisions/` | Decision notes | owner; CLI by proposal | frontmatter managed, body owner |
| `07-Dashboards/` | Generated tables | CLI | yes |
| `_attachments/` | Images and files embedded in notes | owner | no; unmanaged, not registered, backed up with the vault |

Managed files begin, after frontmatter, with the line `%% managed by second-brain — edits here are overwritten %%` (an Obsidian comment, invisible in reading view). In partly managed notes the system writes only between `%% sb:begin <section> %%` and `%% sb:end <section> %%` markers.

## 3. Properties

Flat YAML only: scalars and lists of scalars. Keys are lowercase ASCII with underscores. Unknown keys are preserved untouched.

Common to every registered note:

| Key | Obsidian type | Required | Authority | Allowed values / format |
|---|---|---|---|---|
| `id` | text | yes (assigned on first sync if absent) | managed | `NOT-` + 6 or more digits for human notes; the object ID for managed notes |
| `type` | text | yes | managed | `source`, `concept`, `entity`, `memory`, `project`, `decision`, `research`, `workflow`, `dashboard` |
| `schema_version` | number | yes | managed | `1` |
| `title` | text | yes | owner | one line, NFC, no control or bidi-override characters |
| `status` | text | yes | managed | per type, below |
| `created_at`, `updated_at` | date & time | yes | managed | `YYYY-MM-DDTHH:MM:SS` (UTC; Obsidian's date-time format has no zone suffix) |
| `lang` | text | yes | owner (default from detection) | `ar`, `en`, `mixed`, `und` |
| `dir` | text | yes | owner (default from detection) | `rtl`, `ltr`, `auto` |
| `tags` | tags | no | owner | list of strings; generated notes add `sb/<type>` |
| `aliases` | list | no | owner; for entity notes managed from `entity_aliases` | list of strings |
| `revision` | number | yes | managed | integer ≥ 1 |

Per type:

| Type | Extra required keys | `status` values | Required body sections |
|---|---|---|---|
| source | `source_id`, `sha256`, `media_type`, `source_date` (may be empty), `authority`, `extraction_status` | `active`, `withdrawn`, `purged` | Summary (owner or proposal), Versions (managed), Extraction (managed) |
| concept | `source_ids` (list, may be empty) | `draft`, `reviewed` | free |
| entity | `entity_id`, `entity_type` | `active`, `merged`, `retired` | Relationships (managed), free |
| memory (digest) | `subject_id` or `project` or `period` | `current` | generated |
| project | `project_id`, `slug` | `proposed`, `active`, `on_hold`, `completed`, `cancelled` | Goal, Scope, Status (managed), Items (managed), Decisions (managed), Log (owner) |
| decision | `decision_id`, `project` (may be empty), `decided_on` (may be empty), `superseded_by` (may be empty), `evidence` (list of passage IDs) | `proposed`, `accepted`, `rejected`, `superseded`, `reversed` | Context, Options considered, Decision, Consequences |
| research | `question`, `source_ids` | `open`, `answered`, `abandoned` | Question, Findings (each finding cites a unit ID), Open points. Findings are interpretations unless promoted to memory by proposal |
| workflow (proposal note) | `proposal_id`, `tier`, `expires_at` | proposal states | generated |
| dashboard | — | `current` | generated |

Example (concept note with Arabic title):

```yaml
---
id: NOT-000042
type: concept
schema_version: 1
title: الحوكمة الرشيدة
status: draft
created_at: 2026-11-10T09:00:00
updated_at: 2026-11-10T09:00:00
lang: ar
dir: rtl
revision: 1
source_ids:
  - SRC-000012
aliases:
  - Good governance
tags:
  - sb/concept
---
```

## 4. Templates

Eight templates in `00-System/Templates/` (source, concept, entity, project, decision, research, proposal, dashboard), each consisting of the frontmatter for its type with empty values and its required section headings. Section headings are written in the note's language: English headings for `lang: en`, Arabic for `ar` and `mixed` (heading text table in the template file; the validator matches either language's heading for a required section).

## 5. Validation rules

| Rule | Check | Severity |
|---|---|---|
| OBS-R01 | Frontmatter is the first block and parses as a YAML mapping | error |
| OBS-R02 | `id` matches the pattern for the note's type | error |
| OBS-R03 | `id` is unique in the vault | error (both files) |
| OBS-R04 | `type` is in the vocabulary and consistent with the folder | error |
| OBS-R05 | `schema_version` is a supported integer | error |
| OBS-R06 | `title` is one non-empty NFC line without control or bidi-override characters | error |
| OBS-R07 | Date and date-time properties match their formats and are real dates | error |
| OBS-R08 | `status` is allowed for the type | error |
| OBS-R09 | Every ID in `source_ids`, `evidence`, `superseded_by`, `project` exists in the registry | error |
| OBS-R10 | Properties are flat; list items are scalars | error |
| OBS-R11 | Required body sections for the type are present | warning |
| OBS-R12 | `tags` and `aliases` are lists of strings | error |
| OBS-R13 | `lang` and `dir` have allowed values | error |
| OBS-R14 | Path and filename are NFC, at most 120 characters, without `/ \ : * ? " < > \|`, control or bidi-override characters | error |
| OBS-R15 | No file or folder named `CLAUDE.md`, `CLAUDE.local.md`, `AGENTS.md`, `.mcp.json`, `.claude` anywhere in the vault (finding SEC-F01) | critical |
| OBS-R16 | Filename looks like a sync conflict copy (`(conflicted copy)`, `(conflict …)`, trailing ` 2`) of a registered note | warning |
| OBS-D01 | A managed key's **parsed value** differs from the database value (drift). Comparison is on parsed YAML values, so re-quoting, reordering or re-indenting by Obsidian's property editor is not drift | warning; repaired by `notes sync --repair` |

## 6. Language and direction

- Detection (deterministic): count Arabic-script and Latin-script letters in title plus body; ≥ 80% Arabic → `lang: ar`, `dir: rtl`; ≥ 80% Latin → `en`, `ltr`; otherwise `mixed`, `auto`; no letters → `und`, `auto`. The owner may override both keys.
- All text is stored in logical order. The system never inserts direction marks, embeddings or overrides into notes. Input containing U+202A–U+202E or U+2066–U+2069 in a title, filename or identifier is rejected; in body text it is preserved and reported by `validate` as information.
- `dir` is this system's own property, used by its renderers and available to a CSS snippet if the owner wants one. Obsidian's built-in handling decides paragraph direction on screen. Whether generated mixed-direction notes read well is an acceptance test on the owner's Mac (TEST-OBS-005), not an assumption.
- Property keys, IDs, folder names and status values stay ASCII so that properties, queries and paths behave the same in both directions.
- In tables that mix Arabic text and IDs, each cell holds one direction where possible (ID in its own column).

## 7. Names, links, attachments

- Human notes are named by title (`الحوكمة الرشيدة.md`); managed notes by ID or subject (`SRC-000012.md`, digest `<subject title>.md`). Decision D-14.
- Identity is the `id` property. Renaming or moving a file in Obsidian changes nothing else.
- Generated links use `[[<current filename>|<title>]]` and are regenerated at each projection, so they follow renames after the next `notes sync`.
- Links to memory records use block anchors in digests: `[[<digest>#^MEM-000101]]`.
- Attachments live in `_attachments/` (set as Obsidian's default attachment folder). They are not registered and not indexed. A file that should count as evidence must be ingested as a source.

## 8. Obsidian configuration installed

`.obsidian/app.json`: attachment folder `_attachments`, new-note location `03-Knowledge`, "use Wikilinks" on, "automatically update internal links" on. `.obsidian/core-plugins.json`: file explorer, search, backlinks, outgoing links, properties view, templates (folder `00-System/Templates`), graph view. No `community-plugins.json`. Restricted mode stays on. Exact file contents are verified against the installed Obsidian version in TASK-0302; if the format differs, the installer leaves `.obsidian` absent and the owner applies the four settings by hand.

## 9. Schema evolution

A change to required keys, allowed values or rules increments `schema_version`, ships a migration that rewrites managed keys only, and is recorded in the ADR register. Notes at an older version remain valid until migrated; the validator knows every released version.
