# Agentic Architecture

**DOC-AGT** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `AGENTIC-ARCHITECTURE.md` and `AGENT-RESPONSIBILITY-MATRIX.md` of the V6.0 draft. Addresses V5.0 findings 4, 7 and 8.

## 1. Allocation of responsibility

| Responsibility | Done by | Why |
|---|---|---|
| Understanding a request, planning, choosing queries, reformulating, synthesising an answer, drafting notes and proposals | Claude Code (one interactive session, one orchestrator) | Needs language understanding |
| Hashing, deduplication, type detection, extraction, segmentation, normalisation | Deterministic Python | Must be reproducible and testable |
| Search, ranking, outcome classification, citation resolution | Deterministic Python | Evaluation needs determinism |
| Validation of proposals, conflict detection by key, state transitions, approval checks | Deterministic Python + SQLite constraints | The gate must not depend on model behaviour |
| File and database commits, recovery, index maintenance, backup, restore, audit | Deterministic Python | Integrity |
| Scheduling | macOS launchd running deterministic commands | Survives sessions; no unattended model (FR-AGT-008) |
| Approving consequential changes, resolving conflicts, labelling the benchmark, rating source authority | The owner | Judgement and accountability |
| Independent review of specifications and code in the development repository | One read-only subagent (`spec-reviewer`), development repository only | Context isolation and a second read; justified use |

There are no persistent agents and no agent-per-responsibility. The 16 roles in the engineering directive are review perspectives.

## 2. How Claude Code, the CLI and Obsidian fit together

```mermaid
flowchart LR
  O[Owner] -->|asks, approves| CC[Claude Code session in ~/SecondBrain]
  O -->|reads, edits notes| OB[Obsidian]
  O -->|tier 2 approvals, maintenance| T[Terminal]
  CC -->|second-brain … --json| CLI[second-brain CLI]
  T --> CLI
  L[launchd] -->|backup, doctor| CLI
  CLI --> DB[(SQLite)]
  CLI --> OR[originals]
  CLI --> V[vault Markdown]
  OB <--> V
  CC -. reads notes read-only .-> V
```

Three ways to connect Claude Code to an Obsidian vault were considered:

| Method | Verdict |
|---|---|
| A. Claude Code reads and edits vault files directly | Rejected as the write path. Reading notes is allowed; writing bypasses validation, provenance and approval |
| B. Claude Code calls a validated CLI that owns all writes | **Chosen.** Testable, auditable, works with Obsidian closed |
| C. An Obsidian MCP server | Not in version 1 (ADR-018). It would add third-party code with file access and no benefit over B |

Claude Code does not run inside Obsidian and does not control the Obsidian application. They share the vault folder. The owner uses Claude Code to ask, research and propose; Obsidian to read, navigate, edit prose and review proposal notes.

## 3. Session model

- The owner starts `claude` in `~/SecondBrain`. The operating `CLAUDE.md`, rules, skills and settings load from that folder (CLAUDE-CODE-CONTRACTS).
- No system state lives in a session. Everything durable is in SQLite and the vault. A session that ends, is compacted, or crashes loses nothing the system depends on.
- Claude Code's own auto memory is switched off in this workspace: it is a second, ungoverned memory store that would bypass the evidence rules.
- Development of the software happens in a different folder with different instructions and no access to the knowledge data (ADR-014).

## 4. Agentic retrieval ("agentic RAG") contract

Ordinary retrieval asks once and answers. Here Claude may ask again, in a bounded way, using only read-only commands. The `answer-with-evidence` skill specifies:

1. Restate the question in one line and identify its language, entities and time scope.
2. `second-brain search "<question terms>" --json` with filters that follow from the question (project, dates, language).
3. Read `outcome`. Then:
   - `verified_evidence`: go to step 5.
   - `contradictory`: retrieve both sides (`memory show`), go to step 5 and present both.
   - `outdated`: say so; search for newer sources; go to step 5.
   - `evidence_unverified`, `insufficient`, `no_evidence`: reformulate — synonyms, the other language, entity aliases (`entities resolve`), narrower or broader scope — and search again.
4. Stop searching after six searches for one question, or earlier when two consecutive searches add no new unit IDs.
5. Answer. Every factual sentence carries the unit ID it rests on (`PSG-…` or `MEM-…`). Separate what verified memory states, what sources say, and what is the model's own inference. If nothing supports an answer, say that nothing in the Second Brain supports it. Report the outcome class and `unextracted_sources` if any.
6. Never cite a note section or a summary as the source of a fact when a passage exists; never present a proposed record as verified.
7. Offer, do not perform, follow-up proposals (for example a memory proposal for a well-supported fact).

What is enforced and what is guidance: outcome classes, evidence resolution, state labels and payload size are computed by code. The budget, the stopping rule and the citation discipline are instructions; a session can ignore them, which is why acceptance tests check answers against `evidence show` (TEST-ACC-002, TEST-ACC-003). The trace of a question is the `query_log` rows of the session; which hits the model chose to use is not recorded.

## 5. Approval tiers

Policy version 1. `policy.tier_of()` must return exactly this table (TEST-AGT-007).

| Operation | Tier | Channel |
|---|---|---|
| ingest, re-extract, inbox sweep | 0 | — |
| notes sync (adopt owner edits), create a new human note, link check | 0 | — |
| memory: capture, propose, archive a captured or proposed record | 0 | — |
| entity create, relationship propose, alias add | 0 | — |
| project create, item add/edit/state, decision record as proposed | 0 | — |
| index rebuild, dashboards build, backup create, restore-test, export, doctor | 0 | — |
| memory: verify, dispute, supersede, correct a verified record, archive a verified record, unarchive | 1 | in-session prompt or terminal |
| relationship verify/retract, entity merge/unmerge | 1 | in-session prompt or terminal |
| decision accept/reject/supersede/reverse, project state change, any back-dated change | 1 | in-session prompt or terminal |
| source withdraw, source authority rating, system edit of an existing human note | 1 | in-session prompt or terminal |
| owner-attested memory (create and verify) | 1 | terminal, or in-session prompt on the `memory attest` command |
| purge (memory or source), early backup expiry | 2 | terminal with typed confirmation |
| restore, schema migration after 0001, init | 2 | terminal with typed confirmation |
| configuration or policy change, `workspace install --force`, schedule install/remove | 2 | terminal with typed confirmation |
| enabling any integration (MCP server, plugin, network access) | 2 | terminal, plus an ADR |
| legacy vault import commit or rollback | 2 | terminal with typed confirmation |

No path exists for: changing an original in place; editing or deleting audit events, memory revisions, project events or note revisions; approving from a non-terminal for tier 2; network access by the Python package.

**In-session approval** means Claude Code shows its permission prompt for the exact command `second-brain proposals approve PRP-… --hash ……` because that command pattern is an `ask` rule, and the owner accepts it. The CLI cannot itself tell a human keystroke from an agent; the assurance comes from the layers in SECURITY-ARCHITECTURE §5 and must be verified on the target machine (V-06). The owner may switch tier 1 to terminal-only in configuration (decision D-08).

## 6. Skills (operating workspace)

| Skill | Purpose | Commands it may run without prompting | Produces |
|---|---|---|---|
| `answer-with-evidence` | §4 | `search`, `evidence show`, `memory show`, `memory history`, `entities resolve`, `projects status` | A cited answer |
| `ingest-document` | Register files or sweep the inbox and report | `ingest`, `sources show`, `doctor` | Report: registered, duplicate, rejected, needs OCR |
| `propose-memory` | Draft memory candidates from passages of one source | `search`, `evidence show`, `memory propose` | Proposal IDs; never approves |
| `review-project` | Resume or review a project from records | `projects status`, `projects show`, `decisions list`, `search` | Cited status; item proposals |
| `reconcile-conflict` | Present both sides of a conflict and draft a resolution | `memory show`, `memory history`, `evidence show`, `memory propose` | A compound proposal for the owner |

Skills contain instructions and no scripts. They follow the documented `SKILL.md` format (CLAUDE-CODE-CONTRACTS §4).

## 7. Subagents

None in the operating workspace; the `Agent` tool is denied there, which removes parallel sessions writing proposals and keeps every action in one visible transcript. One in the development repository: `spec-reviewer`, tools `Read, Grep, Glob`, used to review a change against the specification before commit. Further subagents need an ADR showing a measured benefit.

## 8. Hooks

No hooks in version 1. Reasons: hooks run with the owner's full privileges outside the sandbox; a hook that fails open is worse than no hook; the controls a hook would provide are already supplied by permission rules, the sandbox and the CLI gate. A `PreToolUse` hook is a candidate later as an additional layer, never as the only one.

## 9. MCP and other integrations

None installed. Policy for any future addition: an ADR naming publisher, version pin, tools exposed, data it can reach, credentials (Keychain reference only), and trust boundary; tier 2 approval; `doctor` inventory check; no server that fetches external content into a session that can also write proposals.

## 10. Execution governance classes

| Class | Examples | Rule |
|---|---|---|
| Read-only | search, show, status, doctor, validate | Always allowed |
| Proposed modification | any `… propose`, tier 0 creations | Allowed; visible; reversible by archive |
| Approved modification | tier 1 operations | Needs an approval bound to the proposal hash |
| Restricted | tier 2 operations | Terminal only, typed confirmation |
| Prohibited | list in §5 | No code path |
