# Low-Level Design

**DOC-LLD** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Interface contracts and pseudocode only; no implementation code. Per-file detail (purpose, interfaces, dependencies, requirements, tests, phase) is in FILE-BUILD-PLAN.md. Signatures use Python 3.12 type syntax.

## 1. Package

`src/second_brain/` — one distribution, one console script `second-brain = second_brain.cli.main:main`.

## 2. Dependency rule

```
cli → workspace, operations → {memory, projects, knowledge, retrieval, ingestion} → workflows → storage → {db, audit} → {paths, config, text, errors}
```

A module may import only from modules to its right. `text` and `errors` import nothing from the package. No module imports `cli`. No import cycles; checked in `make check` with a small import-graph test. Domain packages (`memory`, `projects`, `knowledge`, `retrieval`, `ingestion`) do not import each other except: `knowledge.notes` → `retrieval.indexer` (index delta), `memory` → `knowledge.relationships` (supersession edges), and all → `text`.

## 3. Modules

| Subsystem | Package | Responsibility | Component |
|---|---|---|---|
| Foundations | `errors`, `config`, `paths`, `text.*` | Errors, typed configuration, path policy, normalisation, language, direction | CMP-CFG, CMP-SEC, CMP-NRM |
| Database | `db.*`, `audit` | Connections, migrations, IDs, audit chain | CMP-DB, CMP-AUD |
| Storage | `storage.*`, `operations.recovery` | Atomic file operations, journal, original store, recovery | CMP-JRN, CMP-STO |
| Workflows | `workflows.*` | Runner, proposals, approvals, policy | CMP-WFL, CMP-PRP |
| Ingestion | `ingestion.*` | Intake, registry, extractors, segmentation, inbox | CMP-ING, CMP-EXT |
| Knowledge | `knowledge.*` | Frontmatter, schemas, rendering, sync, links, entities, relationships, dashboards | CMP-NOT, CMP-GRF |
| Memory | `memory.*` | Model, lifecycle, conflicts, history | CMP-MEM |
| Projects | `projects.*` | Registry, decisions, event replay | CMP-PRJ |
| Retrieval | `retrieval.*` | Indexer, query, search, evidence, evaluation | CMP-RET, CMP-EVL |
| Operations | `operations.*` | Init, doctor, backup, restore, export, scheduler, logging | CMP-OPS |
| Workspace | `workspace.*`, `workspace_template/` | Operating-home files | CMP-CCW |
| CLI | `cli.*` | Parsing, output, command handlers (no logic) | CMP-CLI |

## 4. Interface contracts

```python
# errors
class SecondBrainError(Exception):
    code: ErrorCode            # E_INVALID_INPUT … E_INTERNAL  (CLI-SPECIFICATION §3)
    detail: str                # catalogue value (CLI-SPECIFICATION §5)
    context: Mapping[str, str | int]   # identifiers only, never content

# config / paths
def load_config(home: Path) -> Config: ...                      # raises E_INVALID_INPUT(secret_in_config, schema_violation)
def resolve_in_root(path: Path, root: Path, *, allow_symlink: bool = False) -> Path: ...   # E_FORBIDDEN
def is_forbidden_name(name: str) -> bool: ...

# db / audit
def connect(home: Path, *, readonly: bool = False) -> sqlite3.Connection: ...   # sets pragmas; verifies them
@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[None]: ...                # BEGIN IMMEDIATE … COMMIT / ROLLBACK
def new_id(conn: sqlite3.Connection, prefix: str, object_type: str) -> str: ... # inside caller's transaction
def append(conn: sqlite3.Connection, event: AuditEvent) -> int: ...             # computes prev_hash, event_hash
def verify(conn: sqlite3.Connection) -> ChainReport: ...

# workflows
class Runner:
    def run(self, workflow: WorkflowType, key: str, plan: Callable[[RunContext], RunResult], *, dry_run: bool = False) -> RunResult: ...
def create(conn, proposal: ProposalDraft, actor: Actor) -> Proposal: ...
def validate(conn, proposal_id: str) -> ValidationReport: ...
def approve(conn, proposal_id: str, hash_prefix: str, channel: Channel, approver: str) -> Approval: ...
def apply(ctx: RunContext, proposal_id: str) -> ApplyResult: ...                # requires approval per tier; consumes it
def tier_of(operation: Operation) -> Tier: ...

# storage
class Journal:
    def intent(self, ops: Sequence[FileOp], change_plan: ChangePlan) -> None: ...   # S3
    def apply_files(self) -> None: ...                                              # S4
    def commit(self, apply_db: Callable[[sqlite3.Connection], None]) -> None: ...   # S5
def reconcile(home: Path) -> RecoveryReport: ...
class OriginalStore:
    def put(self, staged: Path, sha256: str) -> Path: ...
    def verify(self, sha256: str) -> bool: ...
    def path_for(self, sha256: str) -> Path: ...

# ingestion
def inspect(path: Path, limits: IntakeLimits) -> IntakeDecision: ...
class SourceRegistry:
    def register(self, source_path: Path, meta: SourceMeta) -> SourceRegistration: ...
    def new_version(self, source_id: str, source_path: Path) -> SourceRegistration: ...
class Extractor(Protocol):
    name: str; version: str; media_types: frozenset[str]
    def extract(self, original: Path) -> Iterable[TextBlock]: ...
def run_bounded(extractor: Extractor, original: Path, limits: ExtractLimits) -> ExtractionOutcome: ...
def segment(blocks: Iterable[TextBlock], cfg: SegmentConfig) -> list[PassageDraft]: ...

# text
NORM_VERSION: Final = "ar-en-1"; STEM_VERSION: Final = "ar-light-1"
def normalise(text: str) -> str: ...
def light_stem(token: str) -> str: ...
def detect_lang(text: str) -> Lang: ...
def direction(text: str) -> Direction: ...
def isolate(text: str) -> str: ...

# knowledge
def read_note(path: Path) -> NoteDoc: ...          # frontmatter mapping + body bytes, lossless
def validate_note(doc: NoteDoc, registry: RegistryView) -> list[Finding]: ...
def sync(ctx: RunContext, *, repair: bool = False, scope: Path | None = None) -> SyncReport: ...
def render_note(note_type: NoteType, fields: Mapping[str, object]) -> str: ...
def project_managed(conn, note_id: str) -> str: ...

# memory
def propose(ctx: RunContext, doc: MemoryProposalDoc, actor: Actor) -> ProposalResult: ...
def transition(ctx: RunContext, memory_id: str, to: MemoryState, reason: str) -> None: ...
def supersede(ctx: RunContext, old_id: str, new_id: str, effective: date) -> str: ...     # returns relationship id
def find(conn, candidate: MemoryCandidate) -> list[Conflict]: ...
def as_of(conn, subject_id: str, when: date) -> list[MemoryView]: ...

# retrieval
def apply_delta(conn, changed: Sequence[str]) -> IndexDelta: ...
def rebuild(ctx: RunContext) -> IndexStats: ...
def search(conn, query: str, *, limit: int = 10, filters: SearchFilters | None = None,
           allow_stale: bool = False, explain: bool = False) -> SearchResult: ...
def resolve(conn, store: OriginalStore, passage_id: str) -> EvidenceRecord: ...
def run_benchmark(conn, bench: Path, split: Split) -> EvalReport: ...

# projects
def replay(conn, project_id: str, as_of: datetime) -> ProjectSnapshot: ...
def status(conn, project_id: str) -> ProjectStatus: ...

# operations
def run_checks(home: Path, *, deep: bool = False) -> DoctorReport: ...
def create(ctx: RunContext, destination: str) -> BackupResult: ...
def restore_test(home: Path, backup_id: str) -> RestoreReport: ...
```

Models are frozen dataclasses with explicit field types; they are defined next to the function that returns them. Example:

```python
@dataclass(frozen=True, slots=True)
class SourceRegistration:
    status: Literal["registered", "duplicate"]
    source_id: str
    source_version_id: str
    sha256: str
    media_type: str
    stored_relpath: str
```

## 5. Pseudocode for the two non-obvious algorithms

```
register(source_path, meta):
  p = resolve_in_root(source_path, allowed_intake_roots)        # E_FORBIDDEN
  d = inspect(p, limits); if not d.accepted: raise E_INVALID_INPUT(d.reason)
  h = sha256(stream p)
  if exists source_versions.sha256 == h: audit(source.duplicate); return duplicate(existing ids)
  runner.run(INGEST, key = "ingest:" + h, plan):
     staged = stage_copy(p); assert sha256(staged) == h          # S2
     note = render_note(source, …)                               # staged too
     journal.intent([place_original(staged → originals/h[:2]/h), write_note(note)], change_plan)   # S3
     journal.apply_files()                                       # S4
     journal.commit(insert objects, sources, source_versions, notes, note_revisions, audit)        # S5
  then extraction as a second run keyed "extract:" + version_id + extractor + version

recovery reconcile(home):
  for run with journal_ops in 'intent' (ordered by seq):
     classify each op by hash(target) ∈ {expected_prev, new, other}, staged present?
     apply the row of the recovery table (DATA-ARCHITECTURE §5); unknown combination → read_only_mode()
  quarantine staging dirs without a run row
```

## 6. Cross-cutting behaviour

- **Transactions.** `BEGIN IMMEDIATE`; one transaction per protocol step (A, B, C); never a transaction held across a file operation.
- **Concurrency.** Writer lock taken by `Runner`; read paths open read-only connections.
- **Errors.** Domain code raises `SecondBrainError`; the CLI maps it to the envelope and exit code; anything else is E_INTERNAL with a traceback in the log (no content).
- **Logging.** `log_event(component, event, **ids)`; values are identifiers, counts, durations, codes. A unit test asserts that no model field named `text`, `statement`, `body`, `excerpt` or `title` is ever passed.
- **Security.** Every path from outside goes through `resolve_in_root`; no `shell=True`, `os.system`, `eval`, `exec`, `pickle`, dynamic import, or network module anywhere in `src/` (static test).
- **Time and IDs** are injected (`Clock`, sequence allocation) so tests are deterministic.

## 7. Configuration

`config/second-brain.toml`, validated at load; unknown keys are errors. Sections and defaults: DEPLOYMENT-SPECIFICATION §5.

## 8. Tests per subsystem

TEST-CASES.md groups tests by the same subsystems; each module's unit and integration tests are named in FILE-BUILD-PLAN.md.

## 9. Extension points

Deliberately three, each versioned: (1) extractors — implement `Extractor`, register by media type; (2) proposal types — a schema, a validator and an applier, added by migration when they need new tables; (3) normaliser and stemmer versions — a new version marks the index stale. Everything else is closed until a requirement asks for it.

## 10. Coding standards

Type hints everywhere, `mypy --strict`; `ruff` with the default rule set plus security rules; functions under about 50 lines; no global state; dataclasses over dictionaries at module boundaries; docstrings state the requirement ID a public function serves; tests named after test-case IDs (`test_ING_002_duplicate_is_idempotent`).
