# High-Level Design

**DOC-HLD** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `HLD.md` of the V6.0 draft (one diagram, no runtime view).

## 1. System context

```mermaid
flowchart TB
  owner([Owner])
  subgraph mac[Owner's Mac — single user account]
    cc[Claude Code<br/>interactive session]
    obs[Obsidian<br/>optional interface]
    term[Terminal]
    ld[launchd<br/>scheduled jobs]
    cli[second-brain CLI<br/>Python, deterministic]
    subgraph home[~/SecondBrain]
      vault[(vault<br/>Markdown)]
      orig[(originals<br/>immutable files)]
      db[(SQLite<br/>registry + FTS5)]
    end
    dev[development repository<br/>code, tests, docs]
  end
  anth[Anthropic API<br/>model inference]
  bkp[(backup destination<br/>outside the home)]
  src[/Source documents<br/>untrusted/]
  owner --> cc & obs & term
  src --> vault
  cc -->|CLI calls| cli
  term --> cli
  ld --> cli
  cli --> vault & orig & db
  obs <--> vault
  cc <-->|session context| anth
  cli --> bkp
```

External parties: Anthropic (receives whatever is in a Claude Code session's context); the backup destination; the publishers of the Python dependencies at install time. There are no other integrations in version 1.

## 2. Design drivers

Arabic-first bilingual content; a single owner on one Mac; public information only; evidence before memory; deterministic code for anything that must be reproducible; nothing added without a measurement.

## 3. Logical architecture

| Layer | Contents | Components |
|---|---|---|
| 1 Interaction | Claude Code session, Obsidian, terminal | — (external) |
| 2 Agent orchestration | Operating `CLAUDE.md`, rules, five skills, permission and sandbox settings | CMP-CCW |
| 3 Application services | CLI commands, workflow runner, proposals, approvals, policy | CMP-CLI, CMP-WFL, CMP-PRP |
| 4 Knowledge management | Ingestion, extraction, notes, memory, entities and relationships, projects and decisions | CMP-ING, CMP-EXT, CMP-NOT, CMP-MEM, CMP-GRF, CMP-PRJ |
| 5 Retrieval | Normalisation, indexing, search, evidence resolution, evaluation | CMP-NRM, CMP-RET, CMP-EVL |
| 6 Persistence | Original store, commit journal, database access, migrations | CMP-STO, CMP-JRN, CMP-DB |
| 7 Security | Path and name policy, audit chain, configuration validation | CMP-SEC, CMP-AUD, CMP-CFG |
| 8 Operations | Init, doctor, backup, restore, export, scheduling, logging | CMP-OPS |

Dependencies point downward only (LLD §2). Layers 3–8 are one Python package, one process per command: a modular monolith.

## 4. Physical architecture: what actually runs

| Process | Started by | Lifetime | Writes |
|---|---|---|---|
| `claude` (Claude Code) in `~/SecondBrain` | owner | interactive session | nothing authoritative; may write `./scratch` |
| `second-brain <command>` | Claude Code Bash tool, owner, or launchd | one command | vault, originals, SQLite, logs, backups — only this process does |
| SQLite | in-process library | — | one file in WAL mode |
| Obsidian | owner | interactive | human notes in the vault |
| launchd agents | macOS | scheduled | start `second-brain backup create`, `doctor`, `doctor --deep` |

No daemon, no server, no listening socket, no background worker, no message queue. "Background workers" in the engineering directive are the launchd-started commands.

## 5. Deployment

One Mac, one user account. Development repository and operating home are separate directories (ADR-014). The CLI is installed as an isolated tool outside both (DEPLOYMENT-SPECIFICATION §3) so that sessions cannot modify it.

## 6. Component interaction

Document ingestion:

```mermaid
sequenceDiagram
  participant O as Owner
  participant C as Claude Code
  participant X as CLI
  participant J as Journal
  participant S as Originals
  participant D as SQLite
  participant V as Vault
  O->>V: drop file in 01-Inbox
  O->>C: "process the inbox"
  C->>X: ingest --inbox --json
  X->>X: lock, recover, intake checks
  X->>J: stage copy + source note, record intent (S2-S3)
  J->>S: rename into originals/aa/sha256
  J->>V: write 02-Sources/SRC-….md
  X->>D: source, version, run, audit (commit point)
  X->>X: extract, segment (bounded)
  X->>D: extraction, passages, index delta
  X-->>C: JSON result (IDs, extraction status)
  C-->>O: report; nothing is verified
```

Knowledge retrieval:

```mermaid
sequenceDiagram
  participant O as Owner
  participant C as Claude Code
  participant X as CLI
  participant D as SQLite
  O->>C: question (Arabic or English)
  loop at most 6 searches
    C->>X: search "…" --json
    X->>D: normalise, MATCH, filter, rank, classify
    X-->>C: hits + outcome class
    C->>C: enough? else reformulate (other language, aliases)
  end
  opt check a citation
    C->>X: evidence show PSG-…
  end
  C-->>O: answer with unit IDs, or "no supporting evidence"
```

Memory update:

```mermaid
sequenceDiagram
  participant C as Claude Code
  participant X as CLI
  participant D as SQLite
  participant V as Vault
  participant O as Owner
  C->>X: memory propose --file p.json
  X->>D: validate, conflict check, create record (proposed), proposal (awaiting_approval)
  X->>V: 00-System/Proposals/PRP-….md
  X-->>C: proposal ID, conflicts
  C-->>O: summary + "review PRP-…"
  O->>V: reads proposal note in Obsidian
  C->>X: proposals approve PRP-… --hash …
  Note over C,O: Claude Code permission prompt (ask rule) — owner accepts or declines
  X->>D: approval, state changes, edges, audit (one transaction)
  X->>V: regenerate digest, remove proposal note
  X->>D: index delta
```

Project-state update: as memory update with proposal type `project_change`; tier 0 changes skip the approval step; every change writes a `project_events` row.

Workflow execution: WORKFLOW-CONTRACTS WF-5 and §8.

Backup and recovery:

```mermaid
sequenceDiagram
  participant L as launchd
  participant X as CLI
  participant D as SQLite
  participant B as Backup destination
  L->>X: backup create
  X->>D: online snapshot (backup API)
  X->>B: snapshot, vault, new originals, config, manifest
  X->>B: re-read and verify hashes
  X->>D: backups row = verified
  Note over X,B: weekly: backup restore-test → restore into temp dir, integrity checks, audit chain, sample originals → restore_tested
```

## 7. Trust boundaries

SECURITY-ARCHITECTURE §2. In one line: source content and vault text are untrusted data; a Claude Code session that has read them is treated as potentially steered; the CLI, the database constraints and the operating-system sandbox are the enforcement points.

## 8. Failure handling

| Failure | Cause | Effect | Detection | Response | Residual risk |
|---|---|---|---|---|---|
| Claude Code or Anthropic unavailable | network, account, outage | No questions answered in natural language; no proposals drafted | obvious | CLI still ingests, searches, validates, backs up (NFR-017) | none to data |
| Session ends mid-task | crash, closed terminal, compaction | Unfinished conversation | — | Nothing durable was in the session; proposals wait in the queue | owner repeats the request |
| Obsidian closed or not installed | — | No visual interface | — | Everything works; notes are plain files | none |
| Obsidian edits a note during a system write | concurrent editing | Possible lost update | hash compare at S4 | Proposal → conflict; owner's text kept | owner re-runs proposal |
| SQLite locked | second writer | Command waits | busy timeout | E_CONFLICT after 5 s; no change | none |
| Process killed mid-commit | power, crash, SIGKILL | Intermediate state | journal intents | Recovery table (DATA-ARCHITECTURE §5) | unknown state → read-only mode until owner acts |
| Source file corrupt or hostile | bad input | Extraction fails or is cut off | extractor error, limits | Source preserved; status failed; quarantine | parser bug inside limits |
| Original modified or missing on disk | disk fault, manual change | Evidence unverifiable | `doctor --deep`, `evidence show` | Restore that file from backup by hash | detection is periodic |
| Index update fails | crash, disk | Stale index | `dirty` flag, unit counts | Search refuses without `--allow-stale`; rebuild | none |
| Database corrupt | disk fault | Writes blocked | `integrity_check` | Restore latest restore-tested backup (RB-03) | loss up to RPO |
| Backup destination absent | disk unplugged | No new backup | DOC-BKP-01 age check | Dashboard and doctor fail; owner reconnects | exposure grows with age |
| Disk full | — | Writes fail | free-space pre-check | E_UNAVAILABLE before any canonical change | none |
| Clock wrong | — | Misordered `recorded_at` | not detected | Sequence numbers, not time, order events and audit | timestamps misleading |
| External service unavailable | — | — | — | None exists in version 1 | — |

## 9. Capacity profiles

Engineering estimates, **unmeasured**, assuming 50 passages per document, 800 characters per passage, a 2 MB average original. Measured in TASK-0801.

| Profile | Documents | Passages | Database (text + index) | Originals | Expectation |
|---|---|---|---|---|---|
| S1 | 100 | 5,000 | ~30 MB | ~200 MB | Trivial |
| S2 | 1,000 | 50,000 | ~300 MB | ~2 GB | Reference profile for NFR targets |
| S3 | 10,000 | 500,000 | ~3 GB | ~20 GB | Supported without structural change; rebuild time to be measured |
| S4 | 100,000 | 5,000,000 | ~30 GB | ~200 GB | Not supported without a measured review (index rebuild, backup strategy, vault file counts) |
| S5 | 1,000,000 | — | — | — | Out of scope for a personal system |

Migration triggers to record when measured: search p95 above target after index tuning; rebuild longer than the owner accepts; backup window longer than a night; Obsidian becoming slow to open the vault.

## 10. Technology decisions

ADR-REGISTER. Stack: Claude Code (only AI platform); Python ≥ 3.12 standard library plus a small pinned set of packages; SQLite with FTS5; Markdown with YAML frontmatter; Obsidian (optional); Git for the code repository and, locally, for vault history; launchd; macOS sandbox through Claude Code's settings. Not used: any other model provider, vector database, graph database, web framework, message broker, container, MCP server, browser automation, Obsidian community plugin.

## 11. Why this architecture and not another

V5.0 required comparing six alternatives. Summary of ADR-011:

| Alternative | Verdict |
|---|---|
| A Claude Code + Markdown | Cannot enforce evidence rules, history or approvals; search degrades with size |
| B Claude Code + Obsidian | Same as A with a better reader |
| C Claude Code + Obsidian + SQLite FTS5 | The baseline retrieval of this design |
| **C+ (chosen)** C plus a provenance registry, memory lifecycle, commit journal, approval gate, backups and evaluation harness | Smallest design that satisfies the MUST requirements |
| D adds hybrid dense retrieval | Deferred behind gate RET-G2 |
| E adds a knowledge graph database | Deferred behind KNOWLEDGE-GRAPH §6 |
| F adds multi-agent workflows | Rejected for version 1: no requirement needs a second agent |
