# File-by-File Build Plan

**DOC-FILE-PLAN** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

No file listed here exists. No placeholder is to be created ahead of its task. Paths are relative to the development repository `ai-second-brain/` (ADR-014). Supersedes the 16-row plan of the V6.0 draft. Generated from the task data.

91 implementation files. Test modules follow the paths in each task's verification command and mirror the source tree under `tests/{unit,integration,data,retrieval,security,recovery}/`.

## Phase 1

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `pyproject.toml` | Package metadata, pinned dependencies, tool configuration | CMP-CLI | entry point `second-brain` | — | FR-SEC-002, NFR-010, NFR-011 | TEST-NFR-010, TEST-NFR-011, TEST-SEC-003 | TASK-0102 |
| `Makefile` | Developer commands: check, test, test-recovery | CMP-CLI | make targets | pyproject.toml | FR-SEC-002, NFR-010, NFR-011 | TEST-NFR-010, TEST-NFR-011, TEST-SEC-003 | TASK-0102 |
| `.gitignore` | Excludes data, virtual environments, local settings | CMP-CLI | — | — | FR-SEC-002, NFR-010, NFR-011 | TEST-NFR-010, TEST-NFR-011, TEST-SEC-003 | TASK-0102 |
| `tests/conftest.py` | Temp-home fixture, crash-point hooks, fixture loader, network-deny marker | CMP-CLI | pytest fixtures | all modules | FR-SEC-002, NFR-010, NFR-011 | TEST-NFR-010, TEST-NFR-011, TEST-SEC-003 | TASK-0102 |
| `src/second_brain/errors.py` | Error classes, stable codes, exit-code mapping, cause and next-step text | CMP-CLI | `SecondBrainError`, `ErrorCode`, `exit_code_for()` | — | FR-OPS-008, FR-SEC-002, NFR-014 | TEST-NFR-013, TEST-OPS-012, TEST-SEC-003 | TASK-0103 |
| `src/second_brain/config.py` | Typed configuration loader with secret-pattern rejection | CMP-CFG | `load_config(home) -> Config` | errors | FR-OPS-008, FR-SEC-002, NFR-014 | TEST-NFR-013, TEST-OPS-012, TEST-SEC-003 | TASK-0103 |
| `src/second_brain/operations/logging.py` | JSON Lines logging without content | CMP-OPS | `configure(home)`, `log_event()` | config | FR-OPS-008, FR-SEC-002, NFR-014 | TEST-NFR-013, TEST-OPS-012, TEST-SEC-003 | TASK-0103 |
| `src/second_brain/paths.py` | Root confinement, symlink policy, forbidden names | CMP-SEC | `resolve_in_root()`, `is_forbidden_name()` | config, errors | FR-SEC-001, FR-SEC-004 | TEST-SEC-001, TEST-SEC-002, TEST-SEC-009 | TASK-0104 |
| `src/second_brain/db/connection.py` | Connection factory, pragmas, transaction helper | CMP-DB | `connect(home, readonly=False)`, `transaction()` | config | FR-OPS-006 | TEST-OPS-009, TEST-OPS-010 | TASK-0105 |
| `src/second_brain/db/migrate.py` | Checksummed forward migrations | CMP-DB | `apply(conn, target=None)`, `current_version()` | connection | FR-OPS-006 | TEST-OPS-009, TEST-OPS-010 | TASK-0105 |
| `src/second_brain/db/ids.py` | Sequential typed ID allocation and objects registration | CMP-DB | `new_id(conn, prefix, object_type) -> str` | connection | FR-OPS-006 | TEST-OPS-009, TEST-OPS-010 | TASK-0105 |
| `src/second_brain/db/migrations/0001_initial.sql` | Schema v1 (DATABASE-SCHEMA.md) | CMP-DB | DDL | — | FR-OPS-006 | TEST-OPS-009, TEST-OPS-010 | TASK-0105 |
| `src/second_brain/audit.py` | Hash-chained audit events | CMP-AUD | `append(conn, event)`, `verify(conn) -> ChainReport` | db | FR-SEC-005, NFR-005 | TEST-SEC-011, TEST-SEC-012 | TASK-0106 |
| `src/second_brain/cli/main.py` | Argument parsing, command dispatch, global options | CMP-CLI | `main(argv) -> int` | all command modules | FR-OPS-004, FR-OPS-009, FR-SEC-006, NFR-004, NFR-009 | TEST-OPS-007, TEST-OPS-013, TEST-OPS-014, TEST-SEC-013 | TASK-0107 |
| `src/second_brain/cli/output.py` | Output envelope, bidi-safe human rendering, untrusted-text delimiters | CMP-CLI | `emit(result, json=False)` | text.bidi, errors | FR-OPS-004, FR-OPS-009, FR-SEC-006, NFR-004, NFR-009 | TEST-OPS-007, TEST-OPS-013, TEST-OPS-014, TEST-SEC-013 | TASK-0107 |
| `src/second_brain/operations/init.py` | Workspace initialisation | CMP-OPS | `init_home(path) -> Manifest` | paths, db, workspace.install | FR-OPS-004, FR-OPS-009, FR-SEC-006, NFR-004, NFR-009 | TEST-OPS-007, TEST-OPS-013, TEST-OPS-014, TEST-SEC-013 | TASK-0107 |
| `src/second_brain/operations/doctor.py` | Health checks and verdict | CMP-OPS | `run_checks(home, deep=False) -> DoctorReport` | all read paths | FR-OPS-004, FR-OPS-009, FR-SEC-006, NFR-004, NFR-009 | TEST-OPS-007, TEST-OPS-013, TEST-OPS-014, TEST-SEC-013 | TASK-0107 |

## Phase 2

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `src/second_brain/workflows/runner.py` | Idempotent workflow runs, writer lock, dry-run | CMP-WFL | `run(workflow, key, plan) -> RunResult` | db, audit, journal | FR-AGT-002, FR-AGT-005 | TEST-AGT-005, TEST-AGT-009, TEST-REC-007 | TASK-0201 |
| `src/second_brain/storage/atomic.py` | Atomic write and replace with full fsync on macOS | CMP-JRN | `stage_bytes()`, `atomic_replace()`, `fsync_dir()` | paths | FR-OPS-005, NFR-002, NFR-018 | TEST-REC-001, TEST-REC-002, TEST-REC-004, TEST-REC-005, TEST-REC-008, TEST-REC-010 | TASK-0202 |
| `src/second_brain/storage/journal.py` | Write-ahead intents for file operations and commit protocol | CMP-JRN | `Journal.intent()`, `.apply()`, `.complete()` | atomic, db | FR-OPS-005, NFR-002, NFR-018 | TEST-REC-001, TEST-REC-002, TEST-REC-004, TEST-REC-005, TEST-REC-008, TEST-REC-010 | TASK-0202 |
| `src/second_brain/operations/recovery.py` | Startup reconciliation by recovery table | CMP-JRN | `reconcile(home) -> RecoveryReport` | journal, db | FR-OPS-005, NFR-002, NFR-018 | TEST-REC-001, TEST-REC-002, TEST-REC-004, TEST-REC-005, TEST-REC-008, TEST-REC-010 | TASK-0202 |
| `src/second_brain/storage/originals.py` | Content-addressed immutable store | CMP-STO | `OriginalStore.put()`, `.verify()`, `.path_for()` | journal | FR-ING-002 | TEST-ING-003, TEST-OPS-008 | TASK-0203 |
| `src/second_brain/ingestion/intake.py` | Media type detection and intake limits | CMP-ING | `inspect(path) -> IntakeDecision` | paths, config | FR-ING-005, FR-SEC-008 | TEST-ING-007, TEST-SEC-008, TEST-SEC-015 | TASK-0204 |
| `src/second_brain/ingestion/registry.py` | Source and version registration, deduplication | CMP-ING | `SourceRegistry.register()`, `.new_version()` | originals, runner | FR-ING-001, FR-ING-004, FR-ING-006 | TEST-ING-001, TEST-ING-002, TEST-ING-006, TEST-ING-008 | TASK-0205 |
| `src/second_brain/cli/cmd_ingest.py` | `ingest`, `sources list\|show`, `extract` | CMP-CLI | command handlers | registry, extract | FR-ING-001, FR-ING-004, FR-ING-006 | TEST-ING-001, TEST-ING-002, TEST-ING-006, TEST-ING-008 | TASK-0205 |
| `src/second_brain/text/lang.py` | Script-ratio language tagging | CMP-NRM | `detect_lang(text) -> Lang` | — | FR-OBS-003 | TEST-OBS-002 | TASK-0206 |
| `src/second_brain/text/bidi.py` | Direction detection, isolate wrapping, override rejection | CMP-NRM | `direction()`, `isolate()`, `has_override()` | — | FR-OBS-003 | TEST-OBS-002 | TASK-0206 |
| `src/second_brain/ingestion/extract/base.py` | Extractor protocol, registry, bounded execution | CMP-EXT | `Extractor`, `run_bounded()` | config | FR-ING-003, FR-ING-007 | TEST-ING-004, TEST-ING-009, TEST-ING-011 | TASK-0207 |
| `src/second_brain/ingestion/extract/text.py` | Plain text extractor | CMP-EXT | `TextExtractor` | base | FR-ING-003, FR-ING-007 | TEST-ING-004, TEST-ING-009, TEST-ING-011 | TASK-0207 |
| `src/second_brain/ingestion/extract/markdown.py` | Markdown extractor (headings, frontmatter aware) | CMP-EXT | `MarkdownExtractor` | base | FR-ING-003, FR-ING-007 | TEST-ING-004, TEST-ING-009, TEST-ING-011 | TASK-0207 |
| `src/second_brain/ingestion/extract/html.py` | HTML extractor using the standard-library parser | CMP-EXT | `HtmlExtractor` | base | FR-ING-003, FR-ING-007 | TEST-ING-004, TEST-ING-009, TEST-ING-011 | TASK-0207 |
| `src/second_brain/ingestion/extract/docx.py` | DOCX extractor | CMP-EXT | `DocxExtractor` | base, python-docx | FR-ING-003, FR-ING-007 | TEST-ING-004, TEST-ING-009, TEST-ING-011 | TASK-0207 |
| `src/second_brain/ingestion/extract/pdf.py` | Text-layer PDF extractor with per-page yield | CMP-EXT | `PdfExtractor` | base, PDF library per ADR-017 | FR-ING-007, FR-ING-009 | TEST-ING-010, TEST-ING-011, TEST-ING-013 | TASK-0208 |
| `src/second_brain/ingestion/segment.py` | Structure-aware segmentation and locator construction | CMP-EXT | `segment(blocks) -> list[Passage]` | lang | FR-ING-003, FR-ING-008 | TEST-ING-005, TEST-ING-012 | TASK-0209 |
| `src/second_brain/ingestion/inbox.py` | Inbox sweep | CMP-ING | `sweep(home, dry_run)` | registry | FR-ING-010 | TEST-ING-014 | TASK-0210 |
| `tests/recovery/test_crash_loop.py` | Randomised crash loop and invariant checker | CMP-JRN | pytest | journal, recovery | NFR-002, NFR-008, NFR-018 | TEST-NFR-008, TEST-REC-010 | TASK-0211 |
| `src/second_brain/operations/backup.py` | Consistent backup with manifest | CMP-OPS | `create()`, `verify()` | db, originals | FR-OPS-002, FR-OPS-003 | TEST-OPS-003, TEST-OPS-004, TEST-OPS-005, TEST-OPS-006 | TASK-0212 |
| `src/second_brain/operations/restore.py` | Restore-test and full restore | CMP-OPS | `restore_test()`, `restore()` | backup, approvals | FR-OPS-002, FR-OPS-003, FR-OPS-010, NFR-006 | TEST-NFR-006, TEST-OPS-003, TEST-OPS-004, TEST-OPS-005, TEST-OPS-006, TEST-OPS-015, TEST-REC-009 | TASK-0212, TASK-0901 |
| `src/second_brain/cli/cmd_backup.py` | `backup`, `restore`, `export`, `schedule` | CMP-CLI | command handlers | operations | FR-OPS-002, FR-OPS-003, FR-OPS-010, NFR-006 | TEST-NFR-006, TEST-OPS-003, TEST-OPS-004, TEST-OPS-005, TEST-OPS-006, TEST-OPS-015, TEST-REC-009 | TASK-0212, TASK-0901 |

## Phase 3

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `src/second_brain/knowledge/frontmatter.py` | Frontmatter read and write preserving unknown keys and body bytes | CMP-NOT | `read_note()`, `write_note()` | PyYAML | FR-KNW-001, NFR-022 | TEST-KNW-001, TEST-KNW-002 | TASK-0301 |
| `src/second_brain/knowledge/schemas.py` | Note schemas v1 and validation rules | CMP-NOT | `validate_note() -> list[Finding]` | frontmatter | FR-KNW-001, NFR-022 | TEST-KNW-001, TEST-KNW-002 | TASK-0301 |
| `src/second_brain/knowledge/render.py` | Template rendering and managed projections | CMP-NOT | `render_note()`, `project_managed()` | schemas, bidi, lang | FR-KNW-003, FR-OBS-001, FR-OBS-003 | TEST-KNW-004, TEST-OBS-001, TEST-OBS-002, TEST-OBS-005 | TASK-0302 |
| `src/second_brain/workspace_template/vault/00-System/Templates/source.md` | Note templates (one per type; this entry stands for the set of eight) | CMP-NOT | templates | — | FR-KNW-003, FR-OBS-001, FR-OBS-003 | TEST-KNW-004, TEST-OBS-001, TEST-OBS-002, TEST-OBS-005 | TASK-0302 |
| `src/second_brain/workspace_template/vault/.obsidian/core-plugins.json` | Minimal Obsidian configuration, core plugins only | CMP-NOT | JSON | — | FR-KNW-003, FR-OBS-001, FR-OBS-003 | TEST-KNW-004, TEST-OBS-001, TEST-OBS-002, TEST-OBS-005 | TASK-0302 |
| `src/second_brain/knowledge/notes.py` | Note registry sync, revisions, drift detection and repair | CMP-NOT | `sync(home, dry_run)`, `repair()` | schemas, journal, indexer | FR-KNW-004, FR-KNW-005 | TEST-KNW-005, TEST-KNW-006, TEST-KNW-007, TEST-REC-006 | TASK-0303 |
| `src/second_brain/cli/cmd_notes.py` | `notes new\|sync`, `validate` | CMP-CLI | command handlers | notes | FR-KNW-004, FR-KNW-005 | TEST-KNW-005, TEST-KNW-006, TEST-KNW-007, TEST-REC-006 | TASK-0303 |
| `src/second_brain/knowledge/links.py` | Wikilink parsing and resolution | CMP-NOT | `check_links()` | frontmatter | FR-KNW-008 | TEST-KNW-012 | TASK-0304 |

## Phase 4

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `src/second_brain/text/normalize.py` | Normaliser ar-en-1 | CMP-NRM | `normalise(text) -> str`, `NORM_VERSION` | — | FR-RET-003 | TEST-RET-004, TEST-RET-005, TEST-RET-006 | TASK-0401 |
| `src/second_brain/text/stem_ar.py` | Arabic light stemmer ar-light-1 | CMP-NRM | `light_stem(token) -> str` | normalize | FR-RET-003 | TEST-RET-004, TEST-RET-005, TEST-RET-006 | TASK-0401 |
| `src/second_brain/retrieval/indexer.py` | Index units, incremental delta, rebuild, stale flag | CMP-RET | `apply_delta()`, `rebuild()`, `status()` | normalize, db | FR-OPS-001, FR-RET-007, NFR-021 | TEST-OPS-001, TEST-OPS-002, TEST-REC-003, TEST-RET-010 | TASK-0402 |
| `src/second_brain/cli/cmd_index.py` | `index status\|rebuild` | CMP-CLI | command handlers | indexer | FR-OPS-001, FR-RET-007, NFR-021 | TEST-OPS-001, TEST-OPS-002, TEST-REC-003, TEST-RET-010 | TASK-0402 |
| `src/second_brain/retrieval/query.py` | Safe FTS5 query construction and ranking | CMP-RET | `build_match()`, `rank()` | normalize | FR-RET-001, FR-RET-004, FR-RET-005, FR-RET-006, NFR-015 | TEST-NFR-015, TEST-RET-001, TEST-RET-002, TEST-RET-007, TEST-RET-008, TEST-RET-009, TEST-RET-011 | TASK-0403 |
| `src/second_brain/retrieval/search.py` | Search service, filters, outcome classification, payload budget, query log | CMP-RET | `search(query, filters, limit) -> SearchResult` | query, indexer | FR-RET-001, FR-RET-004, FR-RET-005, FR-RET-006, NFR-015 | TEST-NFR-015, TEST-RET-001, TEST-RET-002, TEST-RET-007, TEST-RET-008, TEST-RET-009, TEST-RET-011 | TASK-0403 |
| `src/second_brain/cli/cmd_search.py` | `search`, `evidence show` | CMP-CLI | command handlers | search, evidence | FR-RET-001, FR-RET-004, FR-RET-005, FR-RET-006, NFR-015 | TEST-NFR-015, TEST-RET-001, TEST-RET-002, TEST-RET-007, TEST-RET-008, TEST-RET-009, TEST-RET-011 | TASK-0403 |
| `src/second_brain/retrieval/evidence.py` | Locator resolution against stored originals | CMP-RET | `resolve(passage_id) -> EvidenceRecord` | originals | FR-RET-002, FR-RET-009 | TEST-OBS-003, TEST-RET-003 | TASK-0404 |
| `src/second_brain/retrieval/evaluate.py` | Benchmark runner and metrics | CMP-EVL | `run_benchmark()`, metric functions | search | FR-RET-008 | TEST-RET-012 | TASK-0405 |
| `src/second_brain/cli/cmd_eval.py` | `eval run` | CMP-CLI | command handler | evaluate | FR-RET-008 | TEST-RET-012 | TASK-0405 |
| `benchmarks/BENCH-1.jsonl` | Owner-labelled retrieval benchmark | CMP-EVL | schema BENCH-1 | — | NFR-007 | TEST-NFR-007 | TASK-0406 |

## Phase 5

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `src/second_brain/workflows/proposals.py` | Proposal schemas, validation, lifecycle | CMP-PRP | `create()`, `validate()`, `apply()` | db, policy | FR-AGT-003 | TEST-AGT-002, TEST-AGT-006, TEST-AGT-013 | TASK-0501 |
| `src/second_brain/workflows/policy.py` | Tier table and channel rules | CMP-PRP | `tier_of(operation) -> Tier` | — | FR-AGT-003 | TEST-AGT-002, TEST-AGT-006, TEST-AGT-013 | TASK-0501 |
| `src/second_brain/memory/model.py` | Memory dataclasses and proposal schema PRP-MEM-1 | CMP-MEM | `MemoryRecord`, `MemoryRevision` | — | FR-MEM-001, FR-MEM-002, FR-MEM-003, FR-MEM-004, FR-MEM-007, FR-MEM-012 | TEST-MEM-001, TEST-MEM-002, TEST-MEM-003, TEST-MEM-004, TEST-MEM-005, TEST-MEM-007, TEST-MEM-010, TEST-MEM-015 | TASK-0502 |
| `src/second_brain/memory/lifecycle.py` | Transitions, revisions, evidence linking, attestation | CMP-MEM | `transition()`, `revise()`, `supersede()` | proposals, db | FR-MEM-001, FR-MEM-002, FR-MEM-003, FR-MEM-004, FR-MEM-007, FR-MEM-012 | TEST-MEM-001, TEST-MEM-002, TEST-MEM-003, TEST-MEM-004, TEST-MEM-005, TEST-MEM-007, TEST-MEM-010, TEST-MEM-015 | TASK-0502 |
| `src/second_brain/cli/cmd_memory.py` | `memory propose\|show\|list\|attest\|history\|review-queue\|purge` | CMP-CLI | command handlers | memory | FR-MEM-001, FR-MEM-002, FR-MEM-003, FR-MEM-004, FR-MEM-007, FR-MEM-012 | TEST-MEM-001, TEST-MEM-002, TEST-MEM-003, TEST-MEM-004, TEST-MEM-005, TEST-MEM-007, TEST-MEM-010, TEST-MEM-015 | TASK-0502 |
| `src/second_brain/memory/conflicts.py` | Conflict and duplicate detection | CMP-MEM | `find()`, `find_duplicates()` | db | FR-KNW-002, FR-MEM-005, FR-MEM-006, FR-MEM-011 | TEST-KNW-003, TEST-MEM-006, TEST-MEM-008, TEST-MEM-014 | TASK-0503 |
| `src/second_brain/memory/history.py` | As-of queries and freshness queue | CMP-MEM | `as_of()`, `recorded_by()`, `review_queue()` | db | FR-ING-011, FR-MEM-008, FR-MEM-009, FR-MEM-010 | TEST-ING-015, TEST-MEM-009, TEST-MEM-011, TEST-MEM-012, TEST-MEM-013 | TASK-0504 |
| `src/second_brain/cli/cmd_sources.py` | `sources withdraw` | CMP-CLI | command handler | registry, memory | FR-ING-011, FR-MEM-008, FR-MEM-009, FR-MEM-010 | TEST-ING-015, TEST-MEM-009, TEST-MEM-011, TEST-MEM-012, TEST-MEM-013 | TASK-0504 |

## Phase 6

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `src/second_brain/projects/registry.py` | Projects, items, events | CMP-PRJ | `create_project()`, `upsert_item()`, `status()` | db, proposals | FR-PRJ-001, FR-PRJ-002, FR-PRJ-003, FR-PRJ-005 | TEST-PRJ-001, TEST-PRJ-002, TEST-PRJ-003, TEST-PRJ-004, TEST-PRJ-007 | TASK-0601 |
| `src/second_brain/projects/history.py` | Event replay | CMP-PRJ | `replay(project_id, as_of)` | db | FR-PRJ-001, FR-PRJ-002, FR-PRJ-003, FR-PRJ-005 | TEST-PRJ-001, TEST-PRJ-002, TEST-PRJ-003, TEST-PRJ-004, TEST-PRJ-007 | TASK-0601 |
| `src/second_brain/cli/cmd_projects.py` | `projects`, `decisions` | CMP-CLI | command handlers | projects | FR-PRJ-001, FR-PRJ-002, FR-PRJ-003, FR-PRJ-005 | TEST-PRJ-001, TEST-PRJ-002, TEST-PRJ-003, TEST-PRJ-004, TEST-PRJ-007 | TASK-0601 |
| `src/second_brain/projects/decisions.py` | Decision records and supersession | CMP-PRJ | `record()`, `accept()`, `supersede()` | db, proposals | FR-PRJ-004 | TEST-PRJ-005, TEST-PRJ-006 | TASK-0602 |
| `src/second_brain/knowledge/entities.py` | Entity registry, aliases, merge | CMP-GRF | `register()`, `candidates()`, `merge()` | normalize, proposals | FR-KNW-006, FR-KNW-007 | TEST-KNW-008, TEST-KNW-009, TEST-KNW-010, TEST-KNW-011 | TASK-0603 |
| `src/second_brain/knowledge/relationships.py` | Typed relationships | CMP-GRF | `propose_edge()`, `neighbours()` | db, proposals | FR-KNW-006, FR-KNW-007 | TEST-KNW-008, TEST-KNW-009, TEST-KNW-010, TEST-KNW-011 | TASK-0603 |
| `src/second_brain/cli/cmd_graph.py` | `entities`, `relations` | CMP-CLI | command handlers | entities, relationships | FR-KNW-006, FR-KNW-007 | TEST-KNW-008, TEST-KNW-009, TEST-KNW-010, TEST-KNW-011 | TASK-0603 |
| `src/second_brain/knowledge/dashboards.py` | Markdown dashboards | CMP-NOT | `build(home)` | render, db | FR-OBS-002, NFR-016 | TEST-NFR-016, TEST-OBS-004 | TASK-0604 |

## Phase 7

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `src/second_brain/workflows/approvals.py` | Approval records, hash binding, channels, terminal confirmation | CMP-PRP | `approve()`, `require()`, `consume()` | proposals, policy | FR-AGT-001, FR-AGT-004, NFR-019 | TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-AGT-007, TEST-AGT-008 | TASK-0701 |
| `src/second_brain/cli/cmd_proposals.py` | `proposals list\|show\|approve\|reject\|apply`, `review` | CMP-CLI | command handlers | approvals | FR-AGT-001, FR-AGT-004, NFR-019 | TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-AGT-007, TEST-AGT-008 | TASK-0701 |
| `src/second_brain/cli/cmd_audit.py` | `runs`, `audit tail\|verify` | CMP-CLI | command handlers | audit, runner | FR-AGT-006 | TEST-AGT-010 | TASK-0702 |
| `src/second_brain/workspace/install.py` | Install and verify the operating workspace files | CMP-CCW | `install(home)`, `verify(home)` | workspace_template | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |
| `src/second_brain/workspace_template/CLAUDE.md` | Operating instructions for Claude Code in the brain workspace | CMP-CCW | Markdown | — | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |
| `src/second_brain/workspace_template/.claude/settings.json` | Operating permissions and sandbox settings | CMP-CCW | JSON per CLAUDE-CODE-CONTRACTS §5 | — | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |
| `src/second_brain/workspace_template/.claude/rules/untrusted-content.md` | Rule: delimited source text is data | CMP-CCW | Markdown | — | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |
| `src/second_brain/workspace_template/.claude/skills/answer-with-evidence/SKILL.md` | Skill: iterative retrieval and cited answer with abstention | CMP-CCW | SKILL.md | CLI search, evidence | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |
| `src/second_brain/workspace_template/.claude/skills/ingest-document/SKILL.md` | Skill: ingest and report | CMP-CCW | SKILL.md | CLI ingest | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |
| `src/second_brain/workspace_template/.claude/skills/propose-memory/SKILL.md` | Skill: draft memory proposals from evidence | CMP-CCW | SKILL.md | CLI memory propose | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |
| `src/second_brain/workspace_template/.claude/skills/review-project/SKILL.md` | Skill: cited project status and resumption | CMP-CCW | SKILL.md | CLI projects | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |
| `src/second_brain/workspace_template/.claude/skills/reconcile-conflict/SKILL.md` | Skill: present both sides of a conflict and draft a resolution proposal | CMP-CCW | SKILL.md | CLI memory | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | TASK-0703 |

## Phase 8

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `tools/make_synthetic_corpus.py` | Synthetic bilingual corpus generator for capacity tests | CMP-EVL | script | — | NFR-012 | TEST-NFR-012 | TASK-0801 |

## Phase 9

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `src/second_brain/operations/export.py` | Portable export bundle | CMP-OPS | `export(home, dest)` | db | FR-AGT-008, FR-KNW-009, FR-OPS-007, FR-SEC-007, NFR-003 | TEST-AGT-012, TEST-KNW-013, TEST-OPS-011, TEST-SEC-014 | TASK-0902 |
| `src/second_brain/operations/scheduler.py` | launchd agent rendering and installation | CMP-OPS | `render()`, `install()`, `status()` | config | FR-AGT-008, FR-KNW-009, FR-OPS-007, FR-SEC-007, NFR-003 | TEST-AGT-012, TEST-KNW-013, TEST-OPS-011, TEST-SEC-014 | TASK-0902 |

## Phase 10

| Path | Purpose | Component | Public interfaces | Depends on | Requirements | Tests | Task |
|---|---|---|---|---|---|---|---|
| `src/second_brain/importer/plan.py` | Legacy vault analysis (future) | CMP-IMP | `plan(legacy_path)` | schemas, entities | FR-IMP-001, FR-IMP-002, FR-IMP-003 | TEST-IMP-001, TEST-IMP-002, TEST-IMP-003 | TASK-1001 |
| `src/second_brain/importer/commit.py` | Legacy vault import and rollback (future) | CMP-IMP | `commit(plan)`, `rollback(batch)` | registry, notes | FR-IMP-001, FR-IMP-002, FR-IMP-003 | TEST-IMP-001, TEST-IMP-002, TEST-IMP-003 | TASK-1001 |
