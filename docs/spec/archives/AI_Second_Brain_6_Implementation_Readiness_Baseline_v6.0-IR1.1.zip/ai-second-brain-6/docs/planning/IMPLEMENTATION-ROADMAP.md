# Implementation Roadmap and Release Gates

**DOC-ROADMAP** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

Supersedes `IMPLEMENTATION-ROADMAP.md`, `IMPLEMENTATION-ROADMAP-DETAILED.md` and `PRODUCTION-READINESS.md` of the V6.0 draft. **No phase after Phase 0 is authorised.** Tasks are in IMPLEMENTATION-BACKLOG.md.

## 1. Rules

1. One phase at a time; a phase starts only when the previous gate has passed and the owner has said so.
2. Every phase ends with a working, tested increment.
3. Security, integrity and backup concerns are built in from Phase 1; Phase 9 completes them, it does not begin them. Until Phase 9 delivers scheduled backups, the owner copies `~/SecondBrain` manually before each session that ingests real content.
4. Real content is not ingested before the Phase 2 gate; nothing is verified as memory before the Phase 5 gate; Claude Code does not operate the workspace on real content before the Phase 7 security verification.
5. A gate passes on recorded evidence only (TEST-STRATEGY §10).

## 2. Phases

| Phase | Scope | Depends on | Deliverables | Interfaces completed | Security controls in place | Exit gate (all tests listed in the phase's tasks pass, plus) |
|---|---|---|---|---|---|---|
| 0 Specification | This package; owner decisions | — | Approved decision sheet; ADR statuses; updated readiness | — | — | No mandatory blocker in IMPLEMENTATION-READINESS; owner approval |
| 1 Foundation | Environment verification; repository; errors, config, logging; path policy; database and migrations; audit chain; CLI skeleton; `init`, `doctor` | 0 | Installable tool; healthy empty home; verification record V-01..V-15 (those possible before later phases) | `init`, `doctor`, `migrate` | Path policy; forbidden names; audit chain; no network; settings file content reviewed | Verification record exists; any failed V-item has an adopted fallback |
| 2 Source management | Workflow runner; journal and recovery; original store; intake; registry; extractors; segmentation; inbox; backup create, verify and restore-test | 1 | Ingestion of five formats with preserved originals; a restore-tested backup | `ingest`, `sources`, `extract`, `recovery`, `backup` | Intake hardening; crash safety | Randomised crash loop: zero invariant violations; backup of the test home restore-tested, and no owner document ingested before a restore-tested backup exists at the configured destination (GAP-034); Arabic PDF spike recorded and extractor chosen (ADR-017) |
| 3 Knowledge representation | Note schemas; templates; vault skeleton; sync, projection, drift; links | 2 | Valid generated notes; owner edits adopted | `notes`, `validate` | Managed-key projection; bidi rules | Obsidian display test on the Mac (TEST-OBS-005) |
| 4 Retrieval | Normaliser; indexer; search; evidence resolution; evaluation harness; pilot corpus and benchmark | 3 | Cited search in Arabic and English; measured baseline | `index`, `search`, `evidence`, `eval` | Query construction safe against FTS syntax | **Retrieval gate:** holdout results recorded; NFR-007 met or the gap and decision recorded in ADR-005; variant chosen (RET-G1) |
| 5 Memory | Proposals (tier 0); memory lifecycle; conflicts; supersession; history; freshness; archive, purge; source withdrawal | 4 | Governed memory with history | `memory`, `proposals list/show`, `sources withdraw` | Evidence triggers; immutable revisions | All memory integrity tests; no verified record without live evidence (DOC-MEM-01) |
| 6 Projects and decisions | Projects, items, events, replay; decisions; entities and relationships; dashboards | 5 | Project continuity and decision register | `projects`, `decisions`, `entities`, `relations`, `dashboards` | — | As-of reconstruction tests |
| 7 Controlled agentic workflows | Approvals and tiers; run history; operating workspace (CLAUDE.md, rules, skills, settings); security verification; owner acceptance | 6 | Claude Code operating the Second Brain under enforced limits | `proposals approve/reject/apply`, `review`, `runs`, `audit`, `workspace` | Full layered model L1–L5 | Manual security protocol passed on the Mac; journeys J1–J9 accepted by the owner |
| 8 Advanced retrieval evaluation | Capacity measurement; decision under RET-G2 | 4 (may run beside 5–7) | Capacity record; ADR-006 confirmed or an experiment plan | — | — | Either "not justified" recorded with numbers, or an approved experiment plan |
| 9 Reliability and security hardening | Full restore (tier 2); export; scheduling of the backups built in Phase 2; runbooks; restore drill | 7 | Scheduled verified backups; tested restore; portable export | `restore`, `export`, `schedule` | Integration inventory checks | Timed restore drill by the owner; production readiness review |
| 10 Evolution | Legacy vault import; anything else | 9 | Separate proposals | `import` | — | Not part of this baseline; each item needs its own approval and ADR |

## 3. Definition of done for any requirement

Requirement documented and approved; implementation present; its unit, integration and data-integrity tests pass; security requirements touching it pass; documentation and traceability updated; acceptance criteria met; no open critical defect; the change traces to the requirement ID; evidence file recorded. Code existing is not completion.

## 4. Production readiness criteria (checked at the Phase 9 gate)

1. Every MUST requirement has passing tests with recorded evidence.
2. No open critical or high security finding without written owner acceptance.
3. `doctor --deep` passes on the operating home.
4. Retrieval gate result recorded for both languages.
5. Manual security protocol passed on the installed Claude Code version; the version is recorded.
6. A restore drill has been performed by the owner and timed; RPO and RTO approved against the measurement.
7. Scheduled backup and verification have run for seven consecutive days.
8. Export bundle test passed.
9. Runbooks RB-01..RB-06 read through by the owner.
10. Every deviation from this specification is recorded as an approved change.

## 5. After production readiness

A 30-day usage review: how many proposals were approved, rejected and expired; how many searches ended in `no_evidence`; how long the weekly review took; whether the owner actually used it. This decides what, if anything, is worth adding.
