# Implementation Backlog

**DOC-BACKLOG** · v6.0-IR1.1 · 2026-11-10 · Status: PROPOSED (owner approval pending) · Owner: Mohammed Alsaleh

**No task has started. Implementation is not authorised.** Supersedes `ENGINEERING-BACKLOG.md` and `IMPLEMENTATION-BACKLOG-DETAILED.md` of the V6.0 draft, whose `TASK-001..016` identifiers meant different things in the two files; those identifiers are retired (CHG-012). Generated from `docs/specification/data/tasks.json`.

Hierarchy: EPIC → FEATURE (PRD) → USER STORY → ENGINEERING TASK → TEST. Complexity: S about half a day, M one to two days, L three to five days of focused Claude Code sessions with owner review; these are planning estimates, not measurements.

## 1. Epics, features and stories

| Epic | Feature | Story |
|---|---|---|
| EPIC-FND | PRD-015 | **US-01** As the owner I can initialise a healthy workspace with one command and check it at any time. |
| EPIC-ING | PRD-001 | **US-02** As the owner I can drop a document in the inbox and have it registered, preserved and extracted without risk to existing knowledge. |
| EPIC-ING | PRD-001 | **US-03** As the owner I am told when a document is a duplicate, unsupported, unreadable or needs OCR. |
| EPIC-KNW | PRD-005 | **US-04** As the owner I get well-formed notes I can read and edit in Obsidian, in Arabic or English. |
| EPIC-KNW | PRD-006 | **US-05** As the owner I can edit notes freely and the system follows my edits without overwriting them. |
| EPIC-AGT, EPIC-RET | PRD-002 | **US-06** As the owner I can ask a question in Arabic or English and receive passages I can open and check. |
| EPIC-EVL | PRD-019 | **US-07** As the owner I can measure retrieval quality on my own questions before anything more complex is added. |
| EPIC-MEM | PRD-011 | **US-08** As the owner I approve what becomes verified memory and can correct or supersede it without losing history. |
| EPIC-MEM | PRD-011 | **US-09** As the owner I can ask what was held true at an earlier date. |
| EPIC-PRJ | PRD-012 | **US-10** As the owner I can resume a project from recorded state, items and decisions. |
| EPIC-PRJ | PRD-013 | **US-11** As the owner I can record a decision with its alternatives and evidence and later supersede it. |
| EPIC-AGT | PRD-014 | **US-12** As the owner I review a queue of proposed changes with diffs and approve or reject them. |
| EPIC-AGT, EPIC-OPS, EPIC-SEC | PRD-014 | **US-13** As the owner I can see what Claude Code proposed, what ran, and what failed. |
| EPIC-OPS | PRD-015 | **US-14** As the owner I have verified backups and a tested way to restore. |
| — | PRD-017 | **US-15** As an Arabic-first user I see correct direction in notes and terminal output. |
| EPIC-KNW | PRD-016 | **US-16** As the owner I can see entities and typed relationships that are backed by evidence. |
| EPIC-AGT, EPIC-SEC | PRD-003 | **US-17** As the owner I know that neither a document nor Claude Code can change verified knowledge without me. |
| EPIC-IMP | PRD-018 | **US-18** As the owner I can later import an existing vault with a preview and an undo. |

## 2. Tasks by phase

### Phase 0

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0001** Owner approval of the decision sheet | Documentation | EPIC-FND / US-01 | Owner approves or amends D-06..D-17 and the ADR baseline in DECISIONS-FOR-APPROVAL.md. | — | P0 | S | `docs/governance/DECISIONS-FOR-APPROVAL.md` | Signed decision sheet; ADR statuses updated | — | gate review | `manual review` |
| **TASK-0002** Re-run readiness assessment | Documentation | EPIC-FND / US-01 | Update IMPLEMENTATION-READINESS.md after approvals; verdict must name remaining conditions. | TASK-0001 | P0 | S | `docs/governance/IMPLEMENTATION-READINESS.md` | Updated verdict | — | gate review | `python3 tools/spec_lint.py` |

### Phase 1

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0101** Environment verification spike | Infrastructure | EPIC-FND / US-01 | Execute verification items V-01..V-15 on the target Mac and record results in docs/specification/evidence/ENVIRONMENT-VERIFICATION.md. | TASK-0002 | P0 | M | `docs/specification/evidence/ENVIRONMENT-VERIFICATION.md` | Verification record; amended ADRs where results differ | NFR-020 | TEST-OPS-014, TEST-RET-005 | `python3 -I docs/specification/evidence/fts5_arabic_probe.py` |
| **TASK-0102** Repository skeleton and toolchain | Infrastructure | EPIC-FND / US-01 | Create pyproject.toml, lockfile, Makefile targets (check, test), .gitignore, pre-commit secret scan. | TASK-0101 | P0 | S | `pyproject.toml`<br>`Makefile`<br>`.gitignore`<br>`tests/conftest.py` | Installable empty package; `make check` runs | NFR-010, NFR-011, FR-SEC-002 | TEST-NFR-010, TEST-NFR-011, TEST-SEC-003 | `make check` |
| **TASK-0103** Errors, configuration and logging | Application development | EPIC-FND / US-01 | Error catalogue with exit codes; typed config loader; JSON Lines logging without content. | TASK-0102 | P0 | M | `src/second_brain/errors.py`<br>`src/second_brain/config.py`<br>`src/second_brain/operations/logging.py` | Modules with unit tests | FR-OPS-008, FR-SEC-002, NFR-014 | TEST-OPS-012, TEST-SEC-003, TEST-NFR-013 | `pytest tests/unit/test_config.py tests/unit/test_logging.py` |
| **TASK-0104** Path and name policy | Application development | EPIC-SEC / US-17 | Root confinement, symlink rejection, forbidden instruction-file names. | TASK-0103 | P0 | M | `src/second_brain/paths.py` | Module with security tests | FR-SEC-001, FR-SEC-004 | TEST-SEC-001, TEST-SEC-002, TEST-SEC-009 | `pytest tests/security/test_paths.py` |
| **TASK-0105** Database layer and migration 0001 | Data and migration | EPIC-FND / US-01 | Connection factory with pragmas, migration runner with checksums, ID allocation, schema v1. | TASK-0103 | P0 | M | `src/second_brain/db/connection.py`<br>`src/second_brain/db/migrate.py`<br>`src/second_brain/db/ids.py`<br>`src/second_brain/db/migrations/0001_initial.sql` | Database created at schema v1; constraint probe suite | FR-OPS-006 | TEST-OPS-009, TEST-OPS-010 | `pytest tests/integration/test_migrate.py tests/data/test_schema_constraints.py` |
| **TASK-0106** Audit chain | Application development | EPIC-SEC / US-13 | Append and verify hash-chained audit events. | TASK-0105 | P0 | S | `src/second_brain/audit.py` | Module with tamper tests | FR-SEC-005, NFR-005 | TEST-SEC-011, TEST-SEC-012 | `pytest tests/security/test_audit.py` |
| **TASK-0107** CLI skeleton, init and doctor | Application development | EPIC-FND / US-01 | Entry point, output envelope, exit codes, `init`, `doctor` with the Phase 1 check set. | TASK-0104, TASK-0105, TASK-0106 | P0 | M | `src/second_brain/cli/main.py`<br>`src/second_brain/cli/output.py`<br>`src/second_brain/operations/init.py`<br>`src/second_brain/operations/doctor.py` | `second-brain init` and `doctor` working in a temp home | FR-OPS-009, FR-OPS-004, FR-SEC-006, NFR-004, NFR-009 | TEST-OPS-013, TEST-OPS-014, TEST-OPS-007, TEST-SEC-013 | `pytest tests/integration/test_init_doctor.py` |

### Phase 2

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0201** Workflow runner and writer lock | Application development | EPIC-ING / US-02 | Idempotent runs, state persistence, single-writer lock, dry-run plumbing. | TASK-0107 | P0 | L | `src/second_brain/workflows/runner.py` | Runner with idempotency tests | FR-AGT-002, FR-AGT-005 | TEST-AGT-005, TEST-AGT-009, TEST-REC-007 | `pytest tests/integration/test_runner.py` |
| **TASK-0202** Commit journal and startup recovery | Application development | EPIC-ING / US-02 | Stage, intent, atomic replace, database commit, recovery table, quarantine, read-only mode. | TASK-0201 | P0 | L | `src/second_brain/storage/atomic.py`<br>`src/second_brain/storage/journal.py`<br>`src/second_brain/operations/recovery.py` | Journal with crash-point hooks CP1..CP7 | FR-OPS-005, NFR-002, NFR-018 | TEST-REC-001, TEST-REC-002, TEST-REC-004, TEST-REC-005, TEST-REC-008, TEST-REC-010 | `pytest tests/recovery -k 'journal or crash'` |
| **TASK-0203** Original store | Application development | EPIC-ING / US-02 | Content-addressed put/verify with read-only mode and deep verification. | TASK-0202 | P0 | M | `src/second_brain/storage/originals.py` | Store with integrity tests | FR-ING-002 | TEST-ING-003, TEST-OPS-008 | `pytest tests/data/test_originals.py` |
| **TASK-0204** Intake inspection | Application development | EPIC-ING / US-03 | Signature-based type detection, size limit, allowlist, hostile-file limits. | TASK-0104 | P0 | M | `src/second_brain/ingestion/intake.py` | Intake with rejection tests | FR-ING-005, FR-SEC-008 | TEST-ING-007, TEST-SEC-008, TEST-SEC-015 | `pytest tests/security/test_intake.py` |
| **TASK-0205** Source registry and ingest command | Application development | EPIC-ING / US-02 | Register, dedupe, new version; `ingest`, `sources list\|show`. | TASK-0203, TASK-0204 | P0 | M | `src/second_brain/ingestion/registry.py`<br>`src/second_brain/cli/cmd_ingest.py` | Ingest working end to end for plain text | FR-ING-001, FR-ING-004, FR-ING-006 | TEST-ING-001, TEST-ING-002, TEST-ING-006, TEST-ING-008 | `pytest tests/integration/test_ingest.py` |
| **TASK-0206** Text primitives for extraction | Application development | EPIC-ING / US-02 | NFC handling, language and direction detection used by extractors and notes. | TASK-0103 | P0 | S | `src/second_brain/text/lang.py`<br>`src/second_brain/text/bidi.py` | Modules with unit tests | FR-OBS-003 | TEST-OBS-002 | `pytest tests/unit/test_lang_bidi.py` |
| **TASK-0207** Extractors for Markdown, text, HTML, DOCX | Application development | EPIC-ING / US-02 | Extractor protocol, bounded execution, four extractors. | TASK-0205, TASK-0206 | P0 | L | `src/second_brain/ingestion/extract/base.py`<br>`src/second_brain/ingestion/extract/text.py`<br>`src/second_brain/ingestion/extract/markdown.py`<br>`src/second_brain/ingestion/extract/html.py`<br>`src/second_brain/ingestion/extract/docx.py` | Extractions and passages for four formats | FR-ING-003, FR-ING-007 | TEST-ING-004, TEST-ING-009, TEST-ING-011 | `pytest tests/integration/test_extract.py` |
| **TASK-0208** PDF extractor and Arabic quality spike | Application development | EPIC-ING / US-03 | Text-layer PDF extraction; per-page yield; needs_ocr flag; CER measurement on Arabic fixtures; record result in ADR-017. | TASK-0207 | P0 | L | `src/second_brain/ingestion/extract/pdf.py`<br>`docs/specification/evidence/PDF-ARABIC-SPIKE.md` | PDF extraction plus evidence for the extractor decision | FR-ING-007, FR-ING-009 | TEST-ING-010, TEST-ING-011, TEST-ING-013 | `pytest tests/integration/test_extract_pdf.py` |
| **TASK-0209** Segmentation and locators | Application development | EPIC-ING / US-02 | Structure-aware passages, locator schemas, re-extraction and re-anchoring. | TASK-0207 | P0 | M | `src/second_brain/ingestion/segment.py` | Lossless segmentation | FR-ING-008, FR-ING-003 | TEST-ING-012, TEST-ING-005 | `pytest tests/unit/test_segment.py tests/data/test_reextract.py` |
| **TASK-0210** Inbox sweep | Application development | EPIC-ING / US-02 | Per-file runs, processed and rejected folders. | TASK-0208, TASK-0209 | P1 | S | `src/second_brain/ingestion/inbox.py` | `ingest --inbox` | FR-ING-010 | TEST-ING-014 | `pytest tests/integration/test_inbox.py` |
| **TASK-0212** Backup create, verify and restore-test | Application development | EPIC-OPS / US-14 | Online SQLite snapshot, incremental originals by hash, manifest, verification after write, restore-test into a temporary directory. Moved from Phase 9 (GAP-034) so that a tested backup exists before any owner document is ingested. | TASK-0205 | P0 | L | `src/second_brain/operations/backup.py`<br>`src/second_brain/operations/restore.py`<br>`src/second_brain/cli/cmd_backup.py` | `backup create\|list\|verify\|restore-test` | FR-OPS-002, FR-OPS-003 | TEST-OPS-003, TEST-OPS-004, TEST-OPS-005, TEST-OPS-006 | `pytest tests/recovery/test_backup_restore.py` |
| **TASK-0211** Phase 2 gate: integrity, crash suite and restore-tested backup | Testing and gates | EPIC-ING / US-02 | Run ingestion integrity, intake security and randomised crash loop; create a backup of the test home and restore-test it; record evidence; measure throughput. | TASK-0210, TASK-0212 | P0 | M | `tests/recovery/test_crash_loop.py`<br>`docs/specification/evidence/PHASE-2-GATE.md` | Gate evidence record | NFR-002, NFR-008, NFR-018 | TEST-REC-010, TEST-NFR-008 | `pytest tests/recovery tests/security -m phase2` |

### Phase 3

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0301** Frontmatter and note schemas | Application development | EPIC-KNW / US-04 | Round-trip-safe frontmatter parser, schema v1 per note type, rule IDs OBS-R01..R16. | TASK-0211 | P0 | M | `src/second_brain/knowledge/frontmatter.py`<br>`src/second_brain/knowledge/schemas.py` | Validator | FR-KNW-001, NFR-022 | TEST-KNW-001, TEST-KNW-002 | `pytest tests/unit/test_schemas.py` |
| **TASK-0302** Templates, rendering and vault skeleton | Application development | EPIC-KNW / US-04 | Templates for all note types, managed projections, vault skeleton with minimal .obsidian config. | TASK-0301 | P0 | M | `src/second_brain/knowledge/render.py`<br>`src/second_brain/workspace_template/vault/00-System/Templates/source.md`<br>`src/second_brain/workspace_template/vault/.obsidian/core-plugins.json` | Generated notes validate | FR-KNW-003, FR-OBS-001, FR-OBS-003 | TEST-KNW-004, TEST-OBS-001, TEST-OBS-002, TEST-OBS-005 | `pytest tests/integration/test_render.py` |
| **TASK-0303** Note sync, projection and drift | Application development | EPIC-KNW / US-05 | Hash-based sync, revisions, managed-key projection, drift report and repair, source notes on ingest. | TASK-0302 | P0 | L | `src/second_brain/knowledge/notes.py`<br>`src/second_brain/cli/cmd_notes.py` | `notes sync\|new\|validate` | FR-KNW-004, FR-KNW-005 | TEST-KNW-005, TEST-KNW-006, TEST-KNW-007, TEST-REC-006 | `pytest tests/integration/test_notes_sync.py` |
| **TASK-0304** Link integrity | Application development | EPIC-KNW / US-05 | Wikilink parser and resolver; `validate --links`. | TASK-0303 | P1 | S | `src/second_brain/knowledge/links.py` | Link checker | FR-KNW-008 | TEST-KNW-012 | `pytest tests/unit/test_links.py` |

### Phase 4

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0401** Normaliser and light stemmer | Application development | EPIC-RET / US-06 | ar-en-1 normaliser, ar-light-1 stemmer, golden tables. | TASK-0206 | P0 | M | `src/second_brain/text/normalize.py`<br>`src/second_brain/text/stem_ar.py` | Pure functions with golden tests | FR-RET-003 | TEST-RET-004, TEST-RET-006, TEST-RET-005 | `pytest tests/unit/test_normalize.py` |
| **TASK-0402** Indexer | Application development | EPIC-RET / US-06 | Unit construction for passages, note sections, memory; incremental delta; stale flag; rebuild. | TASK-0401, TASK-0303 | P0 | L | `src/second_brain/retrieval/indexer.py`<br>`src/second_brain/cli/cmd_index.py` | `index status\|rebuild` | FR-RET-007, FR-OPS-001, NFR-021 | TEST-OPS-001, TEST-OPS-002, TEST-REC-003, TEST-RET-010 | `pytest tests/integration/test_indexer.py` |
| **TASK-0403** Query building, ranking and search | Application development | EPIC-RET / US-06 | Safe FTS5 query construction, filters, deterministic ranking, payload budget, outcome classes, query log. | TASK-0402 | P0 | L | `src/second_brain/retrieval/query.py`<br>`src/second_brain/retrieval/search.py`<br>`src/second_brain/cli/cmd_search.py` | `search` with JSON contract | FR-RET-001, FR-RET-004, FR-RET-005, FR-RET-006, NFR-015 | TEST-RET-001, TEST-RET-002, TEST-RET-007, TEST-RET-008, TEST-RET-009, TEST-RET-011, TEST-NFR-015 | `pytest tests/retrieval` |
| **TASK-0404** Evidence resolution | Application development | EPIC-RET / US-06 | Locator resolution against originals; `evidence show` with bidi-safe output. | TASK-0403 | P0 | M | `src/second_brain/retrieval/evidence.py` | `evidence show` | FR-RET-002, FR-RET-009 | TEST-RET-003, TEST-OBS-003 | `pytest tests/data/test_evidence_resolve.py` |
| **TASK-0405** Evaluation harness | Application development | EPIC-EVL / US-07 | Benchmark schema BENCH-1, metrics, per-language report, fingerprints. | TASK-0403 | P0 | M | `src/second_brain/retrieval/evaluate.py`<br>`src/second_brain/cli/cmd_eval.py` | `eval run` | FR-RET-008 | TEST-RET-012 | `pytest tests/unit/test_metrics.py` |
| **TASK-0406** Pilot corpus and labelled benchmark | Data and migration | EPIC-EVL / US-07 | Owner supplies the pilot corpus (D-10); Claude drafts candidate questions; owner validates >= 100 with gold passages; development and holdout splits. | TASK-0405 | P0 | L | `benchmarks/BENCH-1.jsonl`<br>`docs/specification/evidence/BENCHMARK-PROTOCOL.md` | Versioned benchmark file | NFR-007 | TEST-NFR-007 | `second-brain eval run benchmarks/BENCH-1.jsonl --split dev` |
| **TASK-0407** Phase 4 gate: retrieval baseline | Testing and gates | EPIC-EVL / US-07 | Run holdout benchmark and latency test; record results; decide tokenizer variant (gate RET-G1) and update ADR-005/006. | TASK-0406, TASK-0404 | P0 | M | `docs/specification/evidence/PHASE-4-GATE.md` | Measured baseline with decision | NFR-001, NFR-007, NFR-017 | TEST-NFR-001, TEST-NFR-007, TEST-NFR-017 | `second-brain eval run benchmarks/BENCH-1.jsonl --split holdout --json` |

### Phase 5

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0501** Proposals and policy (tier 0 path) | Application development | EPIC-AGT / US-12 | Proposal schemas, validation, base versions, expiry, open and per-run limits, duplicate detection, tier table; tier 0 application. | TASK-0407 | P0 | L | `src/second_brain/workflows/proposals.py`<br>`src/second_brain/workflows/policy.py` | Proposal engine | FR-AGT-003 | TEST-AGT-002, TEST-AGT-006, TEST-AGT-013 | `pytest tests/integration/test_proposals.py` |
| **TASK-0502** Memory model and lifecycle | Application development | EPIC-MEM / US-08 | Records, revisions, evidence links, transitions, owner attestation; `memory propose\|show\|list\|attest`. | TASK-0501 | P0 | L | `src/second_brain/memory/model.py`<br>`src/second_brain/memory/lifecycle.py`<br>`src/second_brain/cli/cmd_memory.py` | Memory lifecycle | FR-MEM-001, FR-MEM-002, FR-MEM-003, FR-MEM-004, FR-MEM-007, FR-MEM-012 | TEST-MEM-001, TEST-MEM-002, TEST-MEM-003, TEST-MEM-004, TEST-MEM-005, TEST-MEM-007, TEST-MEM-010, TEST-MEM-015 | `pytest tests/integration/test_memory.py tests/data/test_memory_triggers.py` |
| **TASK-0503** Conflicts, supersession, consolidation | Application development | EPIC-MEM / US-08 | Deterministic conflict detection, supersede transaction, duplicate consolidation, competing-claim relationships. | TASK-0502 | P0 | M | `src/second_brain/memory/conflicts.py` | Conflict and supersession functions | FR-MEM-005, FR-MEM-006, FR-MEM-011, FR-KNW-002 | TEST-MEM-006, TEST-MEM-008, TEST-MEM-014, TEST-KNW-003 | `pytest tests/integration/test_supersession.py` |
| **TASK-0504** History, freshness, archive and purge | Application development | EPIC-MEM / US-09 | As-of queries on both time axes; review queue; archive; purge with exposure report; source withdrawal impact. | TASK-0503 | P0 | M | `src/second_brain/memory/history.py`<br>`src/second_brain/cli/cmd_sources.py` | `memory history\|review-queue\|purge`, `sources withdraw` | FR-MEM-008, FR-MEM-009, FR-MEM-010, FR-ING-011 | TEST-MEM-009, TEST-MEM-011, TEST-MEM-012, TEST-MEM-013, TEST-ING-015 | `pytest tests/integration/test_memory_history.py` |

### Phase 6

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0601** Project registry, items and events | Application development | EPIC-PRJ / US-10 | Projects, items, event log, as-of replay, status report. | TASK-0504 | P1 | L | `src/second_brain/projects/registry.py`<br>`src/second_brain/projects/history.py`<br>`src/second_brain/cli/cmd_projects.py` | `projects new\|show\|item\|status` | FR-PRJ-001, FR-PRJ-002, FR-PRJ-003, FR-PRJ-005 | TEST-PRJ-001, TEST-PRJ-002, TEST-PRJ-003, TEST-PRJ-004, TEST-PRJ-007 | `pytest tests/integration/test_projects.py` |
| **TASK-0602** Decisions | Application development | EPIC-PRJ / US-11 | Decision records, evidence, supersession; `decisions new\|list\|show`. | TASK-0601 | P1 | M | `src/second_brain/projects/decisions.py` | Decision register | FR-PRJ-004 | TEST-PRJ-005, TEST-PRJ-006 | `pytest tests/integration/test_decisions.py` |
| **TASK-0603** Entities and relationships | Application development | EPIC-KNW / US-16 | Entity registry with aliases and merge; typed relationships with evidence. | TASK-0504 | P1 | M | `src/second_brain/knowledge/entities.py`<br>`src/second_brain/knowledge/relationships.py`<br>`src/second_brain/cli/cmd_graph.py` | `entities`, `relations` | FR-KNW-006, FR-KNW-007 | TEST-KNW-008, TEST-KNW-009, TEST-KNW-010, TEST-KNW-011 | `pytest tests/integration/test_graph.py` |
| **TASK-0604** Dashboards | Application development | EPIC-OPS / US-13 | Markdown dashboards generated from the database. | TASK-0602, TASK-0603 | P1 | S | `src/second_brain/knowledge/dashboards.py` | `dashboards build` | FR-OBS-002, NFR-016 | TEST-OBS-004, TEST-NFR-016 | `pytest tests/integration/test_dashboards.py` |

### Phase 7

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0701** Approvals and tiered gate | Application development | EPIC-AGT / US-17 | Approval records, hash binding, single use, channels, terminal confirmation; `proposals approve\|reject\|apply`, `review`. | TASK-0604 | P0 | L | `src/second_brain/workflows/approvals.py`<br>`src/second_brain/cli/cmd_proposals.py` | Tier 1 and tier 2 gate | FR-AGT-001, FR-AGT-004, NFR-019 | TEST-AGT-001, TEST-AGT-003, TEST-AGT-004, TEST-AGT-007, TEST-AGT-008 | `pytest tests/security/test_approvals.py` |
| **TASK-0702** Run history and audit views | Application development | EPIC-AGT / US-13 | `runs`, `proposals list`, `audit tail\|verify`. | TASK-0701 | P0 | S | `src/second_brain/cli/cmd_audit.py` | Listings | FR-AGT-006 | TEST-AGT-010 | `pytest tests/integration/test_history_views.py` |
| **TASK-0703** Claude Code operating workspace | Infrastructure | EPIC-AGT / US-17 | Operating CLAUDE.md, rules, five skills, settings.json; installer and `workspace verify`; output envelope for untrusted text. | TASK-0701 | P0 | L | `src/second_brain/workspace/install.py`<br>`src/second_brain/workspace_template/CLAUDE.md`<br>`src/second_brain/workspace_template/.claude/settings.json`<br>`src/second_brain/workspace_template/.claude/rules/untrusted-content.md`<br>`src/second_brain/workspace_template/.claude/skills/answer-with-evidence/SKILL.md`<br>`src/second_brain/workspace_template/.claude/skills/ingest-document/SKILL.md`<br>`src/second_brain/workspace_template/.claude/skills/propose-memory/SKILL.md`<br>`src/second_brain/workspace_template/.claude/skills/review-project/SKILL.md`<br>`src/second_brain/workspace_template/.claude/skills/reconcile-conflict/SKILL.md` | Installed operating home | FR-AGT-007, FR-SEC-003 | TEST-AGT-011, TEST-SEC-004, TEST-SEC-009 | `pytest tests/security/test_workspace.py` |
| **TASK-0704** Security verification on the target Mac | Testing and gates | EPIC-SEC / US-17 | Run manual and partial security tests in a real Claude Code session; record transcripts and results. | TASK-0703 | P0 | M | `docs/specification/evidence/PHASE-7-SECURITY.md` | Security evidence record | NFR-019 | TEST-SEC-005, TEST-SEC-006, TEST-SEC-007, TEST-SEC-010 | `manual protocol in TEST-STRATEGY §7` |
| **TASK-0705** Owner acceptance of journeys J1-J9 | Testing and gates | EPIC-AGT / US-06 | Owner walks the journeys with the pilot corpus; results recorded. | TASK-0704 | P0 | M | `docs/specification/evidence/PHASE-7-ACCEPTANCE.md` | Acceptance record | NFR-013 | TEST-ACC-001, TEST-ACC-002, TEST-ACC-003, TEST-ACC-004, TEST-ACC-005, TEST-ACC-006, TEST-ACC-007, TEST-ACC-008, TEST-NFR-013 | `manual protocol in TEST-STRATEGY §8` |

### Phase 8

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0801** Capacity measurement at S2 and S3 | Testing and gates | EPIC-EVL / US-07 | Synthetic corpora; record index size, ingest and search timings; update thresholds. | TASK-0407 | P2 | M | `tools/make_synthetic_corpus.py`<br>`docs/specification/evidence/CAPACITY.md` | Capacity record | NFR-012 | TEST-NFR-012 | `second-brain eval run --latency-only` |
| **TASK-0802** Advanced retrieval decision | Documentation | EPIC-EVL / US-07 | Only if gate RET-G2 conditions are met: write an experiment plan and ADR for trigram fallback, embeddings or reranking; otherwise record 'not justified'. | TASK-0801 | P2 | S | `docs/decisions/ADR-REGISTER.md` | ADR-006 updated with measured decision | — | gate review | `python3 tools/spec_lint.py` |

### Phase 9

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-0901** Full restore and recovery objectives | Application development | EPIC-OPS / US-14 | Tier 2 restore over the operating home with the previous home set aside; timed against the recovery objectives. | TASK-0705 | P0 | M | `src/second_brain/operations/restore.py`<br>`src/second_brain/cli/cmd_backup.py` | `restore` | FR-OPS-010, NFR-006 | TEST-OPS-015, TEST-REC-009, TEST-NFR-006 | `pytest tests/recovery/test_backup_restore.py` |
| **TASK-0902** Export and scheduling | Application development | EPIC-OPS / US-14 | Portable export; launchd agents; integration inventory checks. | TASK-0901 | P0 | M | `src/second_brain/operations/export.py`<br>`src/second_brain/operations/scheduler.py` | `export`, `schedule install\|status\|remove` | FR-KNW-009, FR-OPS-007, FR-AGT-008, FR-SEC-007, NFR-003 | TEST-KNW-013, TEST-OPS-011, TEST-AGT-012, TEST-SEC-014 | `pytest tests/integration/test_export_schedule.py` |
| **TASK-0903** Runbooks and restore drill | Operational | EPIC-OPS / US-14 | Finalise runbooks RB-01..RB-06; owner performs a timed restore drill. | TASK-0902 | P0 | S | `docs/operations/DEPLOYMENT-SPECIFICATION.md`<br>`docs/specification/evidence/RESTORE-DRILL.md` | Drill record | — | TEST-ACC-009 | `manual drill per RB-02` |
| **TASK-0904** Production readiness review | Testing and gates | EPIC-OPS / US-14 | Walk the production readiness criteria with linked evidence; owner sign-off. | TASK-0903 | P0 | S | `docs/governance/IMPLEMENTATION-READINESS.md` | Signed readiness record | — | gate review | `manual review` |

### Phase 10

| Task | Type | Epic / Story | Description | Depends on | Pri | Cx | Required files | Expected output | Requirements | Acceptance (tests that must pass) | Verification command |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **TASK-1001** Legacy vault import | Application development | EPIC-IMP / US-18 | Plan, commit and rollback as specified in FR-IMP-001..003, after a separate approval. | TASK-0904 | P3 | L | `src/second_brain/importer/plan.py`<br>`src/second_brain/importer/commit.py` | `import plan\|commit\|rollback` | FR-IMP-001, FR-IMP-002, FR-IMP-003 | TEST-IMP-001, TEST-IMP-002, TEST-IMP-003 | `pytest tests/integration/test_import.py` |

## 3. Tasks by type

| Type | Tasks |
|---|---|
| Documentation | TASK-0001, TASK-0002, TASK-0802 |
| Infrastructure | TASK-0101, TASK-0102, TASK-0703 |
| Application development | TASK-0103, TASK-0104, TASK-0106, TASK-0107, TASK-0201, TASK-0202, TASK-0203, TASK-0204, TASK-0205, TASK-0206, TASK-0207, TASK-0208, TASK-0209, TASK-0210, TASK-0212, TASK-0301, TASK-0302, TASK-0303, TASK-0304, TASK-0401, TASK-0402, TASK-0403, TASK-0404, TASK-0405, TASK-0501, TASK-0502, TASK-0503, TASK-0504, TASK-0601, TASK-0602, TASK-0603, TASK-0604, TASK-0701, TASK-0702, TASK-0901, TASK-0902, TASK-1001 |
| Data and migration | TASK-0105, TASK-0406 |
| Testing and gates | TASK-0211, TASK-0407, TASK-0704, TASK-0705, TASK-0801, TASK-0904 |
| Operational | TASK-0903 |

## 4. Critical path

Longest dependency chain through Phase 9 by complexity weight (S=1, M=2, L=4), total weight 96:

TASK-0001 → TASK-0002 → TASK-0101 → TASK-0102 → TASK-0103 → TASK-0105 → TASK-0106 → TASK-0107 → TASK-0201 → TASK-0202 → TASK-0203 → TASK-0205 → TASK-0207 → TASK-0208 → TASK-0210 → TASK-0211 → TASK-0301 → TASK-0302 → TASK-0303 → TASK-0402 → TASK-0403 → TASK-0405 → TASK-0406 → TASK-0407 → TASK-0501 → TASK-0502 → TASK-0503 → TASK-0504 → TASK-0601 → TASK-0602 → TASK-0604 → TASK-0701 → TASK-0703 → TASK-0704 → TASK-0705 → TASK-0901 → TASK-0902 → TASK-0903 → TASK-0904

Everything on this chain is serial. Work that can proceed beside it once its own dependencies are met: TASK-0204 (intake), TASK-0206 and TASK-0401 (text primitives and normaliser), TASK-0304 (links), TASK-0801 (capacity).

## 5. Retired identifiers

| Retired | Was | Replaced by |
|---|---|---|
| TASK-001..010 (`ENGINEERING-BACKLOG.md`) | Ten epic-level tasks | Phases 1-9 tasks above |
| TASK-001..016 (`IMPLEMENTATION-BACKLOG-DETAILED.md`) | One task per requirement, generated mechanically | Tasks carrying the same requirement IDs in column 'Requirements' |
| T-001..T-020 (`TEST-STRATEGY.md`) | Scenario labels | TEST-* cases; mapping in TEST-STRATEGY §9 |
