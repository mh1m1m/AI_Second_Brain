#!/usr/bin/env python3
"""Cross-document consistency checker for the AI Second Brain 6.0 specification package.
Specification tooling (standard library only). It is not application code and reads only this repository.
Usage: python3 -I tools/spec_lint.py <repository root>      -> writes docs/governance/QUALITY-REPORT.json, exit 1 on any failed check."""
import json, os, re, sys, sqlite3, collections, datetime

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else ".")
D = os.path.join(ROOT, "docs")
def load(name): return json.load(open(os.path.join(D, "specification", "data", name), encoding="utf-8"))
def L(s): return [x.strip() for x in s.split(";") if x.strip()]

reqs = load("requirements.json"); FR, NFR = reqs["functional"], reqs["non_functional"]
tests, tasks, cat = load("tests.json"), load("tasks.json"), load("catalogue.json")
REQ = {r["id"]: r for r in FR + NFR}; TST = {t["id"]: t for t in tests}; TSK = {t["id"]: t for t in tasks}

MANDATED = """specification/BASELINE-INVENTORY.md specification/GAP-REGISTER.md specification/CHANGE-REGISTER.md
requirements/BRD.md requirements/PRD.md requirements/SRS.md requirements/TRACEABILITY-MATRIX.md
architecture/HLD.md architecture/LLD.md architecture/DATA-ARCHITECTURE.md architecture/DATABASE-SCHEMA.md
architecture/OBSIDIAN-SCHEMAS.md architecture/MEMORY-ARCHITECTURE.md architecture/RETRIEVAL-ARCHITECTURE.md
architecture/KNOWLEDGE-GRAPH.md architecture/AGENTIC-ARCHITECTURE.md architecture/WORKFLOW-CONTRACTS.md
engineering/CLAUDE-CODE-CONTRACTS.md engineering/CLI-SPECIFICATION.md security/SECURITY-ARCHITECTURE.md
operations/DEPLOYMENT-SPECIFICATION.md testing/TEST-STRATEGY.md testing/TEST-CASES.md
planning/IMPLEMENTATION-BACKLOG.md planning/IMPLEMENTATION-ROADMAP.md planning/FILE-BUILD-PLAN.md
decisions/ADR-REGISTER.md governance/IMPLEMENTATION-READINESS.md governance/ENGINEERING-HANDOFF.md
governance/DECISIONS-FOR-APPROVAL.md governance/TARGETED-CORRECTIONS-REGISTER.md governance/PRE-IMPLEMENTATION-READINESS-CERTIFICATE.md
decisions/ADR-COMPLETENESS-REPORT.md requirements/REQUIREMENTS-TRACEABILITY-REPORT.md security/SECURITY-ASSURANCE-REPORT.md
specification/SPECIFICATION-CHANGE-MANIFEST.md""".split()

docs = {}
for base, _, files in os.walk(ROOT):
    if os.sep + "_baseline" in base or os.sep + ".git" in base: continue
    for f in files:
        if f.endswith(".md"):
            p = os.path.join(base, f); docs[os.path.relpath(p, ROOT)] = open(p, encoding="utf-8").read()

def defined(pattern, text): return set(re.findall(pattern, text, re.M))
known = {
 "FR": {r["id"] for r in FR}, "NFR": {r["id"] for r in NFR}, "TEST": set(TST), "TASK": set(TSK),
 "CMP": set(cat["components"]), "PRD": {p[0] for p in cat["features"]}, "BRD": {b[0] for b in cat["business_requirements"]},
 "BO": set(cat["objectives"]), "US": {s[0] for s in cat["stories"]},
 "ADR": defined(r"^### (ADR-\d{3}) ", docs.get("docs/decisions/ADR-REGISTER.md", "")),
 "D": defined(r"^\| (D-\d{2}) \|", docs.get("docs/governance/DECISIONS-FOR-APPROVAL.md", "")),
 "V": defined(r"^\| (V-\d{2}) \|", docs.get("docs/security/SECURITY-ARCHITECTURE.md", "")),
 "GAP": defined(r"^\| (GAP-\d{3}) \|", docs.get("docs/specification/GAP-REGISTER.md", "")),
 "RT": defined(r"^\| (RT-[A-Z]\d{2}) \|", docs.get("docs/governance/ADVERSARIAL-REVIEW.md", "")),
 "CHG": defined(r"^\| (CHG-\d{3}) \|", docs.get("docs/specification/CHANGE-REGISTER.md", "")),
}
PAT = {
 "FR": r"(?<![A-Za-z0-9-])(FR-[A-Z]{3}-)(\d{3})((?:\.\.\d{3})?)", "NFR": r"(?<![A-Za-z0-9-])(NFR-)(\d{3})((?:\.\.\d{3})?)",
 "TEST": r"(?<![A-Za-z0-9-])(TEST-[A-Z]{3}-)(\d{3})((?:\.\.\d{3})?)", "TASK": r"(?<![A-Za-z0-9-])(TASK-)(\d{4})((?:\.\.\d{4})?)(?!\d)",
 "PRD": r"(?<![A-Za-z0-9-])(PRD-)(\d{3})((?:\.\.\d{3})?)", "BRD": r"(?<![A-Za-z0-9-])(BRD-)(\d{3})((?:\.\.\d{3})?)",
 "BO": r"(?<![A-Za-z0-9-])(BO-)(\d{2})()", "US": r"(?<![A-Za-z0-9-])(US-)(\d{2})()",
 "ADR": r"(?<![A-Za-z0-9-])(ADR-)(\d{3})()", "D": r"(?<![A-Za-z0-9-])(D-)(\d{2})()(?![0-9])", "V": r"(?<![A-Za-z0-9-])(V-)(\d{2})()(?![0-9])",
 "GAP": r"(?<![A-Za-z0-9-])(GAP-)(\d{3})((?:\.\.\d{3})?)", "RT": r"(?<![A-Za-z0-9-])(RT-[A-Z])(\d{2})()", "CHG": r"(?<![A-Za-z0-9-])(CHG-)(\d{3})()",
}
dangling = []
for rel, text in docs.items():
    for kind, pat in PAT.items():
        for m in re.finditer(pat, text):
            pre, a, rng = m.group(1), m.group(2), m.group(3)
            nums = range(int(a), int(rng[2:]) + 1) if rng else [int(a)]
            for n in nums:
                ident = pre + str(n).zfill(len(a))
                if ident not in known[kind]:
                    if rng and kind in ("FR", "TEST", "NFR", "GAP", "PRD", "BRD", "TASK") and ident not in known[kind] and n != int(a) and n != int(rng[2:]):
                        continue      # sparse range: only endpoints must exist
                    dangling.append({"file": rel, "id": ident})
CMPREF = [{"file": rel, "id": c} for rel, t in docs.items() for c in set(re.findall(r"(?<![A-Za-z0-9-])(CMP-[A-Z]{3})\b", t)) if c not in known["CMP"]]

test_reqs = collections.defaultdict(set); req_tasks = collections.defaultdict(set); test_tasks = collections.defaultdict(set); data_err = []
for r in FR + NFR:
    for t in L(r["tests"]):
        (test_reqs[t].add(r["id"]) if t in TST else data_err.append(f"{r['id']} -> unknown {t}"))
for k in tasks:
    for r in L(k["reqs"]): (req_tasks[r].add(k["id"]) if r in REQ else data_err.append(f"{k['id']} -> unknown {r}"))
    for t in L(k["tests"]): (test_tasks[t].add(k["id"]) if t in TST else data_err.append(f"{k['id']} -> unknown {t}"))
    for d in L(k["deps"]):
        if d not in TSK: data_err.append(f"{k['id']} depends on unknown {d}")
ids_all = [r["id"] for r in FR + NFR] + list(TST) + list(TSK)
structured = [r["id"] for r in FR if not all(r.get(f) for f in ("title", "desc", "why", "prio", "exc", "tests", "acc", "cmp", "iface", "out"))]
phase_order = [f"{k['id']} (phase {k['phase']}) depends on {d} (phase {TSK[d]['phase']})" for k in tasks for d in L(k["deps"]) if d in TSK and TSK[d]["phase"] > k["phase"]]

ddl_ok, ddl_msg = False, ""
try:
    sql = open(os.path.join(D, "specification", "evidence", "schema_v1.sql"), encoding="utf-8").read()
    c = sqlite3.connect(":memory:"); c.execute("PRAGMA foreign_keys=ON"); c.executescript(sql)
    ddl_ok = c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"; ddl_msg = f"SQLite {sqlite3.sqlite_version}"
    doc_sql = re.search(r"## 6\. DDL\n\n```sql\n(.*?)\n```", docs["docs/architecture/DATABASE-SCHEMA.md"], re.S).group(1)
    ddl_same = doc_sql.strip() == sql.strip()
except Exception as e:
    ddl_msg = repr(e); ddl_same = False
impl = [p for p in ("src", "tests") if os.path.exists(os.path.join(ROOT, p))]

# ---- checks added in v6.0-IR1.1 (corrections C-04, C-05, C-09 to C-11, C-13, C-16, C-28)
import hashlib
VERSION = "v6.0-IR1.1"
adr_doc = docs.get("docs/decisions/ADR-REGISTER.md", ""); dec_doc = docs.get("docs/governance/DECISIONS-FOR-APPROVAL.md", "")
adr_secs = {x[4:11]: x for x in re.split(r"(?m)^(?=### ADR-\d{3} )", adr_doc)[1:]}
ADR_FIELDS = ["Context", "Decision", "Alternatives", "Consequences", "Evidence", "Reversal", "Depends on", "Acceptance"]
adr_incomplete = [f"{k}: {f}" for k, x in adr_secs.items() for f in ADR_FIELDS if f"- **{f}.**" not in x]
def _deps(x):
    m = re.search(r"- \*\*Depends on\.\*\* (.*)", x); t = re.sub(r"\(.*?\)", "", m.group(1)) if m else ""; out = set()
    for a, b in re.findall(r"ADR-(\d{3})(?: to ADR-(\d{3}))?", t): out |= {"ADR-%03d" % n for n in range(int(a), int(b or a) + 1)}
    return out
_g = {k: _deps(x) for k, x in adr_secs.items()}
def _cycle():
    st = {}
    def v(n):
        if st.get(n) == 1: return [n]
        if st.get(n) == 2: return None
        st[n] = 1
        for m in _g.get(n, ()):
            r = v(m)
            if r: return [n] + r
        st[n] = 2
    for n in _g:
        r = v(n)
        if r: return r
    return []
approved = []
if not re.search(r"Status: PROPOSED", adr_doc.split("\n")[2] if adr_doc else ""): approved.append("ADR-REGISTER header is not PROPOSED")
approved += [k for k, x in adr_secs.items() if re.search(r"\*\*Status\.\*\* *(APPROVED|ACCEPTED)", x)]
sec_g = dec_doc.split("## G. Owner approval record")[1].split("\n## ")[0] if "## G. Owner approval record" in dec_doc else ""
g_rows = [l for l in sec_g.split("\n") if l.startswith("| ") and not l.startswith("| Item") and not l.startswith("|---")]
filled = [l[:60] for l in g_rows if any(c.strip() for c in l.strip().strip("|").split("|")[1:])]
if not g_rows: filled.append("approval record not found")
DEC_FIELDS = ["question", "recommendation", "alternatives", "evidence", "rationale", "security", "data", "complexity", "dependencies", "acceptance", "owner action", "status"]
dec_gaps = []
for n in range(6, 21):
    d = "D-%02d" % n
    if not re.search(r"(?m)^\| %s \|" % d, dec_doc): dec_gaps.append(d + ": no summary row")
    m = re.search(r"(?ms)^#### %s .*?(?=^#### |^## )" % d, dec_doc)
    if not m: dec_gaps.append(d + ": no detail block"); continue
    names = " ".join(re.findall(r"- \*\*(.*?)\*\*", m.group(0))).lower()
    dec_gaps += [f"{d}: {f}" for f in DEC_FIELDS if f not in names]
    if not any(l.startswith("| " + d + " ") for l in g_rows): dec_gaps.append(d + ": no approval row")
adr_rows = [f"{k}: {n} matrix rows, approval row {'yes' if any(l.startswith('| ' + k + ' ') for l in g_rows) else 'no'}" for k in adr_secs
            for n in [len(re.findall(r"(?m)^\| %s \|" % k, dec_doc))] if n != 2 or not any(l.startswith("| " + k + " ") for l in g_rows)]
if len(adr_secs) != 20: adr_rows.append(f"{len(adr_secs)} ADR records, expected 20")
versions = [rel for rel, t in docs.items() if re.search(r"^\*\*DOC-", t, re.M) and not re.search(r"^\*\*DOC-[A-Z0-9-]+\*\* · " + re.escape(VERSION) + " ·", t, re.M)]
try:
    rmap = load("requirement-decisions.json")
    map_bad = [r for r in REQ if not rmap.get(r, {}).get("adrs")] + [f"{r}: {x}" for r, m in rmap.items() for x in m["adrs"] if x not in adr_secs] + \
              [f"{r}: {x}" for r, m in rmap.items() for x in m["decisions"] if x not in known["D"]] + [r for r in rmap if r not in REQ]
except Exception as e:
    map_bad = [repr(e)]
snap_bad = []
for man, base in (("docs/_baseline/SNAPSHOT-MANIFEST.md", os.path.join(D, "_baseline")), ("docs/_baseline/v6.0-IR1-decision-register/MANIFEST.md", ROOT)):
    try:
        for path, h in re.findall(r"^\| `([^`]+)` \| *\d+ *\| `([0-9a-f]{64})` \|", open(os.path.join(ROOT, man), encoding="utf-8").read(), re.M):
            f = os.path.join(base, path)
            if not os.path.exists(f) or hashlib.sha256(open(f, "rb").read()).hexdigest() != h: snap_bad.append(path)
    except Exception as e:
        snap_bad.append(man + ": " + repr(e))

checks = [
 ("mandated documents present", [m for m in MANDATED if "docs/" + m not in docs]),
 ("identifiers referenced in documents exist", dangling + CMPREF),
 ("data references resolve", data_err),
 ("no duplicate identifiers", [i for i, n in collections.Counter(ids_all).items() if n > 1]),
 ("every requirement has a test", [r["id"] for r in FR + NFR if not L(r["tests"])]),
 ("every test maps to a requirement", [t for t in TST if not test_reqs[t]]),
 ("every MUST requirement has a task", [r["id"] for r in FR + NFR if r["prio"] == "MUST" and not req_tasks[r["id"]]]),
 ("every test is scheduled in a task", [t for t in TST if not test_tasks[t]]),
 ("every component has a requirement", sorted(set(cat["components"]) - {r["cmp"] for r in FR + NFR})),
 ("functional requirements are fully structured", structured),
 ("no task depends on a later phase", phase_order),
 ("schema DDL executes and passes integrity_check", [] if ddl_ok else [ddl_msg]),
 ("DDL in DATABASE-SCHEMA.md equals evidence/schema_v1.sql", [] if ddl_same else ["differs"]),
 ("no implementation directories exist (specification-only mode)", impl),
 ("every ADR record has all eight fields", adr_incomplete),
 ("ADR dependencies form no cycle", _cycle()),
 ("no ADR is marked approved", approved),
 ("owner approval record is empty", filled),
 ("decisions D-06 to D-20 each have summary row, twelve fields and approval row", dec_gaps),
 ("ADR-001 to ADR-020 each appear in both matrix tables and the approval record", adr_rows),
 ("every current document carries the baseline version label", versions),
 ("every requirement maps to an existing ADR; mapped decisions exist", map_bad),
 ("baseline snapshots match their recorded hashes", snap_bad),
]
report = {
 "generated_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
 "baseline": VERSION, "mode": "SPECIFICATION-ONLY",
 "counts": {"documents_checked": len(docs), "functional_requirements": len(FR), "non_functional_requirements": len(NFR),
            "must_requirements": sum(r["prio"] == "MUST" for r in FR + NFR), "test_cases": len(TST),
            "adversarial_test_cases": sum(bool(t["adv"]) for t in tests),
            "tests_by_automation": dict(collections.Counter(t["auto"] for t in tests)),
            "tasks": len(TSK), "components": len(cat["components"]), "adrs": len(known["ADR"]), "decisions": len(known["D"]),
            "verification_items": len(known["V"]), "gaps": len(known["GAP"]), "review_findings": len(known["RT"])},
 "automated_checks": [{"check": n, "result": "pass" if not bad else "fail", "failures": bad[:50]} for n, bad in checks],
 "executed_evidence": {"ddl": ddl_msg, "ddl_probes": "docs/specification/evidence/ddl_check.output.json", "tokenizer_probe": "docs/specification/evidence/fts5_arabic_probe.output.json"},
 "manual_assessments": [
   {"item": "Requirement wording unambiguous and atomic", "result": "reviewed by the author; three external reviews covered IR1 or the earlier draft; IR1.1 not independently reviewed"},
   {"item": "Architecture consistency across documents beyond identifiers", "result": "author cross-check (ADVERSARIAL-REVIEW section 1)"},
   {"item": "Workflow transitions agree with database constraints", "result": "author cross-check; trigger T6 probed"},
   {"item": "Security controls agree with Claude Code documentation", "result": "documentation read 2026-11-10; not run on the target machine"},
   {"item": "Operational procedures executable", "result": "not executed"},
   {"item": "Implementation sequencing", "result": "dependency check automated; estimates unvalidated"}],
 "not_executed": {"application_tests": 0, "benchmarks": 0, "installations": 0},
 "readiness": "NOT READY FOR IMPLEMENTATION (decisions unapproved; dependencies unverified); ready for owner review",
}
report["automated_checks_passed"] = sum(c["result"] == "pass" for c in report["automated_checks"])
report["automated_checks_total"] = len(report["automated_checks"])
json.dump(report, open(os.path.join(D, "governance", "QUALITY-REPORT.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for c in report["automated_checks"]:
    print(("PASS " if c["result"] == "pass" else "FAIL ") + c["check"] + ("" if c["result"] == "pass" else "  -> " + json.dumps(c["failures"][:12], ensure_ascii=False)))
print(json.dumps(report["counts"]))
sys.exit(0 if report["automated_checks_passed"] == report["automated_checks_total"] else 1)
